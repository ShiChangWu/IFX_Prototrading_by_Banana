PROTO-TRADING - SMART TRADING FOR EVERYONE
Built for iFX Hack Hong Kong 2026
Default language: English

1. OPEN THE PORTABLE DEMO
Extract the entire ZIP before opening any file. Keep its folder structure.
Double-click START-HERE.html, then choose Open website.
web/index.html opens the full website; web/workspace.html opens the app directly.
No installation, API key or account is needed for the portable demo.
The optional tour explains the features and always provides a Skip button.
Read KNOWN-LIMITATIONS.html or KNOWN-LIMITATIONS.txt before presenting.
These explain which services need setup, what each missing connection prevents,
and which features are not implemented. The app also has a Prototype status panel.

2. ABOUT YOU, YOUR STRATEGY AND YOUR STOCKS
Complete About you, then click Show my starting plan.
Read the matched strategy's plain-language description and choose stocks to follow.
Search for another ticker or company name and check up to eight stocks.
The connected app can search its stock directory; portable search uses packaged assets.
Save stocks to follow, or keep the selection for the current portable visit.

See allocation, risk and research details follows the same checked stocks.
Existing template weights remain; newly added stocks start at 0% as watch-only ideas.
Unchecking a stock leaves its former amount in cash. A checkbox is not a purchase.
Open Adjust simulated percentages to assign your own hypothetical weights.
Combined stock weights may not exceed 100%; the remainder stays in cash.
Amounts and the stress illustration change with the selected stocks and weights.
These custom amounts have not been re-approved by AI. Recorded trades are separate.
Edited percentages last only for the current page session. Saving the watchlist stores
stocks, reminder settings and trade records, not your edited allocation percentages.
Original AI match & daily observations preserves the original questionnaire allocation
and its dated daily observations, explicitly separate from your custom selection.

3. EXPLORE STRATEGIES AND HYPOTHETICAL PRICES
Open Explore this strategy & backtests or the Explore strategies tab.
Find an approach you understand uses the stocks you already selected.
Each approach shows a short introduction and a 0-100 learning-fit score.
Defensive: keep a larger reserve and begin with smaller investments.
Balanced: spread money across assets and review the mix.
Moving averages: follow a trend after shorter and longer averages cross.
Bollinger Bands: watch a sharp drop recover toward its recent range.
RSI: check whether recent selling pressure is easing.
Price Action: inspect reactions around previous turning points.
ATR: use typical daily movement to understand exit-review distances.
Wyckoff: study failed breakdowns with volume; only a daily proxy is tested.
ICT: learn about intraday highs, lows and gaps; no verified scanner.
Order Flow: learn from trades and orders; required tick/depth data is absent.
The team rubric uses asset type (45%), beginner simplicity (30%) and verified
saved-data coverage (25%), counting each selected stock equally. Click an
approach for individual stock scores, or How scores work for the explanation.
Scores are not returns, win rates or a personal suitability assessment.
Unknown asset types and missing history lower the score. ICT and Order Flow
are learning-only and capped at 20; ATR is a risk tool, not an entry strategy.
Changing or searching for a strategy preserves that stock selection.
Choose a selected stock and explore that strategy's own conditions.
Moving averages use a 20/100-day crossover; RSI uses recovery above 30 or an
exit review at 70; Bollinger uses a recovery into the band or return to the mean.
ATR illustrates a trailing level at the highest close minus 1.5 times ATR.
Price Action requires a confirmed pin bar or retest; Wyckoff requires a spring
and volume confirmation. Defensive and balanced approaches use scheduled weight
reviews. ICT and Order Flow remain learning-only because required data is absent.
Example inputs are hypothetical; dated historical indicators remain separate.
An example event is not an observed signal, forecast, enabled alert or order.
Recorded holdings change the explanation: an exit cannot sell shares not owned.
A single future price cannot establish a future RSI or moving-average crossover.

4. RUN A HISTORICAL RULE TEST
In the strategy lab, select the stock, start/end dates, test amount and trading fee.
The fee is charged on each side: 0.10% means $1 per $1,000 bought and another fee sold.
Click Run this rule test to recalculate the chart, metrics and trade record locally.
Use Data source, assumptions & every trade to inspect dates, fills and limitations.
The test compares one stock under the chosen rule with holding that same stock.
It does not backtest your whole edited allocation. Past returns are not forecasts.
Packaged Yahoo Finance history ends on the date shown; missing history stays unavailable.
Indicators need earlier observations. A recent IPO may lack enough warm-up data.
ICT and Order Flow do not receive fabricated tests where the required data is absent.

5. READ OR UPLOAD RESEARCH
Open Research and click Open prepared report for the saved report popup.
It opens immediately, with no new analysis or API key. Close or Escape returns
to the app. A normal link opens the document if popups are unsupported.
This is the reviewed $10,000 balanced example from 4 Oct 2026, 15:27 HKT,
researching VTI, IEF and SGOV. Original inputs, date and partial status stay visible.
The recorded generation commit is unknown. The packaged TradingAgents source
has a separate pinned revision; that pin does not prove the saved run's revision.
Generate and upload controls are under More options. They remain available.
Check the mode banner: the file-based website is Offline backup and cannot call AI.
For a fresh answer, start the connected app and click Show my starting plan.
The quick DeepSeek explanation appears above the stocks, with a received time.
Refresh AI match requests a new answer; a restored answer is labelled as saved.
For a new report, open More options in Research and inspect Research inputs.
It shows one to eight selected US stocks/ETFs, their exact hypothetical weights,
remaining cash and your confirmed matched approach. Use uppercase ticker codes
of at most ten characters. The backend verifies their available directory identity.
Every checked stock is researched, including 0% watch-only ideas. Those ideas do
not receive invested money and do not affect the portfolio-history calculation.
Click Generate deep research. The accepted job freezes its displayed input snapshot;
later checkbox, weight or questionnaire edits cannot alter the running job.
Exploring a different strategy does not change the matched approach used here.
New custom weights are user assumptions, not an optimized or AI-approved allocation.
Watch the job progress. A measured three-asset run took 7 minutes 23 seconds;
duration varies and more stocks take longer, so prepare research before presenting.
Open generated report opens the actual completed report from that job in a popup,
including its accepted inputs. It does not substitute the prepared example.
Close or Escape returns to the app; the result also remains available inline.
Missing evidence can leave a report partial; unavailable content is not invented.
Open Research for the saved TradingAgents example or upload original Markdown/TXT.
The supplied report retains its original questionnaire, stocks, date and partial status.
Its missing evidence and unavailable horizon summaries are visible; this is saved research.
Changing stock checkboxes or weights does not rewrite saved or uploaded research.
New selected-stock jobs explicitly use the submitted selection and weights.
Legacy questionnaire-only requests keep their original top-three research scope.
If data or instrument classification is unavailable, the report preserves that gap.
Report graphics and dated company facts help explain the report; inspect their sources.
An optional return-scenario calculator uses your assumptions, not a validated forecast.
Browser storage may be restricted for local files. Follow the displayed storage status.

6. START THE CONNECTED APP ON WINDOWS
Install Node.js 22 or later. Open app and double-click Start-Local.cmd.
Open http://127.0.0.1:8787 or http://127.0.0.1:8787/workspace.html.
The first launch creates app/.env.local. Rule-based matching needs no AI key.
For new AI explanations, put your own key after DEEPSEEK_API_KEY= in that local file.
For Yahoo prices, Gmail sending or new TradingAgents research, install Python 3.12
(Python 3.11-3.13 supported), then open PowerShell in app and run:
  powershell -ExecutionPolicy Bypass -File ./Setup-Research.ps1
The first setup downloads dependencies. Research jobs can take several minutes.
Apply configuration changes by running Stop-Local.ps1, then Start-Local.cmd again.
Keep the computer awake, online and the server running for checks and reminders.

macOS/Linux: install Node.js 22+ and Python 3.11-3.13. In app run:
  bash Setup-Research.sh
  bash Start-Local.sh
Run bash Start-Research.sh in a second terminal for the research worker.
Edit the generated .env.local with your credentials and restart after changes.
Ctrl+C stops each terminal service. Separate-machine installation remains unverified.

7. YAHOO FINANCE PRICES
In the connected app, save stocks and click Refresh prices.
The display uses the latest available completed minute bars from Yahoo Finance.
Read the data timestamp, delay and market-closed labels before interpreting a price.
Prices may be delayed or unavailable; this is not a guaranteed execution feed.
Daily strategy confirmations still need completed daily bars, even during the session.
No Alpaca key is required when INTRADAY_PROVIDER=yahoo.

8. SIDEBAR SUBSCRIPTION DEMO
Subscribe (demo) only saves an address on the current device and previews the flow.
It sends no email, and it does not enable the real backend subscription.
The default package has EMAIL_DELIVERY_ENABLED=false, so sending remains off.
You can honestly demonstrate the subscription and trade-recording interface in this mode.

9. ENABLE ACTUAL GMAIL DELIVERY
The submission includes the real sending adapter and supporting workflow:
  app/server/gmail.mjs       Node adapter
  app/worker/send_gmail.py   Gmail SMTP sender with verified TLS
  app/server/tracking.mjs    Tracking and reminder workflow
Install the Python environment in step 6 before enabling the sender.
Use a Gmail account eligible for Google App Passwords with two-step verification.
Create an App Password: https://support.google.com/accounts/answer/185833
Do not use the account's regular login password.
In your private app/.env.local set:
  EMAIL_DELIVERY_ENABLED=true
  GMAIL_USER=your-sending-account@gmail.com
  GMAIL_APP_PASSWORD=your-16-character-app-password
  INTRADAY_PROVIDER=yahoo
  ALERT_INTERVAL_SECONDS=60
  ALERT_BASE_URL=http://127.0.0.1:8787
Restart the local server after saving the file.
In the connected app:
  a. Complete About you and save at least one stock to follow.
  b. Open the watchlist's Email reminders section, enter the receiving address,
     and check consent. This is separate from the sidebar demo subscription.
  c. Click Verify my email address; open the verification link in the received email.
  d. Return to the app and click Refresh email status.
  e. Check Send reminders for my saved stocks, then Save reminder settings.
  f. Under More reminder settings, optionally enter your own price-review levels.
  g. Click Check my saved stocks now to inspect market availability and reminder history.
A normal check sends no alert unless an implemented condition is met.
The sender reports Gmail acceptance, failure or uncertain outcome; acceptance alone
does not confirm inbox delivery. Check the recipient inbox and spam folder separately.
Do not claim that demo previews are delivered emails.

10. RECORD ACTUAL TRADES AND STOP REMINDERS
An actual reminder email contains a private trade-recording link and unsubscribe link.
After trading through your broker, open the form and enter the actual shares and price.
You can also use My holdings & record a trade inside the connected app.
No email reply is read or parsed. The app never executes a broker order.
Sell reminders require an existing recorded holding; you cannot record an oversell.
The prototype ledger does not automatically apply splits, taxes or corporate actions.
Use Turn off email reminders or the email unsubscribe link to stop delivery.
Private sessions expire after seven days; re-match in the same tab to renew a session.
The server and computer must remain running for ongoing checks.

11. LOCAL LINKS AND PUBLIC DEPLOYMENT
Default links beginning http://127.0.0.1:8787 work only on the server computer.
An email opened on another device cannot reach that computer through this address.
For public use, deploy the backend and set ALERT_BASE_URL to its public HTTPS origin.
Keep credentials server-side and provide persistent storage and a running scheduler.
Uploading only web/ gives a portable/static demo; it does not run Gmail or research.
Deployment configuration and an AWS migration plan are included, not a live deployment.
Confirm market-data permissions before public distribution for your intended use.

12. PACKAGE CONTENTS AND VERIFICATION
START-HERE.html          Entry page and quick links
SETUP.html               Connected-mode and Gmail setup
WORKFLOW-AND-GAPS.html   Workflow, limits and demonstration plan
KNOWN-LIMITATIONS.html   Integration status, actual consequences and remaining work
KNOWN-LIMITATIONS.txt    The same notes as a readable text file
README.txt               This English usage tutorial
web/                     Portable website with English default UI
reports/                 Deliberately shared, previously generated research
app/                     Complete source, launchers and pinned TradingAgents code
MANIFEST.json            File hashes
VERIFY-DELIVERY.ps1      Windows package integrity check
THIRD-PARTY.txt           Sources and third-party attribution

No API keys, Gmail passwords, private recipients, sessions, holdings or runtime state
are included. Install dependencies on your own computer; the original .venv is excluded.
Personal-computer Demo wrappers and one-off demo request/status scripts are excluded.
Never publicly upload a configured copy's .env.local, .local or private data directories.
Saved reports keep their original inputs and dates. Browser visual verification and
fresh installation on a separate computer remain to be completed.

TEAM
WU Shi Chang - Initiator
YU Zhuowei - Hipster
HUANG Weiting - Hacker
WEN Wai Hai - Hacker
Equal collaboration. Smart Trading for Everyone.
