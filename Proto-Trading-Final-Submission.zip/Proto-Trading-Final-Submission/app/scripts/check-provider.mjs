import {loadLocalEnv,configuration} from '../server/config.mjs';
loadLocalEnv();const c=configuration();
try {
  const r=await fetch(c.deepseekBase+'/chat/completions',{method:'POST',headers:{Authorization:'Bearer '+c.deepseekKey,'Content-Type':'application/json'},signal:AbortSignal.timeout(40000),body:JSON.stringify({model:c.deepseekModel,messages:[{role:'user',content:'Return a JSON object with one key ok and boolean true. No other text.'}],response_format:{type:'json_object'},thinking:{type:'disabled'},max_tokens:128})});
  const b=await r.json();
  console.log(JSON.stringify({httpStatus:r.status,model:b.model||null,finishReason:b.choices?.[0]?.finish_reason,hasContent:!!b.choices?.[0]?.message?.content,contentLength:b.choices?.[0]?.message?.content?.length,errorType:b.error?.type||null,errorCode:b.error?.code||null}));
} catch(e){ console.log(JSON.stringify({errorName:e.name,causeCode:e.cause?.code||null,causeName:e.cause?.name||null}));process.exitCode=1; }
