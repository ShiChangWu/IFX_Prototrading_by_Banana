import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { bundleWorkspace, portableShell } from './portable-bundle.mjs';
import { renderLimitationsPage } from './render-notes.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.resolve(process.argv[2] || path.join(root, '..', 'delivery', 'Proto-Trading'));
if (out === root || root.startsWith(out + path.sep) || out.startsWith(root + path.sep)) throw new Error('Choose a delivery folder outside the source app.');
try { await fs.access(out); throw new Error('Output folder already exists. Choose a new folder; existing delivery is preserved.'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
async function firstFile(candidates) { for (const candidate of candidates) { try { if ((await fs.stat(candidate)).isFile()) return candidate; } catch (error) { if (error.code !== 'ENOENT') throw error; } } throw new Error('Reviewed report source is missing.'); }
// Only the reviewed public example is approved for redistribution. A later
// personal research run in data/ must never replace it during packaging.
const reportFile = await firstFile([path.join(root, 'examples', 'prepared-report.json')]);
const report = JSON.parse(await fs.readFile(reportFile, 'utf8'));
if (!report.id || !report.profile || !['complete', 'partial'].includes(report.status) || !report.provenance?.engine || !report.research?.length) throw new Error('A real reviewed example report is required.');
const reportText = JSON.stringify(report);
if (/"(?:accessToken|sessionToken|workerSecret|deepseekKey|apiKey|authorization)"\s*:/i.test(reportText)) throw new Error('Private credential fields in sample report.');
execFileSync(process.execPath, [path.join(root, 'scripts/build.mjs')], { cwd: root, stdio: 'inherit', windowsHide: true });
await fs.mkdir(out, { recursive: true });

const excluded = new Set(['.git', '.local', '.venv', '.env', '.env.local', '__pycache__', 'node_modules', '.netlify', 'test-results', 'presentation', 'OPEN-DEMO.html', 'DEMO-README.txt', 'START-DEMO.cmd', 'START-DEMO.ps1', 'CHECK-DEMO.cmd', 'LOCAL-DEMO-CONNECTION.json', 'demo-preflight.mjs', 'create-pc-demo.mjs', 'build-presentation.mjs', 'demo-request.mjs', 'demo-status.mjs']);
async function copyTree(from, to) {
  const info = await fs.lstat(from);
  if (info.isSymbolicLink()) throw new Error(`Package does not follow symlinks: ${path.basename(from)}`);
  if (info.isDirectory()) {
    await fs.mkdir(to, { recursive: true });
    for (const item of await fs.readdir(from, { withFileTypes: true })) {
      if (excluded.has(item.name) || /\.(pyc|pyo|log)$/.test(item.name) || item.name.endsWith('.egg-info')) continue;
      // The personal presentation overlay is served locally but is not a dependency
      // of a recipient's installation or of the standalone submission website.
      if(from===path.join(root,'dist')&&item.name==='presentation')continue;
      await copyTree(path.join(from, item.name), path.join(to, item.name));
    }
  } else await fs.copyFile(from, to);
}
const appOut = path.join(out, 'app');
await fs.mkdir(appOut, { recursive: true });
const directories = ['public', 'shared', 'server', 'worker', 'scripts', 'tests', 'shell', 'netlify', 'supabase', 'dist'];
for (const item of directories) await copyTree(path.join(root, item), path.join(appOut, item));
for (const item of await fs.readdir(root, { withFileTypes: true })) {
  if (item.isFile() && (['.env.example', '.gitignore', 'package.json', 'netlify.toml', 'requirements-lock.txt', 'VENDOR-REVISION.txt'].includes(item.name) || /\.(md|ps1|cmd|sh)$/.test(item.name))) await copyTree(path.join(root, item.name), path.join(appOut, item.name));
}
const vendorOut = path.join(appOut, 'vendor', 'TradingAgents');
await fs.mkdir(vendorOut, { recursive: true });
for (const item of ['tradingagents', 'cli', 'pyproject.toml', 'README.md', 'LICENSE']) await copyTree(path.join(root, 'vendor', 'TradingAgents', item), path.join(vendorOut, item));
// The submission translates language-picker display labels only. Preserve the
// pinned source locally, the available language values and all analysis logic.
const vendorReadme=path.join(vendorOut,'README.md');
const languageLabels={de:'German',es:'Spanish',fr:'French',ja:'Japanese',ko:'Korean',pt:'Portuguese',ru:'Russian',zh:'Chinese'};
await fs.writeFile(vendorReadme,'<!-- English submission: language link labels translated; original links retained. -->\n'+(await fs.readFile(vendorReadme,'utf8')).replace(/(href="https:\/\/www\.readme-i18n\.com\/TauricResearch\/TradingAgents\?lang=)([a-z]+)(">)[^<]+(<\/a>)/g,(all,before,lang,middle,after)=>languageLabels[lang]?before+lang+middle+languageLabels[lang]+after:all));
const vendorPrompts=path.join(vendorOut,'cli','prompts.py');
await fs.writeFile(vendorPrompts,'# English submission: language labels translated; underlying language values unchanged.\n'+(await fs.readFile(vendorPrompts,'utf8')).replace(/questionary\.Choice\("(Chinese|Japanese|Korean|Hindi|Spanish|Portuguese|French|German|Arabic|Russian) \([^"\n]+\)", "\1"\)/g,(_all,language)=>`questionary.Choice("${language}", "${language}")`));
await fs.writeFile(path.join(vendorOut,'ENGLISH-SUBMISSION-NOTICE.txt'),'This copy derives from the pinned revision in app/VENDOR-REVISION.txt.\nThe English submission translates README translation-link labels and CLI language-picker display labels into English.\nOriginal links, selectable language values, analysis logic, author attribution and Apache-2.0 license are preserved.\nThese two files have display-only packaging modifications; they are not byte-for-byte upstream copies.\n');
await fs.mkdir(path.join(out, 'reports'), { recursive: true });
await fs.mkdir(path.join(appOut, 'examples'), { recursive: true });
await fs.copyFile(reportFile, path.join(out, 'reports', 'research-report.json'));
await fs.copyFile(reportFile, path.join(appOut, 'examples', 'demo-report.json'));
await fs.copyFile(reportFile, path.join(appOut, 'examples', 'prepared-report.json'));
await fs.copyFile(await firstFile([path.join(root, 'examples', 'TradingAgents-VTI-prepared.md')]), path.join(out, 'reports', 'TradingAgents-VTI-demo.md'));
execFileSync(process.execPath, [path.join(root, 'scripts/export-report.mjs'), reportFile, path.join(out, 'reports', 'Proto-Trading-Demo-Report.html')], { cwd: root, stdio: 'inherit', windowsHide: true });
await fs.mkdir(path.join(out, 'web'), { recursive: true });
try{await fs.access(path.join(root,'public','assets'));await copyTree(path.join(root,'public','assets'),path.join(out,'web','assets'));}catch(error){if(error.code!=='ENOENT')throw error;}
await fs.writeFile(path.join(out, 'web', 'workspace.html'), (await bundleWorkspace(root, [report])).html);
await fs.copyFile(path.join(root,'public','prepared-report.html'),path.join(out,'web','prepared-report.html'));
await fs.writeFile(path.join(out, 'web', 'index.html'), portableShell(await fs.readFile(path.join(root, 'dist/index.html'), 'utf8')));
const limitations=await fs.readFile(path.join(root,'KNOWN-LIMITATIONS.md'),'utf8');
await fs.copyFile(path.join(root,'dist','prototype-status.html'),path.join(out,'web','prototype-status.html'));
await fs.writeFile(path.join(out,'KNOWN-LIMITATIONS.html'),renderLimitationsPage(limitations,'web/workspace.html'));
await fs.writeFile(path.join(out,'KNOWN-LIMITATIONS.txt'),limitations);

const escape = text => String(text).replace(/[&<>"']/g, x => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[x]));
function renderReview(markdown) {
  const inline = text => escape(text).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  const lines = markdown.split(/\r?\n/), output = [];
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;
    if (/^\|/.test(line)) {
      const rows = [];
      while (i < lines.length && /^\|/.test(lines[i])) {
        const cells = lines[i].split('|').slice(1, -1).map(x => x.trim());
        if (!cells.every(x => /^:?-+:?$/.test(x))) rows.push(cells);
        i++;
      }
      i--;
      output.push('<div style="overflow-x:auto"><table style="border-collapse:collapse;width:100%;font-size:14px">' + rows.map((row, n) => '<tr>' + row.map(cell => `<${n ? 'td' : 'th'} style="text-align:left;vertical-align:top;border:1px solid #26394a;padding:12px;min-width:155px">${inline(cell)}</${n ? 'td' : 'th'}>`).join('') + '</tr>').join('') + '</table></div>');
    } else if (/^#{1,3} /.test(line)) {
      const match = line.match(/^(#{1,3}) (.*)$/); const level = Math.max(2, match[1].length);
      output.push(`<h${level}>${inline(match[2])}</h${level}>`);
    } else if (/^(?:- |\d+\. )/.test(line)) {
      const ordered = /^\d/.test(line), items = [];
      while (i < lines.length && (ordered ? /^\d+\. / : /^- /).test(lines[i])) { items.push(`<li>${inline(lines[i].replace(/^(?:- |\d+\. )/, ''))}</li>`); i++; }
      i--; output.push(`<${ordered ? 'ol' : 'ul'}>${items.join('')}</${ordered ? 'ol' : 'ul'}>`);
    } else output.push(`<p>${inline(line)}</p>`);
  }
  return output.join('\n');
}
const style = `:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#060b12;color:#e7f2fa;font:16px/1.7 system-ui,sans-serif}main{max-width:1050px;margin:auto;padding:60px 26px}a{color:#35d6f4}h1{font-size:clamp(36px,7vw,66px);line-height:1.07;letter-spacing:-2px;margin:16px 0 24px}h2{font-size:23px}p{color:#afbfce}.eyebrow{color:#35d6f4;letter-spacing:2px;font-size:12px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:18px}.card{background:#0d1824;border:1px solid #213345;border-radius:16px;padding:25px}.button{display:inline-block;background:#30d5ef;color:#031118;padding:11px 18px;border-radius:8px;text-decoration:none;font-weight:700}.secondary{background:#18313f;color:#d7f7ff}code{background:#142330;padding:2px 5px;border-radius:4px}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:15px/1.8 system-ui,sans-serif}.note{border-left:3px solid #35d6f4;padding:12px 20px;background:#0c1621}li{margin:8px 0}footer{margin-top:44px;color:#8696a6;font-size:13px}`;
const page = (title, body) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title><style>${style}</style></head><body><main>${body}</main></body></html>`;
await fs.writeFile(path.join(out, 'START-HERE.html'), page('Proto-Trading · Start here', `
<p class="eyebrow">PROTO-TRADING · BUILT FOR iFX HACK HONG KONG 2026</p><h1>Smart Trading<br>for Everyone.</h1>
<div class="note"><strong>Submission build: integration notes included.</strong> The offline website uses local rules and saved evidence. Live services need setup; some prototype features are not implemented. <a href="KNOWN-LIMITATIONS.html">See each limitation and its effect →</a></div>
<p>Understand your choices with a simple questionnaire, transparent amounts and research you can inspect.<br>From Natural Prompt to Quant Strategy: Smarter Trading for Everyone.</p>
<div class="grid"><section class="card"><p class="eyebrow">01 · OPEN NOW</p><h2>Explore the complete website</h2><p>No installation is needed. Start with the optional tour, answer About you, choose stocks and explore strategies using that same selection. Explore strategy-specific conditions, change backtest dates and fees, or open the prepared research instantly.</p><a class="button" href="web/index.html">Open website →</a><p><a href="web/workspace.html">Go directly to the app</a></p></section>
<section class="card"><p class="eyebrow">02 · REAL SAVED RESEARCH</p><h2>Inspect a real research example</h2><p>A previously generated TradingAgents report preserves its original date, questionnaire and source gaps. Its status is partial because some evidence and horizon citations were unavailable.</p><a class="button secondary" href="reports/Proto-Trading-Demo-Report.html">Open research report →</a><p><a href="reports/TradingAgents-VTI-demo.md" download>Download VTI research excerpts</a> · <a href="reports/research-report.json" download>JSON</a></p></section>
<section class="card"><p class="eyebrow">03 · CONNECT YOUR OWN SERVICES</p><h2>Connect AI, market data and Gmail</h2><p>The app folder contains the complete source, pinned TradingAgents code, templates, launchers and Gmail sender. Use your own credentials; email delivery starts disabled.</p><a class="button secondary" href="SETUP.html">Read the setup guide →</a></section></div>
<h2>From your goals to understandable decisions</h2><p>About you → strategy match → selected stocks → hypothetical amounts and strategy conditions → historical tests → saved research, or a new selected-stock report when connected</p>
<p>A new connected research request uses one to eight checked stocks, their exact hypothetical weights and remaining cash. It includes 0% watch-only ideas and freezes the submitted inputs. The prepared report opens immediately and always retains its own original stocks and date.</p>
<div class="note">English is the default language. The portable website uses local rules and saved examples. Fresh AI, Yahoo Finance prices, new research and actual email need the connected server. The sidebar subscription is always a demo and sends no email. Edited simulated weights last for this page session; saving a watchlist does not save those percentages. Uploading a report does not regenerate analysis for your current selection.</div>
<p><a href="README.txt">Read the complete plain-text usage tutorial →</a></p><p><a href="WORKFLOW-AND-GAPS.html">Workflow, completed features, limitations and a three-minute demo →</a></p>
<footer>WU Shi Chang · YU Zhuowei · HUANG Weiting · WEN Wai Hai<br>Equal collaboration. WU Shi Chang: Initiator. No live orders are placed.</footer>`));
await fs.writeFile(path.join(out, 'SETUP.html'), page('Connected app setup', `<p class="eyebrow">PROTO-TRADING · CONNECTED MODE</p><h1>Connect the working app.</h1><p><a href="START-HERE.html">← Back to the start</a></p>
<h2>Windows</h2><ol><li>Extract the entire ZIP, then open <code>START-HERE.html</code>. The portable demo needs no installation.</li><li>For the connected app, install Node.js 22 or later. Open the <code>app</code> folder and double-click <code>Start-Local.cmd</code>. The first launch creates local configuration. Open <code>http://127.0.0.1:8787</code>.</li><li>For fresh AI explanations, edit the generated <code>app/.env.local</code> and enter your own <code>DEEPSEEK_API_KEY</code>. Run <code>Stop-Local.ps1</code>, then <code>Start-Local.cmd</code> to apply changes. Rule-based matching needs no AI key.</li><li>For Yahoo Finance data, Gmail sending or new TradingAgents research, install Python 3.12 (3.11–3.13 are supported), then run <code>powershell -ExecutionPolicy Bypass -File ./Setup-Research.ps1</code> from the app folder. Initial dependency installation needs internet access.</li><li>Restart <code>Start-Local.cmd</code> after setup. It starts the available research process. New research can take several minutes; use the saved report for a short demonstration.</li></ol>
<h2>Research the stocks you selected</h2><p>Complete About you, choose one to eight stocks and set their hypothetical percentages. Open Research → More options and inspect Research inputs before generating: selected tickers, weights, cash and the confirmed matched approach. Each checked stock is included even at 0%; it remains watch-only with no invested amount. More stocks require more processing time and API calls. The server freezes the accepted snapshot, so editing the page while the job runs cannot change its report. Open generated report opens that actual result in a popup. Open prepared report always opens the separately dated example. Browsing another strategy does not change the confirmed matched approach.</p>
<h2>Enable real Gmail reminders</h2><p>The packaged backend includes <code>app/server/gmail.mjs</code> and <code>app/worker/send_gmail.py</code>. Sending is disabled by default. To activate it, create a <a href="https://support.google.com/accounts/answer/185833" target="_blank" rel="noopener noreferrer">Google App Password</a> for an eligible Gmail account with two-step verification, then configure these values in <code>app/.env.local</code>:</p><pre>EMAIL_DELIVERY_ENABLED=true
GMAIL_USER=your-sending-account@gmail.com
GMAIL_APP_PASSWORD=your-16-character-app-password
INTRADAY_PROVIDER=yahoo
ALERT_INTERVAL_SECONDS=60
ALERT_BASE_URL=http://127.0.0.1:8787</pre><p>Use an App Password, not your regular Google password. Restart the server. Complete About you, select and save stocks, then open the watchlist's Email reminders section. Enter the recipient address, consent to reminders, request verification, open the verification link and refresh email status. Select <strong>Send reminders for my saved stocks</strong> and save reminder settings. The sidebar <strong>Subscribe (demo)</strong> remains a local preview and never starts real delivery.</p><p>An email links to a private form for recording a trade you already made with your broker. Enter the actual quantity and execution price. The app does not read email replies or place orders. A sell reminder requires a recorded holding. SMTP acceptance is not proof of inbox delivery.</p><div class="note">Keep the server running, the computer awake and the network connected. Default email links open only on that same computer. For other devices, deploy the backend and use its public HTTPS origin as ALERT_BASE_URL. Static hosting alone cannot run email checks or send reminders.</div>
<h2>macOS / Linux</h2><p>Install Node.js 22+ and Python 3.11–3.13. From the app folder, run <code>bash Start-Local.sh</code> in a terminal. Edit the generated configuration and restart after adding your own credentials. Run <code>bash Setup-Research.sh</code> to install Python dependencies, then run <code>bash Start-Research.sh</code> in a second terminal. Press Ctrl+C to stop. These scripts have been checked but installation has not been verified on a separate macOS or Linux computer.</p>
<h2>What the package contains</h2><p><code>web/</code> is the portable website; <code>reports/</code> contains deliberately shared saved research; <code>app/</code> contains source and launchers; <code>MANIFEST.json</code> records file hashes. Dependencies are installed on the recipient's computer. The original virtual environment is excluded.</p>
<h2>Public access later</h2><p>The <code>web</code> folder can be hosted as a static site for saved examples and local rules. A public connected app also needs API hosting, persistent storage, an available research worker and a running reminder scheduler. Netlify/Supabase configuration and an AWS migration plan are included; this package does not itself deploy them. Check market-data permissions for the intended public distribution.</p>
<div class="note">No credentials, private sessions, email recipients, holdings or local task state are included. After configuring your copy, do not publicly upload the whole app folder. Keep .env.local, .local, .venv and private data outside future deliveries.</div>
<p><a href="README.txt">Complete usage tutorial</a> · <a href="app/PORTABILITY.md">Detailed running instructions</a> · <a href="app/README.md">Project documentation</a> · <a href="WORKFLOW-AND-GAPS.html">Workflow and gaps</a></p>`));
const review = await fs.readFile(path.join(root, 'DELIVERY-REVIEW.md'), 'utf8');
await fs.writeFile(path.join(out, 'WORKFLOW-AND-GAPS.html'), page('Workflow and gaps', `<p><a href="START-HERE.html">← Back to the start</a></p><h1>Workflow and remaining gaps</h1>${renderReview(review)}`));
await fs.writeFile(path.join(out, 'README.txt'), `PROTO-TRADING - SMART TRADING FOR EVERYONE
Built for iFX Hack Hong Kong 2026
Default language: English

1. OPEN THE PORTABLE DEMO
Extract the entire ZIP before opening any file. Keep its folder structure.
Double-click START-HERE.html, then choose Open website.
web/index.html opens the full website; web/workspace.html opens the app directly.
No installation, API key or account is needed for the portable demo.
The optional tour explains the features and always provides a Skip button.
Read KNOWN-LIMITATIONS.html or KNOWN-LIMITATIONS.txt before presenting.
These explain which services need setup, what each missing connection prevents,
and which features are not implemented. The app also has a Prototype status panel.

2. ABOUT YOU, YOUR STRATEGY AND YOUR STOCKS
Complete About you, then click Show my starting plan.
Read the matched strategy's plain-language description and choose stocks to follow.
Search for another ticker or company name and check up to eight stocks.
The connected app can search its stock directory; portable search uses packaged assets.
Save stocks to follow, or keep the selection for the current portable visit.

See allocation, risk and research details follows the same checked stocks.
Existing template weights remain; newly added stocks start at 0% as watch-only ideas.
Unchecking a stock leaves its former amount in cash. A checkbox is not a purchase.
Open Adjust simulated percentages to assign your own hypothetical weights.
Combined stock weights may not exceed 100%; the remainder stays in cash.
Amounts and the stress illustration change with the selected stocks and weights.
These custom amounts have not been re-approved by AI. Recorded trades are separate.
Edited percentages last only for the current page session. Saving the watchlist stores
stocks, reminder settings and trade records, not your edited allocation percentages.
Original AI match & daily observations preserves the original questionnaire allocation
and its dated daily observations, explicitly separate from your custom selection.

3. EXPLORE STRATEGIES AND HYPOTHETICAL PRICES
Open Explore this strategy & backtests or the Explore strategies tab.
Find an approach you understand uses the stocks you already selected.
Each approach shows a short introduction and a 0-100 learning-fit score.
Defensive: keep a larger reserve and begin with smaller investments.
Balanced: spread money across assets and review the mix.
Moving averages: follow a trend after shorter and longer averages cross.
Bollinger Bands: watch a sharp drop recover toward its recent range.
RSI: check whether recent selling pressure is easing.
Price Action: inspect reactions around previous turning points.
ATR: use typical daily movement to understand exit-review distances.
Wyckoff: study failed breakdowns with volume; only a daily proxy is tested.
ICT: learn about intraday highs, lows and gaps; no verified scanner.
Order Flow: learn from trades and orders; required tick/depth data is absent.
The team rubric uses asset type (45%), beginner simplicity (30%) and verified
saved-data coverage (25%), counting each selected stock equally. Click an
approach for individual stock scores, or How scores work for the explanation.
Scores are not returns, win rates or a personal suitability assessment.
Unknown asset types and missing history lower the score. ICT and Order Flow
are learning-only and capped at 20; ATR is a risk tool, not an entry strategy.
Changing or searching for a strategy preserves that stock selection.
Choose a selected stock and explore that strategy's own conditions.
Moving averages use a 20/100-day crossover; RSI uses recovery above 30 or an
exit review at 70; Bollinger uses a recovery into the band or return to the mean.
ATR illustrates a trailing level at the highest close minus 1.5 times ATR.
Price Action requires a confirmed pin bar or retest; Wyckoff requires a spring
and volume confirmation. Defensive and balanced approaches use scheduled weight
reviews. ICT and Order Flow remain learning-only because required data is absent.
Example inputs are hypothetical; dated historical indicators remain separate.
An example event is not an observed signal, forecast, enabled alert or order.
Recorded holdings change the explanation: an exit cannot sell shares not owned.
A single future price cannot establish a future RSI or moving-average crossover.

4. RUN A HISTORICAL RULE TEST
In the strategy lab, select the stock, start/end dates, test amount and trading fee.
The fee is charged on each side: 0.10% means $1 per $1,000 bought and another fee sold.
Click Run this rule test to recalculate the chart, metrics and trade record locally.
Use Data source, assumptions & every trade to inspect dates, fills and limitations.
The test compares one stock under the chosen rule with holding that same stock.
It does not backtest your whole edited allocation. Past returns are not forecasts.
Packaged Yahoo Finance history ends on the date shown; missing history stays unavailable.
Indicators need earlier observations. A recent IPO may lack enough warm-up data.
ICT and Order Flow do not receive fabricated tests where the required data is absent.

5. READ OR UPLOAD RESEARCH
Open Research and click Open prepared report for the saved report popup.
It opens immediately, with no new analysis or API key. Close or Escape returns
to the app. A normal link opens the document if popups are unsupported.
This is the reviewed $10,000 balanced example from 4 Oct 2026, 15:27 HKT,
researching VTI, IEF and SGOV. Original inputs, date and partial status stay visible.
The recorded generation commit is unknown. The packaged TradingAgents source
has a separate pinned revision; that pin does not prove the saved run's revision.
Generate and upload controls are under More options. They remain available.
Check the mode banner: the file-based website is Offline backup and cannot call AI.
For a fresh answer, start the connected app and click Show my starting plan.
The quick DeepSeek explanation appears above the stocks, with a received time.
Refresh AI match requests a new answer; a restored answer is labelled as saved.
For a new report, open More options in Research and inspect Research inputs.
It shows one to eight selected US stocks/ETFs, their exact hypothetical weights,
remaining cash and your confirmed matched approach. Use uppercase ticker codes
of at most ten characters. The backend verifies their available directory identity.
Every checked stock is researched, including 0% watch-only ideas. Those ideas do
not receive invested money and do not affect the portfolio-history calculation.
Click Generate deep research. The accepted job freezes its displayed input snapshot;
later checkbox, weight or questionnaire edits cannot alter the running job.
Exploring a different strategy does not change the matched approach used here.
New custom weights are user assumptions, not an optimized or AI-approved allocation.
Watch the job progress. A measured three-asset run took 7 minutes 23 seconds;
duration varies and more stocks take longer, so prepare research before presenting.
Open generated report opens the actual completed report from that job in a popup,
including its accepted inputs. It does not substitute the prepared example.
Close or Escape returns to the app; the result also remains available inline.
Missing evidence can leave a report partial; unavailable content is not invented.
Open Research for the saved TradingAgents example or upload original Markdown/TXT.
The supplied report retains its original questionnaire, stocks, date and partial status.
Its missing evidence and unavailable horizon summaries are visible; this is saved research.
Changing stock checkboxes or weights does not rewrite saved or uploaded research.
New selected-stock jobs explicitly use the submitted selection and weights.
Legacy questionnaire-only requests keep their original top-three research scope.
If data or instrument classification is unavailable, the report preserves that gap.
Report graphics and dated company facts help explain the report; inspect their sources.
An optional return-scenario calculator uses your assumptions, not a validated forecast.
Browser storage may be restricted for local files. Follow the displayed storage status.

6. START THE CONNECTED APP ON WINDOWS
Install Node.js 22 or later. Open app and double-click Start-Local.cmd.
Open http://127.0.0.1:8787 or http://127.0.0.1:8787/workspace.html.
The first launch creates app/.env.local. Rule-based matching needs no AI key.
For new AI explanations, put your own key after DEEPSEEK_API_KEY= in that local file.
For Yahoo prices, Gmail sending or new TradingAgents research, install Python 3.12
(Python 3.11-3.13 supported), then open PowerShell in app and run:
  powershell -ExecutionPolicy Bypass -File ./Setup-Research.ps1
The first setup downloads dependencies. Research jobs can take several minutes.
Apply configuration changes by running Stop-Local.ps1, then Start-Local.cmd again.
Keep the computer awake, online and the server running for checks and reminders.

macOS/Linux: install Node.js 22+ and Python 3.11-3.13. In app run:
  bash Setup-Research.sh
  bash Start-Local.sh
Run bash Start-Research.sh in a second terminal for the research worker.
Edit the generated .env.local with your credentials and restart after changes.
Ctrl+C stops each terminal service. Separate-machine installation remains unverified.

7. YAHOO FINANCE PRICES
In the connected app, save stocks and click Refresh prices.
The display uses the latest available completed minute bars from Yahoo Finance.
Read the data timestamp, delay and market-closed labels before interpreting a price.
Prices may be delayed or unavailable; this is not a guaranteed execution feed.
Daily strategy confirmations still need completed daily bars, even during the session.
No Alpaca key is required when INTRADAY_PROVIDER=yahoo.

8. SIDEBAR SUBSCRIPTION DEMO
Subscribe (demo) only saves an address on the current device and previews the flow.
It sends no email, and it does not enable the real backend subscription.
The default package has EMAIL_DELIVERY_ENABLED=false, so sending remains off.
You can honestly demonstrate the subscription and trade-recording interface in this mode.

9. ENABLE ACTUAL GMAIL DELIVERY
The submission includes the real sending adapter and supporting workflow:
  app/server/gmail.mjs       Node adapter
  app/worker/send_gmail.py   Gmail SMTP sender with verified TLS
  app/server/tracking.mjs    Tracking and reminder workflow
Install the Python environment in step 6 before enabling the sender.
Use a Gmail account eligible for Google App Passwords with two-step verification.
Create an App Password: https://support.google.com/accounts/answer/185833
Do not use the account's regular login password.
In your private app/.env.local set:
  EMAIL_DELIVERY_ENABLED=true
  GMAIL_USER=your-sending-account@gmail.com
  GMAIL_APP_PASSWORD=your-16-character-app-password
  INTRADAY_PROVIDER=yahoo
  ALERT_INTERVAL_SECONDS=60
  ALERT_BASE_URL=http://127.0.0.1:8787
Restart the local server after saving the file.
In the connected app:
  a. Complete About you and save at least one stock to follow.
  b. Open the watchlist's Email reminders section, enter the receiving address,
     and check consent. This is separate from the sidebar demo subscription.
  c. Click Verify my email address; open the verification link in the received email.
  d. Return to the app and click Refresh email status.
  e. Check Send reminders for my saved stocks, then Save reminder settings.
  f. Under More reminder settings, optionally enter your own price-review levels.
  g. Click Check my saved stocks now to inspect market availability and reminder history.
A normal check sends no alert unless an implemented condition is met.
The sender reports Gmail acceptance, failure or uncertain outcome; acceptance alone
does not confirm inbox delivery. Check the recipient inbox and spam folder separately.
Do not claim that demo previews are delivered emails.

10. RECORD ACTUAL TRADES AND STOP REMINDERS
An actual reminder email contains a private trade-recording link and unsubscribe link.
After trading through your broker, open the form and enter the actual shares and price.
You can also use My holdings & record a trade inside the connected app.
No email reply is read or parsed. The app never executes a broker order.
Sell reminders require an existing recorded holding; you cannot record an oversell.
The prototype ledger does not automatically apply splits, taxes or corporate actions.
Use Turn off email reminders or the email unsubscribe link to stop delivery.
Private sessions expire after seven days; re-match in the same tab to renew a session.
The server and computer must remain running for ongoing checks.

11. LOCAL LINKS AND PUBLIC DEPLOYMENT
Default links beginning http://127.0.0.1:8787 work only on the server computer.
An email opened on another device cannot reach that computer through this address.
For public use, deploy the backend and set ALERT_BASE_URL to its public HTTPS origin.
Keep credentials server-side and provide persistent storage and a running scheduler.
Uploading only web/ gives a portable/static demo; it does not run Gmail or research.
Deployment configuration and an AWS migration plan are included, not a live deployment.
Confirm market-data permissions before public distribution for your intended use.

12. PACKAGE CONTENTS AND VERIFICATION
START-HERE.html          Entry page and quick links
SETUP.html               Connected-mode and Gmail setup
WORKFLOW-AND-GAPS.html   Workflow, limits and demonstration plan
KNOWN-LIMITATIONS.html   Integration status, actual consequences and remaining work
KNOWN-LIMITATIONS.txt    The same notes as a readable text file
README.txt               This English usage tutorial
web/                     Portable website with English default UI
reports/                 Deliberately shared, previously generated research
app/                     Complete source, launchers and pinned TradingAgents code
MANIFEST.json            File hashes
VERIFY-DELIVERY.ps1      Windows package integrity check
THIRD-PARTY.txt           Sources and third-party attribution

No API keys, Gmail passwords, private recipients, sessions, holdings or runtime state
are included. Install dependencies on your own computer; the original .venv is excluded.
Personal-computer Demo wrappers and one-off demo request/status scripts are excluded.
Never publicly upload a configured copy's .env.local, .local or private data directories.
Saved reports keep their original inputs and dates. Browser visual verification and
fresh installation on a separate computer remain to be completed.

TEAM
WU Shi Chang - Initiator
YU Zhuowei - Hipster
HUANG Weiting - Hacker
WEN Wai Hai - Hacker
Equal collaboration. Smart Trading for Everyone.
`.replace(/\n/g, '\r\n'));
await fs.writeFile(path.join(out, 'THIRD-PARTY.txt'), `TradingAgents by Tauric Research\nRepository: https://github.com/TauricResearch/TradingAgents\nPinned revision: ${(await fs.readFile(path.join(root, 'VENDOR-REVISION.txt'), 'utf8')).trim()}\nLicense: Apache-2.0; included at app/vendor/TradingAgents/LICENSE.\nThird-party source remains attributed to its authors.\nTradingView strategy idea sources and team adaptations: app/TRADINGVIEW-SOURCES.md. No TradingView Pine code is copied.\nSaved numeric stock history: Yahoo Finance via yfinance, with provider URLs and retrieval date in app/shared/school-prices.mjs.\nQuarterly financial facts: issuer IR and SEC sources attributed in app/shared/company-facts.mjs.\nOther Python libraries are installed from app/requirements-lock.txt and retain their own licenses.\n`);
await fs.writeFile(path.join(out, 'VERIFY-DELIVERY.ps1'), `$ErrorActionPreference = 'Stop'\n$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json\nforeach ($entry in $manifest.files) {\n  $file = Join-Path $PSScriptRoot $entry.path\n  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Missing: ' + $entry.path) }\n  if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw ('Changed: ' + $entry.path) }\n}\nWrite-Host ('Verified ' + $manifest.files.Count + ' packaged files.')\n`);

// Compare against known local credentials without ever printing their values.
let secrets = [];
try {
  secrets = (await fs.readFile(path.join(root, '.env.local'), 'utf8')).split(/\r?\n/).filter(line => /^\s*(?:DEEPSEEK_API_KEY|WORKER_SECRET|SUPABASE_SERVICE_ROLE_KEY|GMAIL_APP_PASSWORD|ALPACA_API_KEY|ALPACA_API_SECRET)\s*=/.test(line)).map(line => line.slice(line.indexOf('=') + 1).trim().replace(/^['"]|['"]$/g, '')).filter(value => value.length >= 12);
} catch (error) { if (error.code !== 'ENOENT') throw error; }
for(const relative of ['data/demo-session.json','.local/diagnostic-session.json'])try {
  const privateSession = JSON.parse(await fs.readFile(path.join(root, relative), 'utf8'));
  const collect = value => { if (!value || typeof value !== 'object') return; for (const [key, item] of Object.entries(value)) { if (/token|secret/i.test(key) && typeof item === 'string' && item.length >= 12) secrets.push(item); else collect(item); } };
  collect(privateSession);
} catch (error) { if (error.code !== 'ENOENT') throw error; }
const files = [];
async function inventory(directory) {
  for (const item of await fs.readdir(directory, { withFileTypes: true })) {
    const full = path.join(directory, item.name);
    const relative = path.relative(out, full).split(path.sep).join('/');
    if (excluded.has(item.name) || /\.(pyc|log)$/.test(item.name)) throw new Error(`Excluded path in package: ${relative}`);
    if (item.isDirectory()) await inventory(full);
    else { const data = await fs.readFile(full); for (const secret of secrets) if (data.includes(Buffer.from(secret))) throw new Error(`Credential found in ${relative}`); files.push({ path: relative, bytes: data.length, sha256: createHash('sha256').update(data).digest('hex') }); }
  }
}
await inventory(out);
await fs.writeFile(path.join(out, 'MANIFEST.json'), JSON.stringify({ title: 'Proto-Trading — Smart Trading for Everyone', packagedAt: new Date().toISOString(), reportId: report.id, reportStatus: report.status, credentialsIncluded: false, files }, null, 2));
console.log(`Delivery folder ready: ${out}\n${files.length} files; known-credential and private-path checks passed.`);
