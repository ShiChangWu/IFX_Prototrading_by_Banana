import fs from 'node:fs/promises';
import path from 'node:path';
import vm from 'node:vm';

// Deliberately limited to the project's named-import browser modules. Refuse
// unfamiliar syntax instead of silently changing module semantics.
export async function bundleWorkspace(root, reports) {
  const files = ['shared/templates.mjs', 'shared/strategy.mjs', 'shared/short-plan.mjs', 'shared/selected-plan.mjs', 'shared/report-import.mjs', 'shared/company-facts.mjs', 'shared/report-guide.mjs', 'shared/school-backtest.mjs', 'shared/school-fit.mjs', 'shared/school-prices.mjs', 'shared/school-scenarios.mjs', 'public/onboarding.js', 'public/report-guide.js', 'public/school-lab.js', 'public/watchlist.js', 'public/subscription.js', 'public/demo-report.js', 'public/workspace.js'];
  const known = new Set(files);
  let code = `'use strict';\nwindow.PROTO_PORTABLE = true;\nwindow.PROTO_DEMO_REPORTS = ${JSON.stringify(reports).replaceAll('<', '\\u003c').replaceAll('\u2028', '\\u2028').replaceAll('\u2029', '\\u2029')};\nconst protoModules = {};\n`;
  for (const file of files) {
    let source = await fs.readFile(path.join(root, file), 'utf8');
    const exported = new Set();
    source = source.replace(/^import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"];?\s*$/gm, (_all, names, target) => {
      let resolved = target.startsWith('/') ? target.slice(1) : path.posix.normalize(path.posix.join(path.posix.dirname(file), target));
      if (!known.has(resolved) && known.has('public/' + resolved)) resolved = 'public/' + resolved;
      if (!known.has(resolved) || files.indexOf(resolved) >= files.indexOf(file)) throw new Error(`Unsupported portable dependency: ${file}`);
      if (!/^[\w\s,]+$/.test(names)) throw new Error('Portable bundle supports simple named imports only.');
      return `const {${names}} = protoModules[${JSON.stringify(resolved)}];`;
    });
    source = source.replace(/^export\s*\{([^}]+)\};?\s*$/gm, (_all, names) => {
      for (const name of names.split(',').map(x => x.trim())) { if (!/^\w+$/.test(name)) throw new Error('Unsupported export'); exported.add(name); }
      return '';
    });
    source = source.replace(/^export\s+(const|function)\s+(\w+)/gm, (_all, kind, name) => { exported.add(name); return `${kind} ${name}`; });
    if (/^\s*(?:import|export)\s/m.test(source)) throw new Error(`Unsupported module syntax: ${file}`);
    code += `protoModules[${JSON.stringify(file)}] = (() => {\n${source}\nreturn {${[...exported].join(',')}};\n})();\n`;
  }
  new vm.Script(code, { filename: 'portable-workspace.js' });
  let html = await fs.readFile(path.join(root, 'public/workspace.html'), 'utf8');
  const css = await fs.readFile(path.join(root, 'public/workspace.css'), 'utf8');
  if (/<\/style/i.test(css) || /<\/script/i.test(code)) throw new Error('Unsafe inline closing tag in bundle.');
  html = html.replace('<link rel="stylesheet" href="/workspace.css">', () => `<style>\n${css}\n</style>`);
  const introCss = await fs.readFile(path.join(root, 'public/onboarding.css'), 'utf8');
  if (/<\/style/i.test(introCss)) throw new Error('Unsafe onboarding CSS.');
  html = html.replace('<link rel="stylesheet" href="/onboarding.css">', () => `<style>\n${introCss}\n</style>`);
  const trackingCss=await fs.readFile(path.join(root,'public/watchlist.css'),'utf8');
  if(/<\/style/i.test(trackingCss))throw new Error('Unsafe watchlist CSS.');
  html=html.replace('<link rel="stylesheet" href="/watchlist.css">',()=>`<style>\n${trackingCss}\n</style>`);
  const subscriptionCss=await fs.readFile(path.join(root,'public/subscription.css'),'utf8');
  if(/<\/style/i.test(subscriptionCss))throw new Error('Unsafe subscription CSS.');
  html=html.replace('<link rel="stylesheet" href="/subscription.css">',()=>`<style>\n${subscriptionCss}\n</style>`);
  const demoCss=await fs.readFile(path.join(root,'public/demo-report.css'),'utf8');
  if(/<\/style/i.test(demoCss))throw new Error('Unsafe demo report CSS.');
  html=html.replace('<link rel="stylesheet" href="/demo-report.css">',()=>`<style>\n${demoCss}\n</style>`);
  html = html.replace('<script type="module" src="/workspace.js"></script>', '');
  html = html.replace('</body>', () => `<script>\n${code}\n</script>\n</body>`);
  if (/(?:src|href)="\/(?:workspace|shared)/.test(html)) throw new Error('Portable workspace still depends on server paths.');
  return { html, code };
}

export function portableShell(html) {
  const tag = /<script type="__bundler\/template">\s*([\s\S]*?)\s*<\/script>/;
  const match = html.match(tag);
  if (!match) throw new Error('Missing website template');
  const template = JSON.parse(match[1]).replaceAll('src="/workspace.html"', 'src="workspace.html"').replaceAll('href="/workspace.html"', 'href="workspace.html"');
  return html.replace(tag, () => `<script type="__bundler/template">\n${JSON.stringify(template).replaceAll('</', '<\\/')}\n</script>`);
}
