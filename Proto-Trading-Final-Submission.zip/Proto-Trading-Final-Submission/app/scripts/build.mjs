import {readFile,writeFile,mkdir,cp} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {renderLimitationsPage} from './render-notes.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dist=path.join(root,'dist');
await mkdir(dist,{recursive:true});
const shellFile=path.join(root,'shell','proto-trading.html');
let html=await readFile(shellFile,'utf8');
const tag=/<script type="__bundler\/template">\s*([\s\S]*?)\s*<\/script>/;
const match=html.match(tag);if(!match)throw new Error('Existing website shell is missing its template.');
let template=JSON.parse(match[1]);
const start=template.indexOf('<sc-if value="{{ isPreview }}">');
const end=template.indexOf('<sc-if value="{{ isWorkflow }}">',start);
if(start<0||end<0)throw new Error('Existing website route boundaries changed.');
const workspace=`<sc-if value="{{ isPreview }}"><div class="page-content">
<div style="max-width:1380px;margin:0 auto;padding:20px 12px 60px;">
<p style="text-align:right;font:12px Inter,sans-serif;padding:12px;"><a href="/workspace.html" style="color:#00d4ff;">Open the app in its own page ↗</a></p>
<iframe id="proto-workspace" title="Proto-Trading strategy workspace" src="/workspace.html" style="width:100%;height:1600px;border:0;display:block;background:#050a0f;" loading="eager"></iframe>
</div></div></sc-if>\n`;
template=template.slice(0,start)+workspace+template.slice(end);
template=template.replace('    this.restoreDemo();',`    this.restoreDemo();
    this._protoResize = event => {
      const frame = document.getElementById('proto-workspace');
      if (!frame || event.source !== frame.contentWindow || event.origin !== location.origin) return;
      if (event.data && event.data.type === 'proto-height' && Number.isFinite(event.data.height)) {
        frame.style.height = Math.max(720, Math.min(30000, event.data.height)) + 'px';
      }
    };
    window.addEventListener('message', this._protoResize);`);
template=template.replace("    window.removeEventListener('mousemove', this._mm);","    window.removeEventListener('mousemove', this._mm);\n    window.removeEventListener('message', this._protoResize);");
// Preserve the original site frame and team profiles; align capability labels with this build.
const replacements=[
  ['Prototype demo: illustrative data and matches. No live AI connection or trade execution.','Hackathon app: rule-based allocation, optional live DeepSeek matching, and local TradingAgents research. Connection status is shown in the workspace. No orders are placed.'],
  ['Try the Strategy Demo','Open the Strategy App'],
  ['Explore the planned building blocks behind the app. This prototype uses sample data.','Explore the building blocks behind the app. The workspace shows which services are connected.'],
  ['The proposed AI layer translates user goals into structured preferences, compares eligible strategy templates, and explains the trade-offs. Live model integration and evaluation are planned; the current prototype demonstrates the matching journey with examples.','The DeepSeek integration compares team-maintained templates within questionnaire constraints and explains the chosen mix. It requires a configured server-side API key. Rules remain available when the model is disconnected.'],
  ['The planned engine combines simple trading rules with market data to estimate portfolio risk and show the effect of allocation changes. Historical analysis would display its data window, assumptions, and costs. Live feeds and validated backtesting remain future work.','Deterministic calculations show target dollar amounts and illustrative shocks. The local research worker can fetch historical data for a cost-aware allocation comparison, with dates and assumptions attached. These results are separate from current TradingAgents research.'],
  ['Demo figures are examples, not verified results','Every result is labelled: rule, scenario, historical comparison, or AI research'],
  ['Five phases toward a simpler AI trading app. The interface is in prototype development; production capabilities are planned.','Five phases toward a simpler AI trading app. The local integration is ready for connection checks; broader deployment and community publishing follow.']
];
for(const [a,b] of replacements)template=template.replaceAll(a,b);
const safe=JSON.stringify(template).replaceAll('</','<\\/');
html=html.replace(tag,()=>'<script type="__bundler/template">\n'+safe+'\n</script>');
await writeFile(path.join(dist,'index.html'),html);
await cp(path.join(root,'public'),dist,{recursive:true});
await cp(path.join(root,'shared'),path.join(dist,'shared'),{recursive:true});
await writeFile(path.join(dist,'prototype-status.html'),renderLimitationsPage(await readFile(path.join(root,'KNOWN-LIMITATIONS.md'),'utf8')));
await writeFile(path.join(dist,'build-info.json'),JSON.stringify({builtAt:new Date().toISOString(),version:'1.0.0',event:'iFX Hack Hong Kong 2026'},null,2));
console.log('Website built: original frame + strategy workspace. No server configuration copied.');
