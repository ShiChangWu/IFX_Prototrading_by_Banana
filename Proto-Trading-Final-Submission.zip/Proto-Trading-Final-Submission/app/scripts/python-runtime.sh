#!/usr/bin/env bash
proto_python_version() {
  local executable="$1" version
  [[ -x "$executable" ]] || return 1
  version="$("$executable" -c 'import sys; print("%d.%d.%d" % sys.version_info[:3])' 2>/dev/null)" || return 1
  [[ "$version" =~ ^3\.(11|12|13)\.[0-9]+$ ]] || return 1
  printf '%s\n' "$version"
}

find_proto_python() {
  local candidate name
  if [[ -n "${PROTO_PYTHON:-}" ]]; then
    if proto_python_version "$PROTO_PYTHON" >/dev/null; then printf '%s\n' "$PROTO_PYTHON"; return 0; fi
    printf '%s\n' 'PROTO_PYTHON must point to an installed Python 3.11, 3.12 or 3.13 executable. Python 3.12 is the reference environment.' >&2
    return 1
  fi
  for name in python3.12 python3.13 python3.11 python3 python; do
    candidate="$(command -v "$name" 2>/dev/null || true)"
    if [[ -n "$candidate" ]] && proto_python_version "$candidate" >/dev/null; then printf '%s\n' "$candidate"; return 0; fi
  done
  printf '%s\n' 'Install Python 3.12 from https://www.python.org/downloads/ or your operating system package manager, then open a new terminal.' 'Python 3.11-3.13 are accepted. Set PROTO_PYTHON to an installed executable if needed. This script does not download a Python runtime.' >&2
  return 1
}
