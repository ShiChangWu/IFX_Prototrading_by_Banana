#!/usr/bin/env bash
# Sourced by foreground launchers; never downloads or installs a runtime.
if [[ -n "${PROTO_NODE:-}" ]]; then
  NODE_RUNTIME="$PROTO_NODE"
else
  NODE_RUNTIME="$(command -v node 2>/dev/null || true)"
fi
if [[ -z "$NODE_RUNTIME" || ! -x "$NODE_RUNTIME" ]]; then
  printf '%s\n' 'Node.js 22+ is required for the connected app. Install it from https://nodejs.org/ and open a new terminal, or set PROTO_NODE to an installed executable.' 'Nothing was downloaded automatically. The offline HTML can be opened without Node.js.' >&2
  return 1
fi
NODE_VERSION="$("$NODE_RUNTIME" --version 2>/dev/null || true)"
if [[ ! "$NODE_VERSION" =~ ^v([0-9]+)\. ]] || (( BASH_REMATCH[1] < 22 )); then
  printf '%s\n' 'The selected Node.js is older than 22 or could not start. Install Node.js 22+ and reopen the terminal.' >&2
  return 1
fi
