const escape = value => String(value).replace(/[&<>"']/g, x => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
export function renderLimitationsPage(markdown, workspaceHref='workspace.html') {
  const inline=value=>escape(value).replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>');
  const lines=markdown.split(/\r?\n/), blocks=[];
  for(let i=0;i<lines.length;i++){
    const line=lines[i];if(!line.trim())continue;
    if(line.startsWith('|')){
      const rows=[];
      while(i<lines.length&&lines[i].startsWith('|')){
        const cells=lines[i].split('|').slice(1,-1).map(value=>value.trim());
        if(!cells.every(value=>/^:?-+:?$/.test(value)))rows.push(cells);i++;
      }
      i--;blocks.push('<div class="table"><table>'+rows.map((row,index)=>'<tr>'+row.map(cell=>`<${index?'td':'th'}>${inline(cell)}</${index?'td':'th'}>`).join('')+'</tr>').join('')+'</table></div>');
    }else if(/^#{1,3} /.test(line)){const m=line.match(/^(#{1,3}) (.*)$/);blocks.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`);}
    else if(line.startsWith('- '))blocks.push(`<p class="item">• ${inline(line.slice(2))}</p>`);
    else blocks.push(`<p>${inline(line)}</p>`);
  }
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Prototype status and limitations · Proto-Trading</title><style>body{margin:0;background:#071018;color:#dceaf3;font:16px/1.65 system-ui,sans-serif}main{max-width:1100px;margin:auto;padding:40px 24px}a{color:#76e6fb}h1{font-size:34px;line-height:1.2}h2{margin-top:35px;color:#fff}p{max-width:90ch}.table{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:14px;border:1px solid #294250;text-align:left;vertical-align:top;min-width:130px}th{background:#102633}code{background:#15303d;padding:2px 5px;border-radius:4px;overflow-wrap:anywhere}.item{margin:8px 0}small{color:#a5bdc9}</style></head><body><main><p><a href="${escape(workspaceHref)}">Open the app →</a></p><small>SMART TRADING FOR EVERYONE · HONEST HACKATHON DEMO</small>${blocks.join('\n')}</main></body></html>`;
}
