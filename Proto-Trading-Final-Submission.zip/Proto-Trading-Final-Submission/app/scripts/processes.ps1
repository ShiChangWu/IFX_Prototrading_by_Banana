# Process identities include creation time so a reused PID never becomes a target.
function ConvertTo-ProtoProcessStamp {
  param($Value)
  if ($null -eq $Value) { return $null }
  try {
    if ($Value -is [datetimeoffset]) { $UtcDate = $Value.UtcDateTime }
    elseif ($Value -is [datetime]) { $UtcDate = $Value.ToUniversalTime() }
    else {
      $Text = [string]$Value
      if ($Text -notmatch '^\d{4}-\d{2}-\d{2}T') { return $null }
      $Parsed = [datetimeoffset]::MinValue
      $Styles = [System.Globalization.DateTimeStyles]::AllowWhiteSpaces -bor [System.Globalization.DateTimeStyles]::AssumeUniversal
      if (-not [datetimeoffset]::TryParse($Text, [System.Globalization.CultureInfo]::InvariantCulture, $Styles, [ref]$Parsed)) { return $null }
      $UtcDate = $Parsed.UtcDateTime
    }
    return $UtcDate.ToString('o', [System.Globalization.CultureInfo]::InvariantCulture)
  } catch { return $null }
}

function Get-ProtoProcessStamp {
  param($ProcessInfo)
  if (-not $ProcessInfo -or -not $ProcessInfo.CreationDate) { return $null }
  return ConvertTo-ProtoProcessStamp $ProcessInfo.CreationDate
}

function Test-ProtoExecutable {
  param($ProcessInfo, [string]$Expected)
  if (-not $ProcessInfo.ExecutablePath -or -not $Expected) { return $false }
  try { return [System.IO.Path]::GetFullPath([string]$ProcessInfo.ExecutablePath) -ieq [System.IO.Path]::GetFullPath($Expected) }
  catch { return $false }
}

function Test-ProtoService {
  param($ProcessInfo, [string]$Kind)
  if (-not $ProcessInfo -or -not $ProcessInfo.CommandLine) { return $false }
  if ($Kind -eq 'research') {
    return (Test-ProtoExecutable $ProcessInfo $PythonRuntime) -and ([string]$ProcessInfo.CommandLine -match '(?:^|\s)"?-m"?\s+"?worker\.main"?(?=\s|$)')
  }
  if ($Kind -eq 'website') {
    $ExpectedScript = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot 'server/index.mjs')).Replace('/', '\')
    $CommandText = ([string]$ProcessInfo.CommandLine).Replace('/', '\')
    return (Test-ProtoExecutable $ProcessInfo $NodeRuntime) -and ($CommandText -match ('(?:^|\s)"?' + [regex]::Escape($ExpectedScript) + '"?(?=\s|$)'))
  }
  if ($Kind -eq 'research-runner') { return Test-ProtoResearchRunner $ProcessInfo }
  return $false
}

function New-ProtoProcessRecord {
  param($ProcessInfo, [string]$Kind)
  if (-not (Test-ProtoService $ProcessInfo $Kind)) { return $null }
  $Stamp = Get-ProtoProcessStamp $ProcessInfo
  if (-not $Stamp) { return $null }
  return @{ id = [int]$ProcessInfo.ProcessId; executable = [string]$ProcessInfo.ExecutablePath; kind = $Kind; createdAt = $Stamp }
}

function Read-ProtoProcessRecords {
  param([string]$RecordFile)
  if (-not (Test-Path -LiteralPath $RecordFile)) { return @() }
  try {
    $FileDate = (Get-Item -LiteralPath $RecordFile).LastWriteTimeUtc
    # Windows PowerShell 5 can emit a JSON array as one pipeline object, while
    # newer PowerShell enumerates it. Assign first, then enumerate consistently.
    $ParsedRecords = Get-Content -LiteralPath $RecordFile -Raw | ConvertFrom-Json
    $Entries = @($ParsedRecords)
  } catch { Write-Host 'Previous launcher records could not be read; they will not be used to stop processes.'; return @() }
  $Records = @()
  $Seen = @{}
  foreach ($Entry in $Entries) {
    try { $ProcessNumber = [int]$Entry.id } catch { continue }
    if ($ProcessNumber -le 0 -or $Entry.kind -notin @('website', 'research', 'research-runner')) { continue }
    # Failed inspection must not erase ownership records for a live service.
    $Found = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $ProcessNumber) -ErrorAction Stop
    if (-not (Test-ProtoService $Found ([string]$Entry.kind))) { continue }
    if (-not (Test-ProtoExecutable $Found ([string]$Entry.executable))) { continue }
    $Stamp = Get-ProtoProcessStamp $Found
    if (-not $Stamp) { continue }
    if ($Entry.createdAt) {
      if ((ConvertTo-ProtoProcessStamp $Entry.createdAt) -ne $Stamp) { continue }
    } elseif (([datetime]$Found.CreationDate).ToUniversalTime() -gt $FileDate) {
      # Legacy records predate their currently reused process ID.
      continue
    }
    $Identity = [string]$ProcessNumber + '|' + $Stamp
    if ($Seen.ContainsKey($Identity)) { continue }
    $Seen[$Identity] = $true
    $Records += New-ProtoProcessRecord $Found ([string]$Entry.kind)
  }
  return @($Records)
}

function Enter-ProtoLauncherLock {
  $Hasher = [System.Security.Cryptography.SHA256]::Create()
  try { $Digest = $Hasher.ComputeHash([System.Text.Encoding]::UTF8.GetBytes([System.IO.Path]::GetFullPath($ProjectRoot).ToLowerInvariant())) }
  finally { $Hasher.Dispose() }
  $Name = 'Local\ProtoTradingLauncher-' + [System.BitConverter]::ToString($Digest).Replace('-', '')
  $Mutex = [System.Threading.Mutex]::new($false, $Name)
  try { $Owned = $Mutex.WaitOne(0) }
  catch [System.Threading.AbandonedMutexException] { $Owned = $true }
  if (-not $Owned) { $Mutex.Dispose(); throw 'Another start or stop operation is already running for this app. Wait for it to finish.' }
  return $Mutex
}

function Write-ProtoProcessRecords {
  param([string]$RecordFile, [array]$Records)
  $Unique = @(); $Seen = @{}
  foreach ($Entry in $Records) {
    if (-not $Entry -or -not $Entry.createdAt) { continue }
    $Stamp = ConvertTo-ProtoProcessStamp $Entry.createdAt
    if (-not $Stamp) { continue }
    $Identity = [string]$Entry.id + '|' + $Stamp
    if ($Seen.ContainsKey($Identity)) { continue }
    $Seen[$Identity] = $true
    $Unique += @{ id = [int]$Entry.id; executable = [string]$Entry.executable; kind = [string]$Entry.kind; createdAt = $Stamp }
  }
  $Temporary = $RecordFile + '.' + [guid]::NewGuid().ToString('N') + '.tmp'
  try {
    [System.IO.File]::WriteAllText($Temporary, (ConvertTo-Json -InputObject @($Unique) -Depth 4), [System.Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $Temporary -Destination $RecordFile -Force
  } finally { if (Test-Path -LiteralPath $Temporary) { Remove-Item -LiteralPath $Temporary -Force } }
}

function Test-ProtoResearchRunner {
  param($ProcessInfo)
  if (-not (Test-ProtoExecutable $ProcessInfo $PythonRuntime)) { return $false }
  $Pattern = '(?:^|\s)"?-m"?\s+"?worker\.ta_runner"?\s+(?<request>"[^"]+"|\S+)\s+(?<result>"[^"]+"|\S+)\s*$'
  $Parsed = [regex]::Match([string]$ProcessInfo.CommandLine, $Pattern)
  if (-not $Parsed.Success) { return $false }
  try {
    $RequestFile = [System.IO.Path]::GetFullPath($Parsed.Groups['request'].Value.Trim('"'))
    $ResultFile = [System.IO.Path]::GetFullPath($Parsed.Groups['result'].Value.Trim('"'))
    $DataRoot = [System.IO.Path]::GetFullPath((Join-Path $ProjectRoot 'data/worker')).TrimEnd('\', '/') + [System.IO.Path]::DirectorySeparatorChar
    return $RequestFile.StartsWith($DataRoot, [System.StringComparison]::OrdinalIgnoreCase) -and $ResultFile.StartsWith($DataRoot, [System.StringComparison]::OrdinalIgnoreCase) -and ([System.IO.Path]::GetDirectoryName($RequestFile) -ieq [System.IO.Path]::GetDirectoryName($ResultFile)) -and ([System.IO.Path]::GetFileName($RequestFile) -ieq 'request.json') -and ([System.IO.Path]::GetFileName($ResultFile) -ieq 'research.json')
  } catch { return $false }
}

function Get-ProtoRunnerDescendants {
  param($RootProcess, [array]$Snapshot, [datetime]$LatestCreation = [datetime]::MaxValue)
  $Queue = New-Object System.Collections.Queue
  $Queue.Enqueue(@{ process = $RootProcess; depth = 0 })
  $FoundChildren = @(); $Seen = @{}
  while ($Queue.Count -gt 0) {
    $ParentEntry = $Queue.Dequeue(); $ParentInfo = $ParentEntry.process
    foreach ($Child in $Snapshot) {
      if ([int]$Child.ParentProcessId -ne [int]$ParentInfo.ProcessId -or $Seen.ContainsKey([string]$Child.ProcessId)) { continue }
      if (-not (Test-ProtoResearchRunner $Child)) { continue }
      $ChildDate = ([datetime]$Child.CreationDate).ToUniversalTime()
      if ($ChildDate -lt ([datetime]$ParentInfo.CreationDate).ToUniversalTime() -or $ChildDate -gt $LatestCreation) { continue }
      $Seen[[string]$Child.ProcessId] = $true
      $FoundChildren += @{ process = $Child; depth = $ParentEntry.depth + 1 }
      $Queue.Enqueue(@{ process = $Child; depth = $ParentEntry.depth + 1 })
    }
  }
  return @($FoundChildren | Sort-Object -Property depth -Descending)
}

function Stop-ProtoVerifiedProcess {
  param($ExpectedProcess)
  $Number = [int]$ExpectedProcess.ProcessId
  $Found = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $Number) -ErrorAction SilentlyContinue
  if (-not $Found -or (Get-ProtoProcessStamp $Found) -ne (Get-ProtoProcessStamp $ExpectedProcess) -or -not (Test-ProtoExecutable $Found ([string]$ExpectedProcess.ExecutablePath))) { return $false }
  $ProcessHandle = $null
  try {
    $ProcessHandle = [System.Diagnostics.Process]::GetProcessById($Number)
    $null = $ProcessHandle.Handle
    # CIM dates may lose sub-microsecond precision. The retained OS handle binds
    # the stop to this process, not whichever process might later reuse its PID.
    if ([Math]::Abs(($ProcessHandle.StartTime.ToUniversalTime() - ([datetime]$Found.CreationDate).ToUniversalTime()).TotalMilliseconds) -gt 1) { return $false }
    Stop-Process -InputObject $ProcessHandle -Force -ErrorAction Stop
    $null = $ProcessHandle.WaitForExit(3000)
    return $true
  } catch { return $false }
  finally { if ($ProcessHandle) { $ProcessHandle.Dispose() } }
}
