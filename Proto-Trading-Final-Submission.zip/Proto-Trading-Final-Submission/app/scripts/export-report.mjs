import {readFile, writeFile, mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const input = process.argv[2] || path.join(root, 'data', 'demo-report.json');
const out = process.argv[3] || path.join(root, 'data', 'Proto-Trading-Demo-Report.html');
const report = JSON.parse(await readFile(input, 'utf8'));
if (!report?.provenance?.engine || !Array.isArray(report.research) || !report.research.length || !['complete', 'partial'].includes(report.status)) {
  throw new Error('Export requires a finished complete or partial research report with recorded engine provenance and asset results.');
}

const array = value => Array.isArray(value) ? value : [];
const finite = value => typeof value === 'number' && Number.isFinite(value);
const describe = value => value == null ? 'Not recorded' : typeof value === 'object' ? JSON.stringify(value) : String(value);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;'}[c]));
const money = value => finite(value) ? new Intl.NumberFormat('en-US', {style:'currency', currency:'USD', maximumFractionDigits:2}).format(value) : 'Unavailable';
const percentage = value => finite(value) ? `${Number(value.toFixed(4))}%` : 'Unavailable';
const recorded = value => value == null || value === '' ? 'Not recorded' : describe(value);
const row = (label, value) => `<tr><th scope="row">${esc(label)}</th><td>${esc(recorded(value))}</td></tr>`;
const list = items => array(items).length ? `<ul>${array(items).map(item => `<li>${esc(describe(item))}</li>`).join('')}</ul>` : '';
function link(value, label) {
  if (typeof value !== 'string') return esc(recorded(label));
  try {
    const url = new URL(value);
    if (!['https:', 'http:'].includes(url.protocol)) return esc(label || value);
    return `<a href="${esc(url.href)}" target="_blank" rel="noopener noreferrer">${esc(label || value)}</a>`;
  } catch { return esc(label || value); }
}
function sources(items) {
  if (!array(items).length) return '';
  return `<ul class="sources">${array(items).map(source => {
    if (!source || typeof source !== 'object') return `<li>${link(source, describe(source))}</li>`;
    const name = source.title || source.name || source.provider || source.url || 'Recorded source';
    const note = [source.author, source.asOf || source.date || source.accessedAt, source.note].filter(Boolean).map(describe).join(' · ');
    return `<li>${link(source.url || source.href, name)}${note ? `<small>${esc(note)}</small>` : ''}</li>`;
  }).join('')}</ul>`;
}
function qualityOf(asset) {
  if (asset?.status === 'error' || asset?.error) return {type:'warning', label:'Research error · review data gap', limited:true};
  if (asset?.dataQuality?.status === 'limited') return {type:'warning', label:'Limited source coverage', limited:true};
  if (asset?.dataQuality?.status === 'not_independently_verified') return {type:'neutral', label:'Sources not independently verified', limited:false};
  return {type:'neutral', label:'Source verification not recorded', limited:false};
}

const limitedAssets = report.research.filter(asset => qualityOf(asset).limited);
const partial = report.status === 'partial' || limitedAssets.length > 0;
const completeRuns = report.research.filter(asset => asset?.status === 'complete').length;
const statusLabel = partial ? 'Partial report · source gaps or unavailable sections' : 'Pipeline complete · evidence limits still apply';
const statusNotice = partial
  ? `This is a partial research report. ${limitedAssets.length ? `${limitedAssets.length} asset result(s) have an error or limited source coverage. ` : ''}Read the visible quality notes and unavailable sections before interpreting the conclusions.`
  : 'The research pipeline finished. This status does not certify the completeness or accuracy of market data or AI conclusions. Source-quality notes are shown for each asset below.';

const profile = report.profile || {}, match = report.match || {}, template = match.template || {};
const snapshot = [
  ['Budget', money(profile.budget)], ['Goal', profile.goal], ['Horizon', profile.horizon], ['Review frequency', profile.review],
  ['Loss willingness / capacity', `${percentage(profile.lossTolerance)} / ${percentage(profile.lossCapacity)}`],
  ['Starting portfolio', profile.startingPortfolio === 'cash' ? 'Cash / no holdings' : profile.startingPortfolio],
  ['Template', template.name], ['Input', profile.prompt || 'No free-text input']
];
const allocations = array(match.allocations).length
  ? `<div class="table-scroll"><table><thead><tr><th>Asset</th><th>Weight</th><th>Target amount</th></tr></thead><tbody>${match.allocations.map(asset => `<tr><td><b>${esc(asset.ticker)}</b><small>${esc(asset.name)}</small></td><td>${esc(percentage(asset.weight))}</td><td>${esc(money(asset.amount))}</td></tr>`).join('')}</tbody></table></div>`
  : '<p>Allocation details were not supplied in this report.</p>';
const stress = match.stress && finite(match.stress.lossPct) && finite(match.stress.lossAmount)
  ? `<p class="notice">${esc(match.stress.label || 'Illustrative stress scenario')}: ${esc(percentage(match.stress.lossPct))} / ${esc(money(match.stress.lossAmount))}. This is not a historical result or a maximum-loss limit. Actual losses can be larger.</p>${list(array(match.stress.assumptions).map(item => `${item.ticker}: ${percentage(item.returnPct)}`))}`
  : '<p class="small">Stress scenario unavailable; no risk figure has been substituted.</p>';

function historicalChart(rawSeries, benchmarkName) {
  const points = array(rawSeries).filter(point => point && point.date && finite(point.value));
  if (points.length < 2) return '';
  const hasBenchmark = points.some((point, i) => i > 0 && finite(point.benchmark) && finite(points[i - 1].benchmark));
  const values = points.flatMap(point => hasBenchmark && finite(point.benchmark) ? [point.value, point.benchmark] : [point.value]);
  const low = values.reduce((a, b) => Math.min(a, b), Infinity), high = values.reduce((a, b) => Math.max(a, b), -Infinity), span = high - low || 1;
  const paths = [];
  for (const key of ['benchmark', 'value']) {
    if (key === 'benchmark' && !hasBenchmark) continue;
    let segment = [];
    const flush = () => {
      if (segment.length > 1) paths.push(`<polyline points="${segment.join(' ')}" fill="none" stroke="${key === 'value' ? '#00c6e8' : '#d5af72'}" stroke-width="2.4"${key === 'benchmark' ? ' stroke-dasharray="6 4"' : ''}/>`);
      segment = [];
    };
    points.forEach((point, i) => {
      if (finite(point[key])) segment.push(`${(68 + 670 * i / (points.length - 1)).toFixed(2)},${(205 - 180 * (point[key] - low) / span).toFixed(2)}`);
      else flush();
    });
    flush();
  }
  const title = `Historical allocation value from ${points[0].date} to ${points.at(-1).date}: ${money(points[0].value)} to ${money(points.at(-1).value)}.${hasBenchmark ? ` ${benchmarkName} is shown as a dashed line where data is available.` : ''}`;
  return `<svg viewBox="0 0 760 235" role="img" aria-labelledby="history-chart-title"><title id="history-chart-title">${esc(title)}</title><path d="M68 25V205H740" fill="none" stroke="#456174"/><text x="0" y="30" fill="#adc3d4" font-size="10">${esc(money(high))}</text><text x="0" y="209" fill="#adc3d4" font-size="10">${esc(money(low))}</text>${paths.join('')}</svg><p class="small">Cyan solid: allocation${hasBenchmark ? ` · Gold dashed: ${esc(benchmarkName)}` : ''} · ${esc(points[0].date)} to ${esc(points.at(-1).date)}</p>`;
}
function renderBacktest(backtest = {}) {
  if (backtest.status !== 'complete') return `<span class="status warning">Historical calculation unavailable</span><p>${esc(backtest.error || 'Historical data or calculation was not supplied. No performance figures have been substituted.')}</p>${list(backtest.warnings)}`;
  const m = backtest.metrics || {}, benchmark = backtest.benchmark || {};
  const rows = [
    ['Period', `${recorded(backtest.start)} → ${recorded(backtest.end)}`], ['Starting value', money(m.startingValue)], ['Ending value', money(m.endingValue)],
    ['Total return', percentage(m.totalReturnPct)], ['Annualized return', percentage(m.cagrPct)], ['Annualized volatility', percentage(m.annualizedVolatilityPct)],
    ['Largest historical peak-to-trough fall', percentage(m.maxDrawdownPct)], ['Simulated transaction costs', money(m.transactionCosts)]
  ];
  if (benchmark.metrics) rows.push([`${benchmark.ticker || 'Benchmark'} total return`, percentage(benchmark.metrics.totalReturnPct)], [`${benchmark.ticker || 'Benchmark'} largest peak-to-trough fall`, percentage(benchmark.metrics.maxDrawdownPct)]);
  return `<p class="notice">This is a historical allocation comparison using the stated rules. It does not test today’s TradingAgents views or the timing signals in a strategy template.</p><p>${esc(backtest.methodology ? describe(backtest.methodology) : 'Calculation methodology was not recorded.')}</p>${historicalChart(backtest.series, benchmark.ticker || benchmark.name || 'Benchmark')}<table>${rows.map(([a, b]) => row(a, b)).join('')}</table>${backtest.assumptions ? `<details><summary>Calculation assumptions</summary><p class="report-text">${esc(describe(backtest.assumptions))}</p></details>` : ''}${list(backtest.warnings)}${sources(backtest.dataSources)}${backtest.fetchedAt ? `<p class="small">Data retrieved ${esc(backtest.fetchedAt)}</p>` : ''}`;
}

const outlook = array(report.outlook).length ? report.outlook.map(view => `<article><span class="label">${esc(view.horizon || 'Horizon not supplied')}</span><h3>${view.status === 'available' ? 'Conditional research view' : 'Insufficient horizon evidence'}</h3><p>${esc(view.summary || 'No supported view was supplied for this horizon.')}</p>${array(view.evidence).map(e => typeof e === 'object' && e !== null ? `<blockquote>${esc(e.quote || describe(e))}<small>${esc([e.ticker, e.section, e.sourceId].filter(Boolean).join(' · '))}</small></blockquote>` : `<blockquote>${esc(describe(e))}</blockquote>`).join('')}${list(view.conditions)}</article>`).join('') : '<p>No time-horizon outlook was supplied.</p>';
const outlookMethod = report.outlookMethod && typeof report.outlookMethod === 'object'
  ? `<p class="small">Outlook preparation: ${esc(report.outlookMethod.type === 'local-editorial-evidence-review' ? 'Local review of saved evidence' : recorded(report.outlookMethod.type))}${report.outlookMethod.model ? ' · ' + esc(report.outlookMethod.model) : ''} · ${esc(recorded(report.outlookMethod.generatedAt))}</p><p class="small">${esc(report.outlookMethod.description || 'This records the separate outlook preparation step; it does not change the research engine provenance.')}</p>` : '';
const research = report.research.map(asset => {
  const quality = qualityOf(asset), data = asset?.dataQuality || {};
  const engineStatus = data.engineCompleted === true ? 'Engine processing finished' : data.engineCompleted === false ? 'Engine processing did not finish' : `Asset run status: ${recorded(asset?.status)}`;
  return `<article class="asset-result"><header class="asset-heading"><h3>${esc(asset?.ticker || 'Asset not recorded')}</h3><span class="status ${quality.type}">${esc(quality.label)}</span></header><p class="small">${esc(engineStatus)} · Decision text: ${esc(recorded(asset?.decision))}</p>${data.message ? `<p class="${quality.limited ? 'notice' : 'small'}">${esc(data.message)}</p>` : ''}${asset?.error ? `<p class="notice">Research error: ${esc(describe(asset.error))}</p>` : ''}${array(data.affectedSections).length ? `<p class="small">Affected sections: ${esc(data.affectedSections.map(describe).join(', '))}</p>` : ''}${list(asset?.warnings)}<details><summary>Read ${esc(asset?.ticker || 'asset')} research text</summary>${array(asset?.sections).length ? asset.sections.map(s => `<h3>${esc(s.title || 'Analysis')}</h3><div class="report-text">${esc(s.text || 'No text supplied.')}</div>`).join('') : '<p>No research sections were supplied.</p>'}</details></article>`;
}).join('');

function renderHedge(review) {
  if (!review || typeof review !== 'object') return '';
  const comparison = review.historicalComparison || review.comparison;
  let body = `<p class="small">${review.allocated === true ? 'Review the recorded allocation details.' : 'No inverse ETF automatically allocated.'}</p>${review.message ? `<p>${esc(review.message)}</p>` : ''}${review.assessment ? `<p>${esc(review.assessment)}</p>` : ''}`;
  if (comparison) {
    if (comparison.status !== 'complete') body += `<p class="notice">${esc(comparison.error || 'The historical inverse ETF comparison is unavailable. No comparison returns have been substituted.')}</p>`;
    else {
      body += `<h3>A short historical window</h3><p>${esc(recorded(comparison.start))} → ${esc(recorded(comparison.end))}${finite(comparison.sessions) ? ` · ${esc(comparison.sessions)} trading sessions` : ''}</p><p class="small">This window cannot establish future protection or suitability. The scenarios below are research comparisons, not additions to your matched allocation.</p>`;
      const scenarios = [comparison.baseline, comparison.cashComparator, ...array(comparison.scenarios)].filter(item => item && typeof item === 'object');
      if (scenarios.length) body += `<div class="table-scroll"><table class="hedge-table"><thead><tr><th>Scenario</th><th>Return</th><th>Largest fall</th><th>Ending value</th></tr></thead><tbody>${scenarios.map(s => {
        const weights = s.weightsPct && typeof s.weightsPct === 'object' ? Object.entries(s.weightsPct).map(([ticker, weight]) => `${ticker} ${percentage(weight)}`).join(' · ') : '';
        return `<tr><td><b>${esc(s.label || s.ticker || 'Scenario')}</b>${weights ? `<small>${esc(weights)}</small>` : ''}</td><td>${esc(percentage(s.returnPct))}</td><td>${esc(percentage(s.maxDrawdownPct))}</td><td>${esc(money(s.endingValue))}</td></tr>`;
      }).join('')}</tbody></table></div>`;
      if (array(comparison.products).length) body += `<h3>Actual inverse ETF returns in this window</h3>${list(comparison.products.map(p => `${p.ticker || 'ETF'}${finite(p.dailyTargetMultiple) ? ` (${p.dailyTargetMultiple}× daily target)` : ''}: ${percentage(p.returnPct)} return; ${percentage(p.maxDrawdownPct)} peak-to-trough fall.`))}`;
      if (comparison.methodology) body += `<p class="small">${esc(describe(comparison.methodology))}</p>`;
      if (array(comparison.scenarios).some(s => finite(s.approximateInitialInverseExposurePct))) body += '<p class="notice">These scenarios compare approximately equal inverse exposure at the start. Daily resets, changing prices and compounding cause the exposures to drift. A −2× or −3× target applies to one day, not the entire historical window.</p>';
    }
    body += list(comparison.warnings) + sources(comparison.dataSources);
    if (comparison.fetchedAt) body += `<p class="small">Comparison data retrieved ${esc(comparison.fetchedAt)}</p>`;
  }
  body += sources(review.sources);
  if (review.source) body += `<p class="small">${link(review.source, 'Read about leveraged and inverse ETFs')}</p>`;
  return `<section><h2>Compare hedging choices</h2>${body}</section>`;
}

const p = report.provenance;
const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark"><title>Proto-Trading · ${partial ? 'Partial' : 'Completed'} Saved Research Report</title><style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#07101b;color:#e1edf5;font:15px/1.75 Segoe UI,Arial,sans-serif}main{max-width:1080px;margin:auto;padding:46px 30px}.page-header{border-top:3px solid #00c6e8;padding:26px 0}.label{font:11px/1.7 Consolas,monospace;color:#00d4ee;letter-spacing:.13em}h1{font-size:42px;line-height:1.18;letter-spacing:-.04em}h2{margin:0 0 18px;font-size:26px}h3{font-size:17px;line-height:1.5}p{color:#adc3d4}.small,small{font-size:11px;color:#91aabf}small{display:block}section{padding:28px;background:#0c1827;border:1px solid #234055;margin:22px 0}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.grid article{background:#08131f;padding:18px;border:1px solid #234055;min-width:0}.table-scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:13px 10px;border-bottom:1px solid #234055;overflow-wrap:anywhere}td:last-child{text-align:right}th{font-size:11px;color:#9eb7ca}th[scope=row]{font-size:13px;font-weight:500}ul{padding-left:20px;font-size:13px;color:#b5c7d4}li+li{margin-top:8px}a{color:#36d6ed;overflow-wrap:anywhere}blockquote{margin:16px 0;padding-left:14px;border-left:2px solid #42788e;font-size:12px;color:#b4cadb}.report-text{white-space:pre-wrap;overflow-wrap:anywhere;font-size:13px;color:#b7cbd9}details{padding:20px 0;border-top:1px solid #234055}summary{cursor:pointer;color:#37d3ea;font-size:14px}summary:focus-visible,a:focus-visible{outline:2px solid #00c6e8;outline-offset:4px}svg{width:100%;display:block;margin-top:22px}footer{color:#93abbc;font-size:12px;padding:20px 0}.notice{padding:16px 20px;border-left:3px solid #e6ba77;background:#201d17;color:#e4cba5;font-size:13px;overflow-wrap:anywhere}.status{display:inline-block;font-size:11px;border:1px solid #386075;background:#0d2633;color:#a6e5ed;padding:5px 10px;line-height:1.7}.status.warning{border-color:#785c35;background:#282014;color:#f2cc93}.status.neutral{background:#152331;color:#b4c8d8;border-color:#345063}.asset-result{padding:22px 0;border-top:1px solid #234055}.asset-heading{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap}.asset-heading h3{margin:0;font-size:19px}.asset-result details{margin-top:15px}.hedge-table{min-width:540px}.sources{overflow-wrap:anywhere}@media(max-width:700px){main{padding:24px 16px}h1{font-size:32px}.grid{grid-template-columns:1fr}section{padding:20px}}@media print{:root{color-scheme:light}body{background:#fff;color:#172b3a}main{max-width:none;padding:0}section,.grid article{background:#fff;border:1px solid #b9c6ce}p,li,td,.report-text,small,.small{color:#263e4e}h1{font-size:30px}a{color:#006d80}.notice,.status,.status.warning,.status.neutral{background:#fff9ee;color:#655133;border-color:#a18b66}.asset-heading{break-after:avoid}.asset-result{break-inside:avoid}.hedge-table{min-width:0}.table-scroll{overflow:visible}}
</style></head><body><main><header class="page-header"><div class="label">PROTO-TRADING · BUILT FOR IFX HACK HONG KONG 2026</div><h1>Understand the portfolio.<br>See the evidence.</h1><p>${esc(report.title || 'Saved portfolio research')}</p><span class="status ${partial ? 'warning' : 'neutral'}">${esc(statusLabel)}</span><p class="small">Declared report status: ${esc(report.status)} · ${completeRuns} / ${report.research.length} asset runs completed</p><p class="small">Generated ${esc(recorded(report.generatedAt))} · Analysis date ${esc(recorded(report.analysisDate))} · Model ${esc(recorded(p.model))}</p></header><p class="notice">${esc(statusNotice)}</p><p class="small">Saved research output for the input snapshot below. This is not a live analysis of a changed questionnaire. No orders were placed.</p><section><h2>Your starting point</h2><table>${snapshot.map(([a, b]) => row(a, b)).join('')}</table></section><section><h2>Proposed allocation for review</h2>${allocations}${list(match.reasons)}${stress}${list(match.warnings)}</section><section><h2>Future direction, by time horizon</h2><p class="small">Conditional views require evidence for their stated horizon. Unavailable views remain unavailable.</p>${outlookMethod}<div class="grid">${outlook}</div></section><section><h2>Historical allocation comparison</h2>${renderBacktest(report.backtest || {})}</section>${renderHedge(report.hedgeReview)}<section><h2>Review conditions</h2>${array(match.rebalance?.conditions).length ? list(match.rebalance.conditions) : '<p>Review conditions were not recorded.</p>'}</section><section><h2>Research behind the candidates</h2><p class="small">Data-quality labels apply even when an engine run finished. Open a section to read the underlying AI text; it does not silently change the displayed allocation.</p>${research}</section><section><h2>Sources &amp; limitations</h2><p>${link(p.repository, `${p.engine} repository`)}</p><p class="small">Engine commit ${esc(recorded(p.commit))} · Template version ${esc(recorded(p.templateVersion))}</p>${template.source ? sources([template.source]) : ''}${sources(p.dataSources)}${list([...array(p.warnings), ...array(report.limitations)])}</section><footer>WU Shi Chang · YU Zhuowei · HUANG Weiting · WEN Wai Hai<br>Financial access begins with clearer choices.</footer></main></body></html>`;

await mkdir(path.dirname(out), {recursive:true});
await writeFile(out, html);
console.log(`Saved an offline HTML report (${partial ? 'partial; review source gaps' : 'pipeline complete; source verification remains qualified'}).`);
