$ErrorActionPreference = 'Stop'
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$Candidates = @()
if ($env:PROTO_NODE) {
  if (-not (Test-Path -LiteralPath $env:PROTO_NODE -PathType Leaf)) { throw 'PROTO_NODE does not identify an installed Node.js executable. Set it to a valid full path, or remove it and install Node.js 22+ from https://nodejs.org/.' }
  $Candidates += $env:PROTO_NODE
} else {
  $NodeCommand = Get-Command node -CommandType Application -ErrorAction SilentlyContinue
  if ($NodeCommand) { $Candidates += $NodeCommand.Source }
  # An already installed local fallback is optional; it is never downloaded.
  if ($env:USERPROFILE) { $Candidates += (Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe') }
}
$NodeRuntime = $null
foreach ($Candidate in ($Candidates | Select-Object -Unique)) {
  if (-not (Test-Path -LiteralPath $Candidate -PathType Leaf)) { continue }
  try {
    $VersionOutput = & $Candidate --version 2>$null
    $VersionExitCode = $LASTEXITCODE
    $VersionText = $VersionOutput | Select-Object -First 1
    if ($VersionExitCode -eq 0 -and $VersionText -match '^v(\d+)\.' -and [int]$Matches[1] -ge 22) { $NodeRuntime = [System.IO.Path]::GetFullPath($Candidate); break }
  } catch { }
}
if (-not $NodeRuntime) { throw 'Node.js 22 or later is required for the connected app. Install it from https://nodejs.org/, enable Add to PATH, and reopen this launcher. Nothing was downloaded automatically. The offline HTML remains usable without Node.js.' }
$PythonRuntime = Join-Path $ProjectRoot '.venv/Scripts/python.exe'
. (Join-Path $PSScriptRoot 'processes.ps1')
