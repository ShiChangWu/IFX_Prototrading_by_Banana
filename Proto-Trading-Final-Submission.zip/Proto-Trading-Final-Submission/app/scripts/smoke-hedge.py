"""Optional real-data check. No model calls and no orders."""
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from worker.hedging import historical_hedge_assessment

result = historical_hedge_assessment('minus3', 10000)
target = root / 'data' / 'inverse-etf-comparison.json'
target.parent.mkdir(parents=True, exist_ok=True)
target.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': result.get('status'), 'start': result.get('start'), 'end': result.get('end'), 'error': result.get('error')}))
