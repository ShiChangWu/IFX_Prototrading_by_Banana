import { readFile, writeFile } from 'node:fs/promises';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { seedBundledExample } from './seed-example.mjs';

export async function configureLocal(root, { log = console.log } = {}) {
  const file = path.join(root, '.env.local');
  let created = false;
  // Exclusive creation also preserves an existing key if two launchers race.
  try {
    const template = await readFile(path.join(root, '.env.example'), 'utf8');
    const text = template.replace('WORKER_SECRET=', 'WORKER_SECRET=' + randomBytes(48).toString('base64url'));
    await writeFile(file, text, { mode: 0o600, flag: 'wx' });
    created = true;
    log('Local configuration created. Add your DeepSeek key in .env.local.');
  } catch (error) {
    if (error.code !== 'EEXIST') throw error;
    log('Local configuration already exists; kept unchanged.');
  }
  const example = await seedBundledExample(root);
  if (example.status === 'seeded') log('The bundled dated research report is available under saved examples.');
  return { created, example };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
  try { await configureLocal(root); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
