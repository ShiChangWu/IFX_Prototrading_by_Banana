import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';

const folder = path.resolve(process.argv[2] || '');
if (!process.argv[2]) throw new Error('Pass the extracted delivery folder.');
const manifestFile = path.join(folder, 'MANIFEST.json');
const manifest = JSON.parse(await fs.readFile(manifestFile, 'utf8'));
const listed = new Set(manifest.files.map(item => item.path));
assert.equal(listed.size, manifest.files.length, 'Manifest has no duplicate entries');
const personalFiles = new Set(['OPEN-DEMO.html', 'DEMO-README.txt', 'START-DEMO.cmd', 'START-DEMO.ps1', 'CHECK-DEMO.cmd', 'LOCAL-DEMO-CONNECTION.json', 'demo-preflight.mjs']);
async function auditTree(directory) {
  for (const item of await fs.readdir(directory, { withFileTypes: true })) {
    const target = path.join(directory, item.name), relative = path.relative(folder, target).split(path.sep).join('/');
    assert(!item.isSymbolicLink(), `No linked files in the submission: ${relative}`);
    assert(!['.env.local', '.env', '.local', '.venv', '.git', 'presentation'].includes(item.name) && !personalFiles.has(item.name), `No personal demo or runtime state: ${relative}`);
    if (item.isDirectory()) await auditTree(target);
    else assert(relative === 'MANIFEST.json' || listed.has(relative), `Every delivered file is covered by the manifest: ${relative}`);
  }
}
await auditTree(folder);
for (const item of manifest.files) {
  const target = path.resolve(folder, item.path);
  assert(target.startsWith(folder + path.sep), 'Manifest paths stay inside package');
  const data = await fs.readFile(target);
  assert.equal(createHash('sha256').update(data).digest('hex'), item.sha256, `File integrity: ${item.path}`);
}
for (const page of ['START-HERE.html', 'SETUP.html', 'WORKFLOW-AND-GAPS.html', 'KNOWN-LIMITATIONS.html', 'web/prototype-status.html']) {
  const html = await fs.readFile(path.join(folder, page), 'utf8');
  for (const match of html.matchAll(/href="([^"]+)"/g)) {
    if (/^(?:https?:|#)/.test(match[1])) continue;
    const linkPath=path.resolve(folder,path.dirname(page),match[1]);
    assert(linkPath.startsWith(folder+path.sep),'Entry links stay inside the delivery');
    assert((await fs.stat(linkPath)).isFile(), `Local link resolves: ${page} → ${match[1]}`);
  }
}
const portable = await fs.readFile(path.join(folder, 'web/workspace.html'), 'utf8');
assert(portable.includes('id="prototype-notes"')&&portable.includes('href="prototype-status.html"'),'Offline app visibly links its limitation notes');
assert((await fs.readFile(path.join(folder,'KNOWN-LIMITATIONS.txt'),'utf8')).includes('Actual consequence'),'Text notes explain consequences, not only connection labels');
assert((await fs.readFile(path.join(folder,'app/.env.example'),'utf8')).includes('EMAIL_DELIVERY_ENABLED=false'),'Submission leaves mail delivery off');
const scripts = [...portable.matchAll(/<script>([\s\S]*?)<\/script>/g)];
assert.equal(scripts.length, 1, 'Exactly one inline portable app');
new vm.Script(scripts[0][1]);
assert(!/<(?:script|link)[^>]+(?:src|href)="\//.test(portable), 'No server-root script or CSS dependency');
assert(!/^\s*(?:import|export)\s/m.test(scripts[0][1]), 'Offline code contains no unresolved module imports');
assert(scripts[0][1].includes('protoModules["shared/school-scenarios.mjs"]'), 'Strategy-specific conditions are included in the offline bundle');
assert(scripts[0][1].includes('protoModules["public/demo-report.js"]'), 'Prepared-report popup is included in the offline bundle');
for (const marker of ['readResearchSelection', 'research-input-preview', 'recordedResearchInputs', 'openGeneratedReport', 'openGenerated']) {
  assert(scripts[0][1].includes(marker), `Offline bundle includes the current selected-stock and report controls: ${marker}`);
}
assert(!/protoModules\["(?:server|shared)\/research-selection\.mjs"\]/.test(scripts[0][1]), 'The selected-research server contract is never bundled into browser code');
for (const file of ['app/public/workspace.html', 'app/dist/workspace.html', 'web/workspace.html']) {
  const html = await fs.readFile(path.join(folder, file), 'utf8');
  const card = html.indexOf('id="demo-prepared-report"'), optional = html.indexOf('id="research-tools"');
  assert(card >= 0 && optional > card, `${file}: prepared report is visible before the optional analysis controls`);
  assert(html.includes('id="open-demo-report"') && html.includes('Opens immediately. No new analysis.'), `${file}: report has an immediate opening action`);
  assert(html.includes('data-report-src="prepared-report.html"') && html.includes('href="prepared-report.html"'), `${file}: report paths are portable and relative`);
  assert(html.includes('sandbox="allow-popups allow-popups-to-escape-sandbox"'), `${file}: saved document cannot execute scripts`);
  assert(html.includes('id="demo-generated-report"') && html.includes('id="demo-report-own-page"'), `${file}: actual generated research has its own popup content, separate from the prepared iframe`);
  assert(/<a\b[^>]*id="open-demo-report"[^>]*href="prepared-report\.html"/.test(html), `${file}: the prepared report has a working link when dialogs are unsupported`);
  assert(!/(?:file:\/\/\/|[A-Z]:[\\/]Users[\\/]|\/presentation\/)/i.test(html), `${file}: no personal computer or presentation route dependency`);
}
const shell = await fs.readFile(path.join(folder, 'web/index.html'), 'utf8');
const template = JSON.parse(shell.match(/<script type="__bundler\/template">\s*([\s\S]*?)\s*<\/script>/)[1]);
assert(template.includes('src="workspace.html"') && !template.includes('src="/workspace.html"'));
assert(template.includes('Smart Trading for Everyone.'));
const report = JSON.parse(await fs.readFile(path.join(folder, 'reports/research-report.json'), 'utf8'));
assert.equal(report.status, manifest.reportStatus);
assert.equal(report.id, manifest.reportId);
const vendorRevision = (await fs.readFile(path.join(folder, 'app/VENDOR-REVISION.txt'), 'utf8')).trim();
assert.match(vendorRevision, /^[a-f0-9]{40}$/i, 'Packaged TradingAgents source has a specific pinned revision');
const reportRevision = String(report.provenance.commit || '').trim();
const reportRevisionKnown = reportRevision !== '' && reportRevision.toLowerCase() !== 'unknown';
if (reportRevisionKnown) assert.equal(reportRevision, vendorRevision, 'A recorded research revision agrees with the packaged source pin');
else console.log('Research provenance limitation: the saved report did not record its TradingAgents revision. The package source pin is documented separately; no research revision is inferred.');
const reportJson = await fs.readFile(path.join(folder, 'reports/research-report.json'));
for (const file of ['app/examples/prepared-report.json', 'app/examples/demo-report.json']) {
  assert(reportJson.equals(await fs.readFile(path.join(folder, file))), `Same approved research JSON: ${file}`);
}
const embeddedReports = JSON.parse(scripts[0][1].match(/^window\.PROTO_DEMO_REPORTS = (.*);$/m)?.[1] || 'null');
assert.deepEqual(embeddedReports, [report], 'The offline example is exactly the approved report');
const reportHtml = await fs.readFile(path.join(folder, 'reports/Proto-Trading-Demo-Report.html'));
for (const file of ['app/public/prepared-report.html', 'app/dist/prepared-report.html', 'web/prepared-report.html']) {
  assert(reportHtml.equals(await fs.readFile(path.join(folder, file))), `Same prepared report in every entry: ${file}`);
}
assert(!/<(?:script|iframe)\b|\bon(?:load|error)\s*=/i.test(reportHtml.toString()), 'The prepared document is static, escaped HTML');
for (const file of ['app/shared/school-scenarios.mjs', 'app/dist/shared/school-scenarios.mjs', 'app/server/research-selection.mjs', 'app/public/demo-report.js', 'app/public/demo-report.css']) {
  assert((await fs.stat(path.join(folder, file))).isFile(), `New runtime dependency is packaged: ${file}`);
}
for (const file of ['app/dist/server/research-selection.mjs', 'app/dist/shared/research-selection.mjs', 'web/server/research-selection.mjs', 'web/shared/research-selection.mjs']) {
  await assert.rejects(fs.access(path.join(folder, file)), { code: 'ENOENT' }, `Server-only validation is absent from public output: ${file}`);
}
for (const file of ['app/public/workspace.js', 'app/dist/workspace.js']) {
  const source = await fs.readFile(path.join(folder, file), 'utf8');
  for (const marker of ['Research your selected stocks', 'research-input-preview', 'selectedStockResearch', 'recordedResearchInputs', 'openGeneratedReport']) {
    assert(source.includes(marker), `${file}: selected-stock research and generated-report opening are present`);
  }
}
for (const file of ['app/vendor/TradingAgents/LICENSE', 'app/vendor/TradingAgents/tradingagents/assets/tauric-logo.svg', 'app/vendor/TradingAgents/cli/static/welcome.txt']) assert((await fs.stat(path.join(folder, file))).isFile());

// A separate, disposable copy proves the receiver never needs the author's
// original folder or credentials. Do not run configuration in the shareable ZIP.
const scratch = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-delivery-check-'));
const app = path.join(scratch, 'app');
await fs.cp(path.join(folder, 'app'), app, { recursive: true });
execFileSync(process.execPath, ['scripts/configure.mjs'], { cwd: app, stdio: 'pipe', windowsHide: true });
const firstConfig = await fs.readFile(path.join(app, '.env.local'));
const firstState = await fs.readFile(path.join(app, '.local/state.json'));
execFileSync(process.execPath, ['scripts/configure.mjs'], { cwd: app, stdio: 'pipe', windowsHide: true });
assert(firstConfig.equals(await fs.readFile(path.join(app, '.env.local'))), 'Second launch retains new recipient configuration');
assert(firstState.equals(await fs.readFile(path.join(app, '.local/state.json'))), 'Second launch retains recipient state');
execFileSync(process.execPath, ['scripts/build.mjs'], { cwd: app, stdio: 'pipe', windowsHide: true });
assert(reportHtml.equals(await fs.readFile(path.join(app, 'dist/prepared-report.html'))), 'Clean rebuild preserves the prepared report');
const { bundleWorkspace } = await import(pathToFileURL(path.join(app, 'scripts/portable-bundle.mjs')));
assert.equal((await bundleWorkspace(app, [report])).html, portable, 'The portable app is reproducible from the recipient source and approved report');
const freshExport = path.join(scratch, 'regenerated-report.html');
execFileSync(process.execPath, ['scripts/export-report.mjs', 'examples/prepared-report.json', freshExport], { cwd: app, stdio: 'pipe', windowsHide: true });
assert(reportHtml.equals(await fs.readFile(freshExport)), 'The prepared HTML is reproducible from the packaged approved JSON');
// Execute the delivered regression files in this recipient copy. These tests
// use temporary stores and synthetic worker messages, not the real worker.
// Blocking networking additionally prevents an accidental provider or mail call.
const networkGuard = path.join(scratch, 'forbid-provider-network.mjs');
await fs.writeFile(networkGuard, `import http from 'node:http';
import https from 'node:https';
import net from 'node:net';
import tls from 'node:tls';
import {syncBuiltinESMExports} from 'node:module';
const forbidden = () => { throw new Error('Network calls are forbidden in clean-copy regression checks.'); };
globalThis.fetch = forbidden;
http.request = http.get = https.request = https.get = forbidden;
net.connect = net.createConnection = tls.connect = forbidden;
syncBuiltinESMExports();
`);
const regressionFiles = [
  'tests/research-selection.test.mjs',
  'tests/research-selection-ui.test.mjs',
  'tests/research-view-state.test.mjs',
  'tests/demo-report.test.mjs',
  'tests/school-lab-ui.test.mjs',
  'tests/school-scenarios.test.mjs',
  'tests/portable-bundle.test.mjs',
];
for (const file of regressionFiles) assert((await fs.stat(path.join(app, file))).isFile(), `Recipient regression is packaged: ${file}`);
const regressionOutput = execFileSync(process.execPath, ['--import', pathToFileURL(networkGuard).href, '--test', '--test-reporter=tap', ...regressionFiles], { cwd: app, encoding: 'utf8', stdio: 'pipe', windowsHide: true, timeout: 60000, maxBuffer: 8 * 1024 * 1024 });
const regressionCount = Number(regressionOutput.match(/^# tests (\d+)$/m)?.[1]);
assert(Number.isInteger(regressionCount) && regressionCount > 0 && /^# fail 0$/m.test(regressionOutput), 'Packaged selected-research, popup and ten-approach regressions pass');
const { APP_DIR, configuration } = await import(pathToFileURL(path.join(app, 'server/config.mjs')));
assert.equal(APP_DIR, app, 'The copied server resolves only the recipient app directory');
const { createApi } = await import(pathToFileURL(path.join(app, 'server/api.mjs')));
const { LocalStore } = await import(pathToFileURL(path.join(app, 'server/store.mjs')));
const config = configuration({ LOCAL_STORE_PATH: path.join(app, '.local/state.json') });
const api = createApi({ config, store: new LocalStore(config.storeFile), fetchImpl: () => { throw new Error('No external API is allowed in package verification.'); } });
const examples = await (await api(new Request('http://127.0.0.1:8787/api/examples'), { clientIp: 'delivery-check' })).json();
assert.equal(examples.reports.length, 1); assert.equal(examples.reports[0].id, report.id);
const loaded = await (await api(new Request(`http://127.0.0.1:8787/api/examples/${report.id}`), { clientIp: 'delivery-check' })).json();
assert.deepEqual(loaded.report, report);
const response = await api(new Request('http://127.0.0.1:8787/api/match', { method: 'POST', headers: { 'Content-Type': 'application/json', Origin: 'http://127.0.0.1:8787' }, body: JSON.stringify({ profile: report.profile }) }), { clientIp: 'delivery-check' });
assert.equal(response.status, 200);
const matched = await response.json();
assert.equal(matched.explanation.status, 'unavailable');
assert.equal(matched.match.allocations.reduce((sum, item) => sum + Math.round(item.amount * 100), 0), report.profile.budget * 100);
// Exercise the copied HTTP server itself on an OS-assigned loopback port. This
// never starts a worker, reads the author's configuration or contacts a provider.
const { localServer } = await import(pathToFileURL(path.join(app, 'server/index.mjs')));
let forbiddenCalls = 0;
assert.equal(config.deepseekKey, '');
assert.equal(config.workerSecret, '');
assert.equal(config.emailDeliveryEnabled, false);
const server = localServer(config, { store: new LocalStore(config.storeFile), fetchImpl() { forbiddenCalls++; throw new Error('Provider calls are forbidden during delivery HTTP checks.'); } });
try {
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  config.port = server.address().port;
  assert.notEqual(config.port, 8787, 'The verification server never replaces the author\'s app');
  const origin = `http://127.0.0.1:${config.port}`;
  for (const [route, file, contentType] of [
    ['/workspace.html', 'dist/workspace.html', 'text/html'],
    ['/workspace.js', 'dist/workspace.js', 'text/javascript'],
    ['/shared/school-scenarios.mjs', 'shared/school-scenarios.mjs', 'text/javascript'],
    ['/demo-report.js', 'dist/demo-report.js', 'text/javascript'],
    ['/prepared-report.html', 'dist/prepared-report.html', 'text/html'],
  ]) {
    const served = await fetch(origin + route, { redirect: 'error', signal: AbortSignal.timeout(5000) });
    assert.equal(served.status, 200, `Copied HTTP server serves ${route}`);
    assert.equal(served.headers.get('content-type'), `${contentType}; charset=utf-8`, `Correct MIME type: ${route}`);
    assert(Buffer.from(await served.arrayBuffer()).equals(await fs.readFile(path.join(app, file))), `HTTP bytes equal recipient's rebuilt file: ${route}`);
  }
  const healthResponse = await fetch(origin + '/api/health', { redirect: 'error', signal: AbortSignal.timeout(5000) });
  assert.equal(healthResponse.status, 200);
  assert.match(healthResponse.headers.get('content-type'), /^application\/json\b/);
  const health = await healthResponse.json();
  assert.equal(health.ok, true);
  assert.equal(health.mode, 'local');
  assert.equal(health.deepseekConfigured, false);
  assert.equal(health.researchConfigured, false);
  assert.equal(health.selectedStockResearch, true, 'The copied server supports the selected-stock contract before any credentials are configured');
  assert.equal(health.alerts.emailDeliveryEnabled, false);
  for (const route of ['/server/research-selection.mjs', '/shared/research-selection.mjs']) {
    const hidden = await fetch(origin + route, { redirect: 'error', signal: AbortSignal.timeout(5000) });
    assert.equal(hidden.status, 404, `The copied server does not expose its input-validation module: ${route}`);
  }
  assert.equal(forbiddenCalls, 0, 'No provider or mail request during the clean-copy HTTP check');
} finally {
  server.closeAllConnections();
  if (server.listening) await new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
}
console.log(`Verified ${manifest.files.length} files, no personal demo dependencies, entry links, complete offline modules, distinct prepared/generated report controls, selected-stock preview, identical prepared reports, reproducible report export, vendor assets, clean-copy configure/rebuild, ${regressionCount} packaged regression checks, local HTTP assets/health and rule API with the exact saved report. No external API calls.`);
console.log('Browser visual checks and fresh Python dependency installation remain unverified.');
if (process.argv.includes('--record')) {
  const text = `Proto-Trading delivery validation\nChecked: ${new Date().toISOString()}\n\nPASS: All ${manifest.files.length} existing packaged files match SHA-256 manifest.\nPASS: Local entry/setup/workflow links resolve; standalone script parses.\nPASS: Preserved website uses a relative workspace iframe; title matches Smart Trading for Everyone.\nPASS: Pinned TradingAgents source, license and runtime assets are present.\nPASS: Independent temporary copy creates its own configuration and imports only the public example.\nPASS: Repeated setup preserves the receiver's state and configuration.\nPASS: Copied app rebuilds and its API returns the exact saved report and correct rule allocation with external calls forbidden.\nPASS: Known local credentials, private tokens and excluded path names were checked during packaging.\n\nAdditional source regression checks: Node API/rules/upload/portable bundle tests, UI contract checks, Python worker, quick-market, indicator and security-identity tests, and Windows launcher record tests passed in the development environment. These are code/logic checks, not visual screenshots.\n\nNOT VERIFIED: Browser visual/interaction acceptance was unavailable in this session. Open START-HERE.html on the presentation computer and run through the demo.\nNOT VERIFIED: New-machine Python installation, real macOS/Linux startup, public Netlify/Supabase deployment.\nNo new paid model requests or market requests were needed for packaging. Saved report remains partial with original inputs/dates and macro-source gaps.\n`;
  const featureChecks = '\nPASS: Actual package inventory contains no personal demo wrappers, private runtime state or presentation directory.\nPASS: Offline bundle includes strategy-specific scenarios and prepared-report controls without unresolved imports.\nPASS: Prepared report is visible before optional tools, uses relative links and opens in a script-restricted frame.\nPASS: Public, built, portable and exported HTML copies are identical; packaged JSON and embedded offline data agree.\nPASS: Independent clean rebuild reproduces the portable app, and fresh HTML export reproduces the reviewed report.\nPASS: The copied HTTP server starts on an isolated loopback port and serves the workspace, scenario module, popup module and prepared report with correct MIME types and exact file bytes.\nPASS: Copied HTTP health confirms no AI credentials, research credentials or email delivery; no external API or mail call occurs.\n';
  const provenanceNote = reportRevisionKnown ? '' : '\nRESEARCH PROVENANCE LIMITATION: The original saved report records an unknown TradingAgents revision. Its provenance is preserved unchanged. app/VENDOR-REVISION.txt identifies the packaged source, but cannot establish which revision generated that saved report.\n';
  const selectedResearchChecks = `\nPASS: ${regressionCount} regression checks run from the recipient copy with network calls blocked.\nPASS: Selected-stock requests include zero-dollar watch items, preserve remaining cash, validate inputs, and retain frozen submitted snapshots across later edits and restored sessions.\nPASS: A temporary test store accepts selected-stock research, a synthetic worker claims it, and completion validates the unchanged allocation and full requested stock coverage. This is a test fixture, not a real AI analysis.\nPASS: Actual generated reports open separately from the prepared example, retaining their own contents and dates; unsupported dialogs reveal the actual report inline.\nPASS: All ten approaches have concise beginner explanations and distinct, position-aware hypothetical conditions.\nPASS: Source, rebuilt and offline pages contain the current selection preview and separate generated-report container.\nPASS: The selected-research validation module remains server-only; both public HTTP routes return 404.\nPASS: Fresh HTTP health advertises selected-stock research support while AI and worker credentials remain unconfigured and email delivery stays off.\n`;
  const target = path.join(folder, 'VALIDATION.txt'); await fs.writeFile(target, text.replace('\nAdditional source regression checks:', featureChecks + selectedResearchChecks + provenanceNote + '\nAdditional source regression checks:').replace('original inputs/dates and macro-source gaps', 'original inputs/dates, missing evidence and unavailable horizon summaries'));
  const data = await fs.readFile(target);
  manifest.files = manifest.files.filter(item => item.path !== 'VALIDATION.txt');
  manifest.files.push({ path: 'VALIDATION.txt', bytes: data.length, sha256: createHash('sha256').update(data).digest('hex') });
  await fs.writeFile(manifestFile, JSON.stringify(manifest, null, 2));
}
