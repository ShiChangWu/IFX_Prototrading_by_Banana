// Live connection check: saves only the normal explanation, never credentials or provider headers.
import {loadLocalEnv,configuration,APP_DIR} from '../server/config.mjs';
import {explainMatch} from '../server/deepseek.mjs';
import {createMatch,DEFAULT_PROFILE,TEMPLATES} from '../shared/strategy.mjs';
import {mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
loadLocalEnv();const config=configuration();
const match=createMatch(DEFAULT_PROFILE);
const candidates=TEMPLATES.filter(t=>match.candidateTemplateIds.includes(t.id)).map(t=>({...t,allocations:createMatch({...DEFAULT_PROFILE,templateId:t.id}).allocations}));
const started=Date.now();const explanation=await explainMatch(match,config,fetch,candidates);
await mkdir(path.join(APP_DIR,'data'),{recursive:true});
await writeFile(path.join(APP_DIR,'data','live-connection-check.json'),JSON.stringify({checkedAt:new Date().toISOString(),elapsedMs:Date.now()-started,explanation},null,2));
console.log(JSON.stringify({status:explanation.status,model:explanation.model,elapsedMs:Date.now()-started,message:explanation.status==='ready'?'Validated structured response received.':explanation.summary}));
if(explanation.status!=='ready')process.exitCode=1;
