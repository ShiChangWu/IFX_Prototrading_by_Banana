import { access, mkdir, readFile, stat, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { isDeepStrictEqual } from 'node:util';
import { validateProfile } from '../shared/strategy.mjs';
import { emptyState } from '../server/store.mjs';

const MAX_REPORT_BYTES = 2 * 1024 * 1024;
const fail = reason => { throw new Error(`Bundled example was not imported: ${reason}`); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
function rejectCredentials(value, depth = 0) {
  if (depth > 40) fail('report nesting is too deep.');
  if (!value || typeof value !== 'object') return;
  for (const [key, child] of Object.entries(value)) {
    if (/^(?:sessionToken|accessToken|sessionHash|accessHash|leaseToken|workerSecret|apiKey|deepseekApiKey)$/i.test(key)) fail('credential fields are not permitted.');
    rejectCredentials(child, depth + 1);
  }
}

export function validateBundledExample(report) {
  if (!object(report) || !/^[a-zA-Z0-9-]{1,100}$/.test(report.id || '') || !['complete', 'partial'].includes(report.status)) fail('invalid report ID or status.');
  if (typeof report.title !== 'string' || !report.title.trim() || report.title.length > 300) fail('invalid title.');
  if (typeof report.generatedAt !== 'string' || !Number.isFinite(Date.parse(report.generatedAt)) || !/^\d{4}-\d{2}-\d{2}$/.test(report.analysisDate || '') || !Number.isFinite(Date.parse(report.analysisDate))) fail('invalid report dates.');
  let profile;
  try { profile = validateProfile(report.profile); } catch { fail('invalid questionnaire snapshot.'); }
  if (!isDeepStrictEqual(profile, report.profile)) fail('questionnaire contains unexpected or unnormalized fields.');
  if (!object(report.match) || typeof report.match.id !== 'string' || !report.match.id || !Array.isArray(report.match.allocations) || report.match.allocations.length > 20) fail('missing matched allocation snapshot.');
  const tickers = new Set();
  for (const asset of report.match.allocations) {
    if (!object(asset) || !/^[A-Z][A-Z0-9.-]{0,9}$/.test(asset.ticker || '') || tickers.has(asset.ticker) || !Number.isFinite(asset.weight) || asset.weight < 0 || asset.weight > 100 || !Number.isFinite(asset.amount) || asset.amount < 0) fail('invalid allocation.');
    tickers.add(asset.ticker);
  }
  const provenance = report.provenance;
  // Some exported runs did not capture a Git revision. Preserve the explicit
  // unknown value; the packaged source revision must not be invented as its origin.
  const validRevision = typeof provenance?.commit === 'string' && (provenance.commit === 'unknown' || /^[0-9a-f]{40}$/i.test(provenance.commit));
  if (!object(provenance) || provenance.engine !== 'TauricResearch/TradingAgents' || typeof provenance.repository !== 'string' || provenance.repository.replace(/\/$/, '') !== 'https://github.com/TauricResearch/TradingAgents' || !validRevision || typeof provenance.model !== 'string' || !provenance.model.trim() || typeof provenance.templateVersion !== 'string' || !Array.isArray(provenance.dataSources) || !Array.isArray(provenance.warnings)) fail('missing official source and model provenance.');
  if (!Array.isArray(report.research) || !report.research.some(item => item.status === 'complete') || !Array.isArray(report.outlook) || !Array.isArray(report.limitations) || !['complete', 'unavailable'].includes(report.backtest?.status)) fail('no completed research or required sections.');
  for (const item of report.research) {
    if (!object(item) || !tickers.has(item.ticker) || !['complete', 'error'].includes(item.status) || !Array.isArray(item.sections)) fail('research is outside the matched snapshot.');
  }
  rejectCredentials(report);
  return report;
}

export async function seedBundledExample(root) {
  const stateFile = path.join(root, '.local', 'state.json');
  // Do not inspect, validate, merge into, or replace a recipient's existing state.
  try { await access(stateFile); return { status: 'existing' }; }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  const exampleFile = path.join(root, 'examples', 'demo-report.json');
  let source;
  try {
    if ((await stat(exampleFile)).size > MAX_REPORT_BYTES) fail('report exceeds 2 MiB.');
    source = await readFile(exampleFile, 'utf8');
  } catch (error) { if (error.code === 'ENOENT') return { status: 'absent' }; throw error; }
  if (Buffer.byteLength(source) > MAX_REPORT_BYTES) fail('report exceeds 2 MiB.');
  let report;
  try { report = JSON.parse(source); } catch { fail('invalid JSON.'); }
  validateBundledExample(report);
  const state = emptyState();
  state.jobs[report.id] = {
    id: report.id, status: report.status, stage: 'Bundled dated research example',
    createdAt: report.generatedAt, updatedAt: report.generatedAt,
    profile: report.profile, match: report.match, report, published: true,
  };
  await mkdir(path.dirname(stateFile), { recursive: true, mode: 0o700 });
  try { await writeFile(stateFile, JSON.stringify(state), { flag: 'wx', mode: 0o600 }); }
  catch (error) { if (error.code === 'EEXIST') return { status: 'existing' }; throw error; }
  return { status: 'seeded', id: report.id };
}
