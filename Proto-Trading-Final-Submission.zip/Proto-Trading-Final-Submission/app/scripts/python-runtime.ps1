function Get-ProtoPythonVersion {
  param([string]$Executable)
  if (-not $Executable -or -not (Test-Path -LiteralPath $Executable -PathType Leaf)) { return $null }
  # Do not activate the Windows Store's uninstalled Python alias.
  if ($Executable -match '[\\/]Microsoft[\\/]WindowsApps[\\/]') { return $null }
  try {
    $VersionOutput = & $Executable -c "import sys; print('%d.%d.%d' % sys.version_info[:3])" 2>$null
    $VersionExitCode = $LASTEXITCODE
    $Text = $VersionOutput | Select-Object -First 1
    if ($VersionExitCode -eq 0 -and $Text -match '^3\.(11|12|13)\.(\d+)$') { return [pscustomobject]@{ executable = [System.IO.Path]::GetFullPath($Executable); minor = [int]$Matches[1]; version = $Text } }
  } catch { }
  return $null
}

function Find-ProtoSetupPython {
  if ($env:PROTO_PYTHON) {
    $Explicit = Get-ProtoPythonVersion $env:PROTO_PYTHON
    if (-not $Explicit) { throw 'PROTO_PYTHON must point to an installed Python 3.11, 3.12 or 3.13 executable. Python 3.12 is the reference environment.' }
    return $Explicit
  }
  $Candidates = @()
  foreach ($Name in @('python3.12', 'python3.13', 'python3.11', 'python', 'python3')) {
    $Command = Get-Command $Name -CommandType Application -ErrorAction SilentlyContinue
    if ($Command) { $Candidates += $Command.Source }
  }
  $Launcher = Get-Command py -CommandType Application -ErrorAction SilentlyContinue
  if ($Launcher) {
    # List installed runtimes only. Never invoke an absent launcher version that
    # a Python install manager might automatically download.
    try {
      $Installed = & $Launcher.Source -0p 2>$null
      foreach ($Line in $Installed) {
        if ($Line -match '^\s*-(?:V:)?3\.(?:11|12|13)(?:-[^\s]+)?\s+\*?\s*(.+?python(?:\.exe)?)\s*$') { $Candidates += $Matches[1].Trim('"') }
      }
    } catch { }
  }
  $Valid = @()
  foreach ($Candidate in ($Candidates | Select-Object -Unique)) { $Item = Get-ProtoPythonVersion $Candidate; if ($Item) { $Valid += $Item } }
  if ($Valid.Count -gt 0) { return ($Valid | Sort-Object -Property @{ Expression = { if ($_.minor -eq 12) { 0 } elseif ($_.minor -eq 13) { 1 } else { 2 } } } | Select-Object -First 1) }
  if ($env:USERPROFILE) {
    $Fallback = Get-ProtoPythonVersion (Join-Path $env:USERPROFILE '.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
    if ($Fallback) { return $Fallback }
  }
  throw 'Install Python 3.12 from https://www.python.org/downloads/ with Add Python to PATH, then reopen Setup-Research.ps1. Python 3.11-3.13 are accepted; no Python runtime is downloaded automatically. You can also set PROTO_PYTHON to its full installed path.'
}
