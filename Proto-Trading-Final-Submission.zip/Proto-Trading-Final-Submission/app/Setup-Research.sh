#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
[[ "$SCRIPT_DIR" != "${BASH_SOURCE[0]}" ]] || SCRIPT_DIR=.
APP_DIR="$(cd -- "$SCRIPT_DIR" && pwd -P)"
source "$APP_DIR/scripts/python-runtime.sh"
cd "$APP_DIR"
VENDOR_PATH="$APP_DIR/vendor/TradingAgents"
LOCK_FILE="$APP_DIR/requirements-lock.txt"
if [[ ! -f "$VENDOR_PATH/pyproject.toml" || ! -f "$LOCK_FILE" ]]; then
  printf '%s\n' 'The bundled TradingAgents source or requirements-lock.txt is missing. Extract the complete shared folder again. Setup does not download a replacement Git repository.' >&2
  exit 1
fi
while IFS= read -r line || [[ -n "$line" ]]; do
  line="${line%$'\r'}"
  [[ -z "$line" || "$line" == \#* ]] && continue
  if [[ ! "$line" =~ ^[A-Za-z0-9_.-]+==[A-Za-z0-9_.+!-]+$ ]]; then
    printf '%s\n' 'The dependency lock must contain exact package==version pins only.' >&2
    exit 1
  fi
done < "$LOCK_FILE"
PYTHON_RUNTIME="$APP_DIR/.venv/bin/python"
if [[ -e "$APP_DIR/.venv" ]]; then
  if ! proto_python_version "$PYTHON_RUNTIME" >/dev/null; then
    printf '%s\n' 'The existing .venv is incompatible or belongs to another operating system. Extract a fresh app folder and run setup with Python 3.12. No environment is deleted automatically.' >&2
    exit 1
  fi
else
  SETUP_PYTHON="$(find_proto_python)"
  printf 'Creating an isolated environment with Python %s.\n' "$(proto_python_version "$SETUP_PYTHON")"
  "$SETUP_PYTHON" -m venv "$APP_DIR/.venv" || { printf '%s\n' 'Could not create .venv. Install your system Python venv support and check folder write permissions.' >&2; exit 1; }
fi
printf '%s\n' 'Installing exact runtime versions from requirements-lock.txt. Package downloads need internet access.'
"$PYTHON_RUNTIME" -m pip install --requirement "$LOCK_FILE" || { printf '%s\n' 'Pinned dependencies could not be installed. Keep the pins; check internet/platform support. Python 3.12 is the tested reference.' >&2; exit 1; }
"$PYTHON_RUNTIME" -m pip install --no-deps "$VENDOR_PATH" || { printf '%s\n' 'The bundled source could not be installed. Python build tools may also require internet access.' >&2; exit 1; }
"$PYTHON_RUNTIME" -m pip check
printf '%s\n' 'Research setup complete. Git was not required. Add your own DeepSeek key to .env.local before live research.'
printf '%s\n' 'bash Start-Local.sh creates .env.local if it is absent; existing settings are retained.'
