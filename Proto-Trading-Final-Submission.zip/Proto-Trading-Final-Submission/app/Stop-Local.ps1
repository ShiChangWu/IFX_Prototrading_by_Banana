. (Join-Path $PSScriptRoot 'scripts/runtime.ps1')
$LauncherMutex = Enter-ProtoLauncherLock
try {
$RecordFile = Join-Path $ProjectRoot '.local/launcher-processes.json'
if (-not (Test-Path -LiteralPath $RecordFile)) { Write-Host 'No launcher-managed services found.'; exit }
$TrackedProcesses = @(Read-ProtoProcessRecords $RecordFile)
$Remaining = @()
foreach ($Entry in ($TrackedProcesses | Sort-Object -Property @{ Expression = { if ($_.kind -eq 'research') { 0 } else { 1 } } })) {
  $Found = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + [int]$Entry.id) -ErrorAction SilentlyContinue
  if (-not $Found) { continue }
  if ((Get-ProtoProcessStamp $Found) -ne (ConvertTo-ProtoProcessStamp $Entry.createdAt) -or -not (Test-ProtoService $Found ([string]$Entry.kind))) { Write-Host 'Skipped a changed process identity.'; continue }
  $Before = @()
  if ($Entry.kind -eq 'research') { $Before = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue) }
  if (-not (Stop-ProtoVerifiedProcess $Found)) { $Remaining += $Entry; Write-Host 'A managed process could not be stopped; its record was retained.'; continue }
  if ($Entry.kind -eq 'research') {
    # Stop the parent first to prevent another paid research subprocess starting.
    # Re-scan to catch a verified child created between the first scan and stop.
    $StoppedBy = [datetime]::UtcNow
    $After = @(Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)
    $Children = @(Get-ProtoRunnerDescendants $Found @($Before + $After) $StoppedBy)
    foreach ($Child in $Children) {
      if (-not (Stop-ProtoVerifiedProcess $Child.process)) {
        $StillThere = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + [int]$Child.process.ProcessId) -ErrorAction SilentlyContinue
        if ($StillThere -and (Get-ProtoProcessStamp $StillThere) -eq (Get-ProtoProcessStamp $Child.process)) {
          $RunnerRecord = New-ProtoProcessRecord $StillThere 'research-runner'
          if ($RunnerRecord) { $Remaining += $RunnerRecord }
          Write-Host 'A verified research subprocess is still running; its identity was retained so Stop-Local can retry.'
        }
      }
    }
  }
}
Write-ProtoProcessRecords $RecordFile $Remaining
if ($Remaining.Count -gt 0) { Write-Host 'Some managed processes could not be stopped. Their records were retained for another attempt.' }
else { Write-Host 'Launcher-managed services stopped. Research already in progress may become interrupted.' }
} finally { $LauncherMutex.ReleaseMutex(); $LauncherMutex.Dispose() }
