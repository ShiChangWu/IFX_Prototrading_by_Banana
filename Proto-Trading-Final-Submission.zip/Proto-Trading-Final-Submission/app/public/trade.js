export function initTradePage({ document, location, history, fetchImpl = globalThis.fetch, crypto = globalThis.crypto, now = () => Date.now() }) {
  const root = document.getElementById('trade-action');
  const n = (tag, className, text) => { const e = document.createElement(tag); if (className) e.className = className; if (text !== undefined) e.textContent = String(text); return e; };
  const button = (text, action, className = '') => { const e = n('button', className, text); e.type = 'button'; e.addEventListener('click', action); return e; };
  let token = '', link = null, busy = false, complete = false, idempotencyKey = null, formControls = [];
  const fragment = String(location.hash || '').replace(/^#/, '');
  try {
    const params = new URLSearchParams(fragment);
    if (params.getAll('token').length === 1) token = params.get('token') || '';
    else if (!fragment.includes('=')) token = fragment;
  } catch { token = ''; }
  // Keep the bearer capability in memory, never in links, page attributes or storage.
  try { history.replaceState(null, '', location.pathname || '/trade.html'); } catch { token = ''; }
  root.replaceChildren();
  const heading = n('h2', '', 'Your private reminder link');
  const intro = n('p');
  const status = n('p', 'notice'); status.setAttribute('role', 'status');
  const content = n('div');
  const retry = button('Try opening this link again', () => readLink(), 'secondary'); retry.hidden = true;
  root.append(heading, intro, status, content, retry);
  const message = (text, error = false) => { status.textContent = text; status.className = error ? 'notice error' : 'notice'; status.hidden = !text; };
  async function post(path, body) {
    const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 25000);
    try {
      const response = await fetchImpl(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: controller.signal, cache: 'no-store', credentials: 'omit', referrerPolicy: 'no-referrer' });
      let data; try { data = await response.json(); } catch { throw new Error('The server response could not be read. Try again.'); }
      if (!response.ok) throw new Error(typeof data.error === 'string' ? data.error : data.error?.message || data.message || 'This link could not be used. Reopen the original email or request a new link.');
      return data;
    } catch (error) {
      if (controller.signal.aborted) throw new Error('The connection took too long. Check your connection and try again.');
      if (error instanceof TypeError) throw new Error('Cannot reach the app server. Check that it is running, then try again.');
      throw error;
    } finally { clearTimeout(timeout); }
  }
  function render() {
    content.replaceChildren(); formControls = []; retry.hidden = true; message('');
    if (link.used) { complete = true; token = ''; heading.textContent = 'This link has already been used'; intro.textContent = 'No further action was taken. Your saved change was not repeated.'; return; }
    if (link.purpose === 'verify') {
      heading.textContent = 'Confirm your email address'; intro.textContent = `Confirm ${link.email || 'your address'} to receive the reminders you choose. This does not enable reminders by itself.`;
      content.append(button('Confirm this email address', event => confirm({}, event)));
    } else if (link.purpose === 'stop') {
      heading.textContent = 'Turn off email reminders'; intro.textContent = 'Use the button below to stop email reminders for this saved watchlist. Your recorded holdings and trades will stay available.';
      content.append(button('Turn off email reminders', event => confirm({}, event)));
    } else if (link.purpose === 'fill') {
      const side = link.side === 'buy' ? 'purchase' : 'sale';
      heading.textContent = `Record your completed ${side}`; intro.textContent = 'Enter what actually happened at your broker. Opening this page does not place a trade.';
      const summary = n('div', 'trade-summary'); summary.append(n('strong', '', `${link.ticker} · ${link.side === 'buy' ? 'Bought shares' : 'Sold shares'}`));
      const held = (link.positions || []).find(p => p.ticker === link.ticker)?.quantity || 0;
      summary.append(n('p', 'small', `Currently recorded: ${held} shares. This link records only the stock and action shown above.`)); content.append(summary);
      const fields = n('div', 'fields');
      function field(caption, suffix, type, cls) { const wrap = n('div', cls); const label = n('label', '', caption); const input = n('input'); input.id = 'trade-' + suffix; input.type = type; label.htmlFor = input.id; wrap.append(label, input); fields.append(wrap); return input; }
      const quantity = field('Actual number of shares', 'quantity', 'number'); quantity.min = '0.000001'; quantity.max = '1000000'; quantity.step = 'any'; quantity.inputMode = 'decimal';
      const price = field('Actual price per share (USD)', 'price', 'number'); price.min = '0.000001'; price.max = '1000000'; price.step = 'any'; price.inputMode = 'decimal';
      const executed = field('Trade date and time (your local time)', 'executed', 'datetime-local', 'time-field');
      const acknowledgment = n('label', 'check'); const checked = n('input'); checked.type = 'checkbox'; checked.id = 'trade-ack'; acknowledgment.htmlFor = checked.id; acknowledgment.append(checked, n('span', '', 'I already placed this trade with my broker. These are my actual shares and execution price.'));
      const submit = button('Save my completed trade', async event => {
        if (!checked.checked) { message('Confirm that you already completed this trade with your broker.', true); return; }
        const shares = Number(quantity.value), paid = Number(price.value), time = new Date(executed.value);
        if (!quantity.value.trim() || !price.value.trim() || !Number.isFinite(shares) || shares <= 0 || shares > 1000000 || !Number.isFinite(paid) || paid <= 0 || paid > 1000000 || shares * paid > 10000000 || !executed.value || !Number.isFinite(time.getTime())) { message('Enter positive shares, the actual execution price and a valid trade time. Maximum trade value is $10 million.', true); return; }
        if (time.getTime() > now() + 5 * 60000) { message('Enter the time of a completed trade, not a future time.', true); return; }
        if (link.side === 'sell' && shares > held + 1e-9) { message(`Your recorded holding is ${held} shares. Record a missing purchase in the workspace before recording this sale.`, true); return; }
        idempotencyKey ||= crypto.randomUUID();
        await confirm({ ticker: link.ticker, side: link.side, quantity: shares, price: paid, executedAt: time.toISOString(), idempotencyKey }, event);
      });
      formControls = [quantity, price, executed, checked];
      for (const control of [quantity, price, executed]) control.addEventListener('input', () => { if (!busy) idempotencyKey = null; });
      content.append(fields, acknowledgment, submit, n('p', 'muted', 'This private link accepts one completed trade. If you made several fills, enter their combined shares and average execution price, or use the workspace to record each fill separately.'));
    }
    content.append(n('p', 'muted', 'For privacy, the link has been removed from the address bar. Reopen the original email link if you refresh this page.'));
  }
  async function confirm(fields, event) {
    if (busy || complete || !token) return;
    busy = true; const sender = event?.currentTarget; if (sender) sender.disabled = true; for (const control of formControls) control.disabled = true; message('Saving your confirmation…');
    try {
      const data = await post('/api/tracking/confirm', { token, ...fields });
      complete = true; token = ''; idempotencyKey = null; content.replaceChildren(); retry.hidden = true;
      heading.textContent = link.purpose === 'fill' ? 'Your completed trade is recorded' : link.purpose === 'stop' ? 'Email reminders are off' : 'Email address confirmed';
      intro.textContent = data.message || (link.purpose === 'fill' ? 'Your recorded holding has been updated. No broker order was placed.' : 'Your change has been saved.'); message('');
    } catch (error) { message(error.message, true); }
    finally { busy = false; if (!complete) { if (sender) sender.disabled = false; for (const control of formControls) control.disabled = false; } }
  }
  async function readLink() {
    if (busy || complete) return;
    if (!/^[A-Za-z0-9_-]{32,256}$/.test(token)) { message('Open the complete private link from your reminder email. This page cannot use a missing or incomplete link.', true); return; }
    busy = true; retry.hidden = true; message('Checking your private link…');
    try {
      const data = await post('/api/tracking/link', { token });
      if (!data || !['verify', 'fill', 'stop'].includes(data.purpose) || (data.purpose === 'fill' && (!/^[A-Z][A-Z0-9.-]{0,14}$/.test(data.ticker) || !['buy', 'sell'].includes(data.side)))) throw new Error('This link returned an unsupported action. Request a new link from the workspace.');
      link = data; render();
    } catch (error) { message(error.message, true); retry.hidden = false; }
    finally { busy = false; }
  }
  const ready = readLink();
  return { ready };
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') initTradePage({ document, location: window.location, history: window.history });
