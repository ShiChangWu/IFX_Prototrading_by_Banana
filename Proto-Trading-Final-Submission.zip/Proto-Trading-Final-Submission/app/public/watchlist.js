import { ASSETS } from '../shared/strategy.mjs';

let watchlistSequence = 0;
export function createWatchlist(document, { request, getContext = () => ({}), portableMode = false, onExplore, onSelectionChange } = {}) {
  const n = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = String(text); return e; };
  const button = (text, action, cls = 'secondary') => { const e = n('button', cls, text); e.type = 'button'; e.addEventListener('click', action); return e; };
  const money = value => Number(value).toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 4 });
  const date = value => { const d = new Date(value); return value && Number.isFinite(d.getTime()) ? d.toLocaleString() : 'Not checked yet'; };
  const uid = `watchlist-${++watchlistSequence}`;
  const root = n('section', 'watchlist wide'); root.id = uid;
  const status = n('p', 'notice'); status.hidden = true; status.setAttribute('role', 'status');
  const intro = n('p', 'small muted');
  const choices = n('div', 'tracking-choices');
  const selectedSummary = n('p', 'small muted');
  const searchWrap = n('div', 'tracking-search');
  const search = n('input'); search.type = 'search'; search.placeholder = 'Ticker or company name, for example AMD'; search.id = uid + '-search';
  const searchLabel = n('label', '', 'Find another US stock or ETF'); searchLabel.htmlFor = search.id;
  const searchNote = n('p', 'small muted'); searchNote.setAttribute('aria-live', 'polite');
  const results = n('div', 'tracking-search-results');
  const find = button('Search stocks', searchStocks);
  searchWrap.append(searchLabel, search, find, searchNote, results);
  const save = button(portableMode ? 'Keep this selection for this visit' : 'Save stocks to follow', () => saveSelection(), 'primary');
  const saveRow = n('div', 'card-actions'); saveRow.append(save);
  if(onExplore)saveRow.append(button('Explore this strategy & backtests',()=>onExplore(schoolId())));
  root.append(n('p', 'eyebrow', 'YOUR NEXT STEP'), n('h3', '', 'Choose the stocks you want to follow'), intro, choices, selectedSummary, searchWrap, saveRow, status);

  function details(title) { const e = n('details', 'more-panel'); const body = n('div', 'detail-body'); e.append(n('summary', '', title), body); root.append(e); return { element: e, body }; }
  function field(parent, label, input, suffix) { const wrap = n('div', 'tracking-field'); const l = n('label', '', label); input.id = uid + '-' + suffix; l.htmlFor = input.id; wrap.append(l, input); parent.append(wrap); return input; }
  const market = n('section', 'tracking-market');
  market.append(n('h4', '', 'Yahoo Finance intraday'), n('p', 'small muted', 'Check the latest available minute bars for your saved stocks. Yahoo Finance prices may be delayed; confirm a current execution price with your broker.'));
  const marketRows = n('div', 'tracking-market-rows');
  const marketStatus = n('p', 'small muted'); marketStatus.setAttribute('role', 'status');
  const refreshPrices = button('Refresh prices', checkNow);
  market.append(marketRows, refreshPrices, marketStatus); root.append(market);
  const mail = details('Email reminders');
  mail.body.append(n('p', 'small', 'See the email subscription beside the app. Demo delivery is paused. You can preview the flow and record completed trades here.'));
  const futureMail = n('div'); futureMail.hidden = true; mail.body.append(futureMail);
  const capabilityNote = n('p', 'notice');
  const email = field(futureMail, 'Your email address', n('input'), 'email'); email.type = 'email'; email.autocomplete = 'email'; email.placeholder = 'you@gmail.com';
  const consentLabel = n('label', 'tracking-check'); const consent = n('input'); consent.type = 'checkbox'; consentLabel.append(consent, n('span', '', 'I want emails about conditions for the stocks I choose. I can turn them off here or from an email.')); futureMail.append(consentLabel);
  const verify = button('Verify my email address', verifyEmail);
  const enabledLabel = n('label', 'tracking-check'); const enabled = n('input'); enabled.type = 'checkbox'; enabledLabel.append(enabled, n('span', '', 'Send reminders for my saved stocks'));
  const mailActions = n('div', 'card-actions'); const saveMail = button('Save reminder settings', () => saveSelection()); const disable = button('Turn off email reminders', turnOff);
  mailActions.append(verify, saveMail, disable);
  const savedMail = n('p', 'small muted');
  futureMail.append(capabilityNote, enabledLabel, mailActions, savedMail, n('p', 'small muted', 'No trades are placed for you. A sell reminder needs a recorded holding. Buying a stock does not guarantee a later opportunity to sell at a profit.'));
  futureMail.append(n('p','small muted','Keep the local server awake and connected. Re-match in this browser tab within 7 days to renew your session; expired sessions stop reminders. Check your broker for splits and fees: recorded share quantities are not adjusted automatically.'));
  const conditionSection = details('More reminder settings · price levels & checking');
  conditionSection.body.append(n('p', 'small', 'Your strategy still uses completed daily bars. Checking during the trading day does not turn a daily rule into an intraday trading strategy. You can also add your own price levels below.'));
  conditionSection.body.append(n('p', 'small muted', 'Optional: buy review at or below a price; sell review at or above a target, or at or below a loss-review level. Blank fields mean no extra price reminder. These are your chosen levels, not AI forecasts.'));
  conditionSection.body.append(n('p','small muted','Steady foundation and Everyday balance have no automatic buy/sell timing signal; use their allocation review routine or your own price lines. Price Action currently has an entry-watch signal only: set your own exit-review lines. These reminders are not the full backtest exit model.'));
  const conditionRows = n('div', 'tracking-condition-rows');
  const check = button('Check my saved stocks now', checkNow);
  const checkInfo = n('p', 'small muted');
  conditionSection.body.append(conditionRows, check, checkInfo);
  const holdings = details('My holdings & record a trade');
  const positions = n('div', 'tracking-position-list');
  holdings.body.append(n('p', 'small', 'Only record a trade after you have completed it with your broker. Enter the actual shares and execution price; this app does not place an order.'), positions);
  const fillFields = n('div', 'tracking-fill-fields');
  const fillTicker = field(fillFields, 'Stock', n('select'), 'fill-ticker');
  const fillSide = field(fillFields, 'What did you do?', n('select'), 'fill-side');
  for (const [value, label] of [['buy', 'Bought shares'], ['sell', 'Sold shares']]) { const option = n('option', '', label); option.value = value; fillSide.append(option); } fillSide.value = 'buy';
  const quantity = field(fillFields, 'Number of shares', n('input'), 'quantity'); quantity.type = 'number'; quantity.min = '0.000001'; quantity.step = 'any';
  const price = field(fillFields, 'Price per share (USD)', n('input'), 'price'); price.type = 'number'; price.min = '0.000001'; price.step = 'any';
  const executed = field(fillFields, 'When you traded (your local time)', n('input'), 'executed'); executed.type = 'datetime-local';
  const record = button('Record completed trade', recordFill, 'primary');
  holdings.body.append(fillFields, record);
  const activity = details('Reminder history & trade record'); const activityBody = n('div'); activity.body.append(activityBody);

  let context = {}, tracking = {}, capabilities = {}, selected = new Set(), assets = new Map(ASSETS.map(asset => [asset.ticker, asset]));
  let conditions = new Map(), sessionKey = '', profileKey = '', loadedKey = null, revision = 0, editVersion = 0, busy = false, searchSequence = 0, fillKey = null, selectionEdited = false, portableSaved = false;
  const pending = () => portableMode || !context.sessionToken || context.pending;
  const headers = () => ({ 'X-Session-Token': context.sessionToken });
  const schoolId = () => context.match?.template?.id || tracking.schoolId || 'balanced';
  function getSelection() {
    const tickers = [...selected], savedTickers = tracking.tickers;
    return {
      tickers,
      assets: tickers.map(ticker => ({ ...(assets.get(ticker) || { ticker, name: ticker, assetClass: 'unknown' }) })),
      market: tracking.market ? structuredClone(tracking.market) : null,
      positions: structuredClone(tracking.positions || []),
      saved: portableMode ? portableSaved : Array.isArray(savedTickers) && savedTickers.length === tickers.length && tickers.every(ticker => savedTickers.includes(ticker)),
    };
  }
  function notifySelection(reason) { onSelectionChange?.({ ...getSelection(), reason }); }
  function message(text, error = false) { status.hidden = !text; status.textContent = text; status.className = error ? 'notice error' : 'notice'; }
  function canEnable() { return !!(capabilities.emailDeliveryEnabled === true && capabilities.mailConfigured && capabilities.marketConfigured && tracking.verified && email.value.trim().toLowerCase() === String(tracking.email || '').toLowerCase() && consent.checked); }
  function refreshButtons() {
    for (const b of [verify, saveMail, disable, check, record, refreshEmail, refreshPrices]) b.disabled = busy || pending();
    save.disabled = busy || (!portableMode && (!context.sessionToken || context.pending)); find.disabled = busy;
    verify.disabled ||= capabilities.emailDeliveryEnabled !== true || !capabilities.mailConfigured || !selected.size;
    refreshEmail.disabled ||= capabilities.emailDeliveryEnabled !== true;
    check.disabled ||= !tracking.tickers?.length;
    refreshPrices.disabled ||= !tracking.tickers?.length;
    record.disabled ||= !fillTicker.value;
    enabled.disabled = pending() || !canEnable();
    if (enabled.disabled) enabled.checked = false;
    disable.disabled ||= !tracking.enabled;
  }
  function changeSelection(ticker, checked) {
    if (checked && !selected.has(ticker) && selected.size >= 8) { message('Choose up to 8 stocks. Uncheck one before adding another.', true); renderChoices(); return; }
    editVersion++; selectionEdited = true; portableSaved = false; if (checked) selected.add(ticker); else selected.delete(ticker);
    renderChoices(); renderConditions(); renderMarket(); refreshFillTickers(); refreshButtons();
    message('Selection changed. Save it to update the stocks you follow.');
    notifySelection('selection');
  }
  function candidate(asset, label) {
    const row = n('label', 'tracking-choice'); const box = n('input'); box.type = 'checkbox'; box.checked = selected.has(asset.ticker); box.setAttribute('aria-label', `Follow ${asset.ticker}`);
    box.addEventListener('change', () => changeSelection(asset.ticker, box.checked));
    const copy = n('span'); copy.append(n('strong', '', asset.ticker), n('span', 'small', asset.name || asset.ticker), n('span', 'small muted', label)); row.append(box, copy); return row;
  }
  function renderChoices() {
    choices.replaceChildren(); const allocationTickers = new Set((context.match?.allocations || []).filter(a => a.ticker !== 'CASH').map(a => a.ticker));
    const all = new Set([...allocationTickers, ...selected]);
    for (const ticker of all) choices.append(candidate(assets.get(ticker) || { ticker }, allocationTickers.has(ticker) ? 'Included in your starting allocation' : 'Added by you · check suitability before trading'));
    const examples = (context.match?.template?.exampleTickers || []).filter(ticker => ticker !== 'CASH' && !all.has(ticker));
    if (examples.length) {
      const more = n('details', 'tracking-examples more-panel'); more.append(n('summary', '', 'More stocks used to explain this strategy'));
      const body = n('div', 'detail-body'); body.append(n('p', 'small muted', 'These are learning examples. Select one to include it in your stock scenarios and strategy exploration. Selection alone does not establish that a stock suits you.'));
      for (const ticker of examples) body.append(candidate(assets.get(ticker) || { ticker }, 'Strategy learning example'));
      if (onExplore) body.append(button('Explore this strategy & backtests', () => onExplore(schoolId())));
      more.append(body); choices.append(more);
    }
    selectedSummary.textContent = `${selected.size} of 8 stocks selected. Checking a box does not subscribe you to email.`;
  }
  function renderConditions() {
    conditionRows.replaceChildren();
    if (!selected.size) conditionRows.append(n('p', 'small muted', 'Select a stock to add an optional price level.'));
    for (const ticker of selected) {
      const item = conditions.get(ticker) || { ticker, buyBelow: null, sellAbove: null, sellBelow: null }; conditions.set(ticker, item);
      const row = n('fieldset', 'tracking-condition-row'); row.append(n('legend', '', ticker));
      for (const [key, caption] of [['buyBelow', 'Buy review ≤ USD'], ['sellAbove', 'Sell review ≥ USD'], ['sellBelow', 'Loss review ≤ USD']]) {
        const input = field(row, caption, n('input'), `${ticker}-${key}`); input.type = 'number'; input.min = '0.000001'; input.step = 'any'; input.placeholder = 'Optional'; input.value = item[key] == null ? '' : String(item[key]);
        input.addEventListener('input', () => { editVersion++; item[key] = input.value.trim() === '' ? null : Number(input.value); });
      }
      conditionRows.append(row);
    }
  }
  function refreshFillTickers() {
    const prior = fillTicker.value; fillTicker.replaceChildren();
    const tickers = new Set([...selected, ...(tracking.positions || []).map(p => p.ticker)]);
    for (const ticker of tickers) { const option = n('option', '', ticker); option.value = ticker; fillTicker.append(option); }
    fillTicker.value = tickers.has(prior) ? prior : [...tickers][0] || '';
  }
  function renderServerState() {
    futureMail.hidden = capabilities.emailDeliveryEnabled !== true || portableMode;
    const verified = tracking.verified ? 'verified' : 'not verified';
    savedMail.textContent = tracking.email ? `Saved address: ${tracking.email} · ${verified}. Email reminders are ${tracking.enabled ? 'on' : 'off'}.` : 'No email subscription is saved.';
    capabilityNote.textContent = portableMode ? 'Portable demo: selection and strategy exploration work here. Market checks and saved trade records need the connected app server.' : capabilities.emailDeliveryEnabled !== true ? 'Demo email delivery is paused; no email can be sent. The sidebar subscription saves only on this device.' : !capabilities.mailConfigured ? 'Gmail sending is not configured on this server yet. You can choose stocks and record trades; no email can be sent until setup is complete.' : !capabilities.marketConfigured ? 'Gmail is configured. A market-data connection is still needed before automatic price reminders can be enabled.' : 'Gmail and market data are configured. Verify your email, then choose whether to enable reminders.';
    const feed = typeof capabilities.feed === 'object' ? capabilities.feed.name || capabilities.feed.label || 'configured feed' : capabilities.feed;
    checkInfo.textContent = `Last check: ${date(tracking.lastCheck)}${feed ? ` · ${feed}` : ''}${capabilities.automatic && capabilities.intervalSeconds ? ` · checks about every ${capabilities.intervalSeconds} seconds while the server runs` : ' · refresh on request'}. ${tracking.status || ''}. ${tracking.marketNote||''}`;
    renderMarket();
    positions.replaceChildren(); const held = (tracking.positions || []).filter(item => item.quantity > 0);
    if (!held.length) positions.append(n('p', 'small muted', 'No recorded holdings yet. Sell reminders stay off until you record a purchase.'));
    for (const item of held) { const row = n('div', 'tracking-position'); row.append(n('strong', '', item.ticker), n('span', '', `${item.quantity} shares · average recorded cost ${money(item.averagePrice)}`)); positions.append(row); }
    activityBody.replaceChildren();
    const alerts = tracking.alerts || [], fills = tracking.fills || [];
    if (!alerts.length && !fills.length) activityBody.append(n('p', 'small muted', 'No reminders or completed trades recorded.'));
    for (const alert of alerts.slice(-20).reverse()) {
      const statusLabels={preview:'Preview only · no email sent',accepted:'Gmail accepted email · inbox delivery unconfirmed',uncertain:'Send acceptance uncertain · not resent',failed:'Email failed',pending:'Waiting to send',cancelled:'Email cancelled',unavailable:'Email connection unavailable'};
      const entry = n('div', 'tracking-history'); entry.append(n('strong', '', `${alert.ticker} · ${alert.side === 'buy' ? 'Buy review' : alert.side === 'sell' ? 'Sell review' : 'Condition review'}`), n('p', 'small', alert.reason || 'Review your saved condition.'), n('p', 'small muted', `${date(alert.observedAt)}${Number.isFinite(alert.price) ? ` · observed ${money(alert.price)}` : ''} · ${statusLabels[alert.status] || alert.status || 'status unavailable'}`)); activityBody.append(entry);
    }
    if (fills.length) activityBody.append(n('h4', '', 'Your recorded trades'));
    for (const fill of fills.slice(-20).reverse()) activityBody.append(n('p', 'small', `${date(fill.executedAt)} · ${fill.ticker} · ${fill.side === 'sell' ? 'Sold' : 'Bought'} ${fill.quantity} at ${money(fill.price)}`));
    refreshFillTickers(); refreshButtons();
  }
  function renderMarket() {
    const data = tracking.market || {}, raw = data.quotes || {};
    const rows = Array.isArray(raw) ? raw : Object.entries(raw).map(([ticker, quote]) => ({ ...quote, ticker: quote?.ticker || ticker }));
    marketRows.replaceChildren();
    const source = typeof data.source === 'object' ? data.source?.name : data.source;
    marketStatus.textContent = portableMode ? 'Live prices require the connected app. You can open each stock on Yahoo Finance.' : `${source || 'Yahoo Finance'} · ${data.fetchedAt ? `checked ${date(data.fetchedAt)}` : 'not checked yet'}. ${tracking.marketNote || 'Save your stocks, then refresh prices.'}`;
    for (const ticker of selected) {
      if (!/^[A-Z0-9][A-Z0-9.\-^=]{0,14}$/.test(ticker)) continue;
      const quote = rows.find(row => row.ticker === ticker), row = n('div', 'tracking-quote');
      const link = n('a', '', ticker); link.href = `https://finance.yahoo.com/quote/${encodeURIComponent(ticker)}/`; link.target = '_blank'; link.rel = 'noopener noreferrer'; row.append(link);
      const value = quote?.price;
      row.append(n('strong', '', Number.isFinite(value) && value > 0 ? money(value) : 'Price unavailable'));
      const labels = { complete: 'Latest available bar · may be delayed', ready: 'Latest available bar · may be delayed', delayed: 'Delayed quote', market_closed: 'Market closed · last available bar', stale: 'Older quote · not a current signal', unavailable: 'Quote unavailable' };
      const observed = quote?.barEnd || quote?.barTime || quote?.observedAt || quote?.timestamp || quote?.asOf;
      row.append(n('p', 'small muted', quote ? `${labels[quote.status] || 'Data status unavailable'}${observed ? ` · bar ${date(observed)}` : ''}${Number.isFinite(quote.delayMinutes) ? ` · about ${quote.delayMinutes} min delay` : ''}${quote.message || quote.reason ? ` · ${quote.message || quote.reason}` : ''}` : 'Open on Yahoo Finance, or refresh saved stocks in the connected app.'));
      marketRows.append(row);
    }
  }
  function acceptState(data, overwrite = true, reason = 'hydrated') {
    if (Object.hasOwn(data, 'tracking')) tracking = data.tracking || {};
    capabilities = data.capabilities || capabilities;
    if (overwrite) {
      if (Array.isArray(tracking.tickers)) { selected = new Set(tracking.tickers); selectionEdited = true; }
      email.value = tracking.email || ''; consent.checked = !!tracking.consent; enabled.checked = !!tracking.enabled;
      conditions = new Map((tracking.conditions || []).map(item => [item.ticker, { ...item }]));
      renderChoices(); renderConditions();
    }
    renderServerState();
    notifySelection(reason);
  }
  async function call(path, options = {}) { return request(path, { timeout:path.endsWith('/check')?90000:40000, ...options, headers: { ...headers(), ...options.headers } }); }
  async function action(operation) {
    const generation = revision; busy = true; refreshButtons();
    try { await operation(generation); } catch (error) { if (generation === revision) message(error.message || 'Could not complete this action. Try again.', true); }
    finally { if (generation === revision) { busy = false; refreshButtons(); } }
  }
  function payload(overrides = {}) {
    const nextConditions = [...selected].map(ticker => conditions.get(ticker) || { ticker, buyBelow: null, sellAbove: null, sellBelow: null });
    for (const item of nextConditions) for (const key of ['buyBelow', 'sellAbove', 'sellBelow']) if (item[key] !== null && (!Number.isFinite(item[key]) || item[key] <= 0)) throw new Error(`Enter a positive ${key === 'buyBelow' ? 'buy' : 'sell'} price for ${item.ticker}, or leave it blank.`);
    return { tickers: [...selected], schoolId: schoolId(), enabled: capabilities.emailDeliveryEnabled === true && enabled.checked && selected.size > 0, email: email.value.trim(), consent: consent.checked, conditions: nextConditions, ...overrides };
  }
  async function saveSelection() {
    if (portableMode) { portableSaved = true; notifySelection('saved'); message('Selection kept for this visit. Open the connected app to save tracking, refresh prices and record trades. Email delivery is paused for this demo.'); return; }
    return action(async generation => { const edits = editVersion; const data = await call('/api/tracking', { method: 'POST', body: payload() }); if (generation !== revision) return; acceptState(data, edits === editVersion, 'saved'); message(`Saved ${tracking.tickers?.length || 0} stocks.${edits !== editVersion ? ' Your newer selection still needs saving.' : ''} ${tracking.enabled ? 'Email reminders are enabled.' : 'Email reminders are off.'}`); });
  }
  async function verifyEmail() {
    if (capabilities.emailDeliveryEnabled !== true) { message('Demo email delivery is paused. No verification email was sent.'); return; }
    return action(async generation => {
      if (!email.value.trim() || !consent.checked) throw new Error('Enter your email and tick the email consent box first.');
      const edits = editVersion;
      let data = await call('/api/tracking', { method: 'POST', body: payload({ enabled: false }) }); if (generation !== revision) return; acceptState(data, edits === editVersion, 'saved');
      data = await call('/api/tracking/verify', { method: 'POST', body: {} }); if (generation !== revision) return;
      message(data.message || 'Verification requested. Check your email, then use Refresh email status after opening its link.');
    });
  }
  const refreshEmail = button('Refresh email status', () => action(async generation => { const data = await call('/api/tracking'); if (generation !== revision) return; acceptState(data, false, 'email'); message(tracking.verified ? 'Email verified. You can now enable reminders when market data is configured.' : 'Email is not verified yet. Open the verification link sent to you.'); }));
  mailActions.append(refreshEmail);
  async function turnOff() { return action(async generation => { const data = await call('/api/tracking/stop', { method: 'POST', body: {} }); if (generation !== revision) return; acceptState(data, false, 'email'); message('Email reminders are turned off.'); }); }
  async function checkNow() { return action(async generation => { const data = await call('/api/tracking/check', { method: 'POST', body: {} }); if (generation !== revision) return; acceptState(data, false, 'market'); message(data.message || 'Check completed. See reminder history for observed conditions and delivery status.'); }); }
  async function recordFill() {
    return action(async generation => {
      const shares = Number(quantity.value), paid = Number(price.value), when = new Date(executed.value);
      if (!fillTicker.value || !quantity.value.trim() || !price.value.trim() || !Number.isFinite(shares) || shares <= 0 || !Number.isFinite(paid) || paid <= 0 || !executed.value || !Number.isFinite(when.getTime())) throw new Error('Choose a stock and enter positive shares, an actual price and the trade time.');
      const held = (tracking.positions || []).find(p => p.ticker === fillTicker.value)?.quantity || 0;
      if (fillSide.value === 'sell' && shares > held + 1e-8) throw new Error(`Your recorded holding is ${held} shares. Record any missing purchase before recording this sale.`);
      fillKey ||= globalThis.crypto.randomUUID();
      const data = await call('/api/tracking/fills', { method: 'POST', body: { ticker: fillTicker.value, side: fillSide.value, quantity: shares, price: paid, executedAt: when.toISOString(), idempotencyKey: fillKey } });
      if (generation !== revision) return; acceptState(data, false, 'fill'); fillKey = null; quantity.value = ''; price.value = ''; message('Completed trade recorded. Future sell reminders will use your recorded holding.');
    });
  }
  async function searchStocks() {
    const query = search.value.trim(), seq = ++searchSequence; results.replaceChildren();
    if (!query) { searchNote.textContent = 'Enter a ticker or company name.'; return; }
    find.disabled = true; searchNote.textContent = portableMode ? 'Searching the included stock list…' : 'Searching the stock directory…';
    try {
      const data = portableMode ? { results: ASSETS.filter(a => a.ticker !== 'CASH' && `${a.ticker} ${a.name}`.toLowerCase().includes(query.toLowerCase())), status: 'portable', warnings: ['Included stock list only. AKShare search requires the connected server.'] } : await request(`/api/stocks/search?q=${encodeURIComponent(query)}`);
      if (seq !== searchSequence) return;
      const found = Array.isArray(data.results) ? data.results.filter(a => a && typeof a.ticker === 'string' && a.ticker !== 'CASH').slice(0, 30) : [];
      searchNote.textContent = `${found.length ? `${found.length} matches. Search results are not personal recommendations.` : 'No matches found. Try an exact ticker.'}${data.source?.name ? ` Directory: ${data.source.name}.` : ''} ${(data.warnings || []).join(' ')}`;
      for (const item of found) {
        assets.set(item.ticker, { ...assets.get(item.ticker), ...item });
        const row = n('div', 'tracking-search-result'); row.append(n('strong', '', item.ticker), n('span', 'small', item.name || item.ticker));
        const add = button('Add to selection', () => { if (!selected.has(item.ticker)) changeSelection(item.ticker, true); else message(`${item.ticker} is already selected.`); }); row.append(add); results.append(row);
      }
    } catch (error) { if (seq === searchSequence) searchNote.textContent = error.message || 'Stock search is unavailable. Your existing selection is still available.'; }
    finally { if (seq === searchSequence) find.disabled = false; }
  }
  email.addEventListener('input', () => { editVersion++; refreshButtons(); }); consent.addEventListener('change', () => { editVersion++; refreshButtons(); });
  enabled.addEventListener('change', () => { editVersion++; });
  for (const control of [quantity, price, executed, fillTicker, fillSide]) control.addEventListener('input', () => { fillKey = null; });
  search.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); searchStocks(); } });
  function update(nextContext) {
    context = nextContext || getContext() || {};
    const nextKey = `${context.sessionToken || ''}:${context.match?.id || ''}`;
    const profile = context.profile || context.match?.profile;
    const nextProfileKey = profile ? JSON.stringify(profile, Object.keys(profile).sort()) : context.match?.id || '';
    intro.textContent = context.match?.template ? `${context.match.template.name}: ${context.match.template.beginnerSummary || context.match.template.description || 'Start with the selected approach, then explore its stocks.'}` : 'Complete About you to see a starting strategy and its stocks.';
    refreshEmail.disabled = pending();
    if (nextKey !== sessionKey || nextProfileKey !== profileKey || !revision) {
      const keepSelection = revision > 0 && nextProfileKey === profileKey && selectionEdited;
      sessionKey = nextKey; profileKey = nextProfileKey; loadedKey = null; revision++; busy = false; fillKey = null; tracking = {}; capabilities = {};
      if (!keepSelection) { editVersion = 0; selectionEdited = false; portableSaved = false; conditions = new Map(); selected = new Set((context.match?.allocations || []).filter(a => a.ticker !== 'CASH').map(a => a.ticker).slice(0, 8)); }
      email.value = ''; consent.checked = false; enabled.checked = false; message(''); renderChoices(); renderConditions(); renderServerState();
      const now = new Date(); const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000); executed.value = local.toISOString().slice(0, 16);
      notifySelection('context');
    }
    if (!pending() && loadedKey !== nextKey) {
      loadedKey = nextKey; const generation = revision, edits = editVersion;
      call('/api/tracking').then(data => { if (generation === revision) acceptState(data, !selectionEdited && edits === editVersion); }).catch(error => { if (generation === revision) { loadedKey = null; message(error.message || 'Tracking is unavailable.', true); } });
    }
    refreshButtons();
  }
  update();
  return { element: root, update, getSelection };
}
