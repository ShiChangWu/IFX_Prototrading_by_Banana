import { TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createMatch, validateProfile } from '/shared/strategy.mjs';
import { createShortPlan } from '/shared/short-plan.mjs';
import { MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument } from '/shared/report-import.mjs';
import { createReportCompanion } from '/report-guide.js';
import { initOnboarding } from '/onboarding.js';
import { createSchoolLab } from '/school-lab.js';
import { SCHOOL_TESTS } from '/shared/school-backtest.mjs';
import { createWatchlist } from '/watchlist.js';
import { createSubscription } from '/subscription.js';
import { selectedPlan } from '/shared/selected-plan.mjs';
import { SCHOOL_BLURBS, scoreSchoolFit } from '/shared/school-fit.mjs';
import { SCHOOL_PRICES } from '/shared/school-prices.mjs';
import { initDemoReport } from '/demo-report.js';

const $ = (id) => document.getElementById(id);
const portableMode = window.PROTO_PORTABLE === true;
const portableReports = portableMode && Array.isArray(window.PROTO_DEMO_REPORTS) ? window.PROTO_DEMO_REPORTS : [];
const palette = ['#21d5f5', '#5687e7', '#91cbb4', '#cbb97d', '#a995dc', '#54768f'];
const usd = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 });
const pct = (n) => `${Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 })}%`;
const state = { health: null, templates: TEMPLATES, match: null, profile: null, signature: null, explanation: null, sessionToken: null, matchController: null, matchSequence: 0, shortPlan: null, shortPlanController: null, shortPlanStatus: null, shortPlanLoading: false, researchSubmitting: false, job: null, jobToken: null, jobProfile: null, pollTimer: null, pollFailures: 0, report: null, reportExample: false, selectedResearchType: 'generated', uploadedDocument: null, uploadedSaved: false, uploadLibrary: [], uploadMemory: [], remix: null, activeTab: 'questionnaire' };
// Keep the private generated result independent of whichever example is open.
state.generatedReport = null;
const labels = {
  goal: { defensive: 'Lower volatility', balanced: 'Balanced growth', growth: 'Growth focus' },
  horizon: { under1: 'Within 1 year', '1to3': '1–3 years', '3plus': 'More than 3 years' },
  review: { monthly: 'Monthly', weekly: 'Weekly', daily: 'Most trading days' },
  assetPreference: { broad: 'Broad US market', value: 'Value & dividends', growth: 'Technology & growth', unsure: 'Help me compare' },
  inverseInterest: { none: 'No inverse ETF research', minus1: '−1× research only', minus2: '−2× research only', minus3: '−3× research only' },
};

function node(tag, className, text) {
  const result = document.createElement(tag);
  if (className) result.className = className;
  if (text !== undefined && text !== null) result.textContent = String(text);
  return result;
}
function button(label, className, action) { const b = node('button', className, label); b.type = 'button'; b.addEventListener('click', action); return b; }
function append(parent, ...children) { parent.append(...children.filter(Boolean)); return parent; }
const expandedSections = new Set();
let schoolLab;
let reportPopup = null;
let watchlist;
let selectedSnapshot = {tickers:[],assets:[],positions:[],market:null,saved:false};
let selectionWeights = {};
let selectionProfile = '';
let selectionDetails;
let guideFitBadges=[],matchedFitBadges=[];
function fitBadge(id,badges){
  const badge=node('span','school-fit-score');badges.push({id,badge});
  const fit=scoreSchoolFit(id,selectedSnapshot,SCHOOL_PRICES);badge.textContent=fit.score===null?'Choose stocks':`${fit.score}/100 learning fit`;
  badge.setAttribute('data-fit-school',id);return badge;
}
function refreshFitBadges(){for(const {id,badge}of [...guideFitBadges,...matchedFitBadges]){const fit=scoreSchoolFit(id,selectedSnapshot,SCHOOL_PRICES);badge.textContent=fit.score===null?'Choose stocks':`${fit.score}/100 learning fit`;}}

function syncSelection(value) {
  const profileKey = state.profile ? signature(state.profile) : '';
  const changedProfile=profileKey !== selectionProfile;
  if(changedProfile) { selectionWeights = {}; selectionProfile = profileKey; }
  if(!changedProfile&&value.reason==='selection')for(const ticker of value.tickers)if(!selectedSnapshot.tickers.includes(ticker))selectionWeights[ticker]=0;
  selectedSnapshot = value;
  for (const ticker of Object.keys(selectionWeights)) if(!value.tickers.includes(ticker)) delete selectionWeights[ticker];
  syncSchoolSelection();
  refreshFitBadges();
  renderSelectionDetails();
  updateResearchAction();
}
function syncSchoolSelection() {
  schoolLab?.setSelection({tickers:selectedSnapshot.tickers,assets:selectedSnapshot.assets,market:selectedSnapshot.market,holdings:selectedSnapshot.positions,budget:state.profile?.budget||10000});
}
function renderSelectionDetails() {
  if(!selectionDetails || !state.match?.eligible)return;
  selectionDetails.replaceChildren();
  const chosen=selectedSnapshot.tickers;
  const header=append(node('article','card wide'),node('p','eyebrow','YOUR CURRENT SELECTION'),node('h3','',chosen.length?chosen.join(' · '):'No stocks selected'),node('p','small muted','This view follows your checkboxes. Existing template weights are retained; newly added stocks start at 0% for observation. Money removed from the selection stays in cash. Edit the simulated percentages below to explore a different split.'));
  if(!selectedSnapshot.saved)header.append(node('p','card-footnote',portableMode?'This selection is used in the current portable session.':'Selection changed locally. Save it in the watchlist to update server tracking.'));
  selectionDetails.append(header);
  let plan;
  try{plan=selectedPlan(state.match,{...selectedSnapshot,budget:state.profile.budget},selectionWeights);}catch(error){selectionDetails.append(node('p','notice error',error.message));return;}
  const allocation=append(node('article','card'),node('p','eyebrow','SIMULATED AMOUNTS'),node('h3','','How your selected money is split'),allocationBar(plan.allocations),allocationTable(plan.allocations));
  allocation.append(node('p','small muted','These amounts are hypothetical targets, not purchases or a new AI recommendation. Cash remains available. Your recorded trades are shown separately in My holdings.'));
  const watchOnly=plan.allocations.filter(a=>a.ticker!=='CASH'&&a.weight===0);
  if(watchOnly.length)allocation.append(node('p','notice',`${watchOnly.map(a=>a.ticker).join(', ')} ${watchOnly.length===1?'is':'are'} on your watchlist at $0. This is not an AI error. Use Adjust simulated percentages below if you want to model an investment.`));
  const form=node('form','plan-weight-form');
  for(const a of plan.allocations.filter(a=>a.ticker!=='CASH')){
    const label=node('label','',`${a.ticker} simulated weight (%)`),input=node('input');input.type='number';input.min='0';input.max='100';input.step='0.1';input.name=a.ticker;input.value=String(a.weight);label.append(input);form.append(label);
  }
  const result=node('p','small');result.setAttribute('role','status');
  const apply=node('button','secondary','Update simulated amounts');apply.type='submit';form.append(apply,result);
  form.addEventListener('submit',event=>{event.preventDefault();const next={};for(const ticker of chosen)next[ticker]=Number(new FormData(form).get(ticker));try{selectedPlan(state.match,{...selectedSnapshot,budget:state.profile.budget},next);selectionWeights=next;renderSelectionDetails();updateResearchAction();}catch(error){result.textContent=error.message;}});
  if(chosen.length)allocation.append(more('Adjust simulated percentages','selected-weights',form));
  allocation.append(button('Download this selection','secondary',()=>download({type:'selected-stock-simulation',generatedAt:new Date().toISOString(),...plan},'proto-selected-allocation.json')));selectionDetails.append(allocation);
  const risk=append(node('article','card'),node('p','eyebrow','WHAT COULD GO WRONG'),node('h3','','A difficult-market example'),node('strong','',`${pct(plan.stress.lossPct)} · ${usd.format(plan.stress.lossAmount)}`),node('p','small muted','This stress example is recalculated from only your selected amounts and cash. Actual losses can be larger; this is not a forecast, backtest or loss limit.'));
  risk.append(more('See the assumed price changes','selected-risk-assumptions',list(plan.stress.assumptions.map(a=>`${a.ticker}: ${pct(a.returnPct)}`)),node('p','small','Newly searched assets without a maintained shock assumption use an illustrative 50% fall. Cash assumes no change; inflation, fees, taxes and currency effects are excluded. A zero-dollar watch item contributes no portfolio loss.')));
  if(plan.stress.lossPct>Math.min(state.profile.lossCapacity,state.profile.lossTolerance))risk.append(node('p','notice warning','This example exceeds the loss level in your answers. Consider reducing the simulated investment before continuing.'));
  if(chosen.some(t=>!state.match.allocations.some(a=>a.ticker===t)))risk.append(node('p','notice','Your added stocks have not been assessed by the original AI match. Explore their history and concentration risk before assigning money.'));
  selectionDetails.append(risk);
  const actions=append(node('article','card wide'),node('p','eyebrow','IF THE PRICE CHANGES'),node('h3','','Explore a possible next step'),node('p','small',chosen.length?`Use ${chosen.join(', ')} with a strategy, enter a reference price, and explore a rise or fall. Each scenario explains what else needs checking before a buy or sell review.`:'Choose at least one stock above to see a price scenario.'),button('Explore selected stocks & price scenarios →','primary',()=>{setTab('community');syncSchoolSelection();schoolLab?.select(state.match.template.id);}));
  selectionDetails.append(actions);
  const uploaded=state.selectedResearchType==='uploaded';
  const reportTickers=uploaded?[]:(state.report?.allocations||state.report?.match?.allocations||[]).map(a=>a.ticker).filter(t=>t!=='CASH');
  const coverage=uploaded?`Open uploaded document: ${state.uploadedDocument?.filename||'report'}. Its stock coverage has not been verified; review the original text.`:reportTickers.length?`Open report allocation: ${reportTickers.join(', ')}. Check its coverage before applying it to your selection.`:'No selected-stock research coverage has been verified yet.';
  const research=append(node('article','card wide'),node('p','eyebrow','LONGER-TERM RESEARCH'),node('h3','','Research your selected stocks'),node('p','small',`Current selection: ${chosen.join(', ')||'none'}. A new request uses these stocks and the simulated amounts above, including $0 watch-only stocks. Cash is not researched as a stock.`),node('p','small muted',coverage),node('p','small muted',`Research approach: ${state.match.template.name}. Exploring another approach in the strategy lab does not change this matched approach. Saved and uploaded reports keep their original inputs.`),button('Review research inputs →','secondary',()=>{setTab('research');$('research-tools').open=true;$('research-action').scrollIntoView({block:'start'});}));
  selectionDetails.append(research);
}
function trackingContext(){return {match:state.match,profile:state.profile,sessionToken:state.sessionToken,pending:!!state.matchController||isStale()};}
function rememberStrategy(){
  if(portableMode)return;
  try{sessionStorage.setItem('proto-strategy-session-v1',JSON.stringify({token:state.sessionToken,profile:state.profile,templateId:state.match?.template?.id,matchId:state.match?.id,templateVersion:state.match?.template?.version,selection:state.match?.selection,explanation:savedExplanation(state.explanation)}));}catch{}
}
// Keep only bounded display fields. Cached AI text is never used as server authority.
function savedExplanation(value){
  if(!value || !['ready','error','unavailable'].includes(value.status) || typeof value.summary!=='string')return null;
  const clean={status:value.status,summary:value.summary.slice(0,1600)};
  for(const key of ['why','risks','nextSteps'])clean[key]=Array.isArray(value[key])?value[key].filter(x=>typeof x==='string').slice(0,5).map(x=>x.slice(0,600)):[];
  if(typeof value.model==='string')clean.model=value.model.slice(0,100);
  if(typeof value.generatedAt==='string'&&Number.isFinite(Date.parse(value.generatedAt)))clean.generatedAt=value.generatedAt;
  return clean;
}
function restoreStrategy(){
  if(portableMode)return;
  try{
    const saved=JSON.parse(sessionStorage.getItem('proto-strategy-session-v1')||'null');
    if(!saved||typeof saved.token!=='string'||saved.token.length>256||!saved.token)return;
    const profile=validateProfile(saved.profile), form=$('profile-form');
    populateTemplateOptions();
    for(const [key,value]of Object.entries(profile)){const field=form.elements.namedItem(key);if(field){if(field.type==='checkbox')field.checked=value===true;else field.value=String(value);}}
    state.profile=profile;state.signature=signature(readProfile());state.sessionToken=saved.token;
    state.match=createMatch({...profile,templateId:saved.templateId});state.shortPlan=createShortPlan(state.match,null);
    if(saved.selection?.method==='deepseek'&&saved.selection.selectedTemplateId===state.match.template.id)state.match.selection={method:'deepseek',selectedTemplateId:state.match.template.id};
    state.explanation=savedExplanation(saved.explanation)||{status:'unavailable',summary:'This earlier session has no saved AI explanation. Refresh the AI match below to request one.'};
    if((saved.matchId&&saved.matchId!==state.match.id)||(saved.templateVersion&&saved.templateVersion!==state.match.template.version))state.explanation={status:'unavailable',summary:'The maintained plan changed since this answer was saved. Refresh the AI match to explain the current rules.'};
    state.explanation.restored=true;
    renderPortfolio();setTab('portfolio');
  }catch{}
}
function more(label, key, ...children) {
  const details = node('details', 'more-panel');
  details.open = expandedSections.has(key);
  details.setAttribute('data-detail-key', key);
  details.append(node('summary', '', label), append(node('div', 'detail-body'), ...children));
  details.addEventListener('toggle', () => { if (details.open) expandedSections.add(key); else expandedSections.delete(key); });
  return details;
}
function revealControl(id) {
  const control = $(id);
  let parent = control?.parentElement;
  while (parent) { if (parent.tagName?.toLowerCase() === 'details') parent.open = true; parent = parent.parentElement; }
  control?.focus?.();
}
function list(items, className = 'detail-list') {
  const ul = node('ul', className);
  for (const item of Array.isArray(items) ? items : []) ul.append(node('li', '', stringify(item)));
  return ul;
}
function stringify(value) {
  if (typeof value === 'string' || typeof value === 'number') return String(value);
  if (value == null) return '';
  if (Array.isArray(value)) return value.map(stringify).join(' · ');
  return Object.entries(value).map(([key, val]) => `${humanize(key)}: ${stringify(val)}`).join(' · ');
}
function humanize(value) { return String(value).replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[_-]/g, ' ').replace(/^./, (s) => s.toUpperCase()); }
function date(value) { if (!value) return 'Not recorded'; const d = new Date(value); return Number.isNaN(d.getTime()) ? String(value) : d.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }); }
function safeLink(value, label) {
  if (typeof value !== 'string') return node('span', '', label || stringify(value));
  try { const url = new URL(value); if (!['https:', 'http:'].includes(url.protocol)) return node('span', '', label || value); const a = node('a', '', label || url.hostname); a.href = url.href; a.target = '_blank'; a.rel = 'noopener noreferrer'; return a; } catch { return node('span', '', label || value); }
}
function sourceElement(source) {
  if (typeof source === 'string') return safeLink(source, source.startsWith('http') ? source : undefined);
  if (!source || typeof source !== 'object') return node('span', '', 'Source not recorded');
  const span = node('span');
  span.append(safeLink(source.url || source.href, source.title || source.name || source.provider || 'Source'));
  if (source.author) span.append(document.createTextNode(` · ${source.author}`));
  if (source.asOf || source.date || source.accessedAt) span.append(document.createTextNode(` · ${source.asOf || source.date || source.accessedAt}`));
  if (source.note) span.append(document.createTextNode(` — ${source.note}`));
  return span;
}
function announce(text, error = false) { const el = $('global-message'); el.textContent = text; el.hidden = !text; el.className = error ? 'global-message notice error' : 'global-message'; }
function localMessage(id, text, error = false) { const el = $(id); el.textContent = text; el.hidden = !text; el.className = error ? 'notice error' : 'notice'; }
async function request(path, { method = 'GET', body, headers = {}, signal, timeout = 30000 } = {}) {
  if (portableMode) {
    if (method === 'GET' && path === '/api/templates') return { templates: TEMPLATES };
    if (method === 'GET' && path === '/api/examples') return { reports: portableReports.map((report) => ({ id: report.id, title: report.title, generatedAt: report.generatedAt, profileSummary: `${usd.format(report.profile?.budget || 10000)} · saved example · original inputs retained` })) };
    if (method === 'GET' && path.startsWith('/api/examples/')) {
      const report = portableReports.find((item) => item.id === decodeURIComponent(path.slice('/api/examples/'.length)));
      if (report) return { report: structuredClone(report) };
    }
    throw new Error('This is the portable demo. Open START-HERE.html for the connected app setup; live AI, fresh prices and new research need its local server.');
  }
  const controller = new AbortController();
  const abort = () => controller.abort(signal?.reason);
  if (signal?.aborted) abort();
  signal?.addEventListener('abort', abort, { once: true });
  const timer = setTimeout(() => controller.abort(new DOMException('Request timed out', 'TimeoutError')), timeout);
  try {
    const response = await fetch(path, { method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers }, body: body ? JSON.stringify(body) : undefined, signal: controller.signal, cache: 'no-store' });
    let data; try { data = await response.json(); } catch { const error=new Error('The server returned an unreadable response. Check the local server and try again.');error.status=response.status;throw error; }
    if (!response.ok) {
      const detail = typeof data.error === 'string' ? data.error : data.error?.message || data.message;
      const error = new Error(detail || `Request could not be completed (${response.status}).`);
      error.status=response.status;
      const retry=Number(response.headers?.get?.('retry-after'));
      if(Number.isFinite(retry)&&retry>0)error.message+=` Try again in about ${Math.ceil(retry/60)} minute(s).`;
      throw error;
    }
    return data;
  } catch (error) {
    if (controller.signal.aborted && !signal?.aborted) throw new Error('The request took too long. Your rule-based portfolio is still available; try the connection again.');
    if (error instanceof TypeError) throw new Error('Cannot reach the app server. Start the local server or check your connection.');
    throw error;
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
}

function readProfile() {
  const form = new FormData($('profile-form'));
  const profile = { budget: Number(form.get('budget')), goal: form.get('goal'), horizon: form.get('horizon'), review: form.get('review'), assetPreference: form.get('assetPreference'), lossTolerance: Number(form.get('lossTolerance')), lossCapacity: Number(form.get('lossCapacity')), essentialMoney: form.has('essentialMoney'), experience: form.get('experience'), inverseInterest: form.get('inverseInterest'), prompt: String(form.get('prompt') || '').trim(), startingPortfolio: 'cash' };
  if (form.get('templateId')) profile.templateId = form.get('templateId');
  return profile;
}
const signature = (profile) => JSON.stringify(Object.keys(profile).sort().map((key) => [key, profile[key]]));
function isStale() { return !!state.signature && signature(readProfile()) !== state.signature; }
function updateInputs() {
  const p = readProfile();
  const validBudget = Number.isFinite(p.budget) && p.budget >= 100 && p.budget <= 1000000;
  $('tolerance-dollars').textContent = validBudget ? `${pct(p.lossTolerance)} of ${usd.format(p.budget)} is ${usd.format(p.budget * p.lossTolerance / 100)}. This records your comfort level, not a loss limit.` : 'Enter an amount between $100 and $1,000,000 to see the dollar equivalent.';
  $('capacity-dollars').textContent = validBudget ? `${pct(p.lossCapacity)} of ${usd.format(p.budget)} is ${usd.format(p.budget * p.lossCapacity / 100)}. Consider upcoming bills and commitments.` : '';
  $('prompt-count').textContent = `${$('prompt').value.length.toLocaleString()} / 1,500`;
  $('stale-notice').hidden = !isStale();
  if (isStale() && state.shortPlanController) { state.shortPlanController.abort(); state.shortPlanController = null; state.shortPlanLoading = false; renderPortfolio(); }
  if (isStale() && state.matchController) {
    state.matchController.abort(); state.matchController = null; state.matchSequence += 1;
    state.explanation = { status: 'unavailable', summary: 'The profile changed before the explanation completed. Match your updated inputs to request a new explanation.' };
    renderPortfolio();
  }
  updateResearchAction();
  watchlist?.update(trackingContext());
}
function setTab(name, focus = false) {
  if (!['questionnaire', 'portfolio', 'research', 'community'].includes(name)) return;
  state.activeTab = name;
  if(name==='portfolio')renderSelectionDetails();
  for (const tab of document.querySelectorAll('[data-tab]')) { const selected = tab.dataset.tab === name; tab.setAttribute('aria-selected', String(selected)); tab.tabIndex = selected ? 0 : -1; if (selected && focus) tab.focus(); }
  for (const panel of document.querySelectorAll('.tab-panel')) panel.hidden = panel.id !== `panel-${name}`;
  notifyHeight();
}
function snapshot(profile, title = 'Inputs behind this result') {
  const details = node('details', 'snapshot'); details.append(node('summary', '', title));
  const grid = node('div', 'snapshot-grid');
  const entries = [ ['Starting amount', `${usd.format(profile.budget)} · cash`], ['Goal', labels.goal[profile.goal]], ['Horizon', labels.horizon[profile.horizon]], ['Review time', labels.review[profile.review]], ['Loss comfort / capacity', `${pct(profile.lossTolerance)} / ${pct(profile.lossCapacity)}`], ['Asset preference', labels.assetPreference[profile.assetPreference]], ['Experience', profile.experience === 'new' ? 'New investor' : 'Some experience'], ['Inverse ETF interest', labels.inverseInterest[profile.inverseInterest]], ['Essential expenses', profile.essentialMoney ? 'Money may be needed for essentials' : 'Not earmarked for essentials'] ];
  for (const [label, value] of entries) grid.append(append(node('div'), node('strong', '', label), document.createTextNode(value || 'Not recorded')));
  details.append(grid); if (profile.prompt) details.append(node('p', 'snapshot-text', `Your words: ${profile.prompt}`)); return details;
}

async function refreshHealth() {
  if (portableMode) {
    $('api-status').textContent = 'Portable demo · rules ready';
    $('api-status').className = 'status-pill neutral';
    $('worker-status').textContent = portableReports.length ? 'Saved research available' : 'Upload your research';
    $('capability-note').textContent = 'Smart Trading for Everyone. Explore the questionnaire, rule-based allocations, report uploads and saved research here. Fresh AI explanations, prices and new TradingAgents reports require the connected app described in START-HERE.html.';
    $('refresh-health').textContent = 'Check demo status';
    renderModeBanner(); updateResearchAction(); return;
  }
  $('refresh-health').disabled = true;
  try {
    state.health = await request('/api/health', { timeout: 10000 });
    $('api-status').textContent = state.health.deepseekConfigured ? 'DeepSeek configured' : 'Rule matching ready';
    $('api-status').className = state.health.deepseekConfigured ? 'status-pill' : 'status-pill neutral';
    $('worker-status').textContent = state.health.worker?.online ? 'Research worker: online' : 'Research worker: offline';
    $('capability-note').textContent = state.health.deepseekConfigured ? 'DeepSeek is configured on the server. Request a match to confirm a live response. Rule-based matching is ready now.' : 'Rule-based matching is ready. DeepSeek is not configured yet; the allocation still works, and no AI explanation will be fabricated.';
    if (state.health.mode) $('api-status').title = `Server mode: ${state.health.mode}`;
  } catch (error) {
    state.health = null; $('api-status').textContent = 'Server unavailable'; $('api-status').className = 'status-pill warning'; $('worker-status').textContent = 'Research worker: connection unknown'; $('capability-note').textContent = 'The server is unavailable. You can still try the local rule-based portfolio matcher. AI explanations and new research need the server.';
  } finally { $('refresh-health').disabled = false; renderModeBanner(); updateResearchAction(); }
}
function renderModeBanner(){
  const area=$('mode-banner');if(!area)return;area.replaceChildren();
  if(portableMode){
    area.append(node('strong','','Offline backup · saved reports only'),node('p','small','New DeepSeek answers and TradingAgents reports need the running local app. Start START-DEMO.cmd (personal demo) or follow README.txt (submission).'));
    const link=node('a','secondary','Open live AI app →');link.href='http://127.0.0.1:8787/';link.target='_blank';link.rel='noopener noreferrer';area.append(link,node('p','card-footnote','This opens the app on this computer. Re-enter your answers there; offline selections are not transferred.'));
  }else{
    area.append(node('strong','',state.health?'Connected app · prepared research ready':'Local app · connection needs attention'),node('p','small',state.health?.deepseekConfigured?'Show your plan for a fresh DeepSeek explanation. Open Research for the prepared report, ready to present.':'Start the configured local services, then use Check connection. Saved reports remain available.'));
    area.append(button('Check connection','text-button',refreshHealth));
  }
}
async function loadTemplates() {
  try { const data = await request('/api/templates', { timeout: 10000 }); if (Array.isArray(data.templates) && data.templates.length) state.templates = data.templates; } catch { /* The bundled team templates remain usable offline. */ }
  populateTemplateOptions();renderTemplates();
}
function populateTemplateOptions(){
  const selected = $('templateId').value; $('templateId').replaceChildren(node('option', '', 'Match automatically')); $('templateId').firstChild.value = '';
  for (const template of state.templates.filter(item => item.matchable === true)) { const option = node('option', '', template.shortLabel || template.name); option.value = template.id; $('templateId').append(option); }
  if ([...$('templateId').options].some((o) => o.value === selected)) $('templateId').value = selected;
}

async function submitProfile(event) {
  event?.preventDefault();
  localMessage('form-error', '');
  let profile; try { profile = validateProfile(readProfile()); } catch (error) { localMessage('form-error', error.message, true); $('form-error').scrollIntoView({ block: 'nearest' }); return; }
  state.matchController?.abort();
  state.shortPlanController?.abort(); state.shortPlanController = null; state.shortPlanStatus = null; state.shortPlanLoading = false;
  const sequence = ++state.matchSequence;
  state.matchController = new AbortController();
  const signal = state.matchController.signal;
  const previousSessionToken = state.sessionToken;
  state.profile = structuredClone(profile); state.signature = signature(readProfile()); state.sessionToken = null;
  state.match = createMatch(profile);
  state.shortPlan = createShortPlan(state.match, null);
  state.explanation = { status: 'loading' };
  $('stale-notice').hidden = true;
  renderPortfolio(); setTab('portfolio');
  if (portableMode) {
    state.explanation = { status: 'unavailable', summary: 'Portable demo: the maintained rules calculated this allocation. Open a saved research report or upload your own document in Long-term research. Start the connected app with your own API key for a fresh AI explanation and market observations.' };
    state.matchController = null; renderPortfolio(); updateResearchAction();
    announce('Your rule-based match and preliminary checklist are ready. Saved research keeps its original profile and dates.'); return;
  }
  announce('Your rule-based match is ready. Connecting to the server for its explanation.');
  try {
    const data = await request('/api/match', { method: 'POST', body: { profile }, headers: previousSessionToken ? { 'X-Session-Token': previousSessionToken } : {}, signal, timeout: 70000 });
    if (sequence !== state.matchSequence || isStale()) return;
    if (!data.match || !Array.isArray(data.match.allocations)) throw new Error('The server did not return a valid portfolio. The local rule-based preview remains available.');
    state.match = data.match; state.explanation = data.explanation || { status: 'unavailable', summary: 'An AI explanation was not returned.' }; state.sessionToken = data.sessionToken || null;
    if(state.explanation.status==='ready')state.explanation.generatedAt=new Date().toISOString();
    rememberStrategy();
    state.shortPlan = createShortPlan(state.match, null);
    if (state.sessionToken && state.match.eligible) void refreshShortPlan(sequence);
    announce(state.explanation.status === 'ready' ? 'Your strategy match and live AI explanation are ready.' : 'Your strategy match is ready. The explanation panel shows the AI connection status.');
  } catch (error) {
    if (signal.aborted || sequence !== state.matchSequence) return;
    state.explanation = { status: 'error', summary: error.message };
    announce('Your local strategy match is ready. The server explanation could not be completed.');
  } finally { if (sequence === state.matchSequence) { state.matchController = null; renderPortfolio(); updateResearchAction(); } }
}

function renderPortfolio() {
  const area = $('portfolio-content'); selectionDetails=null; matchedFitBadges=[]; area.replaceChildren(); $('portfolio-empty').hidden = !!state.match; area.hidden = !state.match; if (!state.match) return;
  const match = state.match;
  const header = node('div', 'section-heading');
  header.append(append(node('div'), node('p', 'eyebrow', 'YOUR STRATEGY MATCH'), node('h2', '', match.eligible ? match.template?.name || 'Your starting allocation' : 'Keep essential money available.')));
  header.append(button('Edit profile', 'secondary', () => setTab('questionnaire', true))); area.append(header);
  area.append(node('p', 'muted', match.eligible ? match.template?.beginnerSummary || match.template?.description || 'A starting allocation based on your profile.' : 'Keep money for essential expenses and emergencies available.'));
  const badges = node('div', 'badge-row'); badges.append(node('span', 'status-pill', match.selection?.method === 'deepseek' ? 'AI template match' : 'Rule-based template match'), node('span', 'status-pill neutral', `${usd.format(state.profile.budget)} · starting from cash`)); area.append(badges);
  area.append(node('p', 'notice', 'This is a starting plan. It does not place trades, and losses can exceed the example below.'));
  if (Array.isArray(match.warnings) && match.warnings.length) area.append(more('More about this plan’s limits', 'plan-limits', list(match.warnings)));
  if (!match.eligible) { syncSelection({tickers:[],assets:[],positions:[],market:null,saved:false}); area.append(list(match.reasons)); area.append(snapshot(state.profile)); updateResearchAction(); return; }
  area.append(renderAIExplanation());
  if(!watchlist)watchlist=createWatchlist(document,{request,getContext:trackingContext,portableMode,onSelectionChange:syncSelection,onExplore:id=>{setTab('community');schoolLab?.select(id);}});
  watchlist.update(trackingContext());selectedSnapshot=watchlist.getSelection();syncSchoolSelection();area.append(watchlist.element);
  area.append(more('Compare other approaches that fit your answers', 'other-strategies', renderRecommendedSchools(match)));
  selectionDetails=node('div','portfolio-grid');renderSelectionDetails();
  area.append(more('See allocation, risk and research details','full-plan-details',selectionDetails));
  const original=append(node('div'),node('p','notice','Original questionnaire snapshot. The following daily observations refer to the initial template stocks, before any checkbox or percentage changes.'),node('p','small',`Initial stocks: ${match.allocations.map(a=>a.ticker).join(', ')}.`),renderShortPlan());
  area.append(more('Original AI match & daily observations','original-match-snapshot',original));
  if (match.template?.source) area.append(more('Strategy source & version', 'plan-source', node('p', 'small', `Template ${match.template.version || 'unrecorded'}`), sourceElement(match.template.source)));
  area.append(snapshot(state.profile)); updateResearchAction();
}
function renderAIExplanation(){
  const explanation=state.explanation||{status:'unavailable',summary:'Create a fresh match to request an AI explanation.'};
  const card=append(node('article','card ai-brief'),node('p','eyebrow','YOUR AI EXPLANATION'),node('h3','','Why this starting plan?'));
  const loading=explanation.status==='loading',ready=explanation.status==='ready';
  card.append(node('span',`status-pill ${ready?'':loading?'neutral':'warning'}`,loading?'DeepSeek is thinking…':ready?(explanation.restored?'Saved DeepSeek answer':'Fresh DeepSeek answer'):(portableMode?'Offline · rules only':'AI answer unavailable')));
  card.append(node('p','',loading?'Your rule-based plan is ready below. Waiting for DeepSeek to explain the match.':explanation.summary||state.match.reasons?.join(' ')));
  card.append(node('p','card-footnote',`Applies to the original mix: ${state.match.allocations.map(a=>a.ticker).join(', ')}. Checkbox changes do not update this answer.${explanation.generatedAt?` Answer received ${date(explanation.generatedAt)}.`:''}`));
  const extra=node('div');
  for(const [key,title]of [['why','Why it fits'],['risks','What to watch out for'],['nextSteps','Next steps']])if(Array.isArray(explanation[key])&&explanation[key].length)extra.append(node('h4','',title),list(explanation[key]));
  if(extra.children.length)card.append(more('More about the AI answer','ai-explanation-detail',extra));
  const actions=node('div','card-actions');
  if(!portableMode){const retry=button('Refresh AI match','secondary',()=>submitProfile());retry.disabled=loading||!!state.matchController;actions.append(retry);}
  actions.append(button('View prepared research →','primary',()=>{setTab('research');$('demo-prepared-report').scrollIntoView({block:'start',behavior:'smooth'});}));card.append(actions);
  card.append(node('p','small muted',portableMode?'This backup cannot call DeepSeek. Use Open live AI app above for a new answer.':'The prepared TradingAgents report is ready to open in Research. Fresh analysis is optional under More options.'));
  return card;
}
function allocationBar(allocations) { const bar = node('div', 'allocation-bar'); bar.setAttribute('aria-hidden', 'true'); for (const [index, a] of allocations.entries()) { const segment = node('span'); segment.style.width = `${Math.max(0, Number(a.weight))}%`; segment.style.backgroundColor = palette[index % palette.length]; bar.append(segment); } return bar; }
function allocationTable(allocations) {
  const table = node('table', 'allocation-table'); table.setAttribute('aria-label', 'Portfolio allocation');
  const head = node('thead'); const headings = node('tr'); for (const text of ['Asset', 'Weight', 'Amount']) headings.append(node('th', '', text)); head.append(headings); table.append(head);
  const body = node('tbody');
  for (const a of allocations) { const row = node('tr'); const asset=append(node('td'), node('strong', 'ticker', a.ticker), node('span', 'asset-name', a.name));if(a.ticker!=='CASH'&&Number(a.weight)===0)asset.append(node('span','asset-name','Watch only · no money assigned'));row.append(asset, node('td', '', pct(a.weight)), node('td', '', usd.format(a.amount))); body.append(row); }
  const foot = node('tfoot'); foot.append(append(node('tr'), node('td', '', 'Total'), node('td', '', pct(allocations.reduce((sum, a) => sum + Number(a.weight), 0))), node('td', '', usd.format(allocations.reduce((sum, a) => sum + Number(a.amount), 0))))); table.append(body, foot); return table;
}

async function refreshShortPlan(sequence = state.matchSequence) {
  if (!state.match?.eligible || !state.sessionToken || isStale()) return;
  state.shortPlanController?.abort();
  const controller = new AbortController(); state.shortPlanController = controller; state.shortPlanLoading = true;
  const profile = structuredClone(state.profile), matchId = state.match.id, token = state.sessionToken;
  try {
    const data = await request('/api/short-plan', {method:'POST', body:{profile, matchId}, headers:{'X-Session-Token':token}, signal:controller.signal, timeout:30000});
    if (sequence !== state.matchSequence || controller.signal.aborted || isStale() || state.match?.id !== matchId) return;
    if (!data.plan || data.plan.matchId !== matchId || !Array.isArray(data.plan.assets) || !Array.isArray(data.plan.steps)) throw new Error('The market checklist response did not match this portfolio.');
    state.shortPlan = data.plan; state.shortPlanStatus = data.marketStatus || null;
  } catch (error) {
    if (controller.signal.aborted || sequence !== state.matchSequence) return;
    state.shortPlanStatus = {error:error.message};
  } finally {
    if (state.shortPlanController === controller) { state.shortPlanController = null; state.shortPlanLoading = false; renderPortfolio(); }
  }
}
function renderShortPlan() {
  const section = append(node('article', 'card wide short-plan'), node('p', 'eyebrow', 'YOUR NEXT STEP'), node('h3', '', 'What to watch next'));
  const plan = state.shortPlan;
  if (!plan) { section.append(node('p', 'muted small', 'A rule-based checklist is unavailable for this profile.')); return section; }
  const statusLabels = {preliminary:'Rules ready · observations pending', ready:'Rules with market observations', partial:'Some market observations unavailable', unavailable:'Market observations unavailable', blocked:'No investment checklist for this profile'};
  section.append(node('span', `status-pill ${['partial', 'unavailable', 'blocked'].includes(plan.status) ? 'warning' : 'neutral'}`, statusLabels[plan.status] || humanize(plan.status)));
  section.append(node('p', 'plan-summary', 'Check the amounts, watch the stated conditions, and take time to review. A price signal alone is not an instruction to buy.'));
  if (state.shortPlanLoading) section.append(node('p', 'loading-line', 'Refreshing market observations. The conditional rules below remain available.'));
  if (state.shortPlanStatus?.error) section.append(node('p', 'notice warning', `${state.shortPlanStatus.error} The immediate checklist still uses its recorded rules.`));
  const steps = node('ol', 'plan-steps'); for (const step of Array.isArray(plan.steps) ? plan.steps : []) steps.append(append(node('li'), node('strong', '', step.title || 'Review step'), node('p', 'muted small', step.detail || ''))); if (steps.children.length) section.append(more('Walk me through it', 'plan-steps', steps));
  const assets = node('div', 'plan-assets');
  for (const asset of Array.isArray(plan.assets) ? plan.assets : []) {
    const card = node('article', 'plan-asset'); card.append(append(node('div', 'section-heading'), node('strong', 'ticker', asset.ticker), node('span', 'status-pill neutral', asset.status === 'observed' ? 'Observation available' : asset.status === 'not_required' ? 'Allocation review' : 'Waiting for observation')));
    card.append(node('h4', '', asset.actionTitle || 'Review the conditions'));
    const detail = node('div'); detail.append(node('p', 'muted small', asset.explanation || ''), node('p', 'card-footnote', `Target: ${measuredPercent(asset.targetWeight)} · ${typeof asset.targetAmount === 'number' ? usd.format(asset.targetAmount) : 'Amount unavailable'}`), list(asset.conditions));
    if (asset.market) {
      const market = asset.market;
      card.append(node('p', 'card-footnote', `Data date: ${market.priceDate || 'Not recorded'}`));
      detail.append(node('p', 'card-footnote', `Observation date: ${market.priceDate || 'Not recorded'}${market.currency ? ` · ${market.currency}` : ''}${typeof market.close === 'number' && Number.isFinite(market.close) ? ` · Close ${market.currency === 'USD' ? market.close.toLocaleString('en-US', {style:'currency', currency:'USD', maximumFractionDigits:2}) : market.close}` : ''}${typeof market.adjusted === 'boolean' ? ` · ${market.adjusted ? 'Adjusted prices' : 'Unadjusted prices'}` : ''}`));
      const indicators = [['sma20', '20-day SMA'], ['sma100', '100-day SMA'], ['bollingerUpper', 'Upper Bollinger Band'], ['bollingerLower', 'Lower Bollinger Band'], ['rsi14', '14-day RSI'], ['atr14', '14-day ATR (USD)']].filter(([key]) => typeof market[key] === 'number' && Number.isFinite(market[key]));
      if (indicators.length) detail.append(node('p', 'card-footnote', indicators.map(([key, label]) => `${label}: ${Number(market[key]).toFixed(2)}`).join(' · ')));
      if (market.priceBasis) detail.append(node('p', 'card-footnote', `Price basis: ${market.priceBasis}`));
      if (market.fallbackReason) detail.append(node('p', 'notice', market.fallbackReason));
      if (market.source) detail.append(append(node('p', 'card-footnote'), sourceElement(market.source)));
      if (market.providerReference) {
        const reference = market.providerReference;
        const available = reference.status === 'reference_only' && Number.isFinite(reference.latestClose);
        detail.append(node('h5', '', 'AKShare source check'), node('p', 'small', available ? `${reference.source || 'AKShare'} · ${reference.priceDate || 'Date not recorded'} · Original close: ${reference.latestClose.toFixed(2)}. This unadjusted reference is separate from the adjusted prices used for indicators.` : 'An AKShare reference price is currently unavailable. Indicator data uses the source shown above.'));
        if (available && !reference.currencyVerified) detail.append(node('p', 'card-footnote', 'This reference feed does not independently confirm the quote currency. It is not used to calculate signals or amounts.'));
      }
    }
    if (asset.volatility) { const v = asset.volatility; detail.append(node('h5', '', 'ATR: how much the price moves'), node('p', 'small', `Measured ATR: ${Number(v.atr14).toFixed(2)} USD (${Number(v.percentOfClose).toFixed(2)}% of the recorded close). An illustrative ${v.illustrativeMultiplier}× distance is ${Number(v.illustrativeDistance).toFixed(2)} USD.`), node('p', 'small muted', v.explanation)); }
    card.append(more('More detail', `asset-${asset.ticker}`, detail));
    assets.append(card);
  }
  section.append(assets);
  const sourceDetails = node('div');
  sourceDetails.append(node('p', 'small', 'This checklist is independent of uploaded or generated long-term research. It uses maintained rules and does not place orders.'));
  if (Array.isArray(plan.dataAsOf) && plan.dataAsOf.length) sourceDetails.append(node('p', 'card-footnote', `Observation dates: ${plan.dataAsOf.join(', ')}`));
  if (plan.source?.fetchedAt) sourceDetails.append(node('p', 'card-footnote', `Market data retrieved ${date(plan.source.fetchedAt)}`));
  if (state.shortPlanStatus) {
    const market = state.shortPlanStatus;
    const cacheLabels = {cached:'Using cached market observations; review their recorded dates.', shared:'Using observations from a shared market-data request; review their recorded dates.', fresh:'Market observations refreshed. This is not a live streaming quote.', unavailable:'Market observations are unavailable. Follow the conditional rules and wait for verifiable data.'};
    if (cacheLabels[market.cache]) sourceDetails.append(node('p', 'card-footnote', cacheLabels[market.cache]));
    if (market.cutoffDate) sourceDetails.append(node('p', 'card-footnote', `Data cutoff: ${market.cutoffDate}`));
    if (market.warnings?.length) sourceDetails.append(list(market.warnings));
  }
  if (plan.summary) sourceDetails.append(node('p', 'small', plan.summary));
  if (plan.warnings?.length) sourceDetails.append(list(plan.warnings));
  if (plan.source?.templateSource) sourceDetails.append(append(node('p', 'card-footnote'), document.createTextNode('Rule reference: '), sourceElement(plan.source.templateSource)));
  section.append(more('Data sources & limits', 'market-sources', sourceDetails));
  if (state.sessionToken && !isStale()) { const refresh = button('Refresh market observations', 'secondary', () => { void refreshShortPlan(); renderPortfolio(); }); refresh.disabled = state.shortPlanLoading; section.append(append(node('div', 'card-actions'), refresh)); }
  return section;
}

function readResearchSelection() {
  const plan = selectedPlan(state.match, { ...selectedSnapshot, budget: state.profile?.budget }, selectionWeights);
  if (!plan.tickers.length) throw new Error('Choose at least one stock or ETF in Your plan before requesting research.');
  if (plan.tickers.some(ticker => !/^[A-Z][A-Z0-9.\-]{0,9}$/.test(ticker))) throw new Error('Research supports US stock and ETF tickers only. Review your selected symbols.');
  return { tickers: [...plan.tickers], weights: Object.fromEntries(plan.allocations.filter(row => row.ticker !== 'CASH').map(row => [row.ticker, row.weight])), plan };
}
function updateResearchAction() {
  const area = $('research-action'); area.replaceChildren();
  if (portableMode) {
    area.append(append(node('div'), node('strong', '', 'Explore saved research or upload a report'), node('p', 'muted small', 'This portable demo includes a previously generated TradingAgents report. It is separate from your current profile. Use the connected app to generate new research.')),
      button(portableReports.length ? 'Open saved research' : 'Upload a report', 'primary', () => { if (portableReports.length) loadExample(portableReports[0].id); else { setTab('research'); $('upload-form').scrollIntoView({ block: 'start' }); } }));
    return;
  }
  const match = state.match;
  let selection, selectionError;
  if (match?.eligible && !isStale()) { try { selection = readResearchSelection(); } catch (error) { selectionError = error.message; } }
  let title, description, actionLabel, action, disabled = false;
  if (!match) { title = 'Start with a strategy match'; description = 'Create your profile before requesting a personal research report.'; actionLabel = 'Go to profile →'; action = () => setTab('questionnaire'); }
  else if (isStale()) { title = 'Your inputs have changed'; description = 'Generate an updated match before requesting research. Existing reports keep their original inputs.'; actionLabel = 'Update my match →'; action = () => setTab('questionnaire'); }
  else if (!match.eligible) { title = 'Research allocation is unavailable for this profile'; description = 'Money needed for essential expenses should not be assigned to an investment portfolio by this tool.'; actionLabel = 'Review my profile'; action = () => setTab('questionnaire'); }
  else if (state.job && ['queued', 'running', 'processing'].includes(state.job.status)) { title = 'Your report is in progress'; description = 'The job keeps the exact input snapshot used when you requested it.'; actionLabel = 'Research in progress'; disabled = true; action = () => {}; }
  else if (state.researchSubmitting) { title = 'Submitting your research request'; description = 'The server is saving the exact stocks and simulated amounts you submitted. Please wait for the response.'; actionLabel = 'Submitting request…'; disabled = true; action = () => {}; }
  else if (state.matchController) { title = 'The server is finishing your strategy match'; description = 'Your local rule-based preview is ready. Research becomes available after the server confirms the match.'; actionLabel = 'Matching in progress'; disabled = true; action = () => {}; }
  else if (!state.sessionToken) { title = 'Complete the server match first'; description = 'You can explore the local preview now. A confirmed server match is needed before creating a research task.'; actionLabel = 'Finish matching'; action = () => submitProfile(); }
  else if (selectionError) { title = 'Review your research selection'; description = selectionError; actionLabel = 'Choose stocks and amounts'; action = () => setTab('portfolio'); }
  else if (!state.health?.worker?.online || !state.health?.researchConfigured) { title = state.health ? 'The local research worker is not ready' : 'Research server unavailable'; description = 'The portfolio matcher remains usable. Start the configured TradingAgents worker, then check the connection.'; actionLabel = 'Check connection'; action = refreshHealth; }
  else if (state.health.selectedStockResearch !== true) { title = 'Reconnect the research service'; description = 'The running service cannot yet accept your selected-stock inputs. Check the connection after the local service has updated.'; actionLabel = 'Check connection'; action = refreshHealth; }
  else { title = 'Research your selected stocks'; description = 'Every stock listed below will be researched, including watch-only items. More stocks take longer; the local worker may need several minutes per stock.'; actionLabel = 'Generate deep research →'; action = startResearch; }
  const copy = append(node('div'), node('strong', '', title), node('p', 'muted small', description));
  if (selection) {
    copy.append(node('p', 'small', `Research inputs${state.job && ['queued','running','processing'].includes(state.job.status) ? ' for your next request' : ''}: ${selection.tickers.join(', ')}.`), node('p', 'small muted', `Approach: ${match.template.name} (your matched approach). Exploring another strategy does not change this input.`));
    copy.append(more('Check the exact amounts to be sent', 'research-input-preview', allocationTable(selection.plan.allocations), node('p', 'small muted', 'Your simulated amounts, not purchases or a new AI-approved allocation. Stocks at $0 are researched as watch-only. Cash remains cash. Saving email reminders is not required.')));
  }
  const b = button(actionLabel, 'primary', action); b.disabled = disabled; area.append(copy, b);
}
async function startResearch() {
  if (portableMode) { announce('Open START-HERE.html for connected app setup. You can use saved research and upload reports in this demo.'); return; }
  if (!state.match?.eligible || isStale()) { announce('Match your current profile before requesting research.', true); return; }
  if (state.matchController || !state.sessionToken) { announce('Wait for the server match to finish, or retry matching, before requesting research.', true); updateResearchAction(); return; }
  if (state.researchSubmitting || (state.job && ['queued', 'running', 'processing'].includes(state.job.status))) return;
  if (state.health?.selectedStockResearch !== true) { announce('Reconnect the updated research service before submitting selected stocks.', true); updateResearchAction(); return; }
  let selection;
  try { selection = readResearchSelection(); } catch (error) { announce(error.message, true); updateResearchAction(); return; }
  const researchSelection = structuredClone({ tickers: selection.tickers, weights: selection.weights });
  const requestSignature = state.signature;
  const profile = structuredClone(state.profile);
  state.researchSubmitting = true;
  const action = $('research-action').querySelector('button'); if (action) { action.disabled = true; action.textContent = 'Submitting request…'; }
  try {
    const data = await request('/api/research', { method: 'POST', body: { profile, matchId: state.match.id, sessionToken: state.sessionToken, researchSelection }, headers: state.sessionToken ? { 'X-Session-Token': state.sessionToken } : {}, timeout: 15000 });
    if (!data.job?.id || !data.accessToken) throw new Error('The server did not return a usable research task. Please retry.');
    clearTimeout(state.pollTimer); state.job = data.job; state.jobToken = data.accessToken; state.jobProfile = data.job.inputSnapshot?.profile || profile; state.pollFailures = 0; state.generatedReport = null; state.report = null; state.reportExample = false; state.selectedResearchType = 'generated'; $('uploaded-report-content').hidden = true; rememberJob();
    $('report-content').hidden = true;
    let unchanged = false;
    try { const current = readResearchSelection(); unchanged = requestSignature === signature(readProfile()) && JSON.stringify({ tickers: current.tickers, weights: current.weights }) === JSON.stringify(researchSelection); } catch { /* The submitted snapshot remains unchanged if current inputs are no longer valid. */ }
    announce(unchanged ? 'Research requested for your selected stocks. Its submitted stocks and amounts are shown below.' : 'Research requested for the earlier selection shown below. Your current stocks, amounts or answers have changed; the submitted inputs stay fixed.');
    renderJob(); pollResearch();
  } catch (error) { announce(error.message, true); }
  finally { state.researchSubmitting = false; updateResearchAction(); }
}
function recordedResearchInputs(job, report) {
  const valid = input => input && Array.isArray(input.researchTickers) && input.researchTickers.length <= 8 && input.researchTickers.every(ticker => typeof ticker === 'string' && /^[A-Z][A-Z0-9.\-]{0,9}$/.test(ticker)) && Array.isArray(input.allocations) && input.allocations.length <= 9 && input.allocations.every(row => row && typeof row.ticker === 'string' && /^[A-Z][A-Z0-9.\-]{0,9}$/.test(row.ticker) && Number.isFinite(row.weight) && row.weight >= 0 && row.weight <= 100 && Number.isFinite(row.amount) && row.amount >= 0);
  if (valid(job?.inputSnapshot)) return job.inputSnapshot;
  if (!report || report.id !== job?.id) return null;
  const input = { profile: report.profile, template: report.match?.template, allocations: report.match?.allocations || [], researchTickers: report.match?.researchSelection?.tickers || report.provenance?.researchCoverage?.requested || report.research?.map(item => item.ticker) || [], source: report.match?.researchSelection ? 'user-selected' : 'questionnaire' };
  return valid(input) ? input : null;
}
function renderJob() {
  const area = $('job-status'); area.replaceChildren(); area.hidden = !state.job; if (!state.job) return;
  if ($('research-tools')) $('research-tools').open = true;
  const job = state.job;
  const display = { queued: 'Waiting for the research worker', running: 'Research is running', processing: 'Research is running', complete: 'Research report ready', completed: 'Research report ready', partial: 'Partial report ready · review unavailable sections', failed: 'Research could not be completed', error: 'Research could not be completed', unavailable: 'Previous research task is unavailable' };
  area.append(node('strong', '', display[job.status] || humanize(job.status)));
  area.append(node('p', '', `Requested ${date(job.createdAt)}${job.updatedAt ? ` · Updated ${date(job.updatedAt)}` : ''}`));
  if (job.stage) area.append(node('div', 'job-stage', typeof job.stage === 'string' ? job.stage : stringify(job.stage)));
  if (job.error) area.append(node('p', '', stringify(job.error)));
  if (['queued', 'running', 'processing'].includes(job.status)) { area.append(append(node('div', 'job-progress'), node('span')), node('p', '', 'Progress reflects worker updates. There is no estimated completion time.')); if (!state.health?.worker?.online) area.append(node('p', '', 'The worker is currently offline or has not sent a recent heartbeat. Awaiting its next update.')); }
  const inputs = recordedResearchInputs(job, state.generatedReport);
  if (inputs) {
    area.append(node('p', 'notice', `Submitted research inputs: ${inputs.researchTickers.join(', ') || 'No stock coverage recorded'}. These stay fixed even if you change your current selection.`));
    area.append(more('Submitted amounts and approach', `job-inputs-${job.id}`, node('p', 'small', `Approach: ${inputs.template?.name || 'Not recorded'} · ${inputs.source === 'user-selected' ? 'Your selected-stock simulation; not a new AI-approved allocation.' : 'Original questionnaire mix.'}`), allocationTable(inputs.allocations)));
  } else area.append(node('p', 'small muted', 'Stock inputs were not recorded in this older task status. Open its completed report to check the original coverage; today’s selection is not substituted.'));
  if (inputs?.profile || state.jobProfile) area.append(snapshot(inputs?.profile || state.jobProfile, 'Questionnaire submitted for this job'));
  if (state.generatedReport?.id === job.id) area.append(append(node('div', 'card-actions'), button('Open generated report', 'secondary', openGeneratedReport)));
  else if (['complete', 'completed', 'partial'].includes(job.status) && state.jobToken) area.append(append(node('div', 'card-actions'), button('Retrieve generated report', 'secondary', () => { state.pollFailures = 0; void pollResearch(); })));
}
async function pollResearch() {
  if (!state.job || !state.jobToken) return;
  clearTimeout(state.pollTimer); state.pollTimer = null;
  const jobId = state.job.id;
  try {
    const data = await request(`/api/research/${encodeURIComponent(jobId)}`, { headers: { 'X-Report-Token': state.jobToken }, timeout: 15000 });
    if (state.job?.id !== jobId) return;
    if (data.job?.id !== jobId || (data.report && data.report.id !== jobId)) throw new Error('The server returned a report for a different task. No report was substituted.');
    const recordedInputs = state.job.inputSnapshot;
    state.job = data.job;
    if (!state.job.inputSnapshot && recordedInputs) state.job.inputSnapshot = recordedInputs;
    state.pollFailures = 0; rememberJob();
    if (data.worker) { state.health = { ...(state.health || {}), worker: data.worker }; $('worker-status').textContent = data.worker.online ? 'Research worker: online' : 'Research worker: offline'; }
    renderJob(); updateResearchAction();
    if (data.report) {
      state.generatedReport = data.report;
      const keepCurrentView = state.reportExample || state.selectedResearchType === 'uploaded';
      if (!keepCurrentView) { state.report = state.generatedReport; state.reportExample = false; state.selectedResearchType = 'generated'; renderReport(); }
      renderJob(); announce(keepCurrentView ? 'Your generated report is ready. Use Open generated report above when you finish reading the current document.' : 'Your report is available. Check its data dates and any unavailable sections.'); return;
    }
    if (['failed', 'error', 'cancelled', 'complete', 'completed', 'partial'].includes(data.job?.status)) return;
    state.pollTimer = setTimeout(pollResearch, 4000);
  } catch (error) {
    if (state.job?.id !== jobId) return;
    if ([401, 403, 404].includes(error.status)) {
      clearTimeout(state.pollTimer); state.pollTimer = null; state.pollFailures = 0; state.jobToken = null;
      state.job = { ...state.job, status: 'unavailable', stage: 'This browser can no longer retrieve the previous task.', error: 'The task is missing or its private access token is no longer accepted. Your current document is unchanged. You can request new research for a confirmed profile; no new request was submitted automatically.' };
      rememberJob(); renderJob(); updateResearchAction(); announce('The previous research task is unavailable. The request button is unlocked for a new confirmed-profile report.', true); return;
    }
    state.pollFailures += 1;
    const area = $('job-status'); renderJob(); area.append(node('p', '', `Could not refresh the report: ${error.message}`));
    if (state.pollFailures < 3) state.pollTimer = setTimeout(pollResearch, 7000);
    else area.append(append(node('div', 'card-actions'), button('Resume status updates', 'secondary', () => { state.pollFailures = 0; pollResearch(); })));
  }
}
async function loadExamples() {
  const area = $('examples-list'); area.replaceChildren(node('p', 'muted small', 'Loading published reports…')); $('refresh-examples').disabled = true;
  try {
    const data = await request('/api/examples', { timeout: 12000 }); area.replaceChildren();
    if (!Array.isArray(data.reports) || !data.reports.length) { area.append(node('p', 'muted small', 'No real reports have been published yet. Complete a research run and publish its saved report to make it available here.')); return; }
    for (const report of data.reports) {
      const card = node('article', 'example-card'); card.append(node('span', 'status-pill neutral', 'Saved report'), node('h4', '', report.title || 'Research report'), node('p', '', `Generated ${date(report.generatedAt)}`), node('p', '', stringify(report.profileSummary)));
      card.append(button('Open saved report', 'secondary', () => loadExample(report.id))); area.append(card);
    }
  } catch (error) { area.replaceChildren(node('p', 'muted small', `Published reports are unavailable. ${error.message}`)); }
  finally { $('refresh-examples').disabled = false; }
}
async function loadExample(id) {
  try { const data = await request(`/api/examples/${encodeURIComponent(id)}`, { timeout: 15000 }); if (!data.report) throw new Error('This saved report is unavailable.'); state.report = data.report; state.reportExample = true; state.selectedResearchType = 'generated'; $('uploaded-report-content').hidden = true; renderReport(); renderJob(); setTab('research'); announce('Showing a previously generated report. Its inputs may differ from your current profile.'); $('report-content').scrollIntoView({ block: 'start' }); } catch (error) { announce(error.message, true); }
}

function openGeneratedReport() {
  const report = state.generatedReport;
  if (!report || report.id !== state.job?.id) { announce('This task has no matching generated report yet.', true); return; }
  const trigger = document.activeElement;
  state.report = report; state.reportExample = false; state.selectedResearchType = 'generated';
  $('uploaded-report-content').hidden = true;
  setTab('research'); renderReport();
  if ($('research-tools')) $('research-tools').open = true;
  const tickers = (Array.isArray(report.research) ? report.research : []).map(item => item.ticker).filter(Boolean).join(' / ');
  const opened = reportPopup?.openGenerated({
    reportTitle: report.title || 'Your generated research',
    reportNote: `${date(report.generatedAt)}${tickers ? ` · ${tickers}` : ''} · ${report.status === 'partial' ? 'Partial report · review source gaps' : 'Original generated report'}`,
    render: target => renderReport(target), trigger,
  });
  if (!opened) {
    const area = $('report-content'); area.setAttribute('tabindex', '-1');
    area.scrollIntoView({ block: 'start', behavior: 'auto' }); area.focus({ preventScroll: true });
  }
  announce('Opened your generated report with its original date and inputs. No new analysis was requested.');
}

function renderReport(area = $('report-content')) {
  renderSelectionDetails();
  area.replaceChildren(); area.hidden = !state.report || state.selectedResearchType === 'uploaded'; if (!state.report) return;
  if (!area.hidden && $('research-tools')) $('research-tools').open = true;
  const report = state.report; const article = node('article', 'report'); const header = node('header', 'report-header');
  header.append(node('p', 'eyebrow', state.reportExample ? 'PREVIOUSLY GENERATED REPORT' : 'YOUR RESEARCH REPORT'), node('h2', '', report.title || 'Portfolio research'));
  header.append(append(node('div', 'badge-row'), node('span', `status-pill ${report.status === 'partial' ? 'warning' : ''}`, report.status === 'partial' ? 'Partial report · review limitations' : 'Completed research'), node('span', 'status-pill neutral', report.provenance?.engine || 'Research engine not recorded')));
  header.append(node('p', 'small muted', `Research date: ${report.analysisDate || 'Not recorded'}`));
  if (report.match?.researchSelection) header.append(node('p', 'notice', `Research inputs: ${report.match.researchSelection.tickers.join(', ')}. Amounts are your submitted simulation; $0 stocks are watch-only research. This is not a new AI-approved allocation.`));
  header.append(more('Report information', `report-info-${report.id}`, append(node('div', 'report-meta'), node('span', '', `Generated: ${date(report.generatedAt)}`), node('span', '', `Model: ${report.provenance?.model || 'Not recorded'}`))));
  if (state.reportExample) header.append(node('p', 'notice', 'This is a saved public example. It was generated for the profile below, not for your current questionnaire.'));
  else if (report.profile && signature(report.profile) !== signature(readProfile())) header.append(node('p', 'notice warning', 'This report describes its original input snapshot. Your current questionnaire may differ.'));
  header.append(append(node('div', 'card-actions'), button('Download report JSON', 'secondary', () => download(report, `proto-research-${safeFile(report.id || 'report')}.json`)), button('Print / save PDF', 'secondary', printVisible)));
  if (report.profile) header.append(snapshot(report.profile)); article.append(header);
  article.append(createReportCompanion(document, {allocations:report.match?.allocations, budget:report.profile?.budget, tickers:report.match?.allocations?.map(row=>row.ticker) || report.research?.map(row=>row.ticker), factAsOf:report.analysisDate || report.generatedAt?.slice(0,10) || '1900-01-01'}));
  if (report.match?.allocations?.length) article.append(more('See the portfolio used for this report', `report-allocation-${report.id}`, append(node('section', 'report-section card'), node('p', 'eyebrow', 'ALLOCATION AT REPORT GENERATION'), node('h3', '', report.match.template?.name || 'Portfolio allocation'), allocationTable(report.match.allocations), node('p', 'card-footnote', 'These are the report’s original amounts, not a new instruction.'))));
  const outlook = node('section', 'report-section'); outlook.append(node('h3', '', 'A longer view: 1–3 and 6–12 months'), node('p', 'muted small', 'Conditional research views, not guaranteed forecasts. Each view should be read with its supporting evidence. The immediate short-term checklist in the portfolio remains separate.'));
  if (report.outlookMethod && typeof report.outlookMethod === 'object') {
    const method = report.outlookMethod;
    const methodLabel = method.type === 'local-editorial-evidence-review' ? 'Local review of saved evidence' : humanize(method.type || 'Recorded preparation step');
    outlook.append(more('How this outlook was prepared', `outlook-method-${report.id}`, node('p', 'card-footnote', `Outlook preparation: ${methodLabel}${method.generatedAt ? ` · ${date(method.generatedAt)}` : ''}${method.model ? ` · Model: ${method.model}` : ''}`), method.description ? node('p', 'notice', method.description) : null));
  }
  const horizons = node('div', 'outlook-grid');
  const reportViews = Array.isArray(report.outlook) ? report.outlook : [];
  const orderedViews = [...reportViews.filter(view => !/weeks?|\u5468/i.test(view.horizon || '')), ...reportViews.filter(view => /weeks?|\u5468/i.test(view.horizon || ''))];
  for (const view of orderedViews) {
    const card = node('article', 'outlook-card'); card.append(node('h4', '', view.horizon), node('p', '', view.status === 'unavailable' ? view.summary || 'A supported view is unavailable for this horizon.' : view.summary || 'No summary supplied.'));
    if (view.evidence?.length || view.conditions?.length) card.append(more('Why, and what could change?', `horizon-${report.id}-${view.horizon}`, view.evidence?.length ? append(node('div'), node('h5', '', 'Evidence'), list(view.evidence)) : null, view.conditions?.length ? append(node('div'), node('h5', '', 'What could change this view'), list(view.conditions)) : null)); horizons.append(card);
  }
  if (!horizons.children.length) horizons.append(node('p', 'muted small', 'No supported time-horizon outlook was supplied.')); outlook.append(horizons); article.append(outlook);
  const research = node('section', 'report-section'); research.append(node('h3', '', 'Research behind the candidates')); const sections = node('div', 'research-sections');
  for (const item of Array.isArray(report.research) ? report.research : []) {
    const asset = node('article', 'research-item');
    const quality = item.dataQuality || {};
    const hasError = item.status === 'error' || !!item.error;
    const limited = quality.status === 'limited' || hasError;
    const qualityLabel = hasError ? 'Research error' : quality.status === 'limited' ? 'Limited source coverage' : quality.status === 'not_independently_verified' ? 'Sources not independently verified' : 'Source verification not recorded';
    asset.append(append(node('div', 'section-heading'), node('h3', '', item.ticker || 'Asset'), node('span', `status-pill ${limited ? 'warning' : 'neutral'}`, qualityLabel)));
    asset.append(node('p', 'report-text', `Decision text: ${hasError ? 'Unavailable' : stringify(item.decision || 'Not supplied')}`));
    if (quality.message) asset.append(node('p', limited ? 'notice warning' : 'muted small', quality.message));
    if (Array.isArray(quality.affectedSections) && quality.affectedSections.length) asset.append(node('p', 'card-footnote', `Affected sections: ${quality.affectedSections.map(stringify).join(', ')}`));
    if (typeof quality.engineCompleted === 'boolean') asset.append(node('p', 'card-footnote', quality.engineCompleted ? 'The research engine finished. Completion does not certify source completeness or accuracy.' : 'The research engine did not finish this asset run.'));
    if (item.error) asset.append(node('p', 'notice error', stringify(item.error)));
    if (Array.isArray(item.warnings) && item.warnings.length) asset.append(list(item.warnings));
    const details = node('details'); details.append(node('summary', '', `Read ${item.ticker || 'asset'} research text`));
    for (const section of Array.isArray(item.sections) ? item.sections : []) details.append(node('h4', '', section.title || 'Analysis'), node('p', 'report-text', section.text || 'No text supplied.'));
    if (!Array.isArray(item.sections) || !item.sections.length) details.append(node('p', 'report-text', 'No research sections were supplied.'));
    asset.append(details); sections.append(asset);
  }
  if (!sections.children.length) sections.append(node('p', 'muted small', 'No completed per-asset research was supplied.')); research.append(sections); article.append(research);
  article.append(more('Explore the historical allocation comparison', `backtest-${report.id}`, renderBacktest(report.backtest)));
  if (report.hedgeReview) article.append(more('More about hedging', `hedge-${report.id}`, renderHedgeReview(report.hedgeReview)));
  const provenance = append(node('section', 'report-section card'), node('h3', '', 'Sources & limitations'));
  const p = report.provenance || {};
  provenance.append(node('p', 'small muted', `Template version: ${p.templateVersion || 'Not recorded'} · Engine commit: ${p.commit || 'Not recorded'}`));
  if (p.repository) provenance.append(append(node('p', 'small'), safeLink(p.repository, 'Research engine repository')));
  const sources = node('ul', 'source-list'); for (const source of Array.isArray(p.dataSources) ? p.dataSources : []) sources.append(append(node('li'), sourceElement(source))); if (sources.children.length) provenance.append(sources);
  const warnings = [...(Array.isArray(p.warnings) ? p.warnings : []), ...(Array.isArray(report.limitations) ? report.limitations : [])]; if (warnings.length) provenance.append(list(warnings));
  provenance.append(node('p', 'card-footnote', 'Historical results describe the tested rules and data, not future returns. The current AI research is not a record of decisions the model made in the past.'));
  article.append(more('Sources & full limitations', `sources-${report.id}`, provenance)); area.append(article);
}
function renderBacktest(backtest = {}) {
  const section = append(node('section', 'report-section card'), node('p', 'eyebrow', 'HISTORICAL RULE TEST'), node('h3', '', 'How this allocation behaved in the test'));
  if (backtest.status !== 'complete') { section.append(node('span', 'status-pill warning', 'Backtest unavailable'), node('p', 'muted small', backtest.error || 'Historical calculation has not completed. No performance figures have been substituted.')); if (backtest.warnings?.length) section.append(list(backtest.warnings)); return section; }
  section.append(node('p', 'muted small', `${backtest.start || 'Start date not recorded'} → ${backtest.end || 'End date not recorded'}`));
  section.append(node('p', 'notice', 'This is a historical allocation comparison using the stated rebalancing rules. It does not test today’s AI views or the timing signals in a strategy template.'));
  if (backtest.methodology) section.append(node('p', 'report-text', stringify(backtest.methodology)));
  if (backtest.metrics && typeof backtest.metrics === 'object') {
    const metrics = node('div', 'metrics-grid');
    const metricLabels = { startingValue: 'Starting value', endingValue: 'Ending value', totalReturnPct: 'Total return', cagrPct: 'Annualized return', annualizedVolatilityPct: 'Annualized volatility', maxDrawdownPct: 'Largest peak-to-trough fall', transactionCosts: 'Simulated transaction costs', trades: 'Simulated trades', observations: 'Trading days observed' };
    for (const [key, value] of Object.entries(backtest.metrics)) { if (value === null || value === undefined || (typeof value !== 'number' && typeof value !== 'string')) continue; let formatted = String(value); if (typeof value === 'number') { if (/pct|percent/i.test(key)) formatted = pct(value); else if (/value|amount|equity|capital|cost/i.test(key)) formatted = usd.format(value); else formatted = value.toLocaleString('en-US', { maximumFractionDigits: 3 }); } metrics.append(append(node('div', 'backtest-metric'), node('span', '', metricLabels[key] || humanize(key).replace(/ pct$/i, '')), node('strong', '', formatted))); }
    section.append(metrics);
  }
  const points = normalizeSeries(backtest.series);
  if (points.length > 1) section.append(drawChart(points, backtest.benchmark?.ticker || 'Benchmark'), append(node('div', 'chart-caption'), node('span', '', points[0].date), node('span', '', 'Portfolio value · historical data'), node('span', '', points.at(-1).date)));
  if (backtest.benchmark) {
    const benchmark = backtest.benchmark;
    const description = typeof benchmark === 'object' ? `${benchmark.ticker || benchmark.name || 'Comparison'}${benchmark.metrics?.totalReturnPct != null ? ` · total return ${pct(benchmark.metrics.totalReturnPct)}` : ''}${benchmark.metrics?.maxDrawdownPct != null ? ` · maximum drawdown ${pct(benchmark.metrics.maxDrawdownPct)}` : ''}` : stringify(benchmark);
    section.append(node('p', 'card-footnote', `Benchmark: ${description}`));
  }
  if (backtest.assumptions) section.append(append(node('details'), node('summary', '', 'Calculation assumptions'), node('p', 'report-text', stringify(backtest.assumptions))));
  if (backtest.dataSources?.length) { const sources = node('ul', 'source-list'); for (const source of backtest.dataSources) sources.append(append(node('li'), sourceElement(source))); section.append(sources); }
  if (backtest.warnings?.length) section.append(list(backtest.warnings)); return section;
}
function normalizeSeries(series) {
  if (!Array.isArray(series)) return [];
  return series.map((point) => ({ date: String(point.date || point.time || ''), value: Number(point.equity ?? point.value ?? point.portfolio ?? point.portfolioValue), benchmark: typeof point.benchmark === 'number' && Number.isFinite(point.benchmark) ? point.benchmark : null })).filter((p) => p.date && Number.isFinite(p.value));
}
function drawChart(points, benchmarkLabel = 'Benchmark', primaryLabel = 'Your allocation') {
  const container = node('div', 'chart-container');
  const hasBenchmark = points.some((point) => point.benchmark !== null && Number.isFinite(point.benchmark));
  const legend = node('div', 'chart-legend');
  legend.append(append(node('span'), node('i', 'legend-line portfolio-line'), document.createTextNode(`${primaryLabel} · solid`)));
  if (hasBenchmark) legend.append(append(node('span'), node('i', 'legend-line benchmark-line'), document.createTextNode(`${benchmarkLabel} · dashed`)));
  container.append(legend);
  const ns = 'http://www.w3.org/2000/svg'; const svg = document.createElementNS(ns, 'svg'); svg.setAttribute('viewBox', '0 0 760 220'); svg.setAttribute('class', 'chart'); svg.setAttribute('role', 'img');
  const title = document.createElementNS(ns, 'title'); title.textContent = `Historical portfolio value from ${points[0].date} to ${points.at(-1).date}; ${primaryLabel} starts at ${usd.format(points[0].value)} and ends at ${usd.format(points.at(-1).value)}.${hasBenchmark && Number.isFinite(points[0].benchmark) && Number.isFinite(points.at(-1).benchmark) ? ` ${benchmarkLabel} starts at ${usd.format(points[0].benchmark)} and ends at ${usd.format(points.at(-1).benchmark)}.` : ''}`; svg.append(title);
  const values = points.flatMap((point) => Number.isFinite(point.benchmark) ? [point.value, point.benchmark] : [point.value]);
  const min = Math.min(...values); const max = Math.max(...values); const span = max - min || max * .01 || 1;
  for (const [level, y] of [[max, 20], [(min + max) / 2, 110], [min, 200]]) { const line = document.createElementNS(ns, 'line'); line.setAttribute('x1', '68'); line.setAttribute('x2', '750'); line.setAttribute('y1', String(y)); line.setAttribute('y2', String(y)); line.setAttribute('stroke', '#254052'); svg.append(line); const text = document.createElementNS(ns, 'text'); text.setAttribute('x', '0'); text.setAttribute('y', String(y + 4)); text.setAttribute('fill', '#99b2c8'); text.setAttribute('font-size', '10'); text.textContent = usd.format(level); svg.append(text); }
  for (const key of ['benchmark', 'value']) {
    let segment = [];
    const flush = () => { if (segment.length > 1) { const line = document.createElementNS(ns, 'polyline'); line.setAttribute('points', segment.join(' ')); line.setAttribute('fill', 'none'); line.setAttribute('stroke', key === 'value' ? '#21d5f5' : '#bb9be9'); line.setAttribute('stroke-width', '2'); line.setAttribute('vector-effect', 'non-scaling-stroke'); if (key === 'benchmark') line.setAttribute('stroke-dasharray', '6 4'); svg.append(line); } segment = []; };
    points.forEach((point, index) => { if (typeof point[key] === 'number' && Number.isFinite(point[key])) segment.push(`${68 + index / (points.length - 1) * 682},${200 - (point[key] - min) / span * 180}`); else flush(); }); flush();
  }
  container.append(svg); return container;
}

function renderHedgeReview(review) {
  const section = append(node('section', 'report-section card'), node('p', 'eyebrow', 'RESEARCH BEFORE COMPLEXITY'), node('h3', '', 'Compare hedging choices'));
  section.append(node('span', 'status-pill neutral', review.allocated === true ? 'See allocation details' : 'No inverse ETF automatically allocated'));
  if (review.message) section.append(node('p', 'report-text', review.message));
  if (review.assessment) section.append(node('p', 'report-text', review.assessment));
  const comparison = review.historicalComparison || review.comparison;
  if (comparison) {
    if (comparison.status !== 'complete') section.append(node('p', 'notice warning', comparison.error || 'The inverse ETF historical comparison is unavailable. No comparison returns have been substituted.'));
    else {
      section.append(node('p', 'eyebrow hedge-subheading', 'A SHORT HISTORICAL WINDOW'), node('h4', '', `${comparison.start || 'Start date unavailable'} → ${comparison.end || 'End date unavailable'}`));
      if (Number.isFinite(comparison.sessions)) section.append(node('p', 'muted small', `${comparison.sessions} trading sessions. This window cannot establish future protection or suitability.`));
      const rows = [comparison.baseline, comparison.cashComparator, ...(Array.isArray(comparison.scenarios) ? comparison.scenarios : [])].filter(Boolean);
      if (rows.length) {
        const scroll = node('div', 'table-scroll'); const table = node('table', 'allocation-table hedge-table'); table.setAttribute('aria-label', 'Historical comparison of hedging scenarios');
        const head = node('thead'); head.append(append(node('tr'), node('th', '', 'Scenario'), node('th', '', 'Return'), node('th', '', 'Largest fall'), node('th', '', 'Ending value'))); table.append(head); const body = node('tbody');
        for (const row of rows) {
          const title = append(node('td'), node('strong', '', row.label || row.ticker || 'Scenario'));
          if (row.weightsPct && typeof row.weightsPct === 'object') title.append(node('span', 'asset-name', Object.entries(row.weightsPct).map(([ticker, weight]) => `${ticker} ${typeof weight === 'number' ? pct(weight) : stringify(weight)}`).join(' · ')));
          body.append(append(node('tr'), title, node('td', '', measuredPercent(row.returnPct)), node('td', '', measuredPercent(row.maxDrawdownPct)), node('td', '', typeof row.endingValue === 'number' && Number.isFinite(row.endingValue) ? usd.format(row.endingValue) : 'Unavailable')));
        }
        table.append(body); scroll.append(table); section.append(scroll);
      }
      if (Array.isArray(comparison.products) && comparison.products.length) {
        const details = node('details'); details.append(node('summary', '', 'Actual inverse ETF returns in this window'));
        const productRows = comparison.products.map((product) => `${product.ticker}${product.dailyTargetMultiple != null ? ` (${product.dailyTargetMultiple}× daily target)` : ''}: ${measuredPercent(product.returnPct)} return; ${measuredPercent(product.maxDrawdownPct)} peak-to-trough fall.`);
        details.append(list(productRows)); section.append(details);
      }
      if (comparison.methodology) section.append(node('p', 'card-footnote', stringify(comparison.methodology)));
      if (comparison.scenarios?.some((scenario) => Number.isFinite(scenario.approximateInitialInverseExposurePct))) section.append(node('p', 'notice', 'These scenarios compare approximately equal inverse exposure at the start. Daily resets, changing prices and compounding cause the exposures to drift. A stated −2× or −3× target applies to one day, not the entire window.'));
    }
    if (comparison.warnings?.length) section.append(list(comparison.warnings));
    if (comparison.dataSources?.length) { const sources = node('ul', 'source-list'); for (const source of comparison.dataSources) sources.append(append(node('li'), sourceElement(source))); section.append(sources); }
    if (comparison.fetchedAt) section.append(node('p', 'card-footnote', `Comparison data retrieved ${date(comparison.fetchedAt)}`));
  }
  if (Array.isArray(review.sources) && review.sources.length) { const sources = node('ul', 'source-list'); for (const source of review.sources) sources.append(append(node('li'), sourceElement(source))); section.append(sources); }
  if (review.source) section.append(append(node('p', 'small'), safeLink(review.source, 'Read about leveraged and inverse ETFs')));
  return section;
}
function measuredPercent(value) { return typeof value === 'number' && Number.isFinite(value) ? pct(value) : 'Unavailable'; }

let documentDbPromise;
function openDocumentDb() {
  if (documentDbPromise) return documentDbPromise;
  documentDbPromise = new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) { reject(new Error('This browser does not provide local document storage.')); return; }
    let settled = false;
    const timer = setTimeout(() => { if (!settled) { settled = true; reject(new Error('Local document storage did not respond. Close other tabs using this app and retry.')); } }, 10000);
    const request = indexedDB.open('proto-trading-uploaded-reports-v1', 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains('documents')) request.result.createObjectStore('documents', {keyPath:'id'}); };
    request.onsuccess = () => { clearTimeout(timer); if (settled) { request.result.close(); return; } settled = true; request.result.onversionchange = () => { request.result.close(); documentDbPromise = null; }; resolve(request.result); };
    request.onerror = () => { clearTimeout(timer); if (!settled) { settled = true; reject(new Error('Local document storage is unavailable or blocked in this browser.')); } };
    request.onblocked = () => { clearTimeout(timer); if (!settled) { settled = true; reject(new Error('Close other tabs using the local document library and try again.')); } };
  }).catch(error => { documentDbPromise = null; throw error; });
  return documentDbPromise;
}
async function documentStore(mode, operation) {
  const db = await openDocumentDb();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('documents', mode);
    let result;
    const request = operation(transaction.objectStore('documents'));
    request.onsuccess = () => { result = request.result; };
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = transaction.onerror = () => reject(new Error('The browser could not update the local document library. Storage may be full or disabled.'));
  });
}
async function loadUploadedLibrary() {
  $('refresh-uploads').disabled = true;
  try {
    const documents = await documentStore('readonly', store => store.getAll());
    const valid = []; let skipped = 0;
    for (const document of documents || []) { try { valid.push(validateStoredDocument(document)); } catch { skipped += 1; } }
    state.uploadLibrary = valid.sort((a, b) => b.importedAt.localeCompare(a.importedAt));
    renderUploadedLibrary();
    if (skipped) localMessage('upload-message', `${skipped} stored document(s) could not be read. The remaining reports are available.`, true);
  } catch (error) { renderUploadedLibrary(); if (!state.uploadLibrary.length && !state.uploadMemory.length) $('uploaded-library').replaceChildren(node('p', 'muted small', `${error.message} You can still open a document for this page session; it will not survive a refresh.`)); }
  finally { $('refresh-uploads').disabled = false; }
}
async function importReport(event) {
  event.preventDefault();
  const file = $('report-file').files?.[0];
  $('upload-report-button').disabled = true;
  localMessage('upload-message', '');
  try {
    validateUploadFile(file);
    if (file.size > MAX_UPLOAD_BYTES) throw new Error('The report must be 2 MiB or smaller.');
    let text;
    try { text = new TextDecoder('utf-8', {fatal:true, ignoreBOM:true}).decode(await file.arrayBuffer()); } catch { throw new Error('This file is not readable UTF-8 text. Export the original report as UTF-8 Markdown or TXT.'); }
    const document = parseUploadedReport({filename:file.name, text, title:$('report-title').value, reportDate:$('report-date').value, id:crypto.randomUUID()});
    let saved = false;
    try { await documentStore('readwrite', store => store.put(document)); saved = true; state.uploadLibrary = [document, ...state.uploadLibrary.filter(item => item.id !== document.id)]; }
    catch (error) { state.uploadMemory = [document, ...state.uploadMemory]; localMessage('upload-message', `${error.message} The document is open for this page session only. Keep your original file; this copy will disappear on refresh.`, true); }
    openUploadedDocument(document, saved); renderUploadedLibrary();
    if (saved) localMessage('upload-message', 'Saved locally in this browser. The full original text is preserved and has not been sent to any server.');
    $('report-file').value = '';
  } catch (error) { localMessage('upload-message', error.message || 'The report could not be imported.', true); }
  finally { $('upload-report-button').disabled = false; }
}
function renderUploadedLibrary() {
  const area = $('uploaded-library'); area.replaceChildren();
  const documents = [...state.uploadMemory, ...state.uploadLibrary.filter(document => !state.uploadMemory.some(item => item.id === document.id))];
  if (!documents.length) { area.append(node('p', 'muted small', 'No documents imported yet. Saved files remain in this browser after refresh; clearing browser data removes this local library. Keep your original report files.')); return; }
  for (const document of documents) {
    const saved = state.uploadLibrary.some(item => item.id === document.id);
    const card = node('article', 'saved-card'); card.append(node('h4', '', document.title), node('span', 'status-pill neutral', saved ? 'Local document' : 'This page session only'), node('p', '', `${document.filename} · Imported ${date(document.importedAt)}`), node('p', '', UPLOADED_SOURCE_LABEL));
    card.append(append(node('div', 'card-actions'), button('Open document', 'secondary', () => openUploadedDocument(document, saved)), button('Download original', 'secondary', () => downloadOriginal(document)), button('Remove', 'danger-button', () => removeUploadedDocument(document.id, saved)))); area.append(card);
  }
}
async function removeUploadedDocument(id, saved) {
  try {
    if (saved) await documentStore('readwrite', store => store.delete(id));
    state.uploadLibrary = state.uploadLibrary.filter(document => document.id !== id); state.uploadMemory = state.uploadMemory.filter(document => document.id !== id);
    if (state.uploadedDocument?.id === id) { state.uploadedDocument = null; $('uploaded-report-content').replaceChildren(); $('uploaded-report-content').hidden = true; state.selectedResearchType = 'generated'; renderReport(); }
    renderUploadedLibrary(); localMessage('upload-message', 'Document removed from this local library. Your original file has not been changed.');
  } catch (error) { localMessage('upload-message', error.message, true); }
}
function openUploadedDocument(document, saved = false) {
  const valid = validateStoredDocument(document);
  state.uploadedDocument = valid; state.uploadedSaved = saved; state.selectedResearchType = 'uploaded';
  $('report-content').hidden = true; renderUploadedDocument(); setTab('research');
}
function renderUploadedDocument() {
  renderSelectionDetails();
  const area = $('uploaded-report-content'); area.replaceChildren(); area.hidden = !state.uploadedDocument || state.selectedResearchType !== 'uploaded'; if (!state.uploadedDocument) return;
  if (!area.hidden && $('research-tools')) $('research-tools').open = true;
  const document = state.uploadedDocument;
  const report = node('article', 'report uploaded-report');
  const header = node('header', 'report-header'); header.append(node('p', 'eyebrow', 'YOUR IMPORTED LONG-TERM RESEARCH'), node('h2', '', document.title), node('span', 'status-pill neutral', UPLOADED_SOURCE_LABEL));
  header.append(node('p', 'card-footnote', `File: ${document.filename} · Imported: ${date(document.importedAt)} · ${state.uploadedSaved ? 'Saved in this browser' : 'This page session only'}`));
  if (document.userReportDate) header.append(node('p', 'small muted', `Report date supplied by you: ${document.userReportDate}. Not independently verified.`));
  if (document.detectedReportDate) header.append(node('p', 'small muted', `Date found in the document: ${document.detectedReportDate.value} (${document.detectedReportDate.label}, line ${document.detectedReportDate.lineNumber}). Unverified text extraction.`));
  if (!document.userReportDate && !document.detectedReportDate) header.append(node('p', 'small muted', 'Report date not supplied or explicitly identified. Import time is not the research date.'));
  header.append(node('p', 'notice', 'This is the source document you imported. Its profile, assets, conclusions and dates may differ from your current match. Importing does not verify its claims, create a backtest or update the short-term checklist.'));
  header.append(append(node('div', 'card-actions'), button('Download full original', 'secondary', () => downloadOriginal(document)), button('Print document', 'secondary', printVisible), button('Close document', 'secondary', () => { state.selectedResearchType = 'generated'; $('uploaded-report-content').hidden = true; renderReport(); })));
  report.append(header);
  const mentionedTickers = ASSETS.filter(asset => asset.assetClass === 'stock' && new RegExp(`\\b${asset.ticker}\\b`).test(document.originalText)).map(asset=>asset.ticker);
  report.append(createReportCompanion(window.document || globalThis.document, {imported:true,tickers:mentionedTickers}));
  const horizons = node('section', 'report-section card'); horizons.append(node('p', 'eyebrow', 'LITERAL EXCERPTS, NOT NEW FORECASTS'), node('h3', '', 'Longer-term sections in this document'));
  if (document.horizonExcerpts.length) {
    for (const excerpt of document.horizonExcerpts) { const section = node('article', 'import-excerpt'); section.append(node('h4', '', excerpt.horizon), more('Read this part of the report', `upload-excerpt-${document.id}-${excerpt.lineStart}`, node('p', 'card-footnote', `${excerpt.detection || 'Explicit heading'}: ${excerpt.heading} · Original lines ${excerpt.lineStart}–${excerpt.lineEnd}`), node('pre', 'original-source excerpt-source', excerpt.text))); horizons.append(section); }
  } else horizons.append(node('p', 'muted', 'No explicit long-term horizon identified. The full original document is available below; no long-term view has been inferred.'));
  report.append(horizons);
  const original = node('section', 'report-section card'); original.append(node('h3', '', 'Full original document'), node('p', 'muted small', 'Displayed as plain text. Markdown and any embedded HTML remain literal, so the original cannot execute scripts or load remote content.'));
  const details = more('Read the full original report', `upload-original-${document.id}`, node('p', 'card-footnote', `${Number(document.bytes).toLocaleString()} bytes · original wording preserved`), node('pre', 'original-source', document.originalText)); details.className += ' original-document'; original.append(details); report.append(original); area.append(report);
}
function downloadOriginal(document) {
  const url = URL.createObjectURL(new Blob([document.originalText], {type:'text/plain;charset=utf-8'}));
  const anchor = node('a'); anchor.href = url; anchor.download = document.filename.replace(/[\\/\u0000-\u001f]/g, '_'); window.document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function renderTemplates() {
  const area = $('template-list'); area.replaceChildren(); guideFitBadges=[];
  schoolLab?.destroy();schoolLab=createSchoolLab(document,{chart:(points,label)=>drawChart(points,label,'Rule test'),download,initialSchool:state.match?.template?.id||'balanced',selectedTickers:selectedSnapshot.tickers,assets:selectedSnapshot.assets,market:selectedSnapshot.market,holdings:selectedSnapshot.positions,budget:state.profile?.budget||10000});area.append(schoolLab.element);
  area.append(more('Other stock combinations for learning','other-stock-ideas',renderStockIdeas()));
  const guides=node('div','school-grid');
  const advanced = node('div', 'school-grid');
  for (const template of state.templates) {
    const isLearning = template.implementationStatus === 'education_only';
    const role = template.role === 'allocation' ? 'Starting mix' : template.role === 'risk_tool' ? 'Movement & risk tool' : isLearning ? 'Learning guide' : 'Daily price observations';
    const card = node('article', 'template-card'); card.setAttribute('data-school', template.id);
    card.append(node('span', 'strategy-role', role), node('h3', '', template.shortLabel || template.name), fitBadge(template.id,guideFitBadges),node('p', '', SCHOOL_BLURBS[template.id] || template.beginnerSummary || template.description));
    const content = node('div');
    content.append(node('p', '', template.description));
    if (template.learningSteps?.length) content.append(node('h4', '', 'How to read it'), list(template.learningSteps));
    if (template.exampleTickers?.length) content.append(node('p', 'small', `Learning examples: ${template.exampleTickers.join(', ')}. These are examples, not suggested purchases or current signals.`));
    if (template.limitations?.length) content.append(node('h4', '', 'Keep in mind'), list(template.limitations));
    if (template.requiredData?.length) content.append(more('Data needed & sources', `school-sources-${template.id}`, list(template.requiredData), template.source ? sourceElement(template.source) : null, node('p', 'card-footnote', `Team template ${template.version || 'v1'}. Indicator rules are not a verified record of strategy returns.`)));
    if (isLearning) content.append(node('p', 'notice', 'This is a learning guide. The app does not scan for or trade this setup.'));
    else if (template.role === 'risk_tool') content.append(node('p', 'notice', 'ATR measures movement, not direction. Where daily data is valid, the plan shows an illustrative distance under More detail. It does not set a real stop order.'));
    else if (template.role === 'research') content.append(node('p', 'small', `${template.cadence || 'Review regularly'}. Your profile and available data determine whether this approach can be used. You can wait when a condition is missing.`));
    card.append(more('Learn more', `school-${template.id}`, content));
    if (template.matchable === true) card.append(append(node('div', 'card-actions'), button('Check if this fits me', 'secondary', () => { $('templateId').value = template.id; const profileMore = $('profile-more'); if (profileMore) profileMore.open = true; updateInputs(); setTab('questionnaire'); revealControl('templateId'); announce(`${template.shortLabel || template.name} selected. Review your answers, then create your plan to check the fit.`); })));
    if (['mean_reversion', 'wyckoff', 'ict', 'order_flow'].includes(template.id)) advanced.append(card); else guides.append(card);
  }
  if (advanced.children.length) { const extra = more('More approaches: Bollinger Bands, Wyckoff, ICT & Order Flow', 'advanced-schools', advanced); extra.style.gridColumn = '1 / -1'; guides.append(extra); }
  const allGuides=more('All strategy introductions & learning steps','all-school-guides',guides);allGuides.style.gridColumn='1 / -1';area.append(allGuides);
}
function renderRecommendedSchools(match){
  const section=node('section','recommended-schools');section.append(node('p','eyebrow','START WITH AN APPROACH THAT FITS'),node('h3','','Your recommended approaches'),node('p','small muted','Matched to your answers. Learning-fit scores follow your selected stocks, not expected returns.'));
  const ids=[...new Set([match.template.id,...(match.candidateTemplateIds||[])])].slice(0,3),grid=node('div','recommended-school-grid');
  for(const [index,id]of ids.entries()){
    const school=SCHOOL_TESTS[id],template=TEMPLATES.find(item=>item.id===id);if(!school||!template)continue;
    const card=node('article','card');card.append(node('span','status-pill neutral',index===0?'Your current match':'Another eligible approach'),node('h4','',school.label),fitBadge(id,matchedFitBadges),node('p','',SCHOOL_BLURBS[id]||school.summary),button('Explore stocks & backtest →','primary',()=>{setTab('community');schoolLab?.select(id);}));grid.append(card);
  }section.append(grid);return section;
}
function renderStockIdeas() {
  const section=node('section','stock-ideas wide');section.style.gridColumn='1 / -1';
  section.append(node('p','eyebrow','LEARN WITH REAL COMPANIES'),node('h3','','Explore a stock combination'),node('p','small muted','These are editable learning examples with ETFs and cash. They are not a personal recommendation or a new AI report.'));
  const grid=node('div','stock-idea-grid');
  for(const idea of PORTFOLIO_IDEAS){
    const card=node('article','card stock-idea-card');card.append(node('h4','',idea.name),node('p','small muted',idea.summary));
    const tickers=node('div','badge-row');for(const [ticker,weight] of Object.entries(idea.weights))tickers.append(node('span','status-pill neutral',`${ticker} ${weight}%`));card.append(tickers);
    card.append(node('p','small',idea.suitabilityNote));
    card.append(append(node('div','card-actions'),button('Read a simple report','primary',()=>showStockIdea(idea)),button('Try this mix','secondary',()=>{setIdeaRemix(idea);$('remix-editor').scrollIntoView({block:'nearest'});}))); 
    card.append(more('Why these holdings?',`stock-idea-${idea.id}`,list(idea.rationale),list(idea.limits),node('p','small',idea.reviewRule)));
    grid.append(card);
  }
  section.append(grid);const preview=node('div','stock-report-preview');preview.id='stock-report-preview';preview.hidden=true;section.append(preview);return section;
}
function ideaBudget(){const value=Number(readProfile().budget);return Number.isFinite(value)&&value>=100&&value<=1000000?value:10000;}
function ideaRows(idea){return Object.entries(idea.weights).map(([ticker,weight])=>({ticker,name:ASSETS.find(asset=>asset.ticker===ticker)?.name||ticker,weight}));}
function setIdeaRemix(idea){state.remix={name:idea.name,budget:ideaBudget(),sourceTemplate:idea.id,assets:ideaRows(idea)};renderRemix();localMessage('remix-message','This editable example is separate from your matched plan. Check every weight before saving.');}
function showStockIdea(idea){
  const area=$('stock-report-preview');area.hidden=false;area.replaceChildren(node('p','eyebrow','ILLUSTRATIVE COMBINATION · NOT NEW AI RESEARCH'),node('h3','',idea.name),node('p','notice',idea.suitabilityNote),createReportCompanion(document,{allocations:ideaRows(idea),budget:ideaBudget()}),list(idea.limits),append(node('div','card-actions'),button('Edit this combination','primary',()=>{setIdeaRemix(idea);$('remix-editor').scrollIntoView({block:'nearest'});}),button('Close this report','secondary',()=>{area.hidden=true;})));
  area.scrollIntoView({block:'start'});
}
function prepareRemix(match) {
  if (!match?.eligible || !match.allocations?.length) { localMessage('remix-message', 'Create an eligible portfolio first, then bring it into the workbench.', true); return; }
  state.remix = { name: `${match.template?.name || 'Portfolio'} remix`, budget: Number(match.profile?.budget || state.profile?.budget || readProfile().budget), sourceTemplate: match.template?.id || '', assets: match.allocations.map((a) => ({ ticker: a.ticker, name: a.name, weight: Number(a.weight) })) };
  renderRemix(); localMessage('remix-message', 'Edit the weights below. They must total 100% before you can save.');
}
function renderRemix() {
  const area = $('remix-editor'); area.replaceChildren(); const remix = state.remix; if (!remix) return;
  area.append(node('p', 'small muted', `Experiment budget: ${usd.format(remix.budget)}. Changes here do not update your matched portfolio or its research.`));
  const table = node('div', 'remix-table');
  remix.assets.forEach((asset, index) => {
    const row = node('div', 'remix-row'); const label = node('label'); label.htmlFor = `weight-${index}`; label.append(node('strong', 'ticker', asset.ticker), node('span', 'asset-name', asset.name));
    const input = node('input'); input.id = `weight-${index}`; input.type = 'number'; input.min = '0'; input.max = '100'; input.step = '0.1'; input.value = String(asset.weight); input.inputMode = 'decimal'; input.addEventListener('input', () => { asset.weight = input.value === '' ? NaN : Number(input.value); updateRemixTotals(); });
    const amount = node('span', 'remix-amount'); amount.id = `remix-amount-${index}`; row.append(label, append(node('div', 'weight-wrap'), input, node('span', '', '%')), amount); table.append(row);
  }); area.append(table);
  const footer = node('div', 'remix-footer'); footer.append(node('span', '', 'Total weight'), node('strong', '', '')); footer.lastChild.id = 'remix-total'; area.append(footer);
  const save = node('div', 'save-remix-form'); const field = node('div'); const label = node('label', '', 'Name your remix'); label.htmlFor = 'remix-name'; const input = node('input'); input.id = 'remix-name'; input.maxLength = 80; input.value = remix.name; input.addEventListener('input', () => { remix.name = input.value; }); field.append(label, input); const b = button('Save on this device', 'primary', saveRemix); b.id = 'save-remix'; save.append(field, b); area.append(save); updateRemixTotals();
  area.append(button('Read my mix in one picture','secondary',()=>{const total=remix.assets.reduce((sum,row)=>sum+row.weight,0);if(remix.assets.some(row=>!Number.isFinite(row.weight)||row.weight<0||row.weight>100)||Math.abs(total-100)>.00001){localMessage('remix-message','Set valid weights totalling 100% first.',true);return;}const preview=$('stock-report-preview');preview.hidden=false;preview.replaceChildren(node('h3','',remix.name),node('p','notice','Your local experiment. This has not been analysed by AI or backtested.'),createReportCompanion(document,{allocations:remix.assets,budget:remix.budget}));preview.scrollIntoView({block:'start'});}));
}
function updateRemixTotals() {
  if (!state.remix) return;
  let total = 0, valid = true;
  state.remix.assets.forEach((a, index) => { if (!Number.isFinite(a.weight) || a.weight < 0 || a.weight > 100) valid = false; else total += a.weight; $(`remix-amount-${index}`).textContent = Number.isFinite(a.weight) ? usd.format(state.remix.budget * a.weight / 100) : '—'; });
  $('remix-total').textContent = valid ? `${pct(total)}${Math.abs(total - 100) > .00001 ? ' · must equal 100%' : ''}` : 'Enter valid weights'; $('save-remix').disabled = !valid || Math.abs(total - 100) > .00001;
}
const storageKey = 'proto-trading-remixes-v1';
function readRemixes() {
  try { const items = JSON.parse(localStorage.getItem(storageKey) || '[]'); if (!Array.isArray(items)) return []; return items.filter((r) => typeof r.id === 'string' && typeof r.name === 'string' && Number.isFinite(r.budget) && r.budget > 0 && Array.isArray(r.assets) && r.assets.length < 100 && r.assets.every((a) => typeof a.ticker === 'string' && typeof a.name === 'string' && Number.isFinite(a.weight) && a.weight >= 0 && a.weight <= 100) && Math.abs(r.assets.reduce((sum, a) => sum + a.weight, 0) - 100) < .00001).slice(0, 30); } catch { return []; }
}
function saveRemix() {
  const remix = state.remix; if (!remix) return;
  if (!remix.name.trim()) { localMessage('remix-message', 'Give this remix a name before saving.', true); $('remix-name').focus(); return; }
  if (remix.assets.some((a) => !Number.isFinite(a.weight) || a.weight < 0 || a.weight > 100) || Math.abs(remix.assets.reduce((sum, a) => sum + a.weight, 0) - 100) > .00001) { localMessage('remix-message', 'Weights must be valid percentages and total 100%.', true); return; }
  const saved = { ...structuredClone(remix), id: crypto.randomUUID(), name: remix.name.trim(), createdAt: new Date().toISOString() };
  try { const items = readRemixes(); localStorage.setItem(storageKey, JSON.stringify([saved, ...items].slice(0, 30))); localMessage('remix-message', 'Saved in this browser. This remix has not been published online or analysed by AI.'); renderSaved(); } catch { localMessage('remix-message', 'This browser could not save the remix. Use Download on an existing saved item, or enable local browser storage.', true); }
}
function renderSaved() {
  const area = $('saved-remixes'); area.replaceChildren(); const items = readRemixes();
  if (!items.length) { area.append(node('p', 'muted small', 'Your saved remixes will appear here. Browser storage can be cleared, so download any experiment you want to keep.')); return; }
  for (const item of items) {
    const card = node('article', 'saved-card'); card.append(node('h4', '', item.name), node('p', '', `${usd.format(item.budget)} · ${date(item.createdAt)}`), node('p', '', item.assets.map((a) => `${a.ticker} ${pct(a.weight)}`).join(' · ')));
    card.append(append(node('div', 'card-actions'), button('Edit', 'secondary', () => { state.remix = structuredClone(item); renderRemix(); $('remix-editor').scrollIntoView({ block: 'nearest' }); }), button('Download', 'secondary', () => download({ type: 'device-only-remix', ...item }, `proto-remix-${safeFile(item.name)}.json`)), button('Delete', 'danger-button', () => { try { localStorage.setItem(storageKey, JSON.stringify(readRemixes().filter((r) => r.id !== item.id))); renderSaved(); localMessage('remix-message', 'Remix removed from this browser.'); } catch { localMessage('remix-message', 'This browser did not allow the remix to be removed.', true); } }))); area.append(card);
  }
}
function safeFile(value) { return String(value).replace(/[^a-z0-9_-]/gi, '-').slice(0, 60) || 'report'; }
function download(value, filename) { const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' }); const url = URL.createObjectURL(blob); const a = node('a'); a.href = url; a.download = filename; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }
function printVisible() {
  if ($('demo-report-dialog')?.open) reportPopup?.close();
  const details = [...document.querySelectorAll(`#panel-${state.activeTab} details`)]; const previouslyOpen = details.map((d) => d.open); details.forEach((d) => { d.open = true; });
  const restore = () => { details.forEach((d, index) => { d.open = previouslyOpen[index]; }); window.removeEventListener('afterprint', restore); };
  window.addEventListener('afterprint', restore); window.print();
}

const jobStorageKey = 'proto-trading-private-job-v1';
function rememberJob() {
  if (state.job?.status === 'unavailable') { try { sessionStorage.removeItem(jobStorageKey); } catch {} return; }
  if (!state.job || !state.jobToken || !state.jobProfile) return;
  try { sessionStorage.setItem(jobStorageKey, JSON.stringify({ job: state.job, token: state.jobToken, profile: state.jobProfile })); } catch { /* Private browsing may disable storage; the active page still retains its job. */ }
}
function restoreJob() {
  if (portableMode) return;
  try {
    const stored = JSON.parse(sessionStorage.getItem(jobStorageKey) || 'null');
    if (!stored || typeof stored.job?.id !== 'string' || !stored.job.id || stored.job.id.length > 128 || typeof stored.job.status !== 'string' || typeof stored.token !== 'string' || !stored.token || stored.token.length > 256) return;
    if (stored.job.status === 'unavailable') { sessionStorage.removeItem(jobStorageKey); return; }
    const profile = validateProfile(stored.profile);
    state.job = stored.job; state.jobToken = stored.token; state.jobProfile = profile;
    renderJob(); updateResearchAction(); pollResearch();
    announce('Your previous research task is restored in this browser tab. Its report keeps the original inputs.');
  } catch { /* A malformed or unavailable session entry never blocks the questionnaire. */ }
}
let heightFrame;
let lastHeight = 0;
function notifyHeight() {
  cancelAnimationFrame(heightFrame);
  heightFrame = requestAnimationFrame(() => {
    const height = Math.ceil((document.querySelector('.app-layout')||document.querySelector('.workspace')).getBoundingClientRect().height);
    if (window.parent !== window && height > 0 && height !== lastHeight) { lastHeight = height; window.parent.postMessage({ type: 'proto-height', height }, location.origin === 'null' ? '*' : location.origin); }
  });
}
$('profile-form').addEventListener('submit', submitProfile);
$('profile-form').addEventListener('input', updateInputs);
$('profile-form').addEventListener('change', updateInputs);
$('refresh-health').addEventListener('click', refreshHealth);
$('refresh-examples').addEventListener('click', loadExamples);
$('upload-form').addEventListener('submit', importReport);
$('refresh-uploads').addEventListener('click', loadUploadedLibrary);
$('load-current-remix').addEventListener('click', () => { if (isStale()) { localMessage('remix-message', 'Your profile has changed. The remix will use the earlier matched allocation shown in the portfolio tab.'); } prepareRemix(state.match); });
document.querySelectorAll('[data-go]').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.go, true)));
document.querySelectorAll('[data-tab]').forEach((b) => { b.addEventListener('click', () => setTab(b.dataset.tab)); b.addEventListener('keydown', (event) => { const keys = ['ArrowLeft', 'ArrowRight', 'Home', 'End']; if (!keys.includes(event.key)) return; event.preventDefault(); const tabs = [...document.querySelectorAll('[data-tab]')]; const i = tabs.indexOf(b); const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (i + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length; setTab(tabs[next].dataset.tab, true); }); });
window.addEventListener('beforeunload', () => { state.matchController?.abort(); state.shortPlanController?.abort(); clearTimeout(state.pollTimer); });
new ResizeObserver(notifyHeight).observe(document.body);
updateInputs(); renderTemplates(); renderSaved(); restoreJob(); restoreStrategy();
let subscriptionStorage;
try{subscriptionStorage=window.localStorage;}catch{}
$('subscription-slot').append(createSubscription(document,{storage:subscriptionStorage,portableMode}).element);
window.addEventListener('proto-onboarding-complete', event => { const target=event.detail?.destination; if(['questionnaire','community','research'].includes(target))setTab(target,true); });
initOnboarding();
if (typeof initDemoReport === 'function') reportPopup = initDemoReport(document);
Promise.allSettled([refreshHealth(), loadTemplates(), loadExamples(), loadUploadedLibrary()]);
