// Open a reviewed local document. This never starts paid research.
export function initDemoReport(document) {
  const launch = document.getElementById('open-demo-report');
  const dialog = document.getElementById('demo-report-dialog');
  const closeButton = document.getElementById('close-demo-report');
  const frame = document.getElementById('demo-report-frame');
  const generated = document.getElementById('demo-generated-report');
  const title = document.getElementById('demo-report-modal-title');
  const note = document.getElementById('demo-report-modal-note');
  const ownPage = document.getElementById('demo-report-own-page');
  if (!launch || !dialog || !closeButton || !frame) return null;
  // The trigger is a real link, so the saved report remains available without
  // JavaScript or native dialog support. Only intercept a successful popup.
  if (typeof dialog.showModal !== 'function') {
    launch.removeAttribute('aria-haspopup');
    return null;
  }
  let previousFocus = null;
  let previousOverflow = '';
  let activeTrigger = launch;
  const preparedTitle = title?.textContent;
  const preparedNote = note?.textContent;
  const view = document.defaultView;
  function placeInVisibleWindow() {
    if (!view || !dialog.open) return;
    let top = 16;
    let height = Math.min(840, Number(view.innerHeight || 800) - 32);
    // The website shell makes its workspace iframe as tall as the content.
    // Position against the parent's visible viewport, not that tall iframe.
    if (view.parent !== view) {
      try {
        const frameElement = view.frameElement;
        if (!frameElement) throw new Error('Frame position unavailable');
        const frameTop = frameElement.getBoundingClientRect().top;
        top = Math.max(16, 16 - frameTop);
        height = Math.min(840, view.parent.innerHeight - Math.max(16, frameTop + top) - 16, view.innerHeight - top - 16);
      } catch {
        // file:// parents may be opaque. Keep the popup beside its visible trigger.
        top = Math.max(16, activeTrigger.getBoundingClientRect().top - 72);
        height = Math.min(620, Number(view.innerHeight || 800) - top - 16);
      }
    }
    dialog.style.top = `${Math.round(top)}px`;
    dialog.style.height = `${Math.max(180, Math.round(height))}px`;
  }
  function show(event, trigger = launch) {
    if (dialog.open) { event?.preventDefault?.(); return true; }
    activeTrigger = trigger || launch;
    previousFocus = trigger || document.activeElement || launch;
    previousOverflow = document.body.style.overflow;
    try { dialog.showModal(); }
    catch { return false; } // Keep the link's normal navigation if the popup fails.
    event?.preventDefault?.();
    placeInVisibleWindow();
    document.body.style.overflow = 'hidden';
    closeButton.focus();
    return true;
  }
  function open(event) {
    if (event?.ctrlKey || event?.metaKey || event?.shiftKey || event?.altKey) return false;
    // A packaged, static relative path works in both live and file:// modes.
    // Generated reports use their own rendered content, never this saved iframe.
    frame.hidden = false;
    if (generated) generated.hidden = true;
    if (ownPage) ownPage.hidden = false;
    if (title) title.textContent = preparedTitle;
    if (note) note.textContent = preparedNote;
    if (!frame.getAttribute('src')) frame.setAttribute('src', 'prepared-report.html');
    return show(event, launch);
  }
  function openGenerated({ reportTitle, reportNote, render, trigger } = {}) {
    if (!generated || typeof render !== 'function') return false;
    render(generated);
    generated.hidden = false;
    generated.scrollTop = 0;
    frame.hidden = true;
    if (ownPage) ownPage.hidden = true;
    if (title) title.textContent = reportTitle || 'Your generated research';
    if (note) note.textContent = reportNote || 'Original report inputs and evidence';
    return show(null, trigger || document.activeElement || launch);
  }
  function close() { if (dialog.open) dialog.close(); }
  function restore() {
    document.body.style.overflow = previousOverflow;
    if (previousFocus && typeof previousFocus.focus === 'function') previousFocus.focus();
    else launch.focus();
  }
  launch.addEventListener('click', open);
  closeButton.addEventListener('click', close);
  // Escape is handled explicitly so every closing path restores focus and scroll.
  dialog.addEventListener('cancel', event => { event.preventDefault(); close(); });
  dialog.addEventListener('close', restore);
  view?.addEventListener('resize', placeInVisibleWindow);
  try {
    if (view && view.parent !== view) {
      view.parent.addEventListener('scroll', placeInVisibleWindow, { passive: true });
      view.parent.addEventListener('resize', placeInVisibleWindow);
    }
  } catch { /* Opaque file:// parents keep the trigger-relative placement. */ }
  dialog.addEventListener('click', event => {
    if (event.target !== dialog) return;
    const rect = dialog.getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) close();
  });
  return { open, close, openGenerated };
}
