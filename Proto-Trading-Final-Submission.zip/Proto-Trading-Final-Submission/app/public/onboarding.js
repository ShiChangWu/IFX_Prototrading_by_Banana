// A local-only introduction. Selecting an interest never changes investing answers.
export function initOnboarding({ autoOpen = true } = {}) {
  const storageKey = 'proto-trading-introduction-v1';
  const interests = [
    { destination: 'questionnaire', title: 'Build my first plan', detail: 'Start with your goal and budget.' },
    { destination: 'community', title: 'Explore stock examples', detail: 'Learn what different strategies look for.' },
    { destination: 'research', title: 'Read a saved report', detail: 'See a research example without waiting.' },
  ];
  const features = [
    { title: 'About you', subtitle: 'A few answers are enough to begin.', detail: 'Tell us your goal, amount, when you need the money and what loss you could handle. More choices lets you add interests or choose an approach. Your tour choice does not fill in these answers.' },
    { title: 'Your strategy', subtitle: 'Understand the approach, then choose stocks to follow.', detail: 'See your matched strategy and its candidate stocks immediately. Save selected stocks, check dated Yahoo Finance prices, or expand allocations, risks and research. The email panel previews a subscription on this device; this demo does not send emails. A price observation does not place a trade or guarantee an outcome.' },
    { title: 'Research', subtitle: 'Read a simple picture, then open the evidence.', detail: 'A picture explains how a known mix is split; an uploaded document gets a reading guide instead. Read saved research or upload Markdown, text or JSON. Check its original date, missing information and views for 1–3 and 6–12 months. Company numbers show their reporting dates and sources. A time-and-return calculator uses your own assumption, not an AI forecast. Uploaded reports stay on this device and do not update your plan. New research needs connected services.' },
    { title: 'Explore strategies', subtitle: 'Try four editable stock-and-fund examples.', detail: 'Choose one of four learning combinations, open Read a simple report, then change the amounts and save your own mix. The picture shows where the money goes, not expected profit. Covered company results have dates; the calculator explores your chosen yearly change and time period, not a forecast. Open Learn more for strategy rules and limits: RSI and Price Action observe prices, ATR explains movement size, and advanced approaches have learning guides. NVDA, QQQ and TSLA are examples, not suggested purchases. Your edits do not create new AI research or a backtest. Public sharing is planned.' },
  ];
  const make = (tag, className, text) => {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = String(text);
    return element;
  };
  const control = (text, className, handler) => {
    const element = make('button', className, text); element.type = 'button';
    element.addEventListener('click', handler); return element;
  };
  const dialog = make('dialog', 'proto-intro');
  dialog.id = 'proto-introduction'; dialog.hidden = true;
  dialog.setAttribute('aria-labelledby', 'proto-intro-title');
  dialog.setAttribute('aria-describedby', 'proto-intro-description');
  dialog.setAttribute('aria-modal', 'true');
  dialog.setAttribute('role', 'dialog');
  const panel = make('section', 'proto-intro-panel');
  const top = make('div', 'proto-intro-top');
  const brand = make('span', 'proto-intro-brand', 'PROTO-TRADING');
  const skip = control('Skip introduction', 'proto-intro-skip', () => finish(true));
  top.append(brand, skip);
  const progress = make('div', 'proto-intro-progress');
  progress.setAttribute('aria-label', 'Introduction progress');
  const content = make('div', 'proto-intro-content');
  const footer = make('div', 'proto-intro-footer');
  const back = control('Back', 'proto-intro-back', () => { if (step > 0) { step -= 1; render(); } });
  const next = control('Next', 'proto-intro-next', () => { if (step === 3) finish(false); else { step += 1; render(); } });
  const stepLabel = make('span', 'proto-intro-step'); stepLabel.setAttribute('aria-live', 'polite');
  footer.append(back, stepLabel, next); panel.append(top, progress, content, footer); dialog.append(panel);
  document.body.append(dialog);
  const replay = document.getElementById('open-introduction');
  const workspace = document.querySelector?.('.app-layout')||document.querySelector?.('.workspace');
  let step = 0, destination = 'questionnaire', active = false, destroyed = false;
  let previousFocus = null, previousOverflow = '', previousInert = false;

  function details(label, text) {
    const detail = make('details', 'proto-intro-details');
    detail.append(make('summary', '', label), make('p', '', text)); return detail;
  }
  function heading(title, description) {
    const h = make('h2', '', title); h.id = 'proto-intro-title'; h.tabIndex = -1;
    const p = make('p', 'proto-intro-description', description); p.id = 'proto-intro-description';
    content.append(h, p); return h;
  }
  function render() {
    content.replaceChildren(); progress.replaceChildren();
    for (let index = 0; index < 4; index += 1) {
      const dot = make('span', index <= step ? 'is-complete' : '');
      dot.setAttribute('aria-hidden', 'true'); progress.append(dot);
    }
    stepLabel.textContent = `${step + 1} of 4`; back.hidden = step === 0;
    next.textContent = step === 3 ? 'Start exploring →' : step === 0 ? 'Show me around →' : 'Next →';
    let title;
    if (step === 0) {
      title = heading('Smart Trading for Everyone.', 'New to investing? Start with simple questions and a plan you can understand.');
      const points = make('div', 'proto-intro-start');
      for (const [number, label, text] of [
        ['01', 'Start with you', 'Your goal, budget and comfort with loss.'],
        ['02', 'Understand your choices', 'Clear amounts and reasons to review.'],
        ['03', 'Learn at your pace', 'Open more detail whenever you need it.'],
      ]) {
        const point = make('div', 'proto-intro-start-card');
        point.append(make('span', '', number), make('h3', '', label), make('p', '', text)); points.append(point);
      }
      content.append(points, make('p', 'proto-intro-note', 'US stocks and ETFs. A place to learn and plan; no real trades are placed.'));
    } else if (step === 1) {
      title = heading('Where would you like to begin?', 'Pick a starting point. You can explore every feature later.');
      const choices = make('div', 'proto-intro-choices');
      choices.setAttribute('role', 'group'); choices.setAttribute('aria-label', 'Choose your starting point');
      const note = make('p', 'proto-intro-selection'); note.setAttribute('aria-live', 'polite');
      const buttons = [];
      const updateChoice = () => {
        for (const { button, interest } of buttons) {
          button.setAttribute('aria-pressed', String(interest.destination === destination));
          button.className = `proto-intro-choice${interest.destination === destination ? ' is-selected' : ''}`;
        }
        note.textContent = `Your starting point: ${interests.find(item => item.destination === destination).title}.`;
      };
      for (const interest of interests) {
        const button = control('', 'proto-intro-choice', () => { destination = interest.destination; updateChoice(); });
        button.append(make('strong', '', interest.title), make('span', '', interest.detail));
        buttons.push({ button, interest }); choices.append(button);
      }
      updateChoice(); content.append(choices, note, make('p', 'proto-intro-note', 'This choice only decides which page opens first. It does not set your risk level or change a portfolio.'));
    } else if (step === 2) {
      title = heading('Four places to explore.', 'Start with the short explanation. Open a guide when you want more.');
      const grid = make('div', 'proto-intro-features');
      features.forEach((feature, index) => {
        const card = make('article', 'proto-intro-feature');
        card.append(make('span', 'proto-intro-number', `0${index + 1}`), make('h3', '', feature.title), make('p', '', feature.subtitle), details('How to use it', feature.detail)); grid.append(card);
      });
      content.append(grid);
    } else {
      title = heading('You stay in control.', 'Take your time. You can review, change your answers or choose to do nothing.');
      const cards = make('div', 'proto-intro-facts');
      for (const [label, text] of [
        ['A plan is a starting point', 'Amounts are suggestions to understand. Losses can be larger than the examples shown.'],
        ['Check the date and connection', 'Basic rules work here. Fresh AI explanations, market observations and new research need connected services. Saved reports keep their original dates.'],
        ['Your uploads and mixes stay local', 'Save and download what you want to keep. Public creator sharing is a future feature.'],
      ]) {
        const card = make('div', 'proto-intro-fact'); card.append(make('h3', '', label), make('p', '', text)); cards.append(card);
      }
      content.append(cards, make('p', 'proto-intro-selection', `Next: ${interests.find(item => item.destination === destination).title}. You can replay this introduction from “Quick tour”.`));
    }
    title.focus?.({ preventScroll: true }); dialog.scrollTop = 0;
  }
  function restorePage() {
    if (workspace) workspace.inert = previousInert;
    if (document.body.style) document.body.style.overflow = previousOverflow;
    previousFocus?.focus?.({ preventScroll: true });
  }
  function hide() {
    if (!active) return;
    active = false;
    if (typeof dialog.close === 'function') { try { dialog.close(); } catch { /* Fallback has no native dialog state. */ } }
    dialog.hidden = true; dialog.removeAttribute?.('open'); restorePage();
  }
  function finish(skipped = false) {
    if (!active) return;
    hide();
    try { window.localStorage?.setItem(storageKey, 'complete'); } catch { /* The guide remains replayable when storage is unavailable. */ }
    const detail = { destination, skipped: Boolean(skipped) };
    const EventType = window.CustomEvent || (typeof CustomEvent === 'function' ? CustomEvent : null);
    if (EventType) window.dispatchEvent(new EventType('proto-onboarding-complete', { detail }));
  }
  function open() {
    if (destroyed || active) return;
    step = 0; destination = 'questionnaire'; active = true;
    previousFocus = document.activeElement;
    previousOverflow = document.body.style?.overflow || '';
    previousInert = Boolean(workspace?.inert);
    if (workspace) workspace.inert = true;
    if (document.body.style) document.body.style.overflow = 'hidden';
    dialog.hidden = false;
    let native = false;
    if (typeof dialog.showModal === 'function') { try { dialog.showModal(); native = true; } catch { /* Older engines use the modal fallback. */ } }
    dialog.setAttribute('data-fallback', String(!native));
    if (!native) dialog.setAttribute('open', '');
    render();
  }
  function onKey(event) {
    if (!active) return;
    if (event.key === 'Escape') { event.preventDefault(); finish(true); return; }
    if (event.key !== 'Tab') return;
    const controls = [...(dialog.querySelectorAll?.('button, summary, a[href], input, select, textarea, [tabindex="0"]') || [])].filter(item => !item.hidden && !item.disabled && !(item.closest?.('details:not([open])') && item.tagName?.toLowerCase() !== 'summary'));
    if (!controls.length) { event.preventDefault(); return; }
    const first = controls[0], last = controls.at(-1), focused = document.activeElement;
    if (event.shiftKey && (focused === first || !controls.includes(focused))) { event.preventDefault(); last.focus?.(); }
    else if (!event.shiftKey && (focused === last || !controls.includes(focused))) { event.preventDefault(); first.focus?.(); }
  }
  function onCancel(event) { event.preventDefault(); finish(true); }
  dialog.addEventListener('cancel', onCancel); document.addEventListener('keydown', onKey);
  replay?.addEventListener('click', open);
  let completed = false;
  try { completed = window.localStorage?.getItem(storageKey) === 'complete'; } catch { /* Local browser settings can block persistence. */ }
  if (autoOpen && !completed) open();
  return {
    open,
    close: finish,
    destroy() {
      if (destroyed) return;
      hide(); destroyed = true; document.removeEventListener?.('keydown', onKey);
      replay?.removeEventListener?.('click', open); dialog.remove?.();
    },
  };
}
