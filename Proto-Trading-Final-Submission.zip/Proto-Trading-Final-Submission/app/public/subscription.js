let subscriptionSequence = 0;
const STORAGE_KEY = 'proto-trading-email-demo-v1';

/** A browser-only opt-in preview. It never sends an address to the server. */
export function createSubscription(document, { storage, portableMode = false } = {}) {
  const n = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; };
  const uid = `email-demo-${++subscriptionSequence}`;
  const root = n('aside', 'subscription-sidebar'); root.setAttribute('aria-labelledby', uid + '-heading');
  const title = n('h2', '', 'Email updates'); title.id = uid + '-heading';
  const badges = n('div', 'subscription-badges'); badges.append(n('span', 'subscription-gmail', 'Gmail'), n('span', 'subscription-status', 'Demo · emails paused'));
  root.append(badges, title, n('p', '', 'Get a prompt to review a buy or sell condition for the stocks you follow. Then record your actual shares and trade price.'));
  root.append(n('p', 'subscription-demo-note', 'Try the subscription flow below. This demo saves your address on this device only and does not send email.'));
  const form = n('form', 'subscription-form');
  const label = n('label', '', 'Your email'); const email = n('input'); email.id = uid + '-email'; label.htmlFor = email.id; email.type = 'email'; email.name = 'demoEmail'; email.autocomplete = 'email'; email.placeholder = 'you@gmail.com'; email.required = true; email.maxLength = 254;
  const consentLabel = n('label', 'subscription-consent'); const consent = n('input'); consent.type = 'checkbox'; consent.required = true;
  consentLabel.append(consent, n('span', '', 'Save my address on this device for this subscription demo.'));
  const submit = n('button', 'primary', 'Subscribe (demo)'); submit.type = 'submit';
  const result = n('p', 'subscription-result'); result.setAttribute('role', 'status'); result.setAttribute('aria-live', 'polite');
  const clear = n('button', 'secondary', 'Clear saved address'); clear.type = 'button'; clear.hidden = true;
  form.append(label, email, consentLabel, submit, result, clear); root.append(form);
  const preview = n('details', 'subscription-preview'); preview.append(n('summary', '', 'Preview an example email'));
  const example = n('div', 'subscription-email');
  example.append(n('p', 'subscription-example-label', 'EXAMPLE ONLY · NO EMAIL SENT'), n('strong', '', 'Subject: A condition you follow needs a look'), n('p', '', 'A stock you follow has reached a condition in your saved strategy. Review the latest price, your available money and the reason for the signal before deciding what to do.'), n('p', '', 'If you complete a trade with your broker, record the number of shares and the exact price you paid or received. A sell review uses the holdings you have recorded.'), n('p', 'subscription-demo-note', 'Trade-record link appears in enabled emails. Delivery is paused in this demo.'), n('p', 'subscription-demo-note', 'A review prompt is not an order. The app does not trade for you.'));
  preview.append(example); root.append(preview);
  root.append(n('p', 'subscription-demo-note', portableMode ? 'This portable copy can show the subscription preview offline.' : 'Market checks and trade records remain available in your plan.'));
  let local;
  try { local = storage === undefined ? globalThis.localStorage : storage; } catch { local = null; }
  const validAddress = value => typeof value === 'string' && value.length <= 254 && /^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(value);
  try {
    const saved = JSON.parse(local?.getItem(STORAGE_KEY) || 'null');
    if (saved?.consent === true && validAddress(saved.email)) {
      email.value = saved.email; consent.checked = true; clear.hidden = false;
      result.textContent = 'Saved on this device only. No email was sent.';
    }
  } catch { result.textContent = 'Local storage could not be read. No address has been loaded.'; }
  form.addEventListener('submit', event => {
    event.preventDefault();
    const address = email.value.trim();
    if (!validAddress(address)) { result.textContent = 'Enter a valid email address.'; return; }
    if (!consent.checked) { result.textContent = 'Tick the consent box to save your address on this device.'; return; }
    try {
      if (!local) throw new Error('Storage unavailable');
      local.setItem(STORAGE_KEY, JSON.stringify({ email: address, consent: true }));
      if (JSON.parse(local.getItem(STORAGE_KEY) || 'null')?.email !== address) throw new Error('Storage did not retain address');
      result.textContent = 'Saved on this device only. No email was sent.'; clear.hidden = false;
    } catch { result.textContent = 'Your address could not be saved on this device. No email was sent.'; }
  });
  clear.addEventListener('click', () => {
    try {
      if (!local) throw new Error('Storage unavailable');
      local.removeItem(STORAGE_KEY);
      if (local.getItem(STORAGE_KEY) !== null) throw new Error('Storage did not clear address');
      email.value = ''; consent.checked = false; clear.hidden = true;
      result.textContent = 'Saved address cleared from this device.';
    } catch { result.textContent = 'The saved address could not be cleared. Try again or clear this site’s browser storage.'; }
  });
  return { element: root };
}
