import { SCHOOL_TESTS, runSchoolBacktest } from '../shared/school-backtest.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { ASSETS } from '../shared/strategy.mjs';
import { SCHOOL_FIT_RUBRIC, scoreSchoolFit } from '../shared/school-fit.mjs';
import { getSchoolReference, buildSchoolScenario } from '../shared/school-scenarios.mjs';

// Plain-language descriptions of the maintained demo rules, not new signals.
const SCHOOL_EXPLANATIONS=Object.freeze({
  defensive:'Keep more money in reserve and invest a smaller share. Review the mix every quarter; a price drop alone is not a buy signal.',
  balanced:'Spread money across different assets and review monthly. If one holding moves 5 percentage points from its target, review restoring the planned mix.',
  trend:'Compare the 20-day average price with the 100-day average. Crossing above starts an entry review; falling back to or below starts an exit review.',
  mean_reversion:'Price bands show a recent trading range. This rule waits for a fall below the lower band to recover inside before reviewing an entry.',
  rsi:'RSI is a 0–100 measure of recent price strength. This rule reviews an entry when it recovers above 30, and an exit at 70.',
  price_action:'Watch how a stock rebounds around prices where it previously turned. Review an entry only after the full daily price pattern confirms the rebound.',
  atr:'ATR estimates the size of daily price swings. Use it to set an exit-review distance; it does not tell you when to buy.',
  wyckoff:'Look for a brief dip below an earlier low that recovers as more shares trade. This demo studies one pattern, not the full Wyckoff method.',
  ict:'Study moves within one trading day around earlier highs, lows and price gaps. Learning only: the required intraday data and rules are not connected.',
  order_flow:'Look at individual trades and waiting buy/sell orders. Learning only: this demo has no tick trades or order-book feed.',
});

let labSequence=0;
export function createSchoolLab(document,{chart,download,initialSchool='balanced',selectedTickers,assets=[],market=[],holdings=[],budget:initialBudget=10000}={}){
  const n=(tag,cls,text)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e;};
  const add=(parent,...children)=>{parent.append(...children.filter(Boolean));return parent;};
  const b=(text,fn,cls='secondary')=>{const e=n('button',cls,text);e.type='button';e.addEventListener('click',fn);return e;};
  const usd=value=>value.toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0});
  const pct=value=>`${value>=0?'+':''}${value.toFixed(2)}%`;
  const price=value=>value.toLocaleString('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2});
  const cleanTickers=values=>Array.isArray(values)?[...new Set(values.filter(value=>typeof value==='string'&&/^[A-Z0-9][A-Z0-9.\-^=]{0,14}$/.test(value)&&value!=='CASH'))]:[];
  let selection=selectedTickers===undefined?undefined:cleanTickers(selectedTickers),currentTicker='',selectionAssets=assets,selectionMarket=market,selectionHoldings=holdings,testBudget=initialBudget;
  const assumptions=new Map(),testSettings=new Map();
  const uid=`school-lab-${++labSequence}`,root=n('section','school-lab wide');root.style.gridColumn='1 / -1';root.id='school-lab';
  root.append(n('p','eyebrow','FIND AN APPROACH YOU UNDERSTAND'),n('h3','','Explore a strategy with your selected stocks.'));
  const label=n('label','','Search a strategy');label.htmlFor=uid+'-search';const search=n('input','school-search');search.id=label.htmlFor;search.type='search';search.placeholder='For example: RSI, moving average, trend';search.setAttribute('aria-label','Search strategy name or concept');
  const choices=n('div','school-choice-grid'),detail=n('div','school-lab-detail');detail.id=uid+'-detail';detail.setAttribute('aria-live','polite');
  const selectionNote=n('p','small muted');
  const scoring=n('details','more-panel');scoring.append(n('summary','','How scores work'),n('p','small muted','Team learning-fit rules: asset type 45%, beginner simplicity 30%, saved-data coverage 25%. Selected stocks count equally. Scores are not returns, win rates or personal suitability.'),n('p','small muted','Unknown assets and missing data lower scores. ICT and Order Flow are capped at 20: their required data is not implemented. ATR is a risk tool, not an entry strategy.'));
  root.append(selectionNote,label,search,choices,scoring,detail);let selected=initialSchool, expanded=false;
  const valueStamp=value=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
  const detailStamp=()=>valueStamp({selection,assets:selectionAssets,budget:testBudget,school:selected});
  const scenarioStamp=()=>valueStamp({market:selectionMarket,holdings:selectionHoldings});
  let renderedDetailStamp,renderedScenarioStamp,refreshScenario;
  const fitFor=id=>scoreSchoolFit(id,{tickers:selection||[],assets:selectionAssets},SCHOOL_PRICES);
  function scoreBadge(fit){return n('span','school-fit-score',fit.score===null?'Choose stocks':`${fit.score}/100 fit`);}

  function renderChoices(){
    choices.replaceChildren();selectionNote.textContent=selection?.length?`For ${selection.join(' · ')}. Learning fit, not expected returns.`:'Choose stocks in Your plan to see fit scores.';
    const query=search.value.trim().toLowerCase();
    for(const [index,[id,item]]of Object.entries(SCHOOL_TESTS).entries()){
      if(!query&&!expanded&&index>=6)continue;if(!`${item.label} ${item.aliases}`.toLowerCase().includes(query))continue;
      const fit=fitFor(id),itemButton=b('',()=>select(id),'school-choice'+(id===selected?' selected':''));itemButton.setAttribute('aria-pressed',String(id===selected));itemButton.setAttribute('data-school',id);
      const explanation=n('span','small school-explanation',SCHOOL_EXPLANATIONS[id]||item.summary);explanation.setAttribute('data-approach-explanation',id);
      itemButton.append(add(n('span','school-choice-heading'),n('strong','',item.label),scoreBadge(fit)),explanation);choices.append(itemButton);
    }
    if(!query&&!expanded)choices.append(b('More approaches: ATR, Wyckoff, ICT & Order Flow',()=>{expanded=true;renderChoices();}));
    if(!choices.children.length)choices.append(n('p','small muted','No matching strategy. Try RSI, trend, ATR or a shorter name.'));
  }
  function select(id,{scroll=true}={}){if(!SCHOOL_TESTS[id])return;selected=id;if(Object.keys(SCHOOL_TESTS).indexOf(id)>=6)expanded=true;search.value='';renderChoices();renderDetail();if(scroll)detail.scrollIntoView?.({block:'start'});}
  function renderDetail(){
    renderedDetailStamp=detailStamp();renderedScenarioStamp=scenarioStamp();refreshScenario=null;
    detail.replaceChildren();const school=SCHOOL_TESTS[selected],tickers=selection===undefined?school.tickers:selection;
    const fit=fitFor(selected);
    const explanation=add(n('section','notice school-explanation'),n('strong','','How it works'),n('p','',SCHOOL_EXPLANATIONS[selected]||school.summary));explanation.setAttribute('data-selected-explanation',selected);
    detail.append(add(n('div','school-choice-heading'),n('h4','',school.label),scoreBadge(fit)),explanation);
    if(fit.score!==null){
      detail.append(n('p','small muted',fit.shortReason));
      const why=n('details','more-panel');why.append(n('summary','','Why this score?'));
      for(const [key,label]of [['assetCompatibility','Asset type'],['beginnerEase','Beginner simplicity'],['historyCoverage','Saved-data coverage']]){const part=fit.components[key];why.append(n('p','small',`${label}: ${Math.round(part.score)}/100 × ${SCHOOL_FIT_RUBRIC.weights[key]}%`));}
      for(const limit of fit.limits)why.append(n('p','small muted',limit));
      why.append(n('p','small muted','Each selected stock has equal weight here. Questionnaire eligibility and your actual allocation remain separate. Historical coverage is not a measure of past performance.'));detail.append(why);
    }

    if(!tickers.length){detail.append(n('p','notice','Choose stocks in Your plan first. They will appear here for strategy examples and historical tests.'),n('p','small muted',school.scope));return;}
    if(!tickers.includes(currentTicker))currentTicker=tickers[0];
    const candidates=n('div','badge-row');for(const ticker of tickers){const row=fit.perTicker.find(item=>item.ticker===ticker);const pick=b(row?`${ticker} · ${row.score}/100`:ticker,()=>{stock.value=ticker;refreshDates();},'secondary');pick.setAttribute('aria-label',`${ticker}${row?` learning fit ${row.score} out of 100`:''}`);candidates.append(pick);}detail.append(candidates);
    const selectedStock=n('div','school-test-fields');
    const form=n('div','school-test-form'),fields=n('div','school-test-fields');
    function field(caption,input,id){const wrapper=n('div','');const l=n('label','',caption);l.htmlFor=uid+'-'+id;input.id=l.htmlFor;wrapper.append(l,input);fields.append(wrapper);return input;}
    const stock=n('select','');stock.id=uid+'-ticker';const stockLabel=n('label','','Your selected stock or ETF');stockLabel.htmlFor=stock.id;selectedStock.append(stockLabel,stock);
    for(const ticker of tickers){const a=[...(Array.isArray(selectionAssets)?selectionAssets:[]),...ASSETS].find(asset=>asset.ticker===ticker);const option=n('option','',`${ticker}${a?` · ${a.name}`:''}`);option.value=ticker;stock.append(option);}stock.value=currentTicker;detail.append(selectedStock);
    const scenario=n('section','more-panel');detail.append(scenario);
    const start=field('Start date',n('input',''),'start');start.type='date';
    const end=field('End date',n('input',''),'end');end.type='date';
    const fee=field('Trading fee per side (%)',n('input',''),'fee');fee.type='number';fee.min='0';fee.max='5';fee.step='0.01';fee.value='0.10';
    const budget=field('Test amount (USD)',n('input',''),'budget');budget.type='number';budget.min='100';budget.max='1000000';budget.step='100';budget.value=String(Number.isFinite(testBudget)&&testBudget>=100&&testBudget<=1000000?testBudget:10000);
    const availability=n('p','small muted'),status=n('p','notice');status.hidden=true;const output=n('div','school-test-output');
    const run=b('Run this rule test',runTest,'primary');
    form.append(n('h4','','Test this stock on past prices'),fields,availability,n('p','small muted','0.10% means $1 for each $1,000 bought, and another fee when sold. The benchmark uses the same fee.'),run,status);detail.append(form);
    const ruleDetails=n('details','more-panel');ruleDetails.append(n('summary','','Exactly what is being tested?'),add(n('div','detail-body'),n('p','small',school.scope),n('p','small',school.entry?`Entry: ${school.entry}`:school.scope),school.exit?n('p','small',`Exit: ${school.exit}`):null,n('p','small muted','These maintained rules are educational variants. They do not claim to reproduce every version of a trading school.')));detail.append(ruleDetails,output);
    function stale(){testSettings.set(`${selected}:${stock.value}`,{start:start.value,end:end.value,fee:fee.value,budget:budget.value});if(output.children.length){status.hidden=false;status.textContent='Settings changed. Run the test again; the result below still shows the previous inputs.';}}
    for(const control of [start,end,fee,budget]){control.addEventListener('input',stale);control.addEventListener('change',stale);}
    stock.addEventListener('change',refreshDates);
    function refreshDates(){
      currentTicker=stock.value;renderScenario();output.replaceChildren();status.hidden=true;const data=SCHOOL_PRICES.stocks[stock.value];const first=data?.bars?.[school.warmup||0]?.[0],last=data?.bars?.at(-1)?.[0];
      start.min=first||data?.bars?.[0]?.[0]||'';start.max=last||'';end.min=start.min;end.max=last||'';end.value=last||'';start.value=first&&last?(first>'2025-10-01'?first:'2025-10-01'):start.min;
      const priorSettings=testSettings.get(`${selected}:${stock.value}`);if(priorSettings){start.value=priorSettings.start;end.value=priorSettings.end;fee.value=priorSettings.fee;budget.value=priorSettings.budget;}
      run.disabled=!school.mode||!first||!last||first>=last;
      availability.textContent=!school.mode?school.scope:!data?`No verified historical data is packaged for ${stock.value}. Your selection is preserved. You can still explore hypothetical conditions above; a historical result is not available.`:!first?`This ticker has ${data?.bars?.length||0} saved sessions; the rule needs ${school.warmup} earlier sessions. Your selection is preserved.`:`Test start can be ${first} or later after indicator warm-up. Saved data ends ${last}. Calculations run on this device.`;
    }
    function renderScenario(){
      scenario.replaceChildren();const ticker=stock.value,key=`${selected}:${ticker}`;
      const reference=getSchoolReference(ticker,SCHOOL_PRICES);
      const values=assumptions.get(key)||{};
      const held=(Array.isArray(selectionHoldings)?selectionHoldings:[]).find(item=>item.ticker===ticker&&Number.isFinite(item.quantity)&&item.quantity>0);
      const config=()=>buildSchoolScenario({schoolId:selected,ticker,reference,values,heldQuantity:held?.quantity||0,budget:testBudget});
      const initial=config();scenario.setAttribute('data-scenario-school',selected);
      scenario.append(n('p','eyebrow','TRY THIS STRATEGY: HYPOTHETICAL CONDITIONS'),n('h4','',`${ticker} · ${initial.heading}`),n('p','small',initial.intro));
      const marketRoot=selectionMarket||{},raw=Array.isArray(marketRoot)?marketRoot:marketRoot.quotes||marketRoot;
      const rows=Array.isArray(raw)?raw:Object.entries(raw).map(([key,value])=>value&&typeof value==='object'?{...value,ticker:value.ticker||key}:{});
      const quote=rows.find(row=>row.ticker===ticker),q=quote?.market||quote;
      const quotedPrice=q?.price??q?.latestClose??q?.close;
      const quotedAt=q?.barEnd||q?.barTime||q?.observedAt||q?.timestamp||q?.asOf||q?.priceDate;
      const usableQuote=Number.isFinite(quotedPrice)&&quotedPrice>0&&quotedAt&&Number.isFinite(Date.parse(quotedAt))&&Date.parse(quotedAt)<=Date.now()+60000&&q.status!=='unavailable'&&(!q.currency||q.currency==='USD');
      if(usableQuote)scenario.append(n('p','small muted',`Retrieved ${ticker} price: ${price(quotedPrice)} · ${quotedAt}. ${q.status==='stale'||Date.now()-Date.parse(quotedAt)>15*60*1000?'Older observation; not a current execution price.':'May be delayed.'} Indicators below use the separately dated saved history.`));
      else if(reference)scenario.append(n('p','small muted',`Saved ${ticker} adjusted close: ${price(reference.close)} · ${reference.date}. Historical reference, not a live quote.`));
      else scenario.append(n('p','small muted',`No verified saved price is available for ${ticker}. Any number you enter below is your own assumption.`));
      if(initial.observation)scenario.append(n('p','small muted',initial.observation));
      const controls=n('div','school-test-fields'),result=n('div','price-scenario-result');result.setAttribute('aria-live','polite');
      for(const field of initial.fields){
        const wrap=n('div',''),label=n('label','',field.label),input=n(field.type==='select'?'select':'input','');
        input.id=uid+'-scenario-'+field.key;label.htmlFor=input.id;
        if(field.type==='select')for(const option of field.options){const item=n('option','',option.label);item.value=option.value;input.append(item);}
        else{input.type='number';input.min=String(field.min);input.max=String(field.max);input.step=field.step;}
        input.value=String(field.value);values[field.key]=input.value;
        input.addEventListener(field.type==='select'?'change':'input',()=>{values[field.key]=input.value;assumptions.set(key,{...values});update();});
        wrap.append(label,input);controls.append(wrap);
      }
      scenario.append(controls,result,n('p','small muted','These are example conditions, not forecasts, live alerts or orders. Actual execution prices, fees and gaps can differ.'));
      function update(){
        const guide=config();result.replaceChildren();
        if(guide.error)result.append(n('p','notice',guide.error));
        for(const card of guide.cards)result.append(add(n('div','tracking-history'),n('strong','',card.title),n('p','small',card.text)));
        result.append(n('p','small muted',guide.position));
      }
      update();
    }
    function runTest(){
      output.replaceChildren();status.hidden=true;
      try{
        if(!fee.value.trim()||!budget.value.trim())throw new Error('Enter a fee and a test amount.');
        const result=runSchoolBacktest({schoolId:selected,ticker:stock.value,startDate:start.value,endDate:end.value,feePct:Number(fee.value),budget:Number(budget.value),...(selection!==undefined?{allowedTickers:selection}:{})},SCHOOL_PRICES);
        output.append(n('p','eyebrow','ACTUAL HISTORICAL RULE TEST'),n('h4','',`${result.ticker} · ${school.label}`),n('p','small',`${result.start} → ${result.end} · $${result.parameters.budget.toLocaleString()} · ${result.parameters.feePct}% fee on each buy and sell`),n('p','notice',`${result.scope} Past results do not forecast future returns.`));
        const metrics=n('div','school-result-metrics');for(const [name,value]of [['Rule return',pct(result.metrics.totalReturnPct)],['Buy & hold',pct(result.benchmark.totalReturnPct)],['Largest daily-close fall',pct(result.metrics.maxDrawdownPct)],['Completed trades',String(result.metrics.completedTrades)],['Trading fees',usd(result.metrics.transactionCosts)]])metrics.append(add(n('div','backtest-metric'),n('span','',name),n('strong','',value)));output.append(metrics);
        if(chart)output.append(chart(result.series,`${result.ticker} buy & hold`));
        output.append(n('p','small muted',`Solid line: rule test. Dashed line: hold ${result.ticker}. Both start with the same amount and pay the selected fee. Ending rule-test cash: ${usd(result.metrics.endingValue)}.`));
        const notes=n('details','more-panel');notes.append(n('summary','','Data source, assumptions & every trade'));const body=n('div','detail-body');for(const warning of result.warnings)body.append(n('p','small muted',warning));body.append(n('p','small',`${result.source.name} · retrieved ${result.source.fetchedAt.slice(0,10)} · ${result.source.basis}`));
        const link=n('a','source-link','Provider history page');link.href=result.source.url;link.target='_blank';link.rel='noopener noreferrer';body.append(link);
        if(result.orders.length){const table=n('table','allocation-table');table.append(add(n('thead',''),add(n('tr',''),n('th','','Date'),n('th','','Action'),n('th','','Adjusted price'),n('th','','Fee'))));const rows=n('tbody','');for(const order of result.orders)rows.append(add(n('tr',''),n('td','',order.date),n('td','',`${order.side} · ${order.reason}`),n('td','',order.price.toFixed(2)),n('td','',order.fee.toFixed(2))));table.append(rows);body.append(add(n('div','table-scroll'),table));}else body.append(n('p','small','No entry condition occurred. The test stayed in cash.'));
        notes.append(body);output.append(notes);if(download)output.append(b('Download this test',()=>download(result,`proto-${selected}-${stock.value}-backtest.json`)));
      }catch(error){status.hidden=false;status.textContent=error.message;}
    }
    refreshScenario=renderScenario;refreshDates();
  }
  search.addEventListener('input',renderChoices);select(SCHOOL_TESTS[initialSchool]?initialSchool:'balanced',{scroll:false});
  function setSelection(values={}){
    if(Object.hasOwn(values,'tickers'))selection=cleanTickers(values.tickers);
    if(Object.hasOwn(values,'assets'))selectionAssets=values.assets;
    if(Object.hasOwn(values,'market'))selectionMarket=values.market;
    if(Object.hasOwn(values,'holdings'))selectionHoldings=values.holdings;
    if(Number.isFinite(values.budget))testBudget=values.budget;
    if(SCHOOL_TESTS[values.schoolId])selected=values.schoolId;
    // Background quote, holding and matching updates must not erase a completed
    // historical test or its current inputs. Those results do not use live quotes.
    if(detailStamp()!==renderedDetailStamp){renderChoices();renderDetail();}
    else if(scenarioStamp()!==renderedScenarioStamp){refreshScenario?.();renderedScenarioStamp=scenarioStamp();}
  }
  return {element:root,select,setSelection,destroy(){}};
}
