import { returnScenario, guideAllocations } from '../shared/report-guide.mjs';
import { getCompanyFacts, COMPANY_FACTS_AS_OF } from '../shared/company-facts.mjs';

let guideSequence = 0;
export function createReportCompanion(document, options = {}) {
  const make = (tag, cls, text) => { const element=document.createElement(tag); if(cls)element.className=cls; if(text!==undefined)element.textContent=String(text); return element; };
  const add = (parent,...children) => { parent.append(...children.filter(Boolean)); return parent; };
  const dollars = value => Number(value).toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0});
  const percent = value => `${Number(value).toFixed(1)}%`;
  const id = `report-guide-${++guideSequence}`;
  const section=make('section','report-companion card');
  section.append(make('p','eyebrow',options.imported?'READ YOUR DOCUMENT':'YOUR REPORT, AT A GLANCE'),make('h3','',options.imported?'A simple reading guide':'Understand this mix in one picture'));
  const allocations=guideAllocations(options.allocations);
  const budget=Number(options.budget);
  if(allocations.length) {
    const figure=make('figure','report-picture');
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('viewBox','0 0 720 96'); svg.setAttribute('role','img'); svg.setAttribute('aria-label',allocations.map(row=>`${row.ticker}: ${row.weight}%`).join(', ')); svg.setAttribute('class','mix-picture');
    const title=document.createElementNS('http://www.w3.org/2000/svg','title'); title.textContent='Where this example budget goes. This is an allocation, not a return chart.'; svg.append(title);
    const colors=['#21d5f5','#629cf0','#9ad4b9','#d6bd72','#b795e2','#e69f83','#83b4c9','#b4c675','#7cb69f','#bc9da2'];
    let x=0; allocations.forEach((row,i)=>{const rect=document.createElementNS('http://www.w3.org/2000/svg','rect');rect.setAttribute('x',String(x));rect.setAttribute('y','8');rect.setAttribute('width',String(row.weight*7.2));rect.setAttribute('height','64');rect.setAttribute('fill',colors[i%colors.length]);svg.append(rect);x+=row.weight*7.2;});figure.append(svg);
    const legend=make('div','mix-legend');allocations.forEach((row,i)=>{const label=make('span','mix-legend-item');const dot=make('i','');dot.style.backgroundColor=colors[i%colors.length];label.append(dot,make('span','',`${row.ticker} · ${percent(row.weight)}${Number.isFinite(budget)&&budget>0?` · ${dollars(budget*row.weight/100)}`:''}`));legend.append(label);});figure.append(legend,make('figcaption','small muted','The bar shows how the budget is split. It does not show expected profit.'));section.append(figure);
  } else {
    const figure=make('figure','reading-picture');figure.setAttribute('role','img');figure.setAttribute('aria-label','Read in order: check the date, understand the claim, inspect the evidence.');
    for(const [number,title,text] of [['01','Check the date','Old reports describe an earlier situation.'],['02','Find the main idea','What is being suggested, and for how long?'],['03','Check the evidence','Open sources and look for missing information.']])figure.append(add(make('div','reading-step'),make('strong','',number),make('h4','',title),make('p','small muted',text)));
    section.append(figure,make('p','small muted','No allocation or return forecast has been inferred from this document.'));
  }
  const timing=add(make('div','report-time-guide'),make('h4','','What does the time period mean?'),make('p','small','1–4 weeks: watch the rule conditions. 1–3 months: review business and market developments. 6–12 months: revisit the longer-term thesis. These are review windows, not deadlines for making money.'),make('p','notice','Expected return: no validated forecast is supplied here. The calculator below shows only the assumption you choose.'));
  section.append(timing);
  if(Number.isFinite(budget)&&budget>0&&budget<=1000000) {
    const details=make('details','more-panel');details.append(make('summary','','Explore time & possible returns'));
    const body=make('div','detail-body');body.append(make('p','small','Choose an illustrative annual change and a time period. This is a what-if calculation, not an AI prediction, target or probability.'));
    const controls=make('div','field-grid');
    const rateLabel=make('label','','Assumed yearly change (%)');rateLabel.htmlFor=id+'-rate'; const rate=make('input','');rate.id=rateLabel.htmlFor;rate.type='number';rate.min='-99';rate.max='100';rate.step='1';rate.value='0';
    const timeLabel=make('label','','Time period');timeLabel.htmlFor=id+'-months';const months=make('select','');months.id=timeLabel.htmlFor;for(const n of [1,3,6,12,24,36]){const option=make('option','',`${n} month${n>1?'s':''}`);option.value=String(n);months.append(option);}months.value='12';
    controls.append(add(make('div',''),rateLabel,rate),add(make('div',''),timeLabel,months));body.append(controls);
    const presets=make('div','card-actions');for(const [label,value] of [['Try −10%',-10],['Try 0%',0],['Try +10%',10]]){const b=make('button','secondary',label);b.type='button';b.addEventListener('click',()=>{rate.value=String(value);update();});presets.append(b);}body.append(presets);
    const result=make('p','scenario-result');result.setAttribute('aria-live','polite');body.append(result,make('p','card-footnote','Assumes a constant compounded annual change, no deposits or withdrawals. Taxes, fees, inflation and the path of price changes are excluded. Real losses can be larger than a chosen example.'));
    function update(){try{if(rate.value.trim()==='')throw new Error('Enter an annual assumption.');const scenario=returnScenario(budget,Number(rate.value),Number(months.value));result.textContent=`If your assumption holds for ${scenario.months} months: ${dollars(budget)} → ${dollars(scenario.endingValue)} (${scenario.change>=0?'+':''}${dollars(scenario.change)}, ${percent(scenario.periodPct)}). Assumption only.`;}catch(error){result.textContent=error.message;}}
    rate.addEventListener('input',update);months.addEventListener('change',update);update();details.append(body);section.append(details);
  }
  const facts=make('div','company-facts-section');facts.append(make('h4','','Company results, in plain words'));
  const tickers=[...new Set((options.tickers||allocations.map(row=>row.ticker)).filter(value=>typeof value==='string'))];
  const factsDate=options.factAsOf || COMPANY_FACTS_AS_OF;
  let covered=0;
  for(const ticker of tickers) {
    const item=getCompanyFacts(ticker,factsDate);if(!item)continue;covered++;
    const card=make('article','company-fact-card');card.append(make('h5','',`${ticker} · ${item.companyName}`),make('p','small muted',`${item.periodLabel} · released ${item.releaseDate}`));
    const metrics=make('div','facts-metrics');
    const revenue=item.revenue.value;const revenueText=Math.abs(revenue)>=1e9?`$${(revenue/1e9).toFixed(2)}bn`:`$${(revenue/1e6).toFixed(1)}m`;
    for(const [label,value,explain] of [['Revenue',revenueText,'Sales during this reported quarter.'],['Revenue change',`${item.revenue.yoyPct>=0?'+':''}${percent(item.revenue.yoyPct)}`,'Compared with the same quarter a year earlier.'],[item.dilutedEPS.value<0?'GAAP loss per share':'GAAP diluted EPS',item.dilutedEPS.value.toLocaleString('en-US',{style:'currency',currency:'USD',minimumFractionDigits:2,maximumFractionDigits:2}),'Reported profit or loss per diluted share.']])metrics.append(add(make('div','fact-metric'),make('span','small',label),make('strong','',value),make('p','small muted',explain)));
    card.append(metrics);
    if(item.latestAvailableChecked===false)card.append(make('p','notice',`This snapshot has not been refreshed after ${item.asOfDate}. Check for newer results.`));
    const source=make('details','more-panel');source.append(make('summary','','Dates, source & context'));const detail=make('div','detail-body');detail.append(make('p','small',`Financial period ended ${item.periodEnd}. Maintained reference snapshot checked ${item.asOfDate}. This is not a live earnings feed or an estimate of stock returns.`));
    for(const caution of item.caveats||[])detail.append(make('p','small muted',caution));
    for(const s of item.sources||[]){try{const url=new URL(s.url);if(url.protocol!=='https:')continue;const link=make('a','source-link',s.title||s.publisher||'Official results');link.href=url.href;link.target='_blank';link.rel='noopener noreferrer';detail.append(add(make('p','small'),link));}catch{}}
    source.append(detail);card.append(source);facts.append(card);
  }
  if(!covered)facts.append(make('p','small muted','No matching company earnings snapshot is available for this report date. Funds such as ETFs hold assets; their relevant figures are holdings, fees and tracking, rather than company EPS.'));
  else facts.append(make('p','small muted',`${covered} company snapshot${covered>1?'s':''} shown. Other holdings may have no covered earnings data. Revenue growth and EPS do not tell you whether a share is cheap or will rise.`));
  if(options.imported)facts.append(make('p','notice','These company references are separate from the uploaded text. A ticker mention does not confirm a holding, and the uploaded report has not been verified.'));
  section.append(facts);return section;
}
