$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
. (Join-Path $PSScriptRoot 'scripts/python-runtime.ps1')
$VendorPath = Join-Path $PSScriptRoot 'vendor/TradingAgents'
$LockFile = Join-Path $PSScriptRoot 'requirements-lock.txt'
if (-not (Test-Path -LiteralPath (Join-Path $VendorPath 'pyproject.toml'))) { throw 'The bundled TradingAgents source is missing. Extract the complete shared folder before setup. Git is not required and this script does not download a replacement repository.' }
if (-not (Test-Path -LiteralPath $LockFile)) { throw 'requirements-lock.txt is missing. Extract the complete shared folder before setup.' }
foreach ($Line in (Get-Content -LiteralPath $LockFile)) {
  $Pinned = $Line.Trim()
  if ($Pinned -and -not $Pinned.StartsWith('#') -and $Pinned -notmatch '^[A-Za-z0-9_.-]+==[A-Za-z0-9_.+!-]+$') { throw 'The dependency lock must contain exact package==version pins only.' }
}
$PythonRuntime = Join-Path $PSScriptRoot '.venv/Scripts/python.exe'
if (Test-Path -LiteralPath (Join-Path $PSScriptRoot '.venv')) {
  $Selected = Get-ProtoPythonVersion $PythonRuntime
  if (-not $Selected) { throw 'The existing .venv is not a usable Python 3.11-3.13 environment. Create a fresh extracted app folder and run setup with Python 3.12. An existing environment is never deleted automatically.' }
} else {
  $Selected = Find-ProtoSetupPython
  Write-Host ('Creating an isolated research environment with Python ' + $Selected.version + '.')
  & $Selected.executable -m venv (Join-Path $PSScriptRoot '.venv')
  if ($LASTEXITCODE -ne 0) { throw 'Could not create .venv. Check Python venv support and write permission to this folder.' }
}
Write-Host 'Installing the exact runtime dependency versions from requirements-lock.txt. Internet access is needed for packages.'
& $PythonRuntime -m pip install --requirement $LockFile
if ($LASTEXITCODE -ne 0) { throw 'Pinned dependency installation failed. Keep the version pins; check internet access and platform support. Python 3.12 is the tested reference.' }
& $PythonRuntime -m pip install --no-deps $VendorPath
if ($LASTEXITCODE -ne 0) { throw 'Could not install the bundled TradingAgents source. Build tools may require internet access; no runtime dependency versions were substituted.' }
& $PythonRuntime -m pip check
if ($LASTEXITCODE -ne 0) { throw 'The installed dependencies did not pass pip check. Review the reported conflict before running research.' }
Write-Host 'Research environment installed from the pinned dependency lock and bundled TradingAgents source. Git is not required.'
Write-Host 'Configure your own DeepSeek key in .env.local before live research. Start-Local.cmd creates that file without overwriting existing settings.'
