import fs from 'node:fs/promises';

// Signal 0 checks existence only; it never terminates or changes a process.
// Windows force-stop can leave this lock behind because Node receives no SIGTERM.
export async function clearStaleLocalLock(file, { probePid = pid => process.kill(pid, 0) } = {}) {
  let original;
  try { original = await fs.readFile(file, 'utf8'); }
  catch (problem) { if (problem.code === 'ENOENT') return false; throw problem; }
  const value = original.trim();
  if (!/^[1-9]\d*$/.test(value) || !Number.isSafeInteger(Number(value))) throw new Error('The local state lock is invalid. Verify that the website is stopped before repairing the lock.');
  const pid = Number(value);
  try {
    probePid(pid);
    throw new Error('A live local website process owns this state. Stop it before changing reports or starting another website.');
  } catch (problem) {
    if (problem.code !== 'ESRCH') {
      if (problem.code) throw new Error('The local state lock owner cannot be verified. No lock was removed; check process permissions.');
      throw problem;
    }
  }
  // Refuse removal if another operation replaced the lock during inspection.
  let current;
  try { current = await fs.readFile(file, 'utf8'); }
  catch (problem) { if (problem.code === 'ENOENT') return false; throw problem; }
  if (current !== original) throw new Error('The local state lock changed during inspection. Retry after the other operation finishes.');
  await fs.unlink(file);
  return true;
}
