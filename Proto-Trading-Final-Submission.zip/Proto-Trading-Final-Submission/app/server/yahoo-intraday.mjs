import path from 'node:path';
import {spawn} from 'node:child_process';
import {APP_DIR} from './config.mjs';
import {stopOwnedMarketProcess} from './market-snapshot.mjs';

const symbol=/^[A-Z][A-Z0-9.-]{0,9}$/;
const exchanges=new Set(['NMS','NGM','NCM','NYQ','PCX','ASE','BTS','NASDAQ','NYSE','NYSEARCA','NYSEAMERICAN','BATS']);
const warnings=['Yahoo Finance minute data may be delayed or unavailable; this is a timestamped research preview, not a guaranteed real-time execution price.'];
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const clock=value=>typeof value==='function'?value():value??Date.now();
const eastern=new Intl.DateTimeFormat('en-US',{timeZone:'America/New_York',weekday:'short',year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
function session(time){const p=Object.fromEntries(eastern.formatToParts(new Date(time)).map(p=>[p.type,p.value]));return {date:`${p.year}-${p.month}-${p.day}`,regular:!['Sat','Sun'].includes(p.weekday)&&(Number(p.hour)*60+Number(p.minute))>=570&&(Number(p.hour)*60+Number(p.minute))<960};}
const unavailable=(ticker,code='YAHOO_DATA_UNAVAILABLE')=>({ticker,status:'unavailable',code,eligibleForAlerts:false,message:'Yahoo minute data is unavailable or could not be verified. No price was substituted.'});
const sourceUrl=ticker=>`https://finance.yahoo.com/quote/${encodeURIComponent(ticker.replaceAll('.','-'))}/`;

export function validateYahooQuote(row,ticker,now=Date.now()){
  const meta=row?.instrument,bar=row?.bar;
  if(row?.ticker!==ticker||row?.status!=='complete')return unavailable(ticker);
  if(!meta||meta.ticker!==ticker||meta.symbol!==ticker.replaceAll('.','-')||meta.currency!=='USD'||!exchanges.has(meta.exchange)||!['EQUITY','ETF'].includes(meta.instrumentType)||meta.timezone!=='America/New_York'||meta.verified!==true||typeof meta.name!=='string'||!meta.name.trim()||meta.name.length>300||/[\u0000-\u001f\u007f]/.test(meta.name))return unavailable(ticker,'YAHOO_IDENTITY_UNVERIFIED');
  if(ticker==='SPCX'&&!/spacex|space exploration/i.test(meta.name.replace(/\s+/g,' ')))return unavailable(ticker,'YAHOO_IDENTITY_UNVERIFIED');
  const time=typeof bar?.t==='string'&&/^\d{4}-\d{2}-\d{2}T/.test(bar.t)?Date.parse(bar.t):NaN,end=time+60000;
  if(!Number.isFinite(time)||time%60000!==0||!['o','h','l','c'].every(k=>finite(bar[k])&&bar[k]>0)||!finite(bar.v)||bar.v<=0||bar.l>Math.min(bar.o,bar.c)||bar.h<Math.max(bar.o,bar.c)||bar.h<bar.l)return unavailable(ticker,'YAHOO_INVALID_BAR');
  if(end>now)return unavailable(ticker,'YAHOO_INCOMPLETE_BAR');
  if(ticker==='SPCX'&&time<Date.parse('2026-06-12T00:00:00Z'))return unavailable(ticker,'YAHOO_ISSUER_HISTORY');
  if(!session(time).regular)return unavailable(ticker,'YAHOO_OUTSIDE_SESSION');
  const start=meta.session?.start*1000,finish=meta.session?.end*1000;
  const verifiedSession=finite(start)&&finite(finish)&&finish>start&&finish-start<=7*3600000&&session(start).date===session(now).date;
  const marketOpen=!!(verifiedSession&&start<=now&&now<finish&&session(now).regular);
  const ageSeconds=Math.max(0,Math.floor((now-end)/1000));
  const eligible=marketOpen&&time>=start&&end<=finish&&ageSeconds<=300;
  const status=eligible?'complete':!marketOpen?'market_closed':ageSeconds<=900?'delayed':'stale';
  return {ticker,status,code:eligible?undefined:!marketOpen?'MARKET_CLOSED':ageSeconds<=900?'DELAYED_BAR':'STALE_BAR',eligibleForAlerts:eligible,marketOpen,price:bar.c,open:bar.o,high:bar.h,low:bar.l,close:bar.c,volume:bar.v,barTime:new Date(time).toISOString(),barEnd:new Date(end).toISOString(),ageSeconds,currency:'USD',currencyVerified:true,source:'Yahoo Finance',sourceUrl:sourceUrl(ticker),feed:'yahoo',timeframe:'1Min',priceBasis:'Raw trade prices; completed regular-session minute bar',fetchedAt:new Date(now).toISOString(),instrument:{ticker,name:meta.name,exchange:meta.exchange,instrumentType:meta.instrumentType,verified:true},message:eligible?'Latest completed minute bar; provider latency is not guaranteed.':!marketOpen?'The regular US session is not currently verified open. Last available minute price is shown; no intraday alert is eligible.':'The latest completed minute bar is over five minutes old; it is display-only.'};
}

function childEnvironment(env){
  const allowed=new Set(['PATH','PATHEXT','SYSTEMROOT','SYSTEMDRIVE','WINDIR','TEMP','TMP','HOME','USERPROFILE','HOMEDRIVE','HOMEPATH','LOCALAPPDATA','APPDATA','PROGRAMDATA','ALLUSERSPROFILE','PROGRAMFILES','PROGRAMFILES(X86)','COMMONPROGRAMFILES','COMMONPROGRAMFILES(X86)','COMSPEC','NUMBER_OF_PROCESSORS','PROCESSOR_ARCHITECTURE','SSL_CERT_FILE','SSL_CERT_DIR','CURL_CA_BUNDLE','REQUESTS_CA_BUNDLE','HTTPS_PROXY','HTTP_PROXY','ALL_PROXY','NO_PROXY']);
  return {...Object.fromEntries(Object.entries(env).filter(([key,value])=>allowed.has(key.toUpperCase())&&typeof value==='string')),PYTHONUTF8:'1',PYTHONUNBUFFERED:'1'};
}

export function createYahooAdapter({spawnImpl=spawn,appDir=APP_DIR,env=process.env,timeoutMs=25000,maxOutputBytes=128*1024,stopChild=stopOwnedMarketProcess}={}){
  return tickers=>new Promise(resolve=>{
    let child,timer,done=false,size=0,errors=0;const chunks=[];
    const finish=result=>{if(done)return;done=true;clearTimeout(timer);resolve(result);};
    const fail=code=>{if(done)return;finish({rows:[],code});if(child)void stopChild(child).catch(()=>{});};
    try{
      const python=env.PYTHON_EXECUTABLE||path.join(appDir,'.venv',process.platform==='win32'?'Scripts/python.exe':'bin/python');
      child=spawnImpl(python,['-m','worker.yahoo_intraday'],{cwd:appDir,shell:false,windowsHide:true,stdio:['pipe','pipe','pipe'],env:childEnvironment(env)});
      timer=setTimeout(()=>fail('YAHOO_TIMEOUT'),Math.max(1,Math.min(timeoutMs,25000)));
      child.on('error',()=>fail('YAHOO_ADAPTER_UNAVAILABLE'));
      child.stdout.on('data',chunk=>{if(done)return;size+=chunk.length;if(size>maxOutputBytes)return fail('YAHOO_RESPONSE_LIMIT');chunks.push(Buffer.from(chunk));});
      child.stderr.on('data',chunk=>{errors+=chunk.length;if(errors>maxOutputBytes)fail('YAHOO_RESPONSE_LIMIT');});
      child.on('close',code=>{if(done)return;if(code!==0)return fail('YAHOO_ADAPTER_UNAVAILABLE');try{finish(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch{fail('YAHOO_INVALID_RESPONSE');}});
      child.stdin.on('error',()=>fail('YAHOO_ADAPTER_UNAVAILABLE'));
      child.stdin.end(JSON.stringify({tickers}));
    }catch{fail('YAHOO_ADAPTER_UNAVAILABLE');}
  });
}
const adapter=createYahooAdapter();
const cache=new Map(),pending=new Map();
async function cachedRows(tickers,time){
  const key=[...tickers].sort().join(',');
  if(cache.get(key)?.expiresAt>time)return cache.get(key).value;
  if(pending.has(key))return pending.get(key);
  const task=adapter(tickers).then(value=>{if(cache.size>100)cache.clear();cache.set(key,{value,expiresAt:time+45000});return value;}).finally(()=>pending.delete(key));
  pending.set(key,task);return task;
}
export async function getYahooIntradayQuotes(tickers,config={}, {now=Date.now,provider}={}){
  if(!Array.isArray(tickers)||tickers.length>50||tickers.some(t=>typeof t!=='string'||!symbol.test(t))||new Set(tickers).size!==tickers.length)throw new Error('Request up to 50 unique US ticker symbols.');
  const time=clock(now);if(!finite(time))throw new Error('Invalid current time.');
  const base={source:'Yahoo Finance',feed:'yahoo',fetchedAt:new Date(time).toISOString(),warnings:[...warnings]};
  const fail=code=>({...base,status:'unavailable',code,quotes:Object.fromEntries(tickers.map(t=>[t,unavailable(t,code)]))});
  if(config.mode&&config.mode!=='local')return fail('YAHOO_LOCAL_ONLY');
  if(!tickers.length)return {...base,status:'complete',quotes:{}};
  let data;try{data=await (provider?provider(tickers):cachedRows(tickers,time));}catch{return fail('YAHOO_DATA_UNAVAILABLE');}
  if(!data||!Array.isArray(data.rows)||data.rows.length>50)return fail('YAHOO_INVALID_RESPONSE');
  if(data.code&&data.rows.length===0)return fail(data.code);
  const quotes=Object.fromEntries(tickers.map(ticker=>{const matches=data.rows.filter(row=>row?.ticker===ticker);return [ticker,matches.length===1?validateYahooQuote(matches[0],ticker,time):unavailable(ticker,'YAHOO_MISSING_BAR')];}));
  const values=Object.values(quotes),complete=values.filter(row=>row.status==='complete').length,display=values.filter(row=>finite(row.price)).length;
  const closed=display>0&&values.filter(row=>finite(row.price)).every(row=>row.status==='market_closed');
  return {...base,status:complete===tickers.length?'complete':complete?'partial':closed?'market_closed':display?'delayed':'unavailable',code:closed?'MARKET_CLOSED':undefined,marketOpen:values.some(row=>row.marketOpen),quotes};
}
export async function getYahooAsset(ticker,config={},options={}){
  if(typeof ticker!=='string'||!symbol.test(ticker))return unavailable('','YAHOO_IDENTITY_UNVERIFIED');
  const result=await getYahooIntradayQuotes([ticker],config,options),row=result.quotes[ticker];
  if(!row.instrument?.verified)return unavailable(ticker,'YAHOO_IDENTITY_UNVERIFIED');
  // Compatibility field means a verified listed equity/ETF, not broker order
  // eligibility. This provider never connects to an execution account.
  return {ticker,status:'complete',name:row.instrument.name,assetClass:'us_equity',exchange:row.instrument.exchange,tradable:true,currency:'USD',source:'Yahoo Finance listing metadata',fetchedAt:result.fetchedAt};
}
