import path from 'node:path';
import { spawn } from 'node:child_process';
import { APP_DIR } from './config.mjs';

const safeTickers = tickers => Array.isArray(tickers) && tickers.length <= 5 && tickers.every(ticker => typeof ticker === 'string' && /^[A-Z][A-Z0-9.-]{0,9}$/.test(ticker)) && new Set(tickers).size === tickers.length;
const validDate = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && Number.isFinite(Date.parse(value + 'T00:00:00Z')) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;
const timestamp = value => typeof value === 'string' && Number.isFinite(Date.parse(value));
const finite = value => typeof value === 'number' && Number.isFinite(value);
const cleanText = value => typeof value === 'string' ? value.slice(0, 600) : undefined;
const near = (a, b) => Math.abs(a - b) <= 0.000001;

function dailyEvidence(row, cutoffDate) {
  const result = {};
  const positive = ['latestOpen', 'latestHigh', 'latestLow', 'prior20High', 'prior20Low', 'previousPrior20High', 'previousPrior20Low'];
  const nonnegative = ['atr14', 'previousAtr14', 'latestVolume', 'prior20VolumeMedian'];
  for (const key of [...positive, ...nonnegative, 'rsi14', 'previousRsi14']) {
    if (row[key] === undefined) continue;
    if (row[key] === null) { result[key] = null; continue; }
    if (!finite(row[key]) || row[key] < 0 || (positive.includes(key) && row[key] === 0) || (key.toLowerCase().includes('rsi') && row[key] > 100)) throw new Error('Invalid daily indicator');
    result[key] = row[key];
  }
  if (row.bars !== undefined) {
    if (!Array.isArray(row.bars) || row.bars.length < 2 || row.bars.length > 120) throw new Error('Invalid daily bars');
    result.bars = row.bars.map((bar, index) => {
      if (!bar || !validDate(bar.date) || bar.date > row.priceDate || [0, 6].includes(new Date(bar.date + 'T12:00:00Z').getUTCDay()) || (index && row.bars[index - 1].date >= bar.date) || !['open', 'high', 'low', 'close'].every(key => finite(bar[key]) && bar[key] > 0) || !finite(bar.volume) || bar.volume < 0 || bar.low > Math.min(bar.open, bar.close) || bar.high < Math.max(bar.open, bar.close) || bar.high < bar.low) throw new Error('Invalid daily bars');
      return { date: bar.date, open: bar.open, high: bar.high, low: bar.low, close: bar.close, volume: bar.volume };
    });
    const last = result.bars.at(-1), previous = result.bars.at(-2);
    if (last.date !== row.priceDate || !near(last.close, row.latestClose) || !near(previous.close, row.previousClose) || row.bars.length > row.observations) throw new Error('Daily series mismatch');
    for (const [field, key] of [['latestOpen', 'open'], ['latestHigh', 'high'], ['latestLow', 'low'], ['latestVolume', 'volume']]) if (result[field] != null && !near(result[field], last[key])) throw new Error('Daily series mismatch');
  }
  if (row.candle !== undefined) {
    if (!row.candle || !['body', 'range', 'upperWick', 'lowerWick'].every(key => finite(row.candle[key]) && row.candle[key] >= 0) || (row.candle.closePosition !== null && (!finite(row.candle.closePosition) || row.candle.closePosition < 0 || row.candle.closePosition > 1))) throw new Error('Invalid candle');
    result.candle = Object.fromEntries(['body', 'range', 'upperWick', 'lowerWick', 'closePosition'].map(key => [key, row.candle[key]]));
  }
  if (row.providerReference && typeof row.providerReference === 'object') {
    const reference = row.providerReference;
    const validReferenceDate = validDate(reference.priceDate) && reference.priceDate <= cutoffDate;
    result.providerReference = { ticker: row.ticker, status: reference.status === 'reference_only' ? 'reference_only' : 'unavailable', source: cleanText(reference.source), providerSymbol: cleanText(reference.providerSymbol), priceDate: validReferenceDate ? reference.priceDate : undefined, latestClose: validReferenceDate && finite(reference.latestClose) && reference.latestClose > 0 ? reference.latestClose : undefined, adjustmentVerified: false, eligibleForSignals: false, adjustmentMethod: cleanText(reference.adjustmentMethod), currency: reference.currency === 'USD' ? 'USD' : undefined, currencyVerified: false, currencySource: cleanText(reference.currencySource), fallbackReason: cleanText(reference.fallbackReason), errorCode: cleanText(reference.errorCode) };
  }
  return result;
}

export function unavailableSnapshot(tickers, code, message) {
  return { status: 'unavailable', cutoffDate: null, fetchedAt: null, snapshots: tickers.map(ticker => ({ ticker, status: 'error', error: { code, message } })), warnings: [message] };
}

// Validate the external-data boundary before any strategy rules use its values.
export function validateSnapshot(input, tickers, now = Date.now()) {
  if (!safeTickers(tickers)) throw new Error('Only up to five approved tickers can be requested.');
  if (!input || !Array.isArray(input.snapshots) || input.snapshots.length > 5 || !validDate(input.cutoffDate) || !timestamp(input.fetchedAt) || Date.parse(input.fetchedAt) > now + 300000 || input.cutoffDate > new Date(now).toISOString().slice(0, 10)) {
    return unavailableSnapshot(tickers, 'INVALID_MARKET_RESPONSE', 'The market adapter did not return a valid dated snapshot. No prices or signals were substituted.');
  }
  const warnings = Array.isArray(input.warnings) ? input.warnings.filter(v => typeof v === 'string').slice(0, 20).map(v => v.slice(0, 600)) : [];
  const snapshots = tickers.map(ticker => {
    const matches = input.snapshots.filter(row => row?.ticker === ticker);
    if (matches.length !== 1) return { ticker, status: 'error', error: { code: 'MISSING_MARKET_ROW', message: 'The market adapter did not return a unique row for this holding.' } };
    const row = matches[0];
    if (row.status !== 'complete') return { ticker, status: 'error', error: { code: typeof row.error?.code === 'string' ? row.error.code.slice(0, 60) : 'MARKET_DATA_UNAVAILABLE', message: typeof row.error?.message === 'string' ? row.error.message.slice(0, 600) : 'Market data is unavailable for this holding.' } };
    const numericFields = ['sma20', 'sma100', 'previousSma20', 'previousSma100', 'bollingerUpper', 'bollingerLower'];
    const validIndicators = numericFields.every(field => row[field] === null || finite(row[field]));
    if (!validDate(row.priceDate) || row.priceDate > input.cutoffDate || !finite(row.latestClose) || row.latestClose <= 0 || !finite(row.previousClose) || row.previousClose <= 0 || !validIndicators || !Number.isInteger(row.observations) || row.observations < 2 || row.currency !== 'USD' || row.adjusted !== true || row.adjustmentVerified === false || !timestamp(row.fetchedAt) || Date.parse(row.fetchedAt) > now + 300000 || (!row.source || !['object', 'string'].includes(typeof row.source))) {
      return { ticker, status: 'error', error: { code: 'INVALID_MARKET_ROW', message: 'The market adapter returned incomplete or invalid price evidence. No action is inferred from this row.' } };
    }
    let evidence;
    try { evidence = dailyEvidence(row, input.cutoffDate); }
    catch { return { ticker, status: 'error', error: { code: 'INVALID_DAILY_EVIDENCE', message: 'Daily prices or indicators failed validation. No candle, RSI or ATR signal was inferred.' } }; }
    const source = typeof row.source === 'string' ? cleanText(row.source) : { name: cleanText(row.source.name), url: typeof row.source.url === 'string' && /^https?:\/\//.test(row.source.url) ? row.source.url.slice(0, 800) : undefined };
    return { ticker, status: 'complete', priceDate: row.priceDate, previousPriceDate: validDate(row.previousPriceDate) ? row.previousPriceDate : undefined, latestClose: row.latestClose, previousClose: row.previousClose, ...Object.fromEntries(numericFields.map(field => [field, row[field]])), ...evidence, observations: row.observations, currency: 'USD', currencyVerified: row.currencyVerified === true, currencySource: cleanText(row.currencySource), adjusted: true, source, fetchedAt: row.fetchedAt, priceBasis: cleanText(row.priceBasis), adjustmentMethod: cleanText(row.adjustmentMethod), preferredSource: cleanText(row.preferredSource), fallbackReason: cleanText(row.fallbackReason), warnings: Array.isArray(row.warnings) ? row.warnings.filter(v => typeof v === 'string').slice(0, 12).map(cleanText) : [], ohlcvAvailable: row.ohlcvAvailable === true };
  });
  const count = snapshots.filter(row => row.status === 'complete').length;
  return { status: count === tickers.length ? 'complete' : count ? 'partial' : 'unavailable', cutoffDate: input.cutoffDate, fetchedAt: input.fetchedAt, snapshots, warnings };
}

function childEnvironment(env) {
  const names = ['PATH', 'PATHEXT', 'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'HOME', 'USERPROFILE', 'LOCALAPPDATA', 'APPDATA', 'COMSPEC', 'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE', 'SSL_CERT_FILE', 'CURL_CA_BUNDLE', 'REQUESTS_CA_BUNDLE', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY', 'NO_PROXY'];
  const allowed = new Set(names);
  const result = {};
  for (const [key, value] of Object.entries(env)) if (allowed.has(key.toUpperCase()) && typeof value === 'string') result[key] = value;
  return { ...result, PYTHONUTF8: '1', PYTHONUNBUFFERED: '1' };
}

export async function stopOwnedMarketProcess(child, { platform = process.platform, spawnImpl = spawn, env = process.env, helperTimeoutMs = 5000 } = {}) {
  const stillRunning = () => child && child.exitCode == null && child.signalCode == null;
  if (!stillRunning()) return false;
  const stopDirect = () => { if (!stillRunning()) return false; try { return child.kill('SIGKILL'); } catch { return false; } };
  if (platform !== 'win32' || !Number.isSafeInteger(child.pid) || child.pid <= 0) return stopDirect();
  // A Windows venv launcher can own the actual Python interpreter. /T limits
  // termination to the tree rooted at this still-running, directly owned child.
  // Never search by executable name or target the separate research worker.
  return new Promise(resolve => {
    let helper, timer, settled = false;
    const finish = success => { if (settled) return; settled = true; clearTimeout(timer); resolve(success); };
    const fallback = () => finish(stopDirect());
    try {
      const systemRoot = env.SystemRoot || env.SYSTEMROOT || env.WINDIR || 'C:\\Windows';
      helper = spawnImpl(path.win32.join(systemRoot, 'System32', 'taskkill.exe'), ['/PID', String(child.pid), '/T', '/F'], { shell: false, windowsHide: true, stdio: 'ignore', env: childEnvironment(env) });
      timer = setTimeout(() => { try { helper.kill('SIGKILL'); } catch { /* The helper may have exited. */ } fallback(); }, helperTimeoutMs);
      helper.once('error', fallback);
      helper.once('close', code => { if (code === 0) finish(true); else fallback(); });
    } catch { fallback(); }
  });
}

export function createLocalSnapshotProvider({ spawnImpl = spawn, appDir = APP_DIR, env = process.env, timeoutMs = 25000, maxOutputBytes = 131072 } = {}) {
  return async ({ tickers }) => {
    if (!safeTickers(tickers)) throw new Error('Only up to five approved tickers can be requested.');
    if (!tickers.length) return { status: 'complete', cutoffDate: null, fetchedAt: null, snapshots: [], warnings: ['This allocation has no non-cash holdings requiring market data.'] };
    return new Promise(resolve => {
      let child, timer, done = false, outputBytes = 0, errorBytes = 0;
      const chunks = [];
      const finish = value => { if (done) return; done = true; clearTimeout(timer); resolve(value); };
      const fail = (code, message) => { if (done) return; finish(unavailableSnapshot(tickers, code, message)); void stopOwnedMarketProcess(child, { spawnImpl, env }); };
      try {
        const python = path.join(appDir, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
        child = spawnImpl(python, ['-m', 'worker.quick_market'], { cwd: appDir, shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], env: childEnvironment(env) });
        timer = setTimeout(() => fail('MARKET_TIMEOUT', 'The market-data request exceeded its time limit. Retry shortly; no prices or signals were substituted.'), timeoutMs);
        child.on('error', problem => fail(problem.code === 'ENOENT' ? 'MARKET_ADAPTER_MISSING' : 'MARKET_ADAPTER_FAILED', problem.code === 'ENOENT' ? 'The local Python market adapter is not installed. Run the research setup before requesting market evidence.' : 'The local market adapter could not start. Check the local research environment.'));
        child.stdout.on('data', chunk => {
          if (done) return;
          outputBytes += chunk.length;
          if (outputBytes > maxOutputBytes) { fail('MARKET_OUTPUT_LIMIT', 'The market adapter returned too much data. No output was used.'); return; }
          chunks.push(Buffer.from(chunk));
        });
        child.stderr.on('data', chunk => { errorBytes += chunk.length; if (errorBytes > maxOutputBytes) fail('MARKET_OUTPUT_LIMIT', 'The market adapter produced excessive diagnostic output. No output was used.'); });
        child.on('close', code => {
          if (done) return;
          if (code !== 0) { finish(unavailableSnapshot(tickers, 'MARKET_ADAPTER_FAILED', 'The market adapter could not finish. Check local data connectivity and retry.')); return; }
          try { finish(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
          catch { finish(unavailableSnapshot(tickers, 'INVALID_MARKET_RESPONSE', 'The market adapter returned unreadable data. No prices or signals were substituted.')); }
        });
        child.stdin.on('error', () => fail('MARKET_ADAPTER_FAILED', 'The market adapter could not receive its ticker list.'));
        child.stdin.end(JSON.stringify({ tickers }));
      } catch { fail('MARKET_ADAPTER_FAILED', 'The local market adapter could not start. Check the local research environment.'); }
    });
  };
}

export function createSnapshotCache({ provider = createLocalSnapshotProvider(), mode = 'local', now = () => Date.now(), ttlMs = 15 * 60000, failureTtlMs = 30000, maxEntries = 32 } = {}) {
  const cache = new Map(), pending = new Map();
  return async tickers => {
    if (!safeTickers(tickers)) throw new Error('Only up to five approved tickers can be requested.');
    const sorted = [...tickers].sort(), key = sorted.join(',');
    if (mode !== 'local') return { snapshot: unavailableSnapshot(sorted, 'LOCAL_MARKET_ADAPTER_UNAVAILABLE', 'Short-term market data is not connected on this site. The template checklist remains available.'), cache: 'unavailable' };
    if (!sorted.length) return { snapshot: { status: 'complete', cutoffDate: null, fetchedAt: null, snapshots: [], warnings: ['This allocation has no non-cash holdings requiring market data.'] }, cache: 'fresh' };
    const saved = cache.get(key);
    if (saved && saved.expiresAt > now()) return { snapshot: structuredClone(saved.snapshot), cache: 'cached' };
    if (saved) cache.delete(key);
    if (pending.has(key)) return { snapshot: structuredClone(await pending.get(key)), cache: 'shared' };
    const task = (async () => {
      let snapshot;
      try {
        const input = await provider({ tickers: sorted });
        // Preserve deliberate adapter failures instead of replacing their useful
        // public message with a generic schema error.
        if (input?.status === 'unavailable' && input.cutoffDate === null && input.fetchedAt === null && Array.isArray(input.snapshots)) {
          const message = typeof input.warnings?.[0] === 'string' ? input.warnings[0].slice(0, 600) : 'Market evidence is unavailable.';
          const code = typeof input.snapshots[0]?.error?.code === 'string' ? input.snapshots[0].error.code.slice(0, 60) : 'MARKET_DATA_UNAVAILABLE';
          snapshot = unavailableSnapshot(sorted, code, message);
        } else snapshot = validateSnapshot(input, sorted, now());
      } catch { snapshot = unavailableSnapshot(sorted, 'MARKET_DATA_UNAVAILABLE', 'The market-data provider is unavailable. No prices or signals were substituted.'); }
      cache.set(key, { snapshot, expiresAt: now() + (snapshot.status === 'complete' ? ttlMs : failureTtlMs) });
      while (cache.size > maxEntries) cache.delete(cache.keys().next().value);
      return snapshot;
    })();
    pending.set(key, task);
    try { return { snapshot: structuredClone(await task), cache: 'fresh' }; }
    finally { if (pending.get(key) === task) pending.delete(key); }
  };
}
