import { createHash, randomBytes, randomUUID, timingSafeEqual } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { TEMPLATES, ASSETS, TEMPLATE_VERSION, validateProfile, createMatch } from '../shared/strategy.mjs';
import { explainMatch } from './deepseek.mjs';
import { createShortPlan } from '../shared/short-plan.mjs';
import { createSnapshotCache } from './market-snapshot.mjs';
import { createStockSearch, normalizeStockQuery } from './stock-search.mjs';
import { createTrackingService } from './tracking.mjs';
import { validateResearchSelection, createSelectedResearchMatch, researchInputSnapshot } from './research-selection.mjs';

const token = () => randomBytes(32).toString('base64url');
const hash = value => createHash('sha256').update(String(value)).digest('hex');
const iso = now => new Date(now).toISOString();
const error = (status, message) => Object.assign(new Error(message), { status });
const MAX_REPORT_BYTES = 2 * 1024 * 1024;
const text = (value, max, label) => {
  if (typeof value !== 'string' || !value.trim() || value.length > max) throw error(400, `Invalid ${label}.`);
  return value.trim();
};

function send(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), { status, headers: {
    'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff',
    'Referrer-Policy': 'no-referrer', ...extraHeaders,
  } });
}
function sameSecret(actual, expected) {
  if (!actual || !expected || actual.length > 512) return false;
  const a = Buffer.from(hash(actual)), b = Buffer.from(hash(expected));
  return timingSafeEqual(a, b);
}
function workerStatus(state, config, now) {
  const seen = Object.values(state.workers).map(v => v.lastSeen).sort((a, b) => b - a)[0];
  return { online: !!seen && now - seen <= config.workerStaleMs, lastSeen: seen ? iso(seen) : null };
}
function prune(state, now) {
  for (const [key, val] of Object.entries(state.sessions)) if (val.expiresAt < now) delete state.sessions[key];
  for (const [key, val] of Object.entries(state.limits)) if (val.resetAt < now) delete state.limits[key];
  for (const [key, val] of Object.entries(state.workers)) if (now - val.lastSeen > 7 * 86400000) delete state.workers[key];
  for (const job of Object.values(state.jobs)) {
    if (job.status === 'running' && job.leaseExpiresAt <= now) {
      job.status = 'failed'; job.stage = 'Research interrupted'; job.updatedAt = iso(now);
      job.error = 'The research worker stopped responding. Restart the worker and submit a new request.';
    }
    if (job.status === 'queued' && now - Date.parse(job.createdAt) > 30 * 60000) {
      job.status = 'failed'; job.stage = 'Queue expired'; job.updatedAt = iso(now);
      job.error = 'The worker did not start this task within 30 minutes. Check worker availability and submit again.';
    }
  }
}
function rate(state, key, max, now) {
  const bucket = state.limits[key] || { count: 0, resetAt: now + 3600000 };
  if (bucket.count >= max) throw error(429, 'Request limit reached. Please retry after the hourly limit resets.');
  bucket.count++; state.limits[key] = bucket;
}
function publicJob(job) {
  const out = { id: job.id, status: job.status, stage: job.stage, createdAt: job.createdAt, updatedAt: job.updatedAt, inputSnapshot: researchInputSnapshot(job.profile, job.match) };
  if (job.error) out.error = job.error;
  return out;
}
function requireSession(state, supplied, now) {
  if (typeof supplied !== 'string' || supplied.length > 256 || !state.sessions[hash(supplied)] || state.sessions[hash(supplied)].expiresAt <= now) throw error(401, 'Your session expired. Match your profile again before requesting research.');
  return hash(supplied);
}
function confirmedMatch(state, sessionInput, profile, matchId, timestamp) {
  const sessionHash = requireSession(state, sessionInput, timestamp), session = state.sessions[sessionHash];
  if (session.matching) throw error(409, 'Profile matching is still in progress. Wait for the latest match before requesting a plan or research.');
  if (session.profileHash !== hash(JSON.stringify(profile)) || (matchId && matchId !== session.matchId)) throw error(409, 'The profile changed. Match it again before requesting a new plan or report.');
  const match = createMatch({ ...profile, templateId: session.selectedTemplateId });
  match.selection = session.selection;
  if (match.id !== session.matchId) throw error(409, 'The maintained strategy rules changed. Match your profile again before requesting a plan or report.');
  return { sessionHash, match, matchRequestId: session.matchRequestId };
}
function requireLease(state, body, now, allowComplete = false) {
  const job = state.jobs[text(body.jobId, 100, 'job ID')];
  const lease = text(body.leaseToken, 256, 'lease token');
  if (!job || job.workerId !== body.workerId || !sameSecret(lease, job.leaseToken)) throw error(409, 'This worker does not own the research lease.');
  if (allowComplete && ['complete', 'partial'].includes(job.status)) return job;
  if (job.status !== 'running' || job.leaseExpiresAt <= now) throw error(409, 'The research lease has expired or the task is no longer running.');
  return job;
}
function validateReport(report, job) {
  if (!report || typeof report !== 'object' || !['complete', 'partial'].includes(report.status) || report.id !== job.id) throw error(400, 'The report ID and status must match the assigned job.');
  if (!isDeepStrictEqual(report.profile, job.profile)) throw error(400, 'The report profile differs from the assigned input snapshot.');
  if (!isDeepStrictEqual(report.match, job.match)) throw error(400, 'The report strategy, selection or allocation differs from the assigned input snapshot.');
  if (!report.generatedAt || !Number.isFinite(Date.parse(report.generatedAt)) || !/^\d{4}-\d{2}-\d{2}$/.test(report.analysisDate || '')) throw error(400, 'The report requires valid generation and analysis dates.');
  if (report.provenance?.engine !== 'TauricResearch/TradingAgents' || typeof report.provenance.repository !== 'string' || !Array.isArray(report.provenance.dataSources) || !Array.isArray(report.provenance.warnings)) throw error(400, 'The report requires TradingAgents provenance and data sources.');
  if (!Array.isArray(report.research) || !Array.isArray(report.outlook) || !Array.isArray(report.limitations) || !['complete', 'unavailable'].includes(report.backtest?.status)) throw error(400, 'The report is missing required research sections.');
  const allowed = new Set(job.match.allocations.map(a => a.ticker));
  for (const item of report.research) {
    if (!allowed.has(item.ticker) || !['complete', 'error'].includes(item.status) || !Array.isArray(item.sections)) throw error(400, 'The report contains an unassigned ticker or invalid research section.');
  }
  if (job.match.researchSelection?.source === 'user-selected') {
    const assigned = job.match.researchSelection.tickers, returned = report.research.map(item => item.ticker);
    if (returned.length !== assigned.length || new Set(returned).size !== returned.length || assigned.some(ticker => !returned.includes(ticker))) throw error(400, 'Selected-stock research must include each assigned stock exactly once, including watch-only stocks.');
  }
  if (report.status === 'complete' && !report.research.some(r => r.status === 'complete')) throw error(400, 'A complete report must contain actual completed research.');
  if (Buffer.byteLength(JSON.stringify(report)) > MAX_REPORT_BYTES) throw error(413, 'The report is too large.');
  // The assigned server snapshot is authoritative even if a worker sent extra fields.
  return { ...report, profile: job.profile, match: job.match };
}

export function createApi({ config, store, fetchImpl = fetch, snapshotProvider, now = () => Date.now(), stockSearch, trackingService }) {
  const getSnapshot = createSnapshotCache({ ...(snapshotProvider ? { provider: snapshotProvider } : {}), mode: config.mode, now });
  const searchStocks = stockSearch || createStockSearch({mode:config.mode,now});
  const tracking = trackingService || createTrackingService({config,store,getSnapshot,searchStocks,fetchImpl,now});
  return async function handle(request, { clientIp = 'local' } = {}) {
    const url = new URL(request.url);
    const route = url.pathname.replace(/\/$/, '');
    try {
      const origin = request.headers.get('Origin');
      if (origin && origin !== url.origin) throw error(403, 'Cross-origin requests are not allowed.');
      if (request.method === 'OPTIONS') return send({ error: 'Cross-origin access is not enabled.' }, 405);
      const workerRoute = route.startsWith('/api/worker/');
      let body = {};
      if (request.method === 'POST') {
        if (!request.headers.get('Content-Type')?.toLowerCase().startsWith('application/json')) throw error(415, 'Send JSON with Content-Type application/json.');
        const limit = workerRoute ? MAX_REPORT_BYTES + 65536 : 16384;
        if (Number(request.headers.get('Content-Length')) > limit) throw error(413, 'Request is too large.');
        const raw = await request.text();
        if (Buffer.byteLength(raw) > limit) throw error(413, 'Request is too large.');
        try { body = JSON.parse(raw); } catch { throw error(400, 'Request is not valid JSON.'); }
        if (!body || typeof body !== 'object' || Array.isArray(body)) throw error(400, 'Request must be a JSON object.');
      }
      const timestamp = now();
      const sessionInput = request.headers.get('X-Session-Token') || body.sessionToken;
      const ipKey = hash(clientIp);

      if (route === '/api/stocks/search' && request.method === 'GET') {
        let query;try { query=normalizeStockQuery(url.searchParams.get('q')||''); } catch { throw error(400,'Enter a stock code or name of up to 60 characters.'); }
        await store.transact(state=>rate(state,`stocks:${ipKey}`,120,timestamp));
        return send(await searchStocks(query));
      }
      if(route.startsWith('/api/tracking')){
        await store.transact(state=>rate(state,`tracking:${ipKey}`,180,timestamp));
        if(route==='/api/tracking/verify')await store.transact(state=>rate(state,`email-verify:${ipKey}`,3,timestamp));
        return send(await tracking.handle(route,request.method,body,sessionInput));
      }

      if (route === '/api/health' && request.method === 'GET') {
        const worker = await store.transact(state => { prune(state, timestamp); return workerStatus(state, config, timestamp); });
        return send({ ok: true, mode: config.mode, deepseekConfigured: !!config.deepseekKey, researchConfigured: config.workerSecret.length >= 32, selectedStockResearch: true, worker, templatesVersion: TEMPLATE_VERSION, alerts:tracking.capabilities() });
      }
      if (route === '/api/templates' && request.method === 'GET') {
        return send({ templates: TEMPLATES.map(({ researchPrompt, ...publicTemplate }) => publicTemplate), assets: ASSETS });
      }
      if (route === '/api/match' && request.method === 'POST') {
        const profile = validateProfile(body.profile);
        let match = createMatch(profile);
        const freshToken = token(), matchRequestId = randomUUID();
        const sessionToken = await store.transact(state => {
          prune(state, timestamp); rate(state, `match:${ipKey}`, config.matchRequestsPerHour, timestamp);
          let chosen = freshToken;
          if (typeof sessionInput === 'string' && sessionInput.length <= 256 && state.sessions[hash(sessionInput)]) chosen = sessionInput;
          state.sessions[hash(chosen)] = { ...state.sessions[hash(chosen)], createdAt: state.sessions[hash(chosen)]?.createdAt || timestamp, expiresAt: timestamp + 7 * 86400000, matchRequestId, matching: true };
          return chosen;
        });
        const candidateTemplates = TEMPLATES.filter(t => (match.candidateTemplateIds || [match.template.id]).includes(t.id)).map(t => {
          const candidate = createMatch({ ...profile, templateId: t.id });
          return { ...t, allocations: candidate.allocations, stress: candidate.stress, warnings: candidate.warnings };
        });
        const explanation = await explainMatch(match, config, fetchImpl, candidateTemplates);
        const requestedTemplateId = profile.templateId || null;
        let selectedTemplateId = match.template.id;
        let method = 'rules';
        if (!requestedTemplateId && explanation.suggestedTemplateId && candidateTemplates.some(t => t.id === explanation.suggestedTemplateId)) {
          selectedTemplateId = explanation.suggestedTemplateId;
          method = 'deepseek';
        }
        // A canonical selected-template snapshot makes the returned ID exactly
        // reproducible for authenticated follow-up calculations, even offline.
        match = createMatch({ ...profile, templateId: selectedTemplateId });
        match.selection = { method, requestedTemplateId, selectedTemplateId };
        delete explanation.suggestedTemplateId;
        await store.transact(state => {
          const session = state.sessions[hash(sessionToken)];
          if (!session || session.matchRequestId !== matchRequestId) throw error(409, 'A newer matching request replaced this one. Use the result from your latest request.');
          session.profileHash = hash(JSON.stringify(profile)); session.selectedTemplateId = selectedTemplateId; session.matchId = match.id; session.selection = match.selection; session.matching = false;
          session.trackingEligible=match.eligible;
          const followed=state.tracking?.[hash(sessionToken)];
          if(followed&&(!match.eligible||followed.schoolId!==selectedTemplateId||followed.profileHash!==session.profileHash)){followed.enabled=false;followed.status='profile_changed_review_required';}
        });
        return send({ match, explanation, sessionToken });
      }
      if (route === '/api/research' && request.method === 'POST') {
        if (config.workerSecret.length < 32) throw error(503, 'Research is not configured. Set WORKER_SECRET and start the local research worker.');
        const profile = validateProfile(body.profile);
        const selection = Object.hasOwn(body, 'researchSelection') ? validateResearchSelection(body.researchSelection) : null;
        // Authorize before a directory lookup, then release the store lock while
        // the external symbol catalog loads. Reauthorize against current state.
        let initial = null, selectedAssets = [];
        if (selection) {
          text(body.matchId, 100, 'confirmed match ID');
          initial = await store.transact(state => {
            prune(state, timestamp);
            const current = confirmedMatch(state, sessionInput, profile, body.matchId, timestamp);
            if (!current.match.eligible) throw error(422, 'This profile does not meet the investment strategy constraints. No research job was created.');
            rate(state, `research-symbols:${ipKey}`, 60, timestamp);
            return current;
          });
          selectedAssets = await Promise.all(selection.tickers.map(async ticker => {
            const maintained = ASSETS.find(asset => asset.ticker === ticker && asset.assetClass !== 'cash');
            if (maintained) return { ticker, name: maintained.name, assetClass: maintained.assetClass };
            let found;
            try { found = (await searchStocks(ticker, { limit: 12 }))?.results?.find(asset => asset.ticker === ticker); }
            catch { throw error(503, 'The stock directory is unavailable. Try a maintained stock or retry later.'); }
            if (!found || !['maintained', 'provider_catalog'].includes(found.identityStatus) || typeof found.name !== 'string' || !found.name.trim() || found.name.length > 255 || /[\p{Cc}\p{Cf}]/u.test(found.name)) throw error(422, `Could not verify ${ticker} in the available US stock directory. Search for the exact listing before requesting research.`);
            return { ticker, name: found.name.trim(), assetClass: found.etf === false ? 'stock' : found.etf === true ? 'etf' : ['stock', 'equity_stock', 'etf'].includes(found.assetClass) ? found.assetClass : 'unclassified' };
          }));
        }
        const id = randomUUID(), accessToken = token();
        const result = await store.transact(state => {
          const checkedAt = now();
          prune(state, checkedAt);
          const current = confirmedMatch(state, sessionInput, profile, body.matchId, checkedAt);
          if (initial && current.matchRequestId !== initial.matchRequestId) throw error(409, 'A newer strategy match replaced this research request. Review the latest plan and try again.');
          const { sessionHash } = current;
          const match = selection ? createSelectedResearchMatch(current.match, selection, selectedAssets) : current.match;
          if (!match.eligible) throw error(422, 'This profile does not meet the investment strategy constraints. No research job was created.');
          if (!workerStatus(state, config, checkedAt).online) throw error(503, 'The research computer is offline. Start the local worker; completed reports remain available.');
          const active = Object.values(state.jobs).filter(j => ['queued', 'running'].includes(j.status));
          if (active.length >= config.maxQueuedJobs) throw error(503, 'The research queue is full. Please try again after a task finishes.');
          if (active.some(j => j.sessionHash === sessionHash)) throw error(409, 'You already have an active research task. Wait for it to finish before submitting another.');
          if (Object.keys(state.jobs).length >= 100) throw error(503, 'Research storage is full. Ask the operator to export and archive old tasks.');
          rate(state, `research-ip:${ipKey}`, config.researchRequestsPerHour, checkedAt);
          rate(state, `research-session:${sessionHash}`, config.researchRequestsPerHour, checkedAt);
          const job = { id, status: 'queued', stage: 'Waiting for the research worker', createdAt: iso(checkedAt), updatedAt: iso(checkedAt), profile, match, sessionHash, accessHash: hash(accessToken), report: null, published: false };
          state.jobs[id] = job;
          return { job: publicJob(job), accessToken };
        });
        return send(result, 202);
      }
      if (route === '/api/short-plan' && request.method === 'POST') {
        const profile = validateProfile(body.profile);
        const matchId = text(body.matchId, 100, 'confirmed match ID');
        const supplied = request.headers.get('X-Session-Token');
        const confirmed = await store.transact(state => {
          prune(state, timestamp);
          const current = confirmedMatch(state, supplied, profile, matchId, timestamp);
          rate(state, `short-plan-ip:${ipKey}`, config.shortPlanRequestsPerHour || 12, timestamp);
          rate(state, `short-plan-session:${current.sessionHash}`, config.shortPlanRequestsPerHour || 12, timestamp);
          return current;
        });
        if (!confirmed.match.eligible) return send({ plan: createShortPlan(confirmed.match, null, { now: new Date(now()) }), marketStatus: { status: 'unavailable', cache: 'unavailable', cutoffDate: null, fetchedAt: null, coveredTickers: [], omittedTickers: [], warnings: ['No market request was made because this profile does not support an investment allocation.'] } });
        const holdings = confirmed.match.allocations.filter(a => a.ticker !== 'CASH' && a.weight > 0).sort((a, b) => b.weight - a.weight || a.ticker.localeCompare(b.ticker));
        const tickers = holdings.slice(0, 5).map(a => a.ticker), omittedTickers = holdings.slice(5).map(a => a.ticker);
        const { snapshot, cache } = await getSnapshot(tickers);
        snapshot.omittedTickers = omittedTickers;
        if (omittedTickers.length) snapshot.warnings.push(`Quick market evidence covers the five largest non-cash holdings. Not checked in this request: ${omittedTickers.join(', ')}.`);
        // A different questionnaire may have been matched while data was loading.
        await store.transact(state => {
          const latest = confirmedMatch(state, supplied, profile, matchId, now());
          if (latest.matchRequestId !== confirmed.matchRequestId) throw error(409, 'A newer strategy match replaced this plan request. Generate a plan for the latest match.');
        });
        const plan = createShortPlan(confirmed.match, snapshot, { now: new Date(now()) });
        return send({ plan, marketStatus: { status: snapshot.status, cache, cutoffDate: snapshot.cutoffDate, fetchedAt: snapshot.fetchedAt, coveredTickers: snapshot.snapshots.filter(row => row.status === 'complete').map(row => row.ticker), omittedTickers, warnings: snapshot.warnings } });
      }
      const jobRoute = route.match(/^\/api\/research\/([a-zA-Z0-9-]+)$/);
      if (jobRoute && request.method === 'GET') {
        const supplied = request.headers.get('X-Report-Token');
        const result = await store.transact(state => {
          prune(state, timestamp);
          const job = state.jobs[jobRoute[1]];
          if (!job || !supplied || supplied.length > 256 || !sameSecret(hash(supplied), job.accessHash)) throw error(404, 'Report not found or access token is invalid.');
          return { job: publicJob(job), report: job.report, worker: workerStatus(state, config, timestamp) };
        });
        return send(result);
      }
      if (route === '/api/examples' && request.method === 'GET') {
        return send(await store.transact(state => ({ reports: Object.values(state.jobs).filter(j => j.published && j.report).map(j => ({ id: j.id, title: j.report.title, generatedAt: j.report.generatedAt, profileSummary: { goal: j.profile.goal, budget: j.profile.budget, horizon: j.profile.horizon } })) })));
      }
      const exampleRoute = route.match(/^\/api\/examples\/([a-zA-Z0-9-]+)$/);
      if (exampleRoute && request.method === 'GET') {
        return send(await store.transact(state => {
          const job = state.jobs[exampleRoute[1]];
          if (!job?.published || !job.report) throw error(404, 'Published report not found.');
          return { report: job.report };
        }));
      }
      if (workerRoute && request.method === 'POST') {
        const auth = request.headers.get('Authorization') || '';
        if (config.workerSecret.length < 32 || !auth.startsWith('Bearer ') || !sameSecret(auth.slice(7), config.workerSecret)) throw error(401, 'Worker authentication failed.');
        const workerId = text(body.workerId, 100, 'worker ID');
        if (!/^[a-zA-Z0-9_.-]+$/.test(workerId) || ['__proto__', 'constructor', 'prototype'].includes(workerId)) throw error(400, 'Worker ID contains invalid characters.');
        return send(await store.transact(state => {
          prune(state, timestamp);
          if (route === '/api/worker/heartbeat') {
            state.workers[workerId] = { lastSeen: timestamp };
            if (body.jobId) {
              const job = state.jobs[body.jobId];
              if (job?.status === 'running' && job.workerId === workerId && job.leaseExpiresAt > timestamp) job.leaseExpiresAt = timestamp + config.leaseMs;
            }
            return { ok: true };
          }
          if (route === '/api/worker/claim') {
            state.workers[workerId] = { lastSeen: timestamp };
            // One research task at a time across the local worker fleet in v1.
            if (Object.values(state.jobs).some(j => j.status === 'running')) return { job: null };
            const job = Object.values(state.jobs).filter(j => j.status === 'queued').sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
            if (!job) return { job: null };
            job.status = 'running'; job.stage = 'Starting TradingAgents'; job.updatedAt = iso(timestamp);
            job.workerId = workerId; job.leaseToken = token(); job.leaseExpiresAt = timestamp + config.leaseMs;
            return { job: { id: job.id, profile: job.profile, match: job.match, createdAt: job.createdAt, leaseToken: job.leaseToken } };
          }
          if (route === '/api/worker/progress') {
            const job = requireLease(state, body, timestamp);
            job.stage = text(body.stage, 300, 'progress stage'); job.updatedAt = iso(timestamp); job.leaseExpiresAt = timestamp + config.leaseMs;
            state.workers[workerId] = { lastSeen: timestamp };
            return { ok: true };
          }
          if (route === '/api/worker/complete') {
            const job = requireLease(state, body, timestamp, true);
            if (['complete', 'partial'].includes(job.status)) return { ok: true };
            job.report = validateReport(body.report, job); job.status = job.report.status;
            job.stage = job.status === 'partial' ? 'Report ready with unavailable sections' : 'Report ready'; job.updatedAt = iso(timestamp);
            return { ok: true };
          }
          if (route === '/api/worker/fail') {
            const job = requireLease(state, body, timestamp);
            job.status = 'failed'; job.error = text(body.error, 1500, 'error'); job.stage = 'Research failed'; job.updatedAt = iso(timestamp);
            return { ok: true };
          }
          throw error(404, 'API endpoint not found.');
        }));
      }
      throw error(404, 'API endpoint not found.');
    } catch (problem) {
      const status = Number.isInteger(problem.status) ? problem.status : 500;
      // Provider/database exception bodies can contain credentials: never echo or log them.
      return send({ error: status < 500 || problem.status ? problem.message : 'The server could not complete this request. Check the local service and configuration.' }, status, status === 429 ? { 'Retry-After': '3600' } : {});
    }
  };
}
