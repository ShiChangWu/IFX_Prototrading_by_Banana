import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { APP_DIR, loadLocalEnv, configuration } from './config.mjs';
import { createStore } from './store.mjs';
import { createApi } from './api.mjs';
import { clearStaleLocalLock } from './lock.mjs';
import { createSnapshotCache } from './market-snapshot.mjs';
import { createStockSearch } from './stock-search.mjs';
import { createTrackingService } from './tracking.mjs';

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
const inside = (base, file) => file === base || file.startsWith(base + path.sep);

export function localServer(config, { store = createStore(config), fetchImpl = fetch } = {}) {
  const searchStocks=createStockSearch({mode:config.mode});
  const tracking=createTrackingService({config,store,fetchImpl,searchStocks,getSnapshot:createSnapshotCache({mode:config.mode})});
  const api = createApi({ config, store, fetchImpl, stockSearch:searchStocks, trackingService:tracking });
  const server = http.createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'no-referrer');
    try {
      const host = String(req.headers.host || '');
      if (!new RegExp(`^(127\\.0\\.0\\.1|localhost):${config.port}$`).test(host)) { res.writeHead(403); res.end('This local server only accepts loopback hostnames.'); return; }
      const url = new URL(req.url, `http://${host}`);
      if (url.pathname.startsWith('/api/')) {
        const chunks = []; let size = 0;
        const limit = url.pathname.startsWith('/api/worker/') ? 2 * 1024 * 1024 + 65536 : 16384;
        for await (const chunk of req) {
          size += chunk.length;
          if (size > limit) { res.writeHead(413, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: 'Request is too large.' })); return; }
          chunks.push(chunk);
        }
        const request = new Request(url, { method: req.method, headers: req.headers, ...(chunks.length ? { body: Buffer.concat(chunks) } : {}) });
        const response = await api(request, { clientIp: req.socket.remoteAddress || 'local' });
        res.writeHead(response.status, Object.fromEntries(response.headers)); res.end(Buffer.from(await response.arrayBuffer())); return;
      }
      if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end('Method not allowed'); return; }
      let pathname;
      try { pathname = decodeURIComponent(url.pathname); } catch { res.writeHead(400); res.end('Invalid path'); return; }
      if (pathname.includes('\0') || pathname.includes('\\') || pathname.split('/').some(v => v.startsWith('.'))) { res.writeHead(404); res.end('Not found'); return; }
      let root;
      try { await fs.access(path.join(APP_DIR, 'dist', 'index.html')); root = path.join(APP_DIR, 'dist'); }
      catch { root = path.join(APP_DIR, 'public'); }
      let file = path.resolve(root, '.' + (pathname === '/' ? '/index.html' : pathname));
      // The shared browser module is explicitly public; server and local settings are not.
      if (['/shared/strategy.mjs', '/shared/templates.mjs', '/shared/short-plan.mjs', '/shared/report-import.mjs', '/shared/company-facts.mjs', '/shared/report-guide.mjs', '/shared/school-backtest.mjs', '/shared/school-prices.mjs', '/shared/selected-plan.mjs', '/shared/school-fit.mjs', '/shared/school-scenarios.mjs'].includes(pathname)) { root = path.join(APP_DIR, 'shared'); file = path.join(root, path.basename(pathname)); }
      if (!inside(root, file)) { res.writeHead(404); res.end('Not found'); return; }
      let realFile;
      try { realFile = await fs.realpath(file); if (!inside(await fs.realpath(root), realFile)) throw new Error('Outside public directory'); }
      catch { res.writeHead(404); res.end('Not found'); return; }
      const stats = await fs.stat(realFile);
      if (!stats.isFile()) { res.writeHead(404); res.end('Not found'); return; }
      res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache', 'Content-Security-Policy': "frame-ancestors 'self'; base-uri 'self'; object-src 'none'" });
      res.end(req.method === 'HEAD' ? undefined : await fs.readFile(realFile));
    } catch { if (!res.headersSent) res.writeHead(500); res.end('The local server could not complete this request.'); }
  });
  let timer;
  server.once('listening',()=>{if(config.mode==='local'){timer=setInterval(()=>{void tracking.tick().catch(()=>{});},(config.alertIntervalSeconds||60)*1000);timer.unref();void tracking.tick().catch(()=>{});}});
  server.once('close',()=>clearInterval(timer));
  return server;
}

async function start() {
  loadLocalEnv();
  const config = configuration();
  // A single local server owns the file store; two writers must not overwrite it.
  await fs.mkdir(path.dirname(config.storeFile), { recursive: true, mode: 0o700 });
  const lock = config.storeFile + '.lock';
  await clearStaleLocalLock(lock);
  await fs.writeFile(lock, String(process.pid), { flag: 'wx', mode: 0o600 });
  const server = localServer(config);
  const stop = async () => { server.close(); await fs.rm(lock, { force: true }); process.exit(0); };
  process.once('SIGINT', stop); process.once('SIGTERM', stop);
  server.once('error', async () => { await fs.rm(lock, { force: true }); console.error('Unable to start the local server. Check the configured port.'); process.exitCode = 1; });
  server.listen(config.port, '127.0.0.1', () => {
    console.log(`Proto-Trading local website: http://127.0.0.1:${config.port}`);
    console.log(`DeepSeek: ${config.deepseekKey ? 'configured' : 'not configured — rules available'}; research worker: ${config.workerSecret.length >= 32 ? 'credentials configured' : 'not configured'}.`);
  });
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  start().catch(problem => { console.error(problem.message.includes('already owns') ? problem.message : 'Unable to start. Check local configuration and persistent storage.'); process.exitCode = 1; });
}
