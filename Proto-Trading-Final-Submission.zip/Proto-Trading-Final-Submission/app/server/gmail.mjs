import path from 'node:path';
import { spawn } from 'node:child_process';
import { createHash } from 'node:crypto';
import { APP_DIR } from './config.mjs';
import { stopOwnedMarketProcess } from './market-snapshot.mjs';

export const validEmailAddress = value => typeof value === 'string' && value.length <= 254 && /^[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/.test(value) && value.split('@')[0].length <= 64 && !value.split('@')[0].startsWith('.') && !value.split('@')[0].endsWith('.') && !value.split('@')[0].includes('..');
const messageId = id => `<proto.${createHash('sha256').update(id).digest('hex')}@proto-trading.local>`;
function childEnvironment(env) {
  const allow = new Set(['PATH', 'PATHEXT', 'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'USERPROFILE', 'LOCALAPPDATA', 'APPDATA', 'COMSPEC', 'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE']);
  return { ...Object.fromEntries(Object.entries(env).filter(([key, value]) => allow.has(key.toUpperCase()) && typeof value === 'string')), PYTHONUTF8: '1', PYTHONUNBUFFERED: '1' };
}

// Authentication, recipient and message content pass only through stdin.
// A lost acknowledgement is uncertain: callers must NOT automatically retry it.
export async function sendPlainEmail(message, config, { spawnImpl = spawn, appDir = APP_DIR, env = process.env, timeoutMs = 25000 } = {}) {
  const password = typeof config?.gmailAppPassword === 'string' ? config.gmailAppPassword.replace(/ /g, '') : '';
  if (!validEmailAddress(config?.gmailUser) || !/^[A-Za-z0-9]{16}$/.test(password)) return { status: 'unavailable', code: 'GMAIL_NOT_CONFIGURED' };
  if (!message || !validEmailAddress(message.to) || typeof message.id !== 'string' || message.id.length < 1 || message.id.length > 160 || /[\r\n\u0000]/.test(message.id) || typeof message.subject !== 'string' || !message.subject.trim() || message.subject.length > 180 || /[\u0000-\u001f\u007f]/.test(message.subject) || typeof message.text !== 'string' || !message.text.trim() || Buffer.byteLength(message.text) > 48000 || message.text.includes('\u0000')) return { status: 'failed', code: 'INVALID_EMAIL' };
  const id = messageId(message.id), payload = { user: config.gmailUser, password, to: message.to, subject: message.subject, text: message.text, messageId: id };
  const encoded = JSON.stringify(payload);
  if (Buffer.byteLength(encoded) > 65536) return { status: 'failed', code: 'INVALID_EMAIL' };
  return new Promise(resolve => {
    let child, timer, settled = false, bytes = 0, errorBytes = 0, inputStarted = false; const chunks = [];
    const finish = value => { if (settled) return; settled = true; clearTimeout(timer); resolve({ ...value, messageId: id }); };
    const stop = code => { if (settled) return; finish({ status: inputStarted ? 'uncertain' : 'failed', code }); void stopOwnedMarketProcess(child, { spawnImpl, env }); };
    try {
      const python = path.join(appDir, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
      child = spawnImpl(python, ['-m', 'worker.send_gmail'], { cwd: appDir, shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'], env: childEnvironment(env) });
      timer = setTimeout(() => stop('GMAIL_TIMEOUT'), Math.max(1, Math.min(timeoutMs, 30000)));
      child.on('error', () => finish({ status: 'failed', code: 'GMAIL_ADAPTER_UNAVAILABLE' }));
      child.stdout.on('data', chunk => { if (settled) return; bytes += chunk.length; if (bytes > 4096) { stop('GMAIL_INVALID_RESPONSE'); return; } chunks.push(Buffer.from(chunk)); });
      child.stderr.on('data', chunk => { errorBytes += chunk.length; if (errorBytes > 4096) stop('GMAIL_INVALID_RESPONSE'); });
      child.on('close', code => {
        if (settled) return;
        if (code !== 0) { finish({ status: inputStarted ? 'uncertain' : 'failed', code: 'GMAIL_ADAPTER_FAILED' }); return; }
        try {
          const result = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          const permitted = { accepted: ['SMTP_ACCEPTED'], unavailable: ['GMAIL_NOT_CONFIGURED'], failed: ['INVALID_EMAIL', 'SMTP_AUTH_FAILED', 'SMTP_REJECTED', 'SMTP_CONNECT_FAILED'], uncertain: ['SMTP_OUTCOME_UNKNOWN'] };
          if (!permitted[result?.status]?.includes(result.code)) throw new Error();
          finish({ status: result.status, code: result.code });
        } catch { finish({ status: 'uncertain', code: 'GMAIL_INVALID_RESPONSE' }); }
      });
      child.stdin.on('error', () => stop('GMAIL_INPUT_FAILED'));
      inputStarted = true;
      child.stdin.end(encoded);
    } catch { finish({ status: inputStarted ? 'uncertain' : 'failed', code: 'GMAIL_ADAPTER_UNAVAILABLE' }); }
  });
}
