import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const APP_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// Parse values as data. Never evaluate shell syntax or print secret values.
export function loadLocalEnv(file = path.join(APP_DIR, '.env.local'), target = process.env) {
  if (!fs.existsSync(file)) return target;
  for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
    const item = line.match(/^\s*([A-Z][A-Z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!item || target[item[1]] !== undefined) continue;
    let value = item[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    else value = value.replace(/\s+#.*$/, '');
    target[item[1]] = value;
  }
  return target;
}

export function configuration(env = process.env, { mode = 'local' } = {}) {
  const integer = (key, fallback, max) => Math.min(max, Math.max(1, Number.parseInt(env[key], 10) || fallback));
  const deepseekBase = env.DEEPSEEK_BASE_URL || 'https://api.deepseek.com';
  const providerUrl = new URL(deepseekBase);
  if (providerUrl.protocol !== 'https:' || providerUrl.username || providerUrl.password || providerUrl.search || providerUrl.hash) throw new Error('DEEPSEEK_BASE_URL must be a clean HTTPS URL.');
  const alertBaseUrl = (env.ALERT_BASE_URL || `http://127.0.0.1:${integer('PORT',8787,65535)}`).replace(/\/+$/, '');
  const alertUrl = new URL(alertBaseUrl);
  if ((alertUrl.protocol !== 'https:' && !(alertUrl.protocol === 'http:' && ['localhost','127.0.0.1'].includes(alertUrl.hostname))) || alertUrl.username || alertUrl.password || alertUrl.search || alertUrl.hash || alertUrl.pathname !== '/') throw new Error('ALERT_BASE_URL must be an HTTPS site origin or a local HTTP origin.');
  if (env.ALPACA_DATA_FEED && !['iex','sip'].includes(env.ALPACA_DATA_FEED)) throw new Error('ALPACA_DATA_FEED must be iex or sip.');
  if(env.INTRADAY_PROVIDER&&!['yahoo','alpaca'].includes(env.INTRADAY_PROVIDER))throw new Error('INTRADAY_PROVIDER must be yahoo or alpaca.');
  return {
    mode, port: integer('PORT', 8787, 65535),
    deepseekKey: env.DEEPSEEK_API_KEY || '', deepseekModel: env.DEEPSEEK_MODEL || 'deepseek-flash',
    deepseekBase: deepseekBase.replace(/\/+$/, ''), deepseekTimeoutMs: integer('DEEPSEEK_TIMEOUT_MS', 45000, 55000),
    workerSecret: env.WORKER_SECRET || '',
    gmailUser: env.GMAIL_USER || '', gmailAppPassword: env.GMAIL_APP_PASSWORD || '',
    emailDeliveryEnabled: env.EMAIL_DELIVERY_ENABLED === 'true', intradayProvider:env.INTRADAY_PROVIDER||'yahoo',
    alpacaKey: env.ALPACA_API_KEY || '', alpacaSecret: env.ALPACA_API_SECRET || '', alpacaFeed: env.ALPACA_DATA_FEED || 'iex',
    alertBaseUrl, alertIntervalSeconds: Math.max(30, integer('ALERT_INTERVAL_SECONDS', 60, 900)),
    supabaseUrl: env.SUPABASE_URL || '', supabaseKey: env.SUPABASE_SERVICE_ROLE_KEY || '',
    storeFile: path.resolve(env.LOCAL_STORE_PATH || path.join(APP_DIR, '.local', 'state.json')),
    maxQueuedJobs: integer('MAX_QUEUED_JOBS', 10, 50),
    matchRequestsPerHour: integer('MATCH_REQUESTS_PER_HOUR', 20, 1000),
    researchRequestsPerHour: integer('RESEARCH_REQUESTS_PER_HOUR', 2, 100),
    shortPlanRequestsPerHour: integer('SHORT_PLAN_REQUESTS_PER_HOUR', 12, 100),
    workerStaleMs: 90000, leaseMs: 120000,
  };
}
