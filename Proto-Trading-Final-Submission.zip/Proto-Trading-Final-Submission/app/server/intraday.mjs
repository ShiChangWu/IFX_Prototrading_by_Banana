// Market-data reads only. Never place orders or read account balances.
// https://docs.alpaca.markets/us/v1.4.2/reference/stocklatestbars-1
// https://docs.alpaca.markets/us/v1.1/reference/getclock-1
const DATA_URL = 'https://data.alpaca.markets/v2/stocks/bars/latest';
const PAPER_URL = 'https://paper-api.alpaca.markets/v2';
const SYMBOL = /^[A-Z][A-Z0-9.-]{0,9}$/;
const eastern = new Intl.DateTimeFormat('en-US', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
const finite = value => typeof value === 'number' && Number.isFinite(value);
const millis = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value) ? Date.parse(value) : NaN;
const clockNow = now => typeof now === 'function' ? now() : now ?? Date.now();
const configured = config => ['alpacaKey', 'alpacaSecret'].every(key => typeof config?.[key] === 'string' && /^[\x21-\x7e]{1,300}$/.test(config[key]));

function sessionParts(time) {
  const parts = Object.fromEntries(eastern.formatToParts(new Date(time)).map(part => [part.type, part.value]));
  return { day: `${parts.year}-${parts.month}-${parts.day}`, minute: Number(parts.hour) * 60 + Number(parts.minute), weekday: parts.weekday };
}
function inRegularWindow(time) {
  const part = sessionParts(time);
  return !['Sat', 'Sun'].includes(part.weekday) && part.minute >= 570 && part.minute < 960;
}
function providerError(code) { const error = new Error(code); error.code = code; return error; }
async function fetchJson(url, config, fetchImpl, signal) {
  const response = await fetchImpl(url, { method: 'GET', redirect: 'error', signal, headers: { accept: 'application/json', 'APCA-API-KEY-ID': config.alpacaKey, 'APCA-API-SECRET-KEY': config.alpacaSecret } });
  if (!response.ok) throw providerError([401, 403].includes(response.status) ? 'ALPACA_ACCESS_DENIED' : response.status === 404 ? 'ASSET_NOT_FOUND' : response.status === 429 ? 'ALPACA_RATE_LIMIT' : 'ALPACA_UNAVAILABLE');
  const limit = 128 * 1024;
  if (Number(response.headers?.get('content-length')) > limit) throw providerError('ALPACA_RESPONSE_LIMIT');
  let text = '';
  if (response.body?.getReader) {
    const reader = response.body.getReader(), chunks = []; let count = 0;
    try {
      for (;;) {
        const { done, value } = await reader.read(); if (done) break;
        count += value.byteLength;
        if (count > limit) { await reader.cancel(); throw providerError('ALPACA_RESPONSE_LIMIT'); }
        chunks.push(Buffer.from(value));
      }
      text = Buffer.concat(chunks).toString('utf8');
    } finally { reader.releaseLock(); }
  } else {
    text = await response.text();
    if (Buffer.byteLength(text) > limit) throw providerError('ALPACA_RESPONSE_LIMIT');
  }
  try { return JSON.parse(text); } catch { throw providerError('ALPACA_INVALID_RESPONSE'); }
}
function problem(code) {
  return { status: 'unavailable', code, message: ({
    ALPACA_NOT_CONFIGURED: 'Connect Alpaca market-data credentials to enable intraday checks.',
    ALPACA_ACCESS_DENIED: 'Alpaca access was denied. Check the key and selected data-feed entitlement.',
    MARKET_CLOSED: 'The regular US stock session is closed. No intraday alert was evaluated.',
    INVALID_MARKET_CLOCK: 'The current US market session could not be verified.',
    STALE_BAR: 'The latest completed minute bar is over five minutes old.',
    INCOMPLETE_BAR: 'The provider returned an unfinished or future minute bar.',
    OUTSIDE_SESSION: 'The minute bar is outside the current regular US session.',
    MISSING_BAR: 'No minute bar was supplied for this ticker.',
    INVALID_BAR: 'The minute bar failed price or timestamp validation.',
    ASSET_NOT_FOUND: 'This ticker was not found in the connected US asset registry.',
    UNSUPPORTED_ASSET: 'This ticker is not a verified active, tradable US exchange-listed equity or ETF.',
  })[code] || 'The intraday data request could not be verified. No price was substituted.' };
}

export function validateMinuteBar(bar, { ticker, now = Date.now(), nextClose, feed = 'iex' }) {
  const time = millis(bar?.t), end = time + 60000;
  if (!Number.isFinite(time) || time % 60000 !== 0 || !['o', 'h', 'l', 'c'].every(key => finite(bar[key]) && bar[key] > 0) || !finite(bar.v) || bar.v <= 0 || bar.l > Math.min(bar.o, bar.c) || bar.h < Math.max(bar.o, bar.c) || bar.h < bar.l) return { ticker, ...problem('INVALID_BAR') };
  if (end > now) return { ticker, ...problem('INCOMPLETE_BAR') };
  if (now - end > 300000) return { ticker, ...problem('STALE_BAR') };
  if (!inRegularWindow(time) || sessionParts(time).day !== sessionParts(now).day || (Number.isFinite(nextClose) && end > nextClose)) return { ticker, ...problem('OUTSIDE_SESSION') };
  return { ticker, status: 'complete', price: bar.c, open: bar.o, high: bar.h, low: bar.l, close: bar.c, volume: bar.v, barTime: new Date(time).toISOString(), barEnd: new Date(end).toISOString(), currency: 'USD', source: 'Alpaca', feed, timeframe: '1Min', priceBasis: 'Raw trade prices; completed minute bar', fetchedAt: new Date(now).toISOString() };
}

export async function getIntradayQuotes(tickers, config, { fetchImpl = fetch, now = Date.now, timeoutMs = 10000 } = {}) {
  if (!Array.isArray(tickers) || tickers.length > 50 || tickers.some(ticker => typeof ticker !== 'string' || !SYMBOL.test(ticker)) || new Set(tickers).size !== tickers.length) throw new Error('Request up to 50 unique US ticker symbols.');
  const time = clockNow(now), feed = config?.alpacaFeed || 'iex';
  if (!finite(time)) throw new Error('Invalid current time.');
  const base = { source: 'Alpaca', feed, fetchedAt: new Date(time).toISOString(), warnings: feed === 'iex' ? ['IEX covers one exchange, not the consolidated US market. Sparse trading can prevent a fresh minute bar.'] : [] };
  const fail = code => ({ ...base, ...problem(code), quotes: Object.fromEntries(tickers.map(ticker => [ticker, { ticker, ...problem(code) }])) });
  if (!tickers.length) return { ...base, status: 'complete', quotes: {} };
  if (!configured(config)) return fail('ALPACA_NOT_CONFIGURED');
  if (!['iex', 'sip'].includes(feed)) return fail('INVALID_FEED');
  if (!inRegularWindow(time)) return fail('MARKET_CLOSED');
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), Math.max(1, Math.min(timeoutMs, 15000)));
  try {
    const market = await fetchJson(`${PAPER_URL}/clock`, config, fetchImpl, controller.signal);
    if (!market || typeof market.is_open !== 'boolean' || !Number.isFinite(millis(market.timestamp)) || Math.abs(millis(market.timestamp) - time) > 90000) return fail('INVALID_MARKET_CLOCK');
    if (!market.is_open) return fail('MARKET_CLOSED');
    const nextClose = millis(market.next_close);
    if (!Number.isFinite(nextClose) || nextClose <= time || sessionParts(nextClose).day !== sessionParts(time).day) return fail('INVALID_MARKET_CLOCK');
    const url = new URL(DATA_URL); url.searchParams.set('symbols', tickers.join(',')); url.searchParams.set('feed', feed); url.searchParams.set('currency', 'USD');
    const response = await fetchJson(url.href, config, fetchImpl, controller.signal);
    if (!response?.bars || typeof response.bars !== 'object' || Array.isArray(response.bars)) return fail('ALPACA_INVALID_RESPONSE');
    const quotes = Object.fromEntries(tickers.map(ticker => [ticker, Object.hasOwn(response.bars, ticker) ? validateMinuteBar(response.bars[ticker], { ticker, now: time, nextClose, feed }) : { ticker, ...problem('MISSING_BAR') }]));
    const count = Object.values(quotes).filter(row => row.status === 'complete').length;
    return { ...base, status: count === tickers.length ? 'complete' : count ? 'partial' : 'unavailable', marketOpen: true, quotes };
  } catch (error) { return fail(typeof error?.code === 'string' && error.code.startsWith('ALPACA_') ? error.code : 'ALPACA_UNAVAILABLE'); }
  finally { clearTimeout(timer); }
}

export async function getAlpacaAsset(ticker, config, { fetchImpl = fetch, now = Date.now, timeoutMs = 10000 } = {}) {
  if (typeof ticker !== 'string' || !SYMBOL.test(ticker)) return { ticker: '', ...problem('UNSUPPORTED_ASSET') };
  if (!configured(config)) return { ticker, ...problem('ALPACA_NOT_CONFIGURED') };
  const controller = new AbortController(), timer = setTimeout(() => controller.abort(), Math.max(1, Math.min(timeoutMs, 15000)));
  try {
    const asset = await fetchJson(`${PAPER_URL}/assets/${encodeURIComponent(ticker)}`, config, fetchImpl, controller.signal);
    if (!asset || asset.symbol !== ticker || asset.class !== 'us_equity' || asset.status !== 'active' || asset.tradable !== true || !['NYSE', 'NASDAQ', 'ARCA', 'AMEX', 'BATS', 'NYSEARCA', 'NYSEAMERICAN'].includes(asset.exchange) || typeof asset.name !== 'string' || !asset.name.trim() || asset.name.length > 300 || /[\u0000-\u001f\u007f]/.test(asset.name)) return { ticker, ...problem('UNSUPPORTED_ASSET') };
    return { ticker, status: 'complete', name: asset.name, assetClass: 'us_equity', exchange: asset.exchange, tradable: true, source: 'Alpaca asset registry', fetchedAt: new Date(clockNow(now)).toISOString() };
  } catch (error) { return { ticker, ...problem(['ASSET_NOT_FOUND', 'ALPACA_ACCESS_DENIED', 'ALPACA_RATE_LIMIT'].includes(error?.code) ? error.code : 'ALPACA_UNAVAILABLE') }; }
  finally { clearTimeout(timer); }
}
