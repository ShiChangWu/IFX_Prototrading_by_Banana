import fs from 'node:fs/promises';
import path from 'node:path';
import { loadLocalEnv, configuration } from './config.mjs';
import { createStore } from './store.mjs';
import { clearStaleLocalLock } from './lock.mjs';

// Explicit operator action only. Publication exposes the exact questionnaire and
// report: obtain the person's permission before publishing someone else's data.
loadLocalEnv();
const config = configuration(process.env, { mode: process.env.REPORT_STORE_MODE === 'cloud' ? 'cloud' : 'local' });
const [action, id, destination] = process.argv.slice(2);
const store = createStore(config);
const readOnly = action => config.mode === 'local' ? store.read().then(action) : store.transact(action);
try {
  if (action === 'list') {
    const rows = await readOnly(state => Object.values(state.jobs).map(j => ({ id: j.id, status: j.status, published: j.published, createdAt: j.createdAt })));
    console.log(JSON.stringify(rows, null, 2));
  } else if (action === 'export' && id && destination) {
    const report = await readOnly(state => { if (!state.jobs[id]?.report) throw new Error('Completed report not found.'); return state.jobs[id].report; });
    await fs.writeFile(path.resolve(destination), JSON.stringify(report, null, 2), { flag: 'wx', mode: 0o600 });
    console.log('Completed report exported.');
  } else if (['publish', 'unpublish'].includes(action) && id) {
    if (config.mode === 'local') {
      await clearStaleLocalLock(config.storeFile + '.lock');
    }
    await store.transact(state => {
      const job = state.jobs[id];
      if (!job?.report || !['complete', 'partial'].includes(job.status)) throw new Error('A completed real research report is required.');
      if (action === 'publish' && !job.report.research.some(r => r.status === 'complete')) throw new Error('At least one actual completed TradingAgents analysis is required to publish an example.');
      job.published = action === 'publish';
    });
    console.log(action === 'publish' ? 'Report is now a public example, including its input profile.' : 'Report removed from public examples.');
  } else throw new Error('Usage: node server/reports.mjs list | export JOB_ID NEW_FILE | publish JOB_ID | unpublish JOB_ID');
} catch (problem) { console.error(problem.message); process.exitCode = 1; }
