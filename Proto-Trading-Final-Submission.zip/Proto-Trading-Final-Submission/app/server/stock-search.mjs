import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { APP_DIR } from './config.mjs';
import { stopOwnedMarketProcess } from './market-snapshot.mjs';
import { ASSETS } from '../shared/strategy.mjs';

const SOURCE = { name: 'EastMoney security catalog via AKShare', url: 'https://akshare.akfamily.xyz/data/stock/stock.html' };
const NASDAQ_URL = 'https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqtraded.txt';
const NASDAQ_SOURCE = { name: 'Nasdaq Trader directory; AKShare unavailable', url: NASDAQ_URL };
const MAX_BYTES = 6000000;
const MAX_ROWS = 30000;
const TICKER = /^[A-Z][A-Z0-9.-]{0,11}$/;
const DAY = 86400000;

export function normalizeStockQuery(value) {
  if (typeof value !== 'string') throw new Error('Enter a ticker or company name.');
  const query = value.trim();
  if (query.length > 60 || /[\p{Cc}\p{Cf}]/u.test(query)) throw new Error('Search text must be at most 60 characters without control characters.');
  return query;
}

export function validateStockCatalog(input, now = Date.now()) {
  if (input?.status !== 'complete' || input.version !== 1 || !['all_us', 'well_known_us', 'nasdaq_traded_us'].includes(input.scope) || !Array.isArray(input.rows) || !input.rows.length || input.rows.length > MAX_ROWS || typeof input.fetchedAt !== 'string' || !Number.isFinite(Date.parse(input.fetchedAt)) || Date.parse(input.fetchedAt) > now + 300000 || Date.parse(input.fetchedAt) < now - 30 * DAY) throw new Error('Invalid stock catalog.');
  const nasdaq = input.provider === 'nasdaqtrader';
  if (nasdaq !== (input.scope === 'nasdaq_traded_us')) throw new Error('Invalid catalog source.');
  if (nasdaq && (!/^\d{4}-\d{2}-\d{2}$/.test(input.directoryDate) || !Number.isFinite(Date.parse(input.directoryDate)) || new Date(input.directoryDate).toISOString().slice(0, 10) !== input.directoryDate || Date.parse(input.directoryDate) > now + DAY || Date.parse(input.directoryDate) < now - 30 * DAY)) throw new Error('Invalid directory date.');
  const seen = new Set();
  const rows = input.rows.map(row => {
    const validCode = typeof row?.providerSymbol === 'string' && (nasdaq ? row.providerSymbol === row.ticker : /^(105|106|107)\./.test(row.providerSymbol) && row.providerSymbol.slice(4) === row.ticker);
    if (!row || !TICKER.test(row.ticker) || seen.has(row.ticker) || typeof row.name !== 'string' || !row.name.trim() || row.name.length > 255 || /[\p{Cc}\p{Cf}]/u.test(row.name) || !validCode || (row.ticker === 'SPCX' && !/space\s*(?:x|exploration)/i.test(row.name))) throw new Error('Invalid or ambiguous stock identity.');
    seen.add(row.ticker);
    const base = { ticker: row.ticker, name: row.name.trim(), providerSymbol: row.providerSymbol };
    if (!nasdaq) return base;
    if (row.nasdaqTraded !== true || row.testIssue !== false || typeof row.etf !== 'boolean' || typeof row.nextShares !== 'boolean' || !/^[A-Z]$/.test(row.listingExchange) || !['', 'Q', 'G', 'S'].includes(row.marketCategory) || !Number.isInteger(row.roundLotSize) || row.roundLotSize <= 0 || row.roundLotSize > 1000000 || !['', 'N', 'D', 'E', 'Q', 'G', 'H', 'J', 'K', 'C'].includes(row.financialStatus) || !['cqsSymbol', 'nasdaqSymbol'].every(key => typeof row[key] === 'string' && row[key].length <= 14 && !/[\p{Cc}\p{Cf}]/u.test(row[key]))) throw new Error('Invalid Nasdaq security metadata.');
    return { ...base, nasdaqTraded: true, testIssue: false, etf: row.etf, listingExchange: row.listingExchange, marketCategory: row.marketCategory, roundLotSize: row.roundLotSize, financialStatus: row.financialStatus, cqsSymbol: row.cqsSymbol, nasdaqSymbol: row.nasdaqSymbol, nextShares: row.nextShares };
  });
  return { version: 1, status: 'complete', scope: input.scope, fetchedAt: input.fetchedAt, source: nasdaq ? NASDAQ_SOURCE : SOURCE, ...(nasdaq ? { provider: 'nasdaqtrader', directoryDate: input.directoryDate } : {}), rows };
}

// Public format: https://www.nasdaqtrader.com/TraderNews.aspx?id=ETA2016-36
// Field definitions: https://www.nasdaqtrader.com/Trader.aspx?id=SymbolDirDefs
export function parseNasdaqDirectory(text, now = Date.now()) {
  if (typeof text !== 'string' || Buffer.byteLength(text, 'utf8') > 3000000) throw new Error('Directory exceeds its size limit.');
  const lines = text.replace(/^\uFEFF/, '').trim().split(/\r?\n/);
  const columns = 'Nasdaq Traded|Symbol|Security Name|Listing Exchange|Market Category|ETF|Round Lot Size|Test Issue|Financial Status|CQS Symbol|NASDAQ Symbol|NextShares';
  if (lines[0] !== columns || lines.length > MAX_ROWS + 2) throw new Error('Unexpected Nasdaq directory format.');
  const footer = lines.at(-1).match(/^File Creation Time:\s*(\d{2})(\d{2})(\d{4})(\d{2}):?(\d{2})\|/);
  if (!footer || +footer[4] > 23 || +footer[5] > 59) throw new Error('Missing Nasdaq directory timestamp.');
  const directoryDate = `${footer[3]}-${footer[1]}-${footer[2]}`;
  const rows = new Map(), ambiguous = new Set();
  for (const line of lines.slice(1, -1)) {
    const fields = line.split('|');
    if (fields.length !== 12) continue;
    const [traded, ticker, name, listingExchange, marketCategory, etf, roundLot, test, status, cqs, nasdaq, nextShares] = fields.map(field => field.trim());
    if (traded !== 'Y' || test !== 'N' || status === 'S' || !TICKER.test(ticker) || !name || name.length > 255 || /[\p{Cc}\p{Cf}]/u.test(name) || !['Y', 'N'].includes(etf) || !['Y', 'N'].includes(nextShares) || (ticker === 'SPCX' && !/space\s*(?:x|exploration)/i.test(name))) continue;
    const row = { ticker, name, providerSymbol: ticker, nasdaqTraded: true, testIssue: false, etf: etf === 'Y', listingExchange, marketCategory, roundLotSize: Number(roundLot), financialStatus: status, cqsSymbol: cqs, nasdaqSymbol: nasdaq, nextShares: nextShares === 'Y' };
    if (rows.has(ticker) && JSON.stringify(rows.get(ticker)) !== JSON.stringify(row)) ambiguous.add(ticker);
    rows.set(ticker, row);
  }
  for (const ticker of ambiguous) rows.delete(ticker);
  return validateStockCatalog({ version: 1, status: 'complete', provider: 'nasdaqtrader', scope: 'nasdaq_traded_us', source: NASDAQ_SOURCE, fetchedAt: new Date(now).toISOString(), directoryDate, rows: [...rows.values()] }, now);
}

export function createNasdaqStockCatalogProvider({ fetchImpl = fetch, now = () => Date.now(), timeoutMs = 7000, maxOutputBytes = 3000000 } = {}) {
  return async () => {
    const controller = new AbortController();
    let timer;
    try {
      return await Promise.race([
        (async () => {
          const response = await fetchImpl(NASDAQ_URL, { signal: controller.signal, redirect: 'error', credentials: 'omit', headers: { Accept: 'text/plain' } });
          if (!response.ok || !response.body || Number(response.headers?.get('content-length') || 0) > maxOutputBytes) throw new Error('Nasdaq directory is unavailable.');
          const chunks = []; let bytes = 0;
          for await (const chunk of response.body) { bytes += chunk.length; if (bytes > maxOutputBytes) throw new Error('Directory exceeds its size limit.'); chunks.push(Buffer.from(chunk)); }
          return parseNasdaqDirectory(Buffer.concat(chunks).toString('utf8'), now());
        })(),
        new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new Error('Nasdaq directory timed out.')); }, Math.min(7500, Math.max(1, timeoutMs))); }),
      ]);
    } catch { return { status: 'unavailable' }; }
    finally { clearTimeout(timer); controller.abort(); }
  };
}

function childEnvironment(env) {
  const allowed = new Set(['PATH', 'PATHEXT', 'SYSTEMROOT', 'WINDIR', 'TEMP', 'TMP', 'HOME', 'USERPROFILE', 'LOCALAPPDATA', 'APPDATA', 'COMSPEC', 'NUMBER_OF_PROCESSORS', 'PROCESSOR_ARCHITECTURE', 'SSL_CERT_FILE', 'CURL_CA_BUNDLE', 'REQUESTS_CA_BUNDLE', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY', 'NO_PROXY']);
  return { ...Object.fromEntries(Object.entries(env).filter(([key, value]) => allowed.has(key.toUpperCase()) && typeof value === 'string')), PYTHONUTF8: '1', PYTHONUNBUFFERED: '1' };
}

export function createLocalStockCatalogProvider({ appDir = APP_DIR, env = process.env, spawnImpl = spawn, timeoutMs = 22000, maxOutputBytes = MAX_BYTES } = {}) {
  return () => new Promise(resolve => {
    let child, timer, done = false, outputBytes = 0, errorBytes = 0;
    const chunks = [];
    const finish = value => { if (done) return; done = true; clearTimeout(timer); resolve(value); };
    const fail = () => { if (done) return; finish({ status: 'unavailable' }); void stopOwnedMarketProcess(child, { spawnImpl, env }); };
    try {
      const python = path.join(appDir, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
      child = spawnImpl(python, ['-m', 'worker.stock_search'], { cwd: appDir, shell: false, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'], env: childEnvironment(env) });
      timer = setTimeout(fail, timeoutMs);
      child.on('error', fail);
      child.stdout.on('data', chunk => { if (done) return; outputBytes += chunk.length; if (outputBytes > maxOutputBytes) return fail(); chunks.push(Buffer.from(chunk)); });
      child.stderr.on('data', chunk => { errorBytes += chunk.length; if (errorBytes > maxOutputBytes) fail(); });
      child.on('close', code => { if (done) return; if (code !== 0) return fail(); try { finish(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch { fail(); } });
    } catch { fail(); }
  });
}

function matchRows(rows, query, limit) {
  const key = query.toLocaleLowerCase('en-US');
  const rank = row => !key ? 2 : row.ticker.toLowerCase() === key ? 0 : row.ticker.toLowerCase().startsWith(key) ? 1 : 2;
  return rows.filter(row => !key || row.ticker.toLowerCase().includes(key) || row.name.toLocaleLowerCase('en-US').includes(key)).sort((a, b) => rank(a) - rank(b) || a.ticker.localeCompare(b.ticker)).slice(0, limit);
}

/** Search names only. A discovered symbol is neither a quote nor suitability approval. */
export function createStockSearch({ mode = 'local', appDir = APP_DIR, provider = createLocalStockCatalogProvider({ appDir }), now = () => Date.now(), fetchImpl = fetch, fallbackProvider = createNasdaqStockCatalogProvider({ fetchImpl, now }), ttlMs = DAY, staleTtlMs = 7 * DAY, failureTtlMs = 5 * 60000, cacheFile = path.join(appDir, '.local', 'us-stock-catalog.json') } = {}) {
  let catalog = null, pending = null, nextAttemptAt = 0;
  const maintained = ASSETS.filter(asset => asset.assetClass !== 'cash').map(asset => ({ ticker: asset.ticker, name: asset.name, assetClass: asset.assetClass, identityStatus: 'maintained', source: 'Team-maintained instrument catalog', providerSymbol: null, currency: null, currencyVerified: false }));

  async function readDisk() {
    if (!cacheFile) return;
    try {
      if ((await fs.stat(cacheFile)).size > MAX_BYTES) return;
      const saved = validateStockCatalog(JSON.parse(await fs.readFile(cacheFile, 'utf8')), now());
      if (!catalog || Date.parse(saved.fetchedAt) > Date.parse(catalog.fetchedAt) || (saved.scope === 'all_us' && catalog.scope !== 'all_us')) catalog = saved;
    } catch { /* Missing, stale or invalid cache is not provider evidence. */ }
  }

  async function refresh() {
    if (pending) return pending;
    pending = (async () => {
      nextAttemptAt = now() + failureTtlMs;
      try {
        let next;
        try { next = validateStockCatalog(await provider(), now()); }
        catch { next = validateStockCatalog(await fallbackProvider(), now()); }
        // A quick subset must not replace a usable full-market catalog.
        if (catalog?.scope === 'all_us' && next.scope === 'well_known_us' && now() - Date.parse(catalog.fetchedAt) <= staleTtlMs) return;
        catalog = next;
        if (cacheFile) {
          const temporary = cacheFile + '.tmp';
          await fs.mkdir(path.dirname(cacheFile), { recursive: true });
          await fs.writeFile(temporary, JSON.stringify(catalog), 'utf8');
          await fs.rename(temporary, cacheFile);
        }
      } catch { /* Keep an explicitly dated usable catalog, or fall back below. */ }
    })();
    try { await pending; } finally { pending = null; }
  }

  return async (value, { limit = 12 } = {}) => {
    const query = normalizeStockQuery(value);
    if (!Number.isInteger(limit) || limit < 1 || limit > 30) throw new Error('Search limit must be between 1 and 30.');
    if (mode === 'local') {
      await readDisk();
      if ((!catalog || now() - Date.parse(catalog.fetchedAt) > ttlMs) && (pending || now() >= nextAttemptAt)) await refresh();
    }
    const directoryAge = catalog?.directoryDate ? now() - Date.parse(catalog.directoryDate) : 0;
    const usable = mode === 'local' && catalog && now() - Date.parse(catalog.fetchedAt) <= staleTtlMs && directoryAge <= staleTtlMs;
    if (!usable) return { query, status: 'fallback', scope: 'maintained_only', fetchedAt: null, source: { name: 'Team-maintained instrument catalog', url: null }, results: matchRows(maintained, query, limit), warnings: ['AKShare and the Nasdaq directory are unavailable. Only the maintained starter list is searchable; no match does not mean a symbol is unlisted.'] };
    const stale = now() - Date.parse(catalog.fetchedAt) > ttlMs || directoryAge > 3 * DAY;
    const rows = catalog.rows.map(row => ({ ...row, assetClass: row.etf === true ? 'etf' : 'unclassified', identityStatus: 'provider_catalog', currency: null, currencyVerified: false, source: catalog.source.name }));
    // Maintained identity takes priority for known symbols, notably SPCX's issuer change.
    const identities = new Map(rows.map(row => [row.ticker, row]));
    for (const row of maintained) identities.set(row.ticker, { ...row, providerSymbol: identities.get(row.ticker)?.providerSymbol || null });
    const coverage = catalog.provider === 'nasdaqtrader' ? `AKShare is unavailable. Search uses the Nasdaq Trader directory dated ${catalog.directoryDate}, plus the starter list. This is a security directory, not a live price feed or investment recommendation.` : catalog.scope === 'well_known_us' ? 'AKShare well-known US categories plus the starter list; this is a partial catalog. Other listings may be absent.' : 'AKShare US symbol catalog plus the starter list. Names do not verify a current quote, instrument type, currency or investment suitability.';
    return { query, status: stale ? 'stale' : 'cached', scope: catalog.scope, source: catalog.source, fetchedAt: catalog.fetchedAt, ...(catalog.directoryDate ? { directoryDate: catalog.directoryDate } : {}), results: matchRows([...identities.values()], query, limit), warnings: [coverage, ...(stale ? ['The catalog is older than its refresh window. Verify issuer identity before using a ticker.'] : [])] };
  };
}
