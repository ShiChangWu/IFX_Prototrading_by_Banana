import { schoolIndicators, schoolEntryCondition, SCHOOL_TESTS } from '../shared/school-backtest.mjs';

const problem = message => Object.assign(new Error(message), { status: 400 });
const symbol = value => typeof value === 'string' && /^[A-Z][A-Z0-9.-]{0,11}$/.test(value) && value !== 'CASH';
export function validateTracking(input) {
  if (!Array.isArray(input.tickers) || input.tickers.length > 8 || !input.tickers.every(symbol) || new Set(input.tickers).size !== input.tickers.length) throw problem('Choose up to eight different stock or ETF tickers.');
  if (!['defensive', 'balanced', 'trend', 'mean_reversion', 'rsi', 'price_action'].includes(input.schoolId)) throw problem('Choose a matched, maintained strategy.');
  if (typeof input.enabled !== 'boolean') throw problem('Choose whether email alerts are enabled.');
  const email = String(input.email || '').trim().toLowerCase();
  if (email && (email.length > 254 || !/^[^\s@<>\r\n,;]+@[^\s@<>\r\n,;]+\.[A-Za-z]{2,}$/.test(email))) throw problem('Enter one valid email address.');
  if (input.enabled && (!email || input.consent !== true || !input.tickers.length)) throw problem('Select a stock, enter your email, and agree to receive alerts.');
  const conditions = input.conditions || [];
  if (!Array.isArray(conditions) || conditions.length > 8 || new Set(conditions.map(row => row?.ticker)).size !== conditions.length) throw problem('Each stock can have one set of price reminders.');
  return {tickers: [...input.tickers], schoolId: input.schoolId, enabled: input.enabled, email, consent: input.consent === true,
    conditions: conditions.map(row => {
      if (!input.tickers.includes(row?.ticker)) throw problem('Price reminders must belong to selected stocks.');
      const result = {ticker: row.ticker};
      for (const key of ['buyBelow', 'sellAbove', 'sellBelow']) {
        const value = row[key] ?? null;
        if (value !== null && (!Number.isFinite(value) || value <= 0 || value > 1000000)) throw problem('A reminder price must be a positive USD amount, or left empty.');
        result[key] = value;
      }
      if (result.sellAbove && result.sellBelow && result.sellBelow >= result.sellAbove) throw problem('The lower sell-review line must be below the upper line.');
      return result;
    })};
}

export function applyFill(tracking, input, now) {
  if (!symbol(input.ticker) || !['buy','sell'].includes(input.side) || !Number.isFinite(input.quantity) || input.quantity <= 0 || input.quantity > 1000000 || !Number.isFinite(input.price) || input.price <= 0 || input.price > 1000000 || input.quantity * input.price > 10000000) throw problem('Enter a stock, buy or sell, and positive shares and execution price (maximum trade value $10 million).');
  if (typeof input.idempotencyKey !== 'string' || !/^[A-Za-z0-9_-]{12,100}$/.test(input.idempotencyKey)) throw problem('This trade needs a unique submission reference.');
  const executed = Date.parse(input.executedAt);
  if (!Number.isFinite(executed) || executed > now + 60000 || executed < Date.UTC(2000,0,1)) throw problem('Enter the actual trade time, not a future date.');
  tracking.fills ||= []; tracking.positions ||= [];
  const identical = tracking.fills.find(row => row.idempotencyKey === input.idempotencyKey);
  if (identical) {
    if (['ticker','side','quantity','price','executedAt'].some(key => identical[key] !== input[key])) throw problem('This submission reference already belongs to a different trade.');
    return {fill: identical, duplicate: true};
  }
  if (tracking.fills.length >= 2000) throw problem('The local trade ledger is full. Export it before continuing.');
  const last = tracking.fills.filter(row => row.ticker === input.ticker).at(-1);
  if (last && executed < Date.parse(last.executedAt)) throw problem('Record trades in execution order for each stock.');
  let position = tracking.positions.find(row => row.ticker === input.ticker);
  if (!tracking.tickers.includes(input.ticker) && !position?.quantity) throw problem('Select this stock before recording a trade.');
  if (input.side === 'sell' && (!position || input.quantity > position.quantity + 1e-9)) throw problem('You cannot record selling more shares than you have recorded owning.');
  if (!position) { position = {ticker: input.ticker, quantity: 0, averagePrice: 0}; tracking.positions.push(position); }
  if (input.side === 'buy') { position.averagePrice = (position.averagePrice * position.quantity + input.quantity * input.price) / (position.quantity + input.quantity); position.quantity += input.quantity; }
  else { position.quantity = Math.max(0, position.quantity - input.quantity); if (position.quantity < 1e-9) { position.quantity = 0; position.averagePrice = 0; } }
  const fill = {ticker: input.ticker, side: input.side, quantity: input.quantity, price: input.price, executedAt: input.executedAt, recordedAt: new Date(now).toISOString(), idempotencyKey: input.idempotencyKey};
  tracking.fills.push(fill); tracking.updatedAt = new Date(now).toISOString();
  return {fill, duplicate: false};
}

// Minute prices stay separate from adjusted daily candles. No broker orders.
export function evaluateTracking(tracking, quotes, daily, now) {
  const signals = [];
  for (const ticker of tracking.tickers) {
    const quote = quotes?.quotes?.[ticker], observed = Date.parse(quote?.barTime);
    if (!['complete','ready'].includes(quote?.status) || quote.eligibleForAlerts===false || !Number.isFinite(quote.price) || quote.price <= 0 || !Number.isFinite(observed) || now - observed > 300000 || observed + 60000 > now) continue;
    const held = tracking.positions?.find(row => row.ticker === ticker)?.quantity || 0;
    const add = (side, trigger, reason, evidenceDate) => { if (side === 'sell' && held <= 0) return; if (side === 'buy' && held > 0) return; signals.push({ticker, side, trigger, reason, evidenceDate, price:quote.price, observedAt:quote.barTime, source: quotes.source, feed:quotes.feed, quantityHeld: held}); };
    const condition = tracking.conditions?.find(row => row.ticker === ticker);
    if (condition?.buyBelow && quote.price <= condition.buyBelow) add('buy','price_buy_below',`Your price line was reached: $${quote.price} is at or below $${condition.buyBelow}. Review whether to buy.`,quote.barTime.slice(0,10));
    if (condition?.sellAbove && quote.price >= condition.sellAbove) add('sell','price_sell_above',`Your upper price line was reached: $${quote.price} is at or above $${condition.sellAbove}. Review your ${held} recorded shares.`,quote.barTime.slice(0,10));
    if (condition?.sellBelow && quote.price <= condition.sellBelow) add('sell','price_sell_below',`Your lower price line was reached: $${quote.price} is at or below $${condition.sellBelow}. Review your ${held} recorded shares. This is not an executed stop.`,quote.barTime.slice(0,10));
    const row = daily?.snapshots?.find(item => item.ticker === ticker);
    if (row?.status !== 'complete' || row.currency !== 'USD' || row.currencyVerified !== true || row.adjusted !== true || row.adjustmentVerified === false || !Array.isArray(row.bars)) continue;
    const end = Date.parse(row.priceDate+'T23:59:59Z'), fetched = Date.parse(row.fetchedAt);
    if (!Number.isFinite(end) || end > now || now-end > 4*86400000 || !Number.isFinite(fetched) || fetched > now+300000 || now-fetched>86400000) continue;
    const school = SCHOOL_TESTS[tracking.schoolId], bars = row.bars;
    if (!school?.mode || ['hold','atr'].includes(school.mode) || bars.length <= school.warmup || (ticker === 'SPCX' && bars.some(bar=>bar.date<'2026-06-12'))) continue;
    const indicators = schoolIndicators(bars), i = bars.length-1, current = indicators[i];
    // Preserve the provider's longer Wilder initialization for RSI. Re-seeding
    // Wilder on only the 120 displayed candles can move a borderline crossing.
    if(school.mode==='rsi'){
      if(!Number.isFinite(row.rsi14)||!Number.isFinite(row.previousRsi14))continue;
      current.rsi=row.rsi14;indicators[i-1].rsi=row.previousRsi14;
    }
    if (!held && schoolEntryCondition(school.mode,bars,indicators,i)) add('buy',`daily_${school.mode}_entry`,`${school.label}: the completed daily entry-watch condition appeared on ${row.priceDate}. The latest minute price is a separate reference; review the current price and your allocation before trading.`,row.priceDate);
    const exit = held && ((school.mode==='trend' && Number.isFinite(current.sma100) && current.sma20<=current.sma100) || (school.mode==='rsi' && current.rsi>=70) || (school.mode==='bands' && bars[i].close>=current.sma20));
    if(exit) add('sell',`daily_${school.mode}_exit`,`${school.label}: the daily exit-review condition appeared on ${row.priceDate}. Review your ${held} recorded shares; no sale has been placed.`,row.priceDate);
  }
  return signals;
}
