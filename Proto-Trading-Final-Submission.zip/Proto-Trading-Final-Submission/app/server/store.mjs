import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

export function emptyState() { return { schema: 1, sessions: {}, jobs: {}, workers: {}, limits: {} }; }
export function assertState(state) {
  if (state?.schema !== 1 || !state.sessions || !state.jobs || !state.workers || !state.limits) throw new Error('Persistent state is invalid; restore a backup before restarting.');
  return state;
}

export class LocalStore {
  constructor(file) { this.file = file; this.chain = Promise.resolve(); }
  async read() {
    try { return assertState(JSON.parse(await fs.readFile(this.file, 'utf8'))); }
    catch (error) { if (error.code === 'ENOENT') return emptyState(); throw error; }
  }
  transact(action) {
    const next = this.chain.then(async () => {
      const state = await this.read();
      const result = action(state);
      if (result instanceof Promise) throw new Error('Store transactions must be synchronous.');
      await fs.mkdir(path.dirname(this.file), { recursive: true, mode: 0o700 });
      const data = JSON.stringify(state);
      if (Buffer.byteLength(data) > 32 * 1024 * 1024) throw Object.assign(new Error('Report storage is full. Export completed reports before adding more.'), { status: 503 });
      const temp = `${this.file}.${randomUUID()}.tmp`;
      try { await fs.writeFile(temp, data, { mode: 0o600, flag: 'wx' }); await fs.rename(temp, this.file); }
      finally { await fs.rm(temp, { force: true }).catch(() => {}); }
      return result;
    });
    this.chain = next.catch(() => {});
    return next;
  }
}

// Optimistic compare-and-swap keeps all cloud transitions durable and atomic.
// Appropriate for this single-worker prototype; migrate to row-per-job for scale.
export class SupabaseStore {
  constructor({ url, key, fetchImpl = fetch }) {
    if (!url || !key) throw new Error('Supabase URL and service-role key are required for cloud persistence.');
    const parsed = new URL(url);
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new Error('SUPABASE_URL must use HTTPS.');
    this.url = url.replace(/\/+$/, ''); this.key = key; this.fetch = fetchImpl;
  }
  async rpc(name, payload) {
    let response;
    try {
      response = await this.fetch(`${this.url}/rest/v1/rpc/${name}`, {
        method: 'POST', headers: { apikey: this.key, Authorization: `Bearer ${this.key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload), signal: AbortSignal.timeout(8000),
      });
    } catch { throw Object.assign(new Error('Cloud report storage is temporarily unavailable.'), { status: 503 }); }
    if (!response.ok) throw Object.assign(new Error('Cloud report storage is unavailable. Check server configuration and apply the Supabase migration.'), { status: 503 });
    return response.json();
  }
  async transact(action) {
    for (let attempt = 0; attempt < 10; attempt++) {
      const row = await this.rpc('proto_read_state', {});
      const state = assertState(row.data);
      const result = action(state);
      if (result instanceof Promise) throw new Error('Store transactions must be synchronous.');
      if (Buffer.byteLength(JSON.stringify(state)) > 32 * 1024 * 1024) throw Object.assign(new Error('Report storage is full.'), { status: 503 });
      const saved = await this.rpc('proto_compare_exchange', { expected_revision: row.revision, next_data: state });
      if (saved === true) return result;
    }
    throw Object.assign(new Error('The research queue is busy. Please try again shortly.'), { status: 503 });
  }
}

export function createStore(config, fetchImpl) {
  if (config.mode === 'cloud') return new SupabaseStore({ url: config.supabaseUrl, key: config.supabaseKey, fetchImpl });
  return new LocalStore(config.storeFile);
}
