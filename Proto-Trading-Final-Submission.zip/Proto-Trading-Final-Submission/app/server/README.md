# Local API and future public adapter

Start from the app directory with `node server/index.mjs`. Configuration is read
from `app/.env.local`, without evaluating shell expressions or printing secrets.
The server binds only `127.0.0.1`. It serves `dist/` when built, otherwise `public/`.
The two shared browser modules are explicitly public; server files, credentials,
and `.local/state.json` are never exposed as static content.

`DEEPSEEK_API_KEY` enables a real provider request. The response can select only a
template permitted by the questionnaire; all amounts and risk illustrations are
recalculated locally. Missing keys and provider errors remain visible and leave a
usable rules result. They never produce a fake AI explanation.
Each session also tracks its latest matching request. If two requests overlap,
the older late response cannot replace the latest result. Research waits for the
latest matching request to finish and verifies the exact saved input snapshot.

## Immediate short-term checklist

`POST /api/short-plan` accepts `{profile, matchId}` and requires the matching
`X-Session-Token` header. It uses the confirmed allocation's five largest non-cash
holdings and a deterministic template checklist. It makes no DeepSeek or
TradingAgents request. The market subprocess receives only a ticker array, never
the questionnaire or API keys. Its environment excludes provider and worker
secrets; the command is fixed, has no shell, and stops after 25 seconds or 128 KiB
of output. On Windows the timeout targets the owned quick-market process tree,
including a venv launcher child; it never selects the research worker by name.
Prices, dates, indicators, adjustment status and currency evidence are
checked before the shared plan rules use them. Missing evidence remains missing.

Successful ticker snapshots are cached for 15 minutes; simultaneous requests for
the same tickers share one retrieval. Failed or partial retrievals get a 30-second
cooldown. The default quota is 12 requests per hour per session and IP; override
with `SHORT_PLAN_REQUESTS_PER_HOUR`. Coverage gaps and cached-data dates remain in
the response. A profile changed while prices are loading causes a stale-result
rejection. Essential-money profiles receive a blocked checklist without fetching
prices. Cloud mode currently returns a clear unavailable-data plan because its
market adapter has not been configured.

`WORKER_SECRET` must contain at least 32 characters and be shared with the Python
worker. A recent worker heartbeat is required before a new research request can
enter the queue. New tasks are rejected when the worker is offline, the queue is
full, the hourly quota is exhausted, or the visitor already has an active task.
One research task runs at a time. Leases expire after 120 seconds without renewal;
unstarted tasks expire after 30 minutes. Reports require opaque per-report access
tokens; matching creates a separate session token. Token hashes are persisted.

Local state is serialized to an atomic file replacement and survives restart.
The server holds a file lock to prevent two local server processes from owning
the same data. Keep `.local/` out of source control and backups shared publicly.

## Explicit example publication

No examples are fabricated or automatically published. After real research:

```
node server/reports.mjs list
node server/reports.mjs export JOB_ID NEW_REPORT_FILE.json
node server/reports.mjs publish JOB_ID
node server/reports.mjs unpublish JOB_ID
```

Stop the local website before `publish` or `unpublish`, then restart it. Listing
and exporting are read-only and can run while the server is running. Publishing
reveals the full saved profile, including its free-text input, so use a deliberate
demonstration profile or obtain the person's permission first. Exports use a new
file and refuse to overwrite an existing one.

## Public deployment later

The Netlify function imports the same API. Set the DeepSeek key, worker secret,
Supabase project URL, and Supabase service-role key only in server environment
variables. Apply `supabase/001_private_state.sql` in a new Supabase project. Never
place the service-role key or worker secret in the frontend bundle. Public mode
requires Supabase and has no ephemeral-file or in-memory fallback.

The SQL stores a private state row updated by compare-and-swap revision checks.
The table has RLS with no public policies; only the service role can call its RPCs.
This makes a small single-worker demonstration durable. At higher concurrency,
migrate to individual job rows and a dedicated queue rather than expanding this
JSON row. Cloud SQL and Netlify deployment need validation against actual accounts;
the automated test covers mocked CAS conflicts and unavailable-storage behavior.

To move the research computer to AWS later, retain the worker HTTP contract and
configure its public API URL and worker secret on the new compute service. The
website and saved-report format can remain the same.

## Verification

`node --test tests/server.test.mjs` checks local HTTP exposure, private token
ownership, persistence, lease expiry and renewal, completion idempotency, rate
limits, explicit unavailable states, and bounded mocked-provider template
selection. All provider and research fixtures in the tests are labeled test-only;
they are not included as public examples or claimed as live API research.
