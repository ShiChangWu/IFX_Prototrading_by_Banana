import {randomBytes, randomUUID, createHash} from 'node:crypto';
import {validateTracking, applyFill, evaluateTracking} from './tracking-rules.mjs';
import {getIntradayQuotes, getAlpacaAsset} from './intraday.mjs';
import {sendPlainEmail} from './gmail.mjs';
import {getYahooIntradayQuotes, getYahooAsset} from './yahoo-intraday.mjs';

const hash = value => createHash('sha256').update(String(value)).digest('hex');
const fail = (status,message) => Object.assign(new Error(message),{status});
const stamp = now => new Date(now).toISOString();
const init = state => {state.tracking ||= {}; state.trackingLinks ||= {}; state.mailOutbox ||= {};};
const owner = (state, token, now) => {
  const key=hash(token),session=state.sessions[key];
  if(typeof token!=='string'||token.length>256||!session||session.expiresAt<=now)throw fail(401,'Match your profile again to reconnect your private watchlist.');
  return key;
};
function publicTracking(row) {
  if(!row)return null;
  const {tickers,schoolId,enabled,email,consent,verified,conditions,positions,fills,alerts,lastCheck,status,updatedAt,marketNote,market}=row;
  return {tickers,schoolId,enabled,email,consent,verified,conditions,positions,fills,alerts:(alerts||[]).slice(-50),lastCheck,status,updatedAt,marketNote,market};
}
export function createTrackingService({config,store,getSnapshot,searchStocks,fetchImpl=fetch,now=()=>Date.now(),quoteProvider,assetProvider,mailer=sendPlainEmail}) {
  const yahoo=config.intradayProvider==='yahoo';
  quoteProvider ||= yahoo?getYahooIntradayQuotes:getIntradayQuotes;
  assetProvider ||= yahoo?getYahooAsset:getAlpacaAsset;
  let checking=null,flushing=null;
  const assetCache=new Map();
  async function activeAsset(ticker){
    const cached=assetCache.get(ticker);if(cached?.expiresAt>now())return cached.value;
    const value=await assetProvider(ticker,config,{fetchImpl,now});
    const valid=value?.status==='complete'&&value.assetClass==='us_equity'&&value.tradable===true;
    assetCache.set(ticker,{value:valid,expiresAt:now()+(valid?6*3600000:60000)});return valid;
  }
  const capabilities=()=>({mailConfigured:config.mode==='local'&&!!(config.gmailUser&&config.gmailAppPassword),emailDeliveryEnabled:config.emailDeliveryEnabled===true,marketConfigured:config.mode==='local'&&(yahoo||!!(config.alpacaKey&&config.alpacaSecret)),feed:yahoo?'yahoo':config.alpacaFeed||'iex',marketSource:yahoo?'Yahoo Finance':'Alpaca',intervalSeconds:config.alertIntervalSeconds||60,linkScope:/^https:\/\//.test(config.alertBaseUrl||'')?'public':'this computer only',automatic:config.mode==='local'&&config.emailDeliveryEnabled===true});
  const snapshot=key=>store.transact(state=>{init(state);return {tracking:publicTracking(state.tracking[key]),capabilities:capabilities()};});
  function link(state,key,purpose,extra={}) {
    const raw=randomBytes(32).toString('base64url'),created=now();
    state.trackingLinks[hash(raw)]={key,purpose,createdAt:created,expiresAt:created+(purpose==='verify'?86400000:7*86400000),...extra};
    return `${config.alertBaseUrl||`http://127.0.0.1:${config.port||8787}`}/trade.html#token=${raw}`;
  }
  function readLink(state,raw) {
    if(typeof raw!=='string'||raw.length>100)throw fail(404,'This private link is invalid or expired.');
    const item=state.trackingLinks[hash(raw)];
    if(!item||item.expiresAt<=now()||!state.tracking[item.key])throw fail(404,'This private link is invalid or expired.');
    return item;
  }
  function mailRow(state,key,to,subject,text,alertId=null) {
    const id=randomUUID();state.mailOutbox[id]={id,key,to,subject,text,alertId,status:'pending',createdAt:stamp(now())};return id;
  }
  async function flush() {
    if(flushing)return flushing;
    flushing=(async()=>{
      if(!capabilities().mailConfigured||!capabilities().emailDeliveryEnabled)return;
      // Recover only the state marker. An interrupted SMTP send may have been
      // accepted: it is never automatically retried and sent twice.
      await store.transact(state=>{init(state);for(const row of Object.values(state.mailOutbox))if(row.status==='sending')row.status='uncertain';});
      for(let count=0;count<25;count++) {
        const row=await store.transact(state=>{
          init(state);
          const next=Object.values(state.mailOutbox).find(item=>item.status==='pending');if(!next)return null;
          const tracking=state.tracking[next.key];
          const session=state.sessions[next.key];
          if(!tracking || next.to!==tracking.email || (next.alertId&&(!tracking.enabled||!tracking.verified||!session||session.expiresAt<=now()||session.matching||!session.trackingEligible||session.selectedTemplateId!==tracking.schoolId||session.profileHash!==tracking.profileHash))) {next.status='cancelled';const alert=tracking?.alerts?.find(item=>item.id===next.alertId);if(alert)alert.status='cancelled';return {skip:true};}
          next.status='sending';return structuredClone(next);
        });
        if(!row)break;if(row.skip)continue;
        let result;try{result=await mailer({to:row.to,subject:row.subject,text:row.text,id:row.id},config);}catch{result={status:'uncertain'};}
        await store.transact(state=>{
          const saved=state.mailOutbox[row.id];if(!saved)return;
          saved.status=['accepted','failed','unavailable','uncertain'].includes(result?.status)?result.status:'uncertain';saved.updatedAt=stamp(now());
          const alert=state.tracking[row.key]?.alerts?.find(item=>item.id===row.alertId);if(alert)alert.status=saved.status;
          // Never retain email capability links in accepted message bodies.
          if(saved.status==='accepted')delete saved.text;
        });
      }
    })();
    try{await flushing;}finally{flushing=null;}
  }
  async function checkOne(key) {
    const start=now();
    const tracking=await store.transact(state=>{init(state);return structuredClone(state.tracking[key]||null);});
    if(!tracking)return;
    if(capabilities().marketConfigured&&!yahoo){
      const eligibility=await Promise.all(tracking.tickers.map(activeAsset));
      if(eligibility.some(value=>!value)){
        await store.transact(state=>{const current=state.tracking[key];if(current?.revision===tracking.revision){current.status='asset_verification_unavailable';current.lastCheck=stamp(now());current.marketNote='An active US-listed stock or ETF could not be confirmed. No alerts were generated.';}});return;
      }
    }
    const quotes=await quoteProvider(tracking.tickers,config,{fetchImpl,now:()=>now()});
    const hasQuotes=Object.values(quotes.quotes||{}).some(row=>['complete','ready'].includes(row.status));
    const daily={snapshots:[]};
    if(hasQuotes&&!['defensive','balanced'].includes(tracking.schoolId))for(let i=0;i<tracking.tickers.length;i+=5){const data=await getSnapshot(tracking.tickers.slice(i,i+5));daily.snapshots.push(...(data.snapshot?.snapshots||[]));}
    await store.transact(state=>{
      init(state);const current=state.tracking[key];if(!current||current.revision!==tracking.revision)return;
      current.lastCheck=stamp(now());current.status=quotes.code==='MARKET_CLOSED'?'market_closed':quotes.status||'unavailable';current.marketNote=[quotes.message,...(quotes.warnings||[])].filter(Boolean).join(' ').slice(0,1200);
      current.market={source:quotes.source,feed:quotes.feed,status:quotes.status,fetchedAt:quotes.fetchedAt,quotes:quotes.quotes||{},warnings:quotes.warnings||[]};
      current.alerts ||= [];current.seen ||= {};
      const freshNow=now();const signals=evaluateTracking(current,quotes,daily,freshNow);
      for(const signal of signals){
        const duplicate=`${signal.ticker}:${signal.trigger}:${signal.evidenceDate}`;
        if(current.seen[duplicate])continue;
        current.seen[duplicate]=freshNow;
        const alert={...signal,id:randomUUID(),createdAt:stamp(freshNow),status:'preview'};
        current.alerts.push(alert);
        const canSend=current.enabled&&current.verified&&capabilities().mailConfigured&&capabilities().emailDeliveryEnabled&&state.sessions[key]?.expiresAt>freshNow&&state.sessions[key]?.trackingEligible&&!state.sessions[key]?.matching&&state.sessions[key]?.selectedTemplateId===current.schoolId&&state.sessions[key]?.profileHash===current.profileHash;
        if(canSend){
          const fillUrl=link(state,key,'fill',{ticker:signal.ticker,side:signal.side});const stopUrl=link(state,key,'stop');
          alert.status='pending';
          mailRow(state,key,current.email,`Proto Trading | ${signal.ticker} ${signal.side.toUpperCase()} review`,`${signal.reason}\n\nObserved minute close: USD ${signal.price} at ${signal.observedAt}. Source: ${signal.source}; feed: ${signal.feed}. ${signal.feed==='yahoo'?'Yahoo Finance data may be delayed; it is informational, not an execution quote.':'IEX covers one exchange, not the whole US market.'}\nThis is a condition to review, not an order or a guaranteed execution price. Daily strategy evidence date: ${signal.evidenceDate}.\n\nIf you actually placed a trade, record the exact shares and execution price here:\n${fillUrl}\n\nNo purchase? Do not submit a trade.\nStop emails: ${stopUrl}\nPrivate links expire in 7 days. ${capabilities().linkScope==='this computer only'?'This local link opens only on the computer running Proto Trading.':''}`,alert.id);
        }
      }
      current.alerts=current.alerts.slice(-200);
      for(const [id,time] of Object.entries(current.seen))if(freshNow-time>30*86400000)delete current.seen[id];
      current.checkDurationMs=Math.max(0,now()-start);
    });
    await flush();
  }
  async function tick() {
    if(!capabilities().emailDeliveryEnabled)return;
    if(checking)return checking;
    checking=(async()=>{
      const keys=await store.transact(state=>{init(state);
        for(const [id,value]of Object.entries(state.trackingLinks))if(value.expiresAt<=now())delete state.trackingLinks[id];
        for(const [id,value]of Object.entries(state.mailOutbox))if(value.status!=='pending'&&now()-Date.parse(value.createdAt)>7*86400000)delete state.mailOutbox[id];
        return Object.entries(state.tracking).filter(([key,row])=>row.enabled&&row.verified&&state.sessions[key]?.expiresAt>now()&&state.sessions[key]?.trackingEligible&&!state.sessions[key]?.matching).map(([key])=>key);
      });
      for(const key of keys){try{await checkOne(key);}catch{await store.transact(state=>{if(state.tracking[key]){state.tracking[key].status='check_failed';state.tracking[key].lastCheck=stamp(now());}});}}
      await flush();
    })();try{await checking;}finally{checking=null;}
  }
  async function handle(route,method,body,sessionToken) {
    if(!route.startsWith('/api/tracking'))return null;
    if(route==='/api/tracking/link'&&method==='POST')return store.transact(state=>{
      init(state);const item=readLink(state,body.token),tracking=state.tracking[item.key];
      return {purpose:item.purpose,ticker:item.ticker,side:item.side,used:!!item.usedAt,positions:tracking.positions.filter(row=>row.ticker===item.ticker),email:item.purpose==='verify'?tracking.email:undefined};
    });
    if(route==='/api/tracking/confirm'&&method==='POST')return store.transact(state=>{
      init(state);const item=readLink(state,body.token),tracking=state.tracking[item.key];
      if(item.purpose==='stop'){tracking.enabled=false;tracking.updatedAt=stamp(now());return {message:'Email alerts stopped.'};}
      if(item.purpose==='verify'){
        if(item.email!==tracking.email)throw fail(409,'This email address changed. Request a new confirmation.');
        tracking.verified=true;item.usedAt=stamp(now());return {message:'Email confirmed. Return to Your strategy and enable alerts.'};
      }
      if(item.purpose==='fill'){
        if(item.usedAt)throw fail(409,'This private trade link has already been used. Your trade was not added twice.');
        if(body.ticker!==item.ticker||body.side!==item.side)throw fail(400,'The stock and side must match this private link.');
        const result=applyFill(tracking,body,now());item.usedAt=stamp(now());return {...result,positions:tracking.positions.filter(row=>row.ticker===item.ticker),message:'Your actual trade was recorded. No broker order was placed.'};
      }
      throw fail(400,'Unknown private link action.');
    });
    const key=await store.transact(state=>owner(state,sessionToken,now()));
    if(route==='/api/tracking'&&method==='GET')return snapshot(key);
    if(route==='/api/tracking'&&method==='POST') {
      const input=validateTracking(body);
      if(input.enabled&&!capabilities().emailDeliveryEnabled)throw fail(409,'Email delivery is paused for this demo. Use the sidebar to preview a subscription; no email will be sent.');
      const original=await store.transact(state=>{init(state);return structuredClone(state.tracking[key]||null);});
      for(const ticker of input.tickers.filter(ticker=>!original?.tickers.includes(ticker))){
        const found=await searchStocks(ticker);
        if(!found.results.some(row=>row.ticker===ticker))throw fail(400,`${ticker} could not be confirmed in the available stock catalogue. Search again after the source refreshes.`);
      }
      if(input.enabled&&capabilities().marketConfigured){const valid=await Promise.all(input.tickers.map(activeAsset));if(valid.some(value=>!value))throw fail(409,'An active US-listed stock or ETF could not be confirmed by the intraday provider. Leave alerts off and check the selected codes.');}
      await store.transact(state=>{
        init(state);const session=state.sessions[key];
        if(session.matching||!session.trackingEligible||input.schoolId!==session.selectedTemplateId)throw fail(409,'Complete About you and use its confirmed strategy before saving stocks.');
        const previous=state.tracking[key];
        if(!previous&&Object.keys(state.tracking).length>=100)throw fail(503,'The local watchlist limit was reached.');
        const verified=!!(previous?.verified&&previous.email===input.email);
        if(input.enabled&&(!verified||!capabilities().mailConfigured||!capabilities().marketConfigured))throw fail(409,'Confirm your email and configure Gmail plus the intraday data connection before enabling alerts. Your selections can still be saved with alerts off.');
        state.tracking[key]={positions:[],fills:[],alerts:[],seen:{},...previous,...input,verified,profileHash:session.profileHash,revision:randomUUID(),updatedAt:stamp(now()),status:input.enabled?'waiting_for_check':'paused'};
        if(!previous?.enabled&&input.enabled)state.tracking[key].seen={};
      });return snapshot(key);
    }
    if(route==='/api/tracking/fills'&&method==='POST')return store.transact(state=>{
      init(state);const tracking=state.tracking[key];if(!tracking)throw fail(409,'Save your selected stocks first.');
      const result=applyFill(tracking,body,now());return {...result,tracking:publicTracking(tracking)};
    });
    if(route==='/api/tracking/verify'&&method==='POST'){
      if(!capabilities().emailDeliveryEnabled)throw fail(503,'Email delivery is paused for this demo. No confirmation email was sent.');
      if(!capabilities().mailConfigured)throw fail(503,'Gmail is not configured yet. Add the sender address and Google App Password to .env.local. No email was sent.');
      const id=await store.transact(state=>{
        init(state);const tracking=state.tracking[key];if(!tracking?.email||!tracking.consent)throw fail(400,'Save your email and agree to receive alerts first.');
        if(tracking.verified)throw fail(409,'This email is already confirmed.');
        if(tracking.lastVerification&&now()-tracking.lastVerification<300000)throw fail(429,'Wait five minutes before requesting another confirmation.');
        tracking.lastVerification=now();const url=link(state,key,'verify',{email:tracking.email});
        return mailRow(state,key,tracking.email,'Confirm Proto Trading email alerts',`You requested stock-condition emails in Proto Trading. Confirm this address by opening the link and pressing Confirm:\n${url}\n\nThis does not place trades or subscribe you until you enable alerts in the app. Ignore this message if it was not you. Link expires in 24 hours. ${capabilities().linkScope==='this computer only'?'This link opens only on the computer running the local app.':''}`);
      });await flush();
      return store.transact(state=>({status:state.mailOutbox[id].status,message:state.mailOutbox[id].status==='accepted'?'Gmail accepted the confirmation email. Check your inbox and spam folder.':'The email was not confirmed as accepted. Check local Gmail configuration before retrying.'}));
    }
    if(route==='/api/tracking/check'&&method==='POST'){
      await store.transact(state=>{init(state);const row=state.tracking[key];if(!row)throw fail(409,'Save selected stocks first.');if(row.lastCheckRequest&&now()-row.lastCheckRequest<15000)throw fail(429,'Wait 15 seconds between checks.');row.lastCheckRequest=now();});
      await checkOne(key);return snapshot(key);
    }
    if(route==='/api/tracking/stop'&&method==='POST'){await store.transact(state=>{init(state);if(state.tracking[key])state.tracking[key].enabled=false;});return snapshot(key);}
    throw fail(404,'Tracking action not found.');
  }
  return {handle,tick,flush,checkOne,capabilities};
}
