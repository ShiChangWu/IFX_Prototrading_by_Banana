import { createHash } from 'node:crypto';
import { selectedPlan } from '../shared/selected-plan.mjs';

const invalid = message => { throw Object.assign(new Error(message), { status: 400 }); };
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);

// This is a server input contract. Names, amounts, risk and instrument identity
// are never accepted from the browser; only the chosen symbols and percentages.
export function validateResearchSelection(value) {
  if (!object(value) || Object.keys(value).some(key => !['tickers', 'weights'].includes(key))) invalid('Send only selected tickers and their hypothetical weights.');
  if (!Array.isArray(value.tickers) || value.tickers.length < 1 || value.tickers.length > 8) invalid('Choose one to eight stocks or ETFs for research.');
  const tickers = [...value.tickers];
  if (tickers.some(ticker => typeof ticker !== 'string' || !/^[A-Z][A-Z0-9.-]{0,9}$/.test(ticker) || ticker === 'CASH') || new Set(tickers).size !== tickers.length) invalid('Use distinct uppercase US stock or ETF codes of at most ten characters; cash is calculated separately.');
  if (!object(value.weights) || Object.keys(value.weights).length !== tickers.length || Object.keys(value.weights).some(ticker => !tickers.includes(ticker))) invalid('Provide exactly one weight for each selected ticker.');
  const weights = {};
  for (const ticker of tickers) {
    const weight = value.weights[ticker];
    if (!Object.hasOwn(value.weights, ticker) || typeof weight !== 'number' || !Number.isFinite(weight) || weight < 0 || weight > 100) invalid('Each hypothetical weight must be a number from 0% to 100%.');
    weights[ticker] = weight;
  }
  if (Object.values(weights).reduce((sum, weight) => sum + weight, 0) > 100.000001) invalid('Selected weights exceed 100%; reduce them before requesting research.');
  return { tickers, weights };
}

export function createSelectedResearchMatch(base, selection, assets) {
  const checked = validateResearchSelection(selection);
  let plan;
  try { plan = selectedPlan(base, { tickers: checked.tickers, assets }, checked.weights); }
  catch (problem) { invalid(problem.message); }
  const allocations = plan.allocations.map(row => ({ ...row, assetClass: row.ticker === 'CASH' ? 'cash' : assets.find(asset => asset.ticker === row.ticker)?.assetClass || 'unclassified' }));
  const selectionMetadata = { version: 1, tickers: [...checked.tickers], source: 'user-selected' };
  const id = 'research-' + createHash('sha256').update(JSON.stringify({ originalMatchId: base.id, selection: selectionMetadata, weights: checked.weights })).digest('hex').slice(0, 32);
  const warnings = [
    'These hypothetical weights were chosen by the user. They have not been approved by AI or checked for personal suitability.',
    'A selected stock at 0% is researched as a watch-only idea; it receives no allocated money.',
    'Cash is the unallocated remainder. No trade is placed and no future return or maximum loss is guaranteed.',
  ];
  if (plan.stress.lossPct > Math.min(base.profile.lossTolerance, base.profile.lossCapacity)) warnings.push('This illustrative stress exceeds the lower loss threshold in your questionnaire. Review the chosen amounts and concentration.');
  if (assets.some(asset => asset.assetClass === 'unclassified')) warnings.push('Some directory identities do not establish instrument class. Company-specific facts must be checked before treating them as stocks or ETFs.');
  return {
    ...base, id, originalMatchId: base.id, researchSelection: selectionMetadata, hypothetical: true, allocationSource: 'user-selected',
    allocations,
    reasons: ['Research uses exactly the selected stocks and user-entered weights, with the confirmed questionnaire and strategy as context.'],
    warnings,
    stress: { ...plan.stress, lossAmount: plan.stress.lossAmount || 0, lossPct: plan.stress.lossPct || 0, label: 'Illustrative shock for your selected amounts; not a forecast or maximum loss', source: 'Team-maintained shocks; unknown instruments use an assumed -50% shock' },
    hedgeReview: { ...base.hedgeReview, allocated: allocations.some(row => row.weight > 0 && /inverse/i.test(row.assetClass)), message: 'Any selected inverse exposure and its weight were chosen by the user for research. Daily reset, leverage and compounding require separate review; this is not an automatic hedge recommendation.' },
    backtest: { status: 'pending', message: 'The worker will test the positive-weight selected allocation where historical evidence is available. Watch-only names do not affect portfolio returns.' },
  };
}

export function researchInputSnapshot(profile, match) {
  const selected = match.researchSelection?.source === 'user-selected';
  return {
    profile: structuredClone(profile), template: { id: match.template.id, name: match.template.name },
    allocations: structuredClone(match.allocations),
    researchTickers: selected ? [...match.researchSelection.tickers] : match.allocations.filter(row => row.ticker !== 'CASH' && row.weight > 0).sort((a, b) => b.weight - a.weight || a.ticker.localeCompare(b.ticker)).slice(0, 3).map(row => row.ticker),
    source: selected ? 'user-selected' : 'questionnaire',
  };
}
