import { configuration } from '../../server/config.mjs';
import { createStore } from '../../server/store.mjs';
import { createApi } from '../../server/api.mjs';

let api;
export function netlifyRequest(event) {
  const headers = new Headers(event.headers || {});
  const method = String(event.httpMethod || '').toUpperCase();
  if (!/^(GET|HEAD|POST|OPTIONS|PUT|PATCH|DELETE)$/.test(method)) throw Object.assign(new Error('Invalid request method.'), { status: 400 });
  const rawUrl = event.rawUrl;
  const host = headers.get('host');
  if (!rawUrl && (!host || /[\s/\\?#@]/.test(host))) throw Object.assign(new Error('A valid public request URL is required.'), { status: 400 });
  const url = new URL(rawUrl || `https://${host}/`);
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw Object.assign(new Error('Invalid request URL.'), { status: 400 });
  const eventPath = event.path || url.pathname;
  if (typeof eventPath !== 'string' || !eventPath.startsWith('/') || eventPath.includes('?') || eventPath.includes('#')) throw Object.assign(new Error('Invalid API path.'), { status: 400 });
  url.pathname = eventPath.replace(/^\/\.netlify\/functions\/api(?=\/|$)/, '/api');
  if (event.body !== undefined && event.body !== null && typeof event.body !== 'string') throw Object.assign(new Error('Invalid request body.'), { status: 400 });
  const limit = url.pathname.startsWith('/api/worker/') ? 2 * 1024 * 1024 + 65536 : 16384;
  if ((event.body?.length || 0) > (event.isBase64Encoded ? Math.ceil(limit / 3) * 4 : limit * 2)) throw Object.assign(new Error('Request is too large.'), { status: 413 });
  const body = event.body ? Buffer.from(event.body, event.isBase64Encoded ? 'base64' : 'utf8') : undefined;
  if (body && body.length > limit) throw Object.assign(new Error('Request is too large.'), { status: 413 });
  return { request: new Request(url, { method, headers, ...(!['GET', 'HEAD'].includes(method) && body ? { body } : {}) }), clientIp: headers.get('x-nf-client-connection-ip') || 'unknown-netlify-client' };
}

export async function handler(event) {
  let converted;
  try { converted = netlifyRequest(event); }
  catch (problem) {
    return { statusCode: problem.status || 400, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ error: problem.status ? problem.message : 'Invalid request.' }) };
  }
  try {
    if (!api) {
      const config = configuration(process.env, { mode: 'cloud' });
      api = createApi({ config, store: createStore(config) });
    }
    const response = await api(converted.request, { clientIp: converted.clientIp });
    return { statusCode: response.status, headers: Object.fromEntries(response.headers), body: await response.text() };
  } catch {
    // Never fall back to an ephemeral cloud filesystem or leak environment values.
    return { statusCode: 503, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: JSON.stringify({ error: 'Cloud persistence is not configured. Configure Supabase server credentials and apply the migration before using the public API.' }) };
  }
}
