# Proto-Trading hybrid app contract

This is the authorized implementation for the existing website. Preserve its dark/cyan frame and equal team presentation. No brokerage orders. Do not represent rules, fixtures or cached reports as fresh AI results.

## Browser API (same origin, JSON)

- `GET /api/health`: `{ok, mode, deepseekConfigured, researchConfigured, worker:{online,lastSeen}, templatesVersion}`. No secrets.
- `GET /api/templates`: `{templates:[{id,name,shortLabel,description,beginnerSummary,cadence,version,source,sources,role,matchable,implementationStatus,noviceAvailability,requiredData,exampleTickers,exampleNote,learningSteps,limitations,...}], assets:[...]}` from the maintained shared catalog. Public metadata supports discovery; private research prompts are not returned. Only `matchable === true` candidates can enter allocation matching.
- `POST /api/match`: `{profile}` => `{match, explanation:{status:'ready'|'unavailable'|'error',summary,why:[],risks:[],nextSteps:[],model,generatedAt},sessionToken}`. Session token optional input in `X-Session-Token`. DeepSeek may choose a template from the server's eligible candidates; the server then computes its allocation deterministically. Explicit template choices and questionnaire constraints are preserved. If DeepSeek missing/fails, return a valid rule match and clear status, never fake an AI response.
- `POST /api/research`: `{profile,matchId?,sessionToken}` => `{job:{id,status,createdAt},accessToken}`. Server recomputes match. Accept session via header also. Rate limit and reject unavailable worker/queue full with actionable message, not indefinite progress. Jobs use opaque access tokens; never list other visitors' reports.
- `GET /api/research/:id` with `X-Report-Token` => `{job:{id,status,stage,createdAt,updatedAt,error?},report:null|Report,worker:{online,lastSeen}}`.
- `POST /api/short-plan`: `{profile,matchId}` with the confirmed `X-Session-Token` => `{plan,marketStatus}`. Confirms the exact saved match before and after the market request. The local adapter receives only up to five non-cash tickers, fetches completed daily observations and caches snapshots briefly. No uploaded report or model call is used. Missing, stale or unverified data stays unavailable; the template checklist remains visible. Cloud mode needs a separate market-data adapter.
- `GET /api/examples`: `{reports:[{id,title,generatedAt,profileSummary}]}` only real completed, explicitly published reports. No sample report advertised as real.
- `GET /api/examples/:id` => `{report}` for those public reports only.

## Profile

`{budget:10000, goal:'defensive'|'balanced'|'growth', horizon:'under1'|'1to3'|'3plus', review:'monthly'|'weekly'|'daily', assetPreference:'broad'|'value'|'growth'|'unsure', lossTolerance:5|10|15|20|30, lossCapacity:5|10|15|20|30, essentialMoney:false, experience:'new'|'some', inverseInterest:'none'|'minus1'|'minus2'|'minus3', prompt:'', startingPortfolio:'cash', templateId?:'defensive'|'balanced'|'trend'|'mean_reversion'|'rsi'|'price_action'}`.
The six IDs above are matchable templates. The full ten-item catalog also includes `atr` (risk tool) and `wyckoff`, `ict`, `order_flow` (education only); these four never enter eligible allocation candidates. A submitted maintained but nonmatchable ID receives an eligible fallback with an explicit warning, not a fabricated allocation for that school. RSI/Price Action require daily review and at least 15 in both loss-answer fields; these preferences do not guarantee a loss limit.

Only USD, US-listed stock/ETF and cash, empty starting positions in version 1. Budget 100..1,000,000. Prompt max 1500 chars. Inverse interest is research-only; -2/-3 never automatically allocated in beginner profiles. Essential money leads to `eligible:false`, no generated investment allocation.

## Beginner UI contract

The four tabs are **About you**, **Your plan**, **Research**, and **Explore strategies**. Main questions show goal, amount, horizon, loss willingness/capacity and essential-money status; other fields retain their defaults inside **More choices**. Keep existing control IDs and names. Connection/operator information lives under **Connection & details**.

Use native `details` / `summary` for optional rules, sources, calculations and original documents. Preserve opened sections across rerenders. Reveal containing disclosures before focusing an optional input. Keep the main loss warning, missing-source notices and observation dates visible without requiring an expansion. New school cards show simple descriptions; only matchable cards offer allocation actions. Never carry over illustrative screenshot support prices, alleged institutional intent or protection guarantees.

## Shared JS module owned by root: `shared/strategy.mjs`

Exports `TEMPLATES`, `ASSETS`, `TEMPLATE_VERSION`, `validateProfile(input)` returns normalized profile or throws Error with status=400; `createMatch(profile)` validates and returns Match. Node and browser-compatible, no dependencies.

Match: `{id,eligible,profile,template:{id,name,description,beginnerSummary,cadence,version,source,rules,...},allocations:[{ticker,name,assetClass,weight,amount}],reasons:[],warnings:[],rebalance:{cadence,conditions:[]},stress:{label,assumptions:[{ticker,returnPct}],lossPct,lossAmount,endingValue},hedgeReview:{interest,allocated:false,message,comparators:[]},backtest:{status:'pending',message},createdAt}`. Weights are percent summing 100. Metrics illustrative until historical worker calculation.

## Local worker contract

Worker communicates OUTBOUND with the public site. `Authorization: Bearer WORKER_SECRET`; no Supabase admin key required on computer.
- `POST /api/worker/heartbeat` `{workerId,jobId?}` => `{ok}`
- `POST /api/worker/claim` `{workerId}` => `{job:null|{id,profile,match,createdAt,leaseToken}}`
- `POST /api/worker/progress` `{workerId,jobId,leaseToken,stage}` => `{ok}` (renews lease)
- `POST /api/worker/complete` `{workerId,jobId,leaseToken,report}` => `{ok}` (idempotent)
- `POST /api/worker/fail` `{workerId,jobId,leaseToken,error}` => `{ok}`
Persist cloud jobs/results; lease and ownership checks. Heartbeat 15s, stale after 90s, lease 120s renewed while working. One local job at a time. Failed jobs remain honest errors. Local development persistence allowed only on loopback server, never silently in serverless.

## Report (worker-owned computation)

`{id,title,status:'complete'|'partial',generatedAt,analysisDate,profile,match,provenance:{engine:'TauricResearch/TradingAgents',repository,commit,model,templateVersion,dataSources:[],warnings:[]},research:[{ticker,status:'complete'|'error',decision,sections:[{title,text}],error?}],outlook:[{horizon:'1–4 weeks'|'1–3 months'|'6–12 months',summary,evidence:[],conditions:[],status:'available'|'unavailable'}],backtest:{status:'complete'|'unavailable',start?,end?,methodology?,metrics?,series?,benchmark?,warnings:[],error?},hedgeReview:{...},limitations:[]}`.

HTML/LLM strings rendered as text, never trusted markup. Reports tied to the exact input snapshot; editing profile marks existing result stale. Never claim maximum loss guarantee or future probability. Any unavailable data stays unavailable. No artificial fixture published as actual research. Public examples require explicit admin publication/local export action.

## Two planning layers and uploaded research

`shared/short-plan.mjs` exports `createShortPlan(match, snapshot = null, {now} = {})`. Without data it produces a preliminary template checklist; verified completed daily observations add conditional short-term review actions. It never changes the matched amounts. Timing indicators apply only to equity sleeves. The plan contains `status`, `horizon`, `steps`, `assets`, `coverage`, `dataAsOf`, `source` and `warnings`; it is independent of the longer-term TradingAgents report.

Daily observations require completed, date-valid, USD-verified adjusted history from one series. Current measured rules include SMA20/100 crossovers (101 observations), Bollinger20 with 2 population standard deviations (20), Wilder RSI14 current/previous crossing back above 30 (16), and a team-defined support pin bar or one-session breakout retest reconstructed from 22 dated adjusted OHLC bars. Price Action levels exclude the observation bar and stay fixed during retest verification. Conditions remain watches, not confirmed reversals, proof of institutional activity or orders.

`assets[].volatility` may provide Wilder ATR14, percentage of adjusted close and `illustrativeMultiplier:1.5` / illustrative distance when at least 15 valid daily observations and OHLC are present. ATR is a nondirectional risk tool; no actual stop, share quantity or maximum loss is derived from an adjusted historical close. These observations do not change the fixed-weight historical comparison into a full signal backtest. Definitions and project adaptations are documented in `TRADINGVIEW-SOURCES.md`, with official [RSI](https://www.tradingview.com/support/solutions/43000502338-relative-strength-index-rsi/), [ATR](https://www.tradingview.com/support/solutions/43000501823-average-true-range-atr/) and [Hammer](https://www.tradingview.com/support/solutions/43000583775-hammer-bullish/) references.

AKShare 1.19.1 adds a separately bounded Sina `stock_us_daily(symbol=..., adjust='')` reference request; this integration has returned real unadjusted daily history. [Official AKShare documentation](https://akshare.akfamily.xyz/data/stock/stock.html) describes the endpoint. Store it as `providerReference` with `status:'reference_only'`, `adjustmentVerified:false`, `currency:null`, `currencyVerified:false` and `eligibleForSignals:false`; the source supplies no per-instrument currency metadata. Record provider symbol, date and fallback reason. Indicator calculations continue to use the separate Yahoo Finance USD-verified adjusted series. Never mix these histories, label the raw reference USD-verified, or use it to produce a signal. Failure or timeout leaves a source-specific unavailable result. Browser market fields expose only sanitized source metadata.

No new paid model run is implied by this daily-data integration. The existing saved report retains its dates, original inputs, partial source status and fixed-allocation history. Public deployment and browser visual acceptance remain separate, unfinished verification steps.

Uploaded Markdown/TXT documents are local browser artifacts, limited to 2 MiB each. Preserve original text and filename/import time, distinguish operator-entered and automatically detected report dates, and label extracted text as unverified source excerpts. Never turn imported prose into fabricated allocation, backtest or verified model provenance. No upload is sent to DeepSeek or the backend. Current questionnaire and short-term plan remain independent. A document may be saved, reopened or deleted in the browser's own library. Its full source text is available in an initially collapsed disclosure even when no explicit horizon is detected; opening it renders text only, never executable Markdown/HTML. TradingAgents research supplies medium/long-term context; older short-term material remains readable as part of its original source.
