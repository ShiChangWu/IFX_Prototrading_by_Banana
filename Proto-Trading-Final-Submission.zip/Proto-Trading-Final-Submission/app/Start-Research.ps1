. (Join-Path $PSScriptRoot 'scripts/runtime.ps1')
Set-Location -LiteralPath $ProjectRoot
if (-not (Test-Path -LiteralPath $PythonRuntime)) { throw 'The local Python environment is missing. Run Setup-Research.ps1 first.' }
Write-Host 'Local research worker: keep the computer awake and this terminal open.'
& $PythonRuntime -m worker.main
