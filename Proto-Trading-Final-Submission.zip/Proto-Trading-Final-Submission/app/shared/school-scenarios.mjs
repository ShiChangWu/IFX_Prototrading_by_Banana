// Educational examples. These describe maintained rules; they never place
// orders or infer a future indicator from one assumed stock price.
import { SCHOOL_TESTS, schoolIndicators } from './school-backtest.mjs';

const finite=Number.isFinite;
const money=value=>`$${value.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const rounded=value=>finite(value)?Number(value.toFixed(2)):null;
const day=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&finite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;

export function getSchoolReference(ticker,dataset){
  const data=dataset?.stocks?.[ticker];
  if(!data||data.currency!=='USD'||data.currencyVerified!==true||data.adjusted!==true||!Array.isArray(data.bars)||!data.bars.length||data.bars.length>6000)return null;
  const first=ticker==='SPCX'?'2026-06-12':data.firstTradingDate;
  const valid=data.bars.every((row,index)=>Array.isArray(row)&&row.length===6&&day(row[0])&&row[0]<=dataset.cutoffDate&&(!first||row[0]>=first)&&(!index||row[0]>data.bars[index-1][0])&&[1,2,3,4].every(key=>finite(row[key])&&row[key]>0)&&finite(row[5])&&row[5]>=0&&row[2]>=Math.max(row[1],row[3],row[4])&&row[3]<=Math.min(row[1],row[4]));
  if(!valid||!day(dataset.cutoffDate))return null;
  const bars=data.bars.map(row=>({date:row[0],open:row[1],high:row[2],low:row[3],close:row[4],volume:row[5]}));
  const last=bars.at(-1),indicator=schoolIndicators(bars).at(-1),prior=bars.slice(-21,-1);
  const breakout=bars.slice(-22,-2);
  return {ticker,date:last.date,source:data.source,close:last.close,indicator,
    support:prior.length===20?Math.min(...prior.map(row=>row.low)):null,
    breakout:breakout.length===20?Math.max(...breakout.map(row=>row.high)):null};
}

export function buildSchoolScenario({schoolId,ticker,reference,values={},heldQuantity=0,budget=10000}){
  const school=SCHOOL_TESTS[schoolId];if(!school)throw new Error('Choose a maintained strategy.');
  const hasHolding=finite(heldQuantity)&&heldQuantity>0;
  budget=finite(budget)&&budget>=100&&budget<=1000000?budget:10000;
  const fields=[],cards=[];
  const choice=(key,label,options,initial)=>{const value=options.some(option=>option.value===values[key])?values[key]:initial;fields.push({key,label,type:'select',options,value});return value;};
  const number=(key,label,initial,min=0.01,max=10000000)=>{const raw=Object.hasOwn(values,key)?values[key]:rounded(initial);const value=raw===null||raw===undefined?'':String(raw);fields.push({key,label,type:'number',value,min,max,step:'0.01'});return value.trim()!==''&&finite(Number(value))&&Number(value)>=min&&Number(value)<=max?Number(value):null;};
  const add=(title,text)=>cards.push({title,text});
  const opt=(value,label)=>({value,label});
  const position=hasHolding?`Recorded holding: ${heldQuantity} shares. Review only the shares you actually own.`:'No holding recorded. Exit examples explain a future holding; there is nothing to sell now.';
  const r=reference?.indicator||{};
  let heading='',intro='',observation='',error='';
  const snapshot=parts=>{observation=reference?`Saved ${ticker} · ${reference.date}: ${parts.filter(Boolean).join(' · ')}. Historical adjusted data, not a live signal.`:`No verified saved indicators for ${ticker}. All examples below are assumptions.`;};
  if(schoolId==='defensive'||schoolId==='balanced'){
    const defensive=schoolId==='defensive';
    heading=defensive?'Review the size, protect the reserve':'Rebalance at your scheduled review';
    intro=defensive?'A price move alone is not a trade. Check the amount at your quarterly review.':'Review monthly. Compare this holding with its chosen share of the whole plan.';
    const target=number('targetWeight','My example target weight (%)',defensive?10:25,0,100);
    const actual=number('assumedWeight','Assumed weight at review (%)',defensive?15:32,0,100);
    const event=choice('event','When am I reviewing?',[
      opt('scheduled',defensive?'At my quarterly review':'At my monthly review'),opt('early','Before my scheduled review')],'scheduled');
    snapshot([`close ${money(reference?.close||0)}`]);
    if(target===null||actual===null)error='Enter weights from 0% to 100%.';
    else if(event==='early')add('Wait for the planned review','A daily rise or fall does not trigger rebalancing. Review sooner only if your goals or ability to bear losses changed.');
    else{
      const gap=actual-target,amount=Math.abs(gap)/100*budget;
      if(defensive){
        if(gap>0)add('Above the chosen limit',`If ${ticker} is ${actual}% instead of ${target}%, review reducing the excess ${money(amount)} in this assumed ${money(budget)} plan and restoring the reserve.`);
        else add('Reserve first',`If ${ticker} is ${actual}% against a ${target}% target, keep the reserve intact. A lower weight does not automatically justify another purchase.`);
      }else if(Math.abs(gap)>=5)add(gap>0?'Review an overweight holding':'Review an underweight holding',`If ${ticker} is ${actual}% instead of ${target}%, the gap is ${Math.abs(gap).toFixed(2)} percentage points (${money(amount)} in this assumed plan). Review ${gap>0?'trimming the excess':'restoring the target using available cash'} within the whole portfolio.`);
      else add('Leave the weights alone',`The gap is ${Math.abs(gap).toFixed(2)} percentage points. This demonstration reviews changes of at least 5 points, so no rebalance review is triggered.`);
    }
    add('What this example means',`${defensive?'Quarterly reserve review':'Monthly review with a 5-point tolerance'} is a demo planning convention, separate from the single-stock buy-and-hold backtest. Weights and dollar changes are hypothetical.`);
  }else if(school.mode==='trend'){
    heading='Follow an average crossover';intro='A rising price alone is not enough. Wait for the two completed daily averages to cross.';
    const event=choice('event','Assume the next completed day shows',[
      opt('up','20-day average crosses ABOVE the 100-day average'),opt('down','20-day average crosses BELOW / equals the 100-day average'),opt('none','No new crossover')],'up');
    snapshot([finite(r.sma20)?`20-day average ${money(r.sma20)}`:null,finite(r.sma100)?`100-day average ${money(r.sma100)}`:'100-day average unavailable']);
    if(event==='up')add(hasHolding?'Already holding: no additional entry':'Consider an entry review',`If ${ticker}'s 20-day average was at or below the 100-day average and now crosses above it, ${hasHolding?'the rule does not buy more while a position is already held. Continue checking the exit condition.':'review a purchase at the next session open within your chosen amount.'}`);
    if(event==='down')add('Review an exit for held shares',`If ${ticker}'s completed 20-day average falls to or below the 100-day average, review selling at the next session open.`);
    if(event==='none')add('Wait; do not chase a price rise','Without a new upward crossover, this rule does not open a new position. An existing holding is reviewed if the 20-day average is at or below the 100-day average.');
    add('No fixed profit target','This rule follows the averages. It does not sell just because the price rises 10%, and one assumed price cannot establish a crossover.');
  }else if(school.mode==='rsi'){
    heading='Wait for RSI to recover';intro='RSI measures recent strength from 0 to 100. Below 30 alone is not a buy.';
    const prior=number('priorRsi','Assumed previous daily RSI',28,0,100),next=number('nextRsi','Assumed next daily RSI',34,0,100);
    snapshot([finite(r.rsi)?`14-day RSI ${r.rsi.toFixed(2)}`:'RSI unavailable']);
    if(prior===null||next===null)error='Enter RSI values from 0 to 100.';
    else if(hasHolding&&next>=70)add('High RSI: review an exit',`If ${ticker}'s completed RSI reaches ${next}, the 70 exit threshold is met. Review selling held shares at the next session open.`);
    else if(hasHolding)add('Already holding: check the other exits','RSI is below 70, so its exit threshold is not met. A recovery crossing does not add another position; also check the loss and holding-time rules below.');
    else if(prior<=30&&next>30)add('Recovery: consider an entry review',`If ${ticker}'s completed RSI moves from ${prior} to ${next}, it crosses back above 30. With no holding recorded, the rule reviews buying at the next session open.${next>=70?' Even above 70, the maintained backtest checks entry while flat; it checks exits only once shares are held. This unusual jump does not guarantee a good entry.':''}`);
    else if(next>=70)add('No recovery entry; no holding to exit',`RSI ${next} meets the 70 exit threshold only for an existing holding. These values do not cross back above 30, so this rule has no entry to review.`);
    else add('Wait for a recovery','The assumed values do not cross from 30 or below to above 30, and do not meet the 70 exit threshold. A low share price alone is not an entry.');
    add('Other exit checks','For an existing holding, also review a completed close 5% below its actual entry, or 20 holding sessions. These are close-based reviews; gaps can lose more.');
  }else if(school.mode==='bands'){
    heading='Wait for a return inside the band';intro='Bollinger bands describe a recent price range. Buy only after a fall starts to recover.';
    const event=choice('event','Assume the next completed day shows',[
      opt('recovery','Previous close below lower band; next close back inside'),opt('mean','Held stock closes at / above the 20-day mean'),opt('below','Price stays below the lower band')],'recovery');
    snapshot([finite(r.lower)?`lower band ${money(r.lower)}`:null,finite(r.sma20)?`20-day mean ${money(r.sma20)}`:'band history unavailable']);
    if(event==='recovery')add(hasHolding?'Already holding: no additional entry':'Recovery: consider an entry review',`If ${ticker} closed below the lower band, then closes back at or above its updated lower band, ${hasHolding?'the rule does not buy more while a position is already held. Check the mean, loss and holding-time exit rules.':'review buying at the next session open.'}`);
    if(event==='mean')add('Mean reached: review an exit',`If a held ${ticker} position closes at or above its updated 20-day mean, review selling at the next session open.`);
    if(event==='below')add('Wait; a low price is not enough','Remaining below the band is not the recovery this rule needs. The band must be recalculated from the completed price history.');
    add('Other exit checks','Also review a close 5% below the actual entry or 20 holding sessions. Saved band levels change over time; they are not fixed future targets.');
  }else if(school.mode==='atr'){
    heading='Calculate a trailing risk-review level';intro='ATR measures the size of daily moves. It provides no buy signal.';
    const highest=number('highestClose','Assumed highest close since purchase (USD)',reference?.close);
    const atr=number('atr','Assumed current daily ATR (USD)',r.atr);
    const close=number('nextClose','Assumed next completed close (USD)',finite(reference?.close)&&finite(r.atr)?reference.close-1.6*r.atr:null);
    snapshot([finite(r.atr)?`14-day ATR ${money(r.atr)}`:'ATR unavailable']);
    if(highest===null||atr===null||close===null)error='Enter positive assumed values. No indicator is invented when saved history is missing.';
    else if(highest<=1.5*atr)error='The assumed highest close must exceed 1.5 times ATR.';
    else{
      const effectiveHigh=Math.max(highest,close),level=effectiveHigh-1.5*atr;
      add(`Example trailing level: ${money(level)}`,`${money(effectiveHigh)} highest close − 1.5 × ${money(atr)} ATR. ${close<level?`A ${money(close)} completed close is below it: review selling held ${ticker} shares at the next open.`:`A ${money(close)} completed close is not below it: this exit rule is not triggered.`}`);
      add('Close-based risk review','Recalculate ATR and the highest close each completed day. This is not an intraday stop order, a guaranteed maximum loss or an entry recommendation.');
    }
  }else if(school.mode==='price_action'||school.mode==='wyckoff'){
    const wyckoff=school.mode==='wyckoff';
    heading=wyckoff?'Check a failed breakdown with volume':'Confirm a support reaction';
    intro=wyckoff?'A spring dips below an earlier low, then recovers with stronger volume.':'Wait for a completed candle pattern. Touching a price level is not enough.';
    const event=choice('event','Assume the next completed day shows',wyckoff?[
      opt('spring','Below prior 20-day low, closes above it, volume confirms'),opt('weak','Recovers above the low, but volume does not confirm'),opt('failed','Closes below the prior low')]:[
      opt('pin','A qualifying support pin bar closes above support'),opt('retest','A confirmed breakout retest closes above its level'),opt('none','Touches support without a confirmed pattern')],wyckoff?'spring':'pin');
    const entry=number('entry','Assumed next-session entry price (USD)',reference?.close);
    const atr=number('atr','Assumed signal-day ATR (USD)',r.atr);
    snapshot([finite(reference?.support)?`prior 20-day low ${money(reference.support)}`:null,!wyckoff&&finite(reference?.breakout)?`prior breakout level ${money(reference.breakout)}`:null,finite(r.atr)?`ATR ${money(r.atr)}`:'setup history unavailable']);
    const confirmed=wyckoff?event==='spring':event!=='none';
    if(!confirmed)add('Wait for confirmation',wyckoff?`No spring entry for ${ticker}: both recovery above the prior low and volume above the preceding 20-day median are required.`:`No Price Action entry for ${ticker}: a touch of support alone is not a qualifying pin bar or retest.`);
    else if(hasHolding)add('Already holding: no additional entry',`A new ${wyckoff?'spring':'price-pattern'} setup does not add more ${ticker} under this rule. Review the exits for the existing position using its actual entry and signal-day ATR.`);
    else add('Consider an entry review',wyckoff?`If all three spring conditions are confirmed on a completed ${ticker} daily bar, review an entry at the next session open.`:`If ${ticker} completes the ${event==='pin'?'support pin-bar':'breakout-retest'} conditions, review an entry at the next session open.`);
    if(entry===null||atr===null)error='Enter a positive assumed entry and ATR to calculate example exit levels.';
    else if(entry<=1.5*atr)error='The assumed entry price must exceed 1.5 times ATR.';
    else{
      const distance=1.5*atr;
      add(`After an assumed entry at ${money(entry)}`,`Using ${money(atr)} signal-day ATR: review a close at / below ${money(entry-distance)} for loss control, or at / above ${money(entry+2*distance)} for a 2R target. Otherwise review after 20 holding sessions. These inputs are assumptions, not recorded fills. Execution is at the next open, which may differ.`);
    }
    add(wyckoff?'A limited spring study':'What must be confirmed',wyckoff?'This is a defined daily spring proxy, not a detection of all Wyckoff phases or institutional intent.':'Pin bar: nonzero body, lower wick at least 2× body, upper wick no larger than the body, close in the top third and back above touched support. Retest: close was at / below the level two sessions ago, broke above yesterday, then retested and closed above today.');
  }else if(schoolId==='ict'){
    heading='Study an intraday setup';intro='ICT needs session-aware intraday evidence. This demo cannot verify it.';
    const event=choice('event','Choose a learning example',[
      opt('sweep','Price sweeps a prior high / low and returns'),opt('gap','Price revisits a fair-value gap')],'sweep');
    add(event==='sweep'?'Liquidity-sweep checklist':'Fair-value-gap checklist',event==='sweep'?`For ${ticker}, inspect the session, prior swing, sweep and completed recovery on intraday candles. A daily low alone does not prove a sweep.`:`For ${ticker}, first identify the three-candle intraday gap and session context. A price touch alone is not an entry confirmation.`);
    add('Learning only — data not connected','No verified ICT entry, exit, backtest or return is generated. The app does not supply the required session-aware intraday setup engine.');
  }else{
    heading='Read actual trades and the order book';intro='Order Flow needs tick trades and order-book data. Daily volume cannot replace them.';
    const event=choice('event','Choose a learning example',[
      opt('imbalance','Buying / selling imbalance'),opt('absorption','Large orders absorb repeated trades')],'imbalance');
    add(event==='imbalance'?'Imbalance checklist':'Absorption checklist',event==='imbalance'?`For ${ticker}, compare executed bid/ask volume and order-book changes. A green daily candle does not establish an order-flow imbalance.`:`For ${ticker}, inspect repeated executions at a level and the remaining orders. Daily volume alone cannot verify absorption.`);
    add('Learning only — data not connected','Tick trades and depth-of-book data are unavailable. This demo produces no Order Flow entry, exit, backtest or return.');
  }
  return {schoolId,ticker,heading,intro,fields,cards,observation,error,position};
}
