import { ASSETS } from './strategy.mjs';
import { SCHOOL_TESTS } from './school-backtest.mjs';

// Team-authored teaching rubric. It measures neither performance nor personal suitability.
export const SCHOOL_BLURBS = Object.freeze({
  defensive: 'Keep a larger reserve and start with a smaller investment.',
  balanced: 'Spread money across different assets and review the mix regularly.',
  trend: 'Follow a rising trend after shorter and longer averages agree.',
  mean_reversion: 'Wait for a sharp price drop to begin recovering.',
  rsi: 'Use RSI to check whether recent selling pressure is easing.',
  price_action: 'Study how the price reacts around earlier turning points.',
  atr: 'Use typical daily price movement to understand exit-review distances.',
  wyckoff: 'Study failed price breakdowns together with trading volume.',
  ict: 'Learn how intraday traders study previous highs, lows and gaps.',
  order_flow: 'Study individual trades and orders to understand short-term activity.',
});

const freeze = value => {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
};

export const SCHOOL_FIT_RUBRIC = freeze({
  version: 'educational-fit-v1',
  title: 'Educational fit for your selected stocks',
  method: 'Team-maintained teaching preferences, equally averaged across selected tickers.',
  weights: { assetCompatibility: 45, beginnerEase: 30, historyCoverage: 25 },
  descriptions: {
    assetCompatibility: 'Team preference for using each asset class to explain this approach; not measured future performance.',
    beginnerEase: 'Team judgement of rule simplicity for a first-time learner; independent of the selected ticker.',
    historyCoverage: '100 when verified saved daily USD history has the required warm-up plus two observations; otherwise 0.',
  },
  assetCompatibility: {
    defensive: { stock: 30, equity_etf: 55, short_treasury_etf: 95, treasury_etf: 80, gold_etf: 60, unknown: 0 },
    balanced: { stock: 70, equity_etf: 90, short_treasury_etf: 80, treasury_etf: 85, gold_etf: 80, unknown: 0 },
    trend: { stock: 85, equity_etf: 95, short_treasury_etf: 15, treasury_etf: 55, gold_etf: 65, unknown: 0 },
    mean_reversion: { stock: 75, equity_etf: 90, short_treasury_etf: 10, treasury_etf: 45, gold_etf: 55, unknown: 0 },
    rsi: { stock: 80, equity_etf: 90, short_treasury_etf: 10, treasury_etf: 45, gold_etf: 60, unknown: 0 },
    price_action: { stock: 85, equity_etf: 80, short_treasury_etf: 10, treasury_etf: 40, gold_etf: 55, unknown: 0 },
    atr: { stock: 90, equity_etf: 85, short_treasury_etf: 15, treasury_etf: 60, gold_etf: 65, unknown: 0 },
    wyckoff: { stock: 70, equity_etf: 55, short_treasury_etf: 5, treasury_etf: 25, gold_etf: 40, unknown: 0 },
    ict: { stock: 60, equity_etf: 55, short_treasury_etf: 0, treasury_etf: 20, gold_etf: 35, unknown: 0 },
    order_flow: { stock: 60, equity_etf: 55, short_treasury_etf: 0, treasury_etf: 20, gold_etf: 35, unknown: 0 },
  },
  beginnerEase: { defensive: 100, balanced: 95, trend: 75, mean_reversion: 55, rsi: 60, price_action: 45, atr: 65, wyckoff: 25, ict: 15, order_flow: 10 },
  learningOnlyCaps: { ict: 20, order_flow: 20 },
  maximumTickers: 8,
  aggregation: 'Each selected ticker contributes equally, regardless of its simulated allocation or holding size.',
  exclusions: 'No return, win rate, price forecast, AI output or probability enters this score.',
});

const finite = Number.isFinite;
const validTicker = value => typeof value === 'string' && /^[A-Z0-9][A-Z0-9.\-^=]{0,14}$/.test(value) && value !== 'CASH';
const dateOnly = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)
  && finite(Date.parse(value + 'T00:00:00Z')) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;
const round = value => Math.round(value * 100) / 100;
const maintained = new Map(ASSETS.map(asset => [asset.ticker, asset]));

function metadata(ticker) {
  const known = maintained.get(ticker);
  if (known) return { assetClass: known.assetClass, assetClassSource: 'maintained', firstTradingDate: known.firstTradingDate };
  // Directory labels and caller-supplied classes are not independently verified.
  // Keep unclassified selected securities in the average with zero compatibility.
  return { assetClass: 'unknown', assetClassSource: 'unverified' };
}

function coverage(school, ticker, asset, dataset) {
  const data = dataset?.stocks?.[ticker], required = (school.warmup || 0) + 2;
  const result = { available: false, observations: Array.isArray(data?.bars) ? data.bars.length : 0, required, reason: '' };
  if (!school.mode) return { ...result, reason: 'The required intraday or order-level rule test is not implemented.' };
  if (!data || data.currency !== 'USD' || data.currencyVerified !== true || data.adjusted !== true) return { ...result, reason: 'Verified adjusted USD history is missing.' };
  if (!dateOnly(dataset.cutoffDate) || !Array.isArray(data.bars) || data.bars.length > 6000) return { ...result, reason: 'Saved history metadata or observation count is invalid.' };
  const firstTradingDate = asset.firstTradingDate || data.firstTradingDate;
  if (firstTradingDate && !dateOnly(firstTradingDate)) return { ...result, reason: 'The security identity date is unverified.' };
  if (!data.bars.every((bar, index) => Array.isArray(bar) && bar.length === 6 && dateOnly(bar[0])
    && bar[0] <= dataset.cutoffDate && (!firstTradingDate || bar[0] >= firstTradingDate)
    && (!index || data.bars[index - 1][0] < bar[0])
    && [1, 2, 3, 4].every(field => finite(bar[field]) && bar[field] > 0)
    && finite(bar[5]) && bar[5] >= 0
    && bar[2] >= Math.max(bar[1], bar[3], bar[4]) && bar[3] <= Math.min(bar[1], bar[4]))) return { ...result, reason: 'Saved price history or security identity failed validation.' };
  if (data.bars.length < required) return { ...result, reason: 'The saved series is too short for warm-up plus two test sessions.' };
  return { ...result, available: true, reason: 'Verified daily history supports a rule test.', cutoffDate: dataset.cutoffDate };
}

function componentsFor(assetCompatibility, beginnerEase, historyCoverage) {
  return Object.fromEntries(Object.entries({ assetCompatibility, beginnerEase, historyCoverage }).map(([key, score]) => [key, {
    score: round(score), weight: SCHOOL_FIT_RUBRIC.weights[key], weightedPoints: round(score * SCHOOL_FIT_RUBRIC.weights[key] / 100),
  }]));
}

export function scoreSchoolFit(schoolId, { tickers = [], assets = [] } = {}, dataset = {}) {
  if (!Object.hasOwn(SCHOOL_TESTS, schoolId)) throw new Error('Choose a maintained strategy to calculate educational fit.');
  const school = SCHOOL_TESTS[schoolId];
  const limits = ['Educational fit is a team-authored heuristic, not a return forecast, success probability, AI assessment or personal investment recommendation.',
    'All selected stocks receive equal influence. Simulated dollar weights, holdings, risk capacity and market returns are not evaluated.',
    'Historical coverage means the packaged data can support a rule test. It does not mean that the data is current or that a trade condition is present.'];
  const rawTickers = Array.isArray(tickers) ? tickers : [];
  const normal = rawTickers.map(ticker => typeof ticker === 'string' ? ticker.trim().toUpperCase() : ticker);
  const unique = [...new Set(normal.filter(validTicker))];
  if (!Array.isArray(tickers) || normal.some(ticker => !validTicker(ticker))) limits.push('Invalid symbols and cash were omitted; no asset class was inferred from their spelling.');
  if (unique.length < normal.filter(validTicker).length) limits.push('Repeated symbols were counted once.');
  if (unique.length > SCHOOL_FIT_RUBRIC.maximumTickers) limits.push('Only the first eight unique selected stocks are included.');
  const selected = unique.slice(0, SCHOOL_FIT_RUBRIC.maximumTickers);
  const learningOnly = Object.hasOwn(SCHOOL_FIT_RUBRIC.learningOnlyCaps, schoolId), riskToolOnly = schoolId === 'atr';
  const cap = learningOnly ? SCHOOL_FIT_RUBRIC.learningOnlyCaps[schoolId] : 100;
  if (learningOnly) limits.push('Learning guide only: the required rule engine and data are absent. Fit is capped at 20/100 and daily history earns no coverage points.');
  if (riskToolOnly) limits.push('ATR is a risk tool, not a standalone entry strategy. This score does not recommend buying a stock.');
  if (['defensive', 'balanced'].includes(schoolId)) limits.push('An asset-by-asset learning score does not establish whether your complete allocation is diversified or appropriate.');
  if (!selected.length) return { schoolId, kind: 'educational_fit', version: SCHOOL_FIT_RUBRIC.version, score: null, rawScore: null,
    perTicker: [], components: null, shortReason: 'Select stocks to see an educational fit score.', limits, learningOnly, riskToolOnly, cap };
  const perTicker = selected.map(ticker => {
    const asset = metadata(ticker), history = coverage(school, ticker, asset, dataset);
    const compatibility = SCHOOL_FIT_RUBRIC.assetCompatibility[schoolId][asset.assetClass] ?? 0;
    const components = componentsFor(compatibility, SCHOOL_FIT_RUBRIC.beginnerEase[schoolId], history.available ? 100 : 0);
    const rawScore = round(Object.values(components).reduce((total, part) => total + part.weightedPoints, 0));
    return { ticker, assetClass: asset.assetClass, assetClassSource: asset.assetClassSource, score: Math.min(cap, Math.round(rawScore)), rawScore, components, history };
  });
  const average = key => perTicker.reduce((sum, row) => sum + row.components[key].score, 0) / perTicker.length;
  const components = componentsFor(average('assetCompatibility'), average('beginnerEase'), average('historyCoverage'));
  const rawScore = round(Object.values(components).reduce((total, part) => total + part.weightedPoints, 0)), score = Math.min(cap, Math.round(rawScore));
  const unknownCount = perTicker.filter(item => item.assetClass === 'unknown').length, missing = perTicker.filter(item => !item.history.available).length;
  if (unknownCount) limits.push('Only maintained asset definitions supply classifications. Other selected assets stay in the average with zero compatibility points, even when a directory or caller supplies a type.');
  if (missing && !learningOnly) limits.push(`${missing} of ${perTicker.length} selected stocks lack validated history long enough for this test; they receive zero history points.`);
  const shortReason = learningOnly ? 'Learning only: required trading data is not implemented.'
    : riskToolOnly ? 'Risk sizing aid, not a stock-entry recommendation.'
    : unknownCount ? 'Some selected asset types are unverified.'
    : missing === perTicker.length ? 'Selected stocks need verified history before meaningful rule testing.'
    : missing ? 'Some selected stocks lack enough verified historical data.'
    : score >= 75 ? 'Clearer rules and stronger data coverage for your selection.'
    : score >= 50 ? 'Usable learning rules; review the trade-offs first.'
    : 'This approach adds complexity for your selected assets.';
  return { schoolId, kind: 'educational_fit', version: SCHOOL_FIT_RUBRIC.version, score, rawScore, perTicker, components, shortReason, limits, learningOnly, riskToolOnly, cap };
}
