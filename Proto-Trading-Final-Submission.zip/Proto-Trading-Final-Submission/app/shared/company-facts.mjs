// Maintained primary-source earnings snapshot, checked on 2026-10-04.
// All amounts below are actual reported quarterly results, never forecasts.
// Source tables express revenue/net income in millions; store full USD here.
export const COMPANY_FACTS_AS_OF = '2026-10-04';

const freeze = value => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) {
    Object.values(value).forEach(freeze);
    Object.freeze(value);
  }
  return value;
};

const educationalNotes = {
  revenue: 'Revenue is money earned from selling products and services before expenses. It is not the same as profit.',
  growth: 'Year-over-year growth compares this quarter with the corresponding quarter one year earlier. It does not predict the share price.',
  eps: 'GAAP diluted EPS is reported profit or loss per share after allowing for potential additional shares. It is not a cash dividend.',
};

function record(input) {
  return {
    ...input,
    asOfDate: COMPANY_FACTS_AS_OF,
    latestAvailableChecked: true,
    lastCheckedDate: COMPANY_FACTS_AS_OF,
    coverage: 'maintained_snapshot',
    coverageNote: 'Five selected companies; latest quarterly results found in primary sources as of the checked date. No live financial-statement feed.',
    periodType: 'quarter',
    currency: 'USD',
    accountingBasis: 'US GAAP',
    audited: false,
    whyItMatters: educationalNotes,
  };
}

export const COMPANY_FACTS = freeze({
  AMD: record({
    ticker: 'AMD', companyName: 'Advanced Micro Devices, Inc.',
    periodLabel: 'Q2 2026', periodEnd: '2026-06-27', releaseDate: '2026-08-04',
    revenue: { value: 11536000000, unit: 'USD', priorYearValue: 7685000000, priorYearPeriodEnd: '2025-06-28', yoyPct: 50, yoyPrecision: 0, basis: 'GAAP', sourceIds: ['earnings'] },
    dilutedEPS: { value: 1.38, priorYearValue: 0.54, unit: 'USD/share', basis: 'GAAP diluted', sourceIds: ['earnings'] },
    netIncome: { value: 2297000000, unit: 'USD', basis: 'GAAP', sourceIds: ['earnings'] },
    sources: [{ id: 'earnings', title: 'AMD second-quarter 2026 financial results', publisher: 'AMD Investor Relations', publishedAt: '2026-08-04', url: 'https://ir.amd.com/news-events/press-releases/detail/1295/amd-reports-second-quarter-2026-financial-results', locator: 'GAAP Quarterly Financial Results; condensed statements of operations, three months ended June 27, 2026' }],
    latestCheckUrl: 'https://ir.amd.com/financial-information/financial-results',
    caveats: ['EPS includes continuing and discontinued operations. It is the reported $1.38 GAAP figure, not $1.66 non-GAAP EPS.', 'The prior-year quarter included $800 million of inventory and related export-control charges, which affects comparisons.'],
  }),
  NVDA: record({
    ticker: 'NVDA', companyName: 'NVIDIA Corporation',
    periodLabel: 'Q2 FY2027', periodEnd: '2026-07-26', releaseDate: '2026-08-26',
    revenue: { value: 96221000000, unit: 'USD', priorYearValue: 46743000000, priorYearPeriodEnd: '2025-07-27', yoyPct: 106, yoyPrecision: 0, basis: 'GAAP', sourceIds: ['earnings'] },
    dilutedEPS: { value: 2.46, priorYearValue: 1.08, unit: 'USD/share', basis: 'GAAP diluted', sourceIds: ['earnings'] },
    netIncome: { value: 59688000000, unit: 'USD', basis: 'GAAP', sourceIds: ['earnings'] },
    sources: [{ id: 'earnings', title: 'NVIDIA second-quarter fiscal 2027 financial results', publisher: 'NVIDIA Investor Relations', publishedAt: '2026-08-26', url: 'https://investor.nvidia.com/news/press-release-details/2026/NVIDIA-Announces-Financial-Results-for-Second-Quarter-Fiscal-2027/', locator: 'Condensed consolidated statements of income; GAAP EPS reconciliation, three months ended July 26, 2026' }],
    latestCheckUrl: 'https://investor.nvidia.com/financial-info/quarterly-results/default.aspx',
    caveats: ['FY2027 is NVIDIA’s fiscal-year label; this quarter ended in calendar year 2026.', 'GAAP EPS includes investment-related gains. The $2.22 non-GAAP EPS figure is a different measure and is not substituted here.'],
  }),
  AAPL: record({
    ticker: 'AAPL', companyName: 'Apple Inc.',
    periodLabel: 'Q3 FY2026', periodEnd: '2026-06-27', releaseDate: '2026-07-30',
    revenue: { value: 109417000000, unit: 'USD', priorYearValue: 94036000000, priorYearPeriodEnd: '2025-06-28', yoyPct: 16, yoyPrecision: 0, basis: 'GAAP', sourceIds: ['statements', 'earnings'] },
    dilutedEPS: { value: 2.02, priorYearValue: 1.57, unit: 'USD/share', basis: 'GAAP diluted', sourceIds: ['statements'] },
    netIncome: { value: 29789000000, unit: 'USD', basis: 'GAAP', sourceIds: ['statements'] },
    sources: [
      { id: 'earnings', title: 'Apple third-quarter 2026 results', publisher: 'Apple Newsroom', publishedAt: '2026-07-30', url: 'https://www.apple.com/newsroom/2026/07/apple-reports-third-quarter-results/', locator: 'Reported revenue growth and diluted EPS; tariff-refund explanation' },
      { id: 'statements', title: 'Apple FY2026 Q3 consolidated financial statements', publisher: 'Apple', publishedAt: '2026-07-30', url: 'https://www.apple.com/newsroom/pdfs/fy2026q3/FY26_Q3_Consolidated_Financial_Statements.pdf', locator: 'Page 1, three months ended June 27, 2026 and June 28, 2025' },
    ],
    latestCheckUrl: 'https://www.apple.com/newsroom/topics/company-news/',
    caveats: ['Reported diluted EPS includes a favorable $0.11 impact from tariff refunds. This benefit should not automatically be repeated in future-quarter forecasts.'],
  }),
  MSFT: record({
    ticker: 'MSFT', companyName: 'Microsoft Corporation',
    periodLabel: 'Q4 FY2026', periodEnd: '2026-06-30', releaseDate: '2026-07-29',
    revenue: { value: 90007000000, unit: 'USD', priorYearValue: 76441000000, priorYearPeriodEnd: '2025-06-30', yoyPct: 18, yoyPrecision: 0, basis: 'GAAP', sourceIds: ['earnings'] },
    dilutedEPS: { value: 4.81, priorYearValue: 3.65, unit: 'USD/share', basis: 'GAAP diluted', sourceIds: ['earnings'] },
    netIncome: { value: 35766000000, unit: 'USD', basis: 'GAAP', sourceIds: ['earnings'] },
    sources: [{ id: 'earnings', title: 'Microsoft FY2026 fourth-quarter results', publisher: 'Microsoft Investor Relations', publishedAt: '2026-07-29', url: 'https://www.microsoft.com/en-us/investor/earnings/fy-2026-q4/press-release-webcast', locator: 'Three months ended June 30: income statement and GAAP/non-GAAP reconciliation' }],
    latestCheckUrl: 'https://www.microsoft.com/en-us/investor/earnings/fy-2026-q4/press-release-webcast',
    caveats: ['These are quarterly results, not the $331.8 billion full-year revenue or $17.95 full-year EPS on the same page.', 'The $4.81 GAAP diluted EPS includes investment effects and other discrete items. Non-GAAP EPS of $4.74 is a separate measure.'],
  }),
  SPCX: record({
    ticker: 'SPCX', companyName: 'Space Exploration Technologies Corp. (SpaceX)',
    periodLabel: 'Q2 2026', periodEnd: '2026-06-30', releaseDate: '2026-08-04',
    revenue: { value: 7814000000, unit: 'USD', priorYearValue: 4071000000, priorYearPeriodEnd: '2025-06-30', yoyPct: 91.9, yoyPrecision: 1, basis: 'GAAP', sourceIds: ['10q'] },
    dilutedEPS: { value: -0.09, priorYearValue: -0.34, unit: 'USD/share', basis: 'GAAP diluted', label: 'Diluted loss per share', sourceIds: ['10q'] },
    netIncome: { value: -541000000, unit: 'USD', basis: 'GAAP', label: 'Net loss', sourceIds: ['10q'] },
    sources: [
      { id: '10q', title: 'SpaceX June 2026 Form 10-Q', publisher: 'SpaceX filing with the US SEC', publishedAt: '2026-08-04', url: 'https://www.sec.gov/Archives/edgar/data/1181412/000162828026052535/spcx-20260630.htm', locator: 'Consolidated statements of operations; Note 13 EPS; MD&A total-company revenue table' },
      { id: 'filing-index', title: 'SEC filing date and report period', publisher: 'US SEC EDGAR', publishedAt: '2026-08-04', url: 'https://www.sec.gov/Archives/edgar/data/1181412/000162828026052535/0001628280-26-052535-index.html', locator: 'Filed August 4, 2026; period of report June 30, 2026' },
    ],
    latestCheckUrl: 'https://ir.spacex.com/financials/',
    identity: { cik: '0001181412', exchange: 'Nasdaq', listedSince: '2026-06-12', priorTickerUse: 'SPCX previously identified a different issuer’s SPAC ETF, which changed its symbol to SPCK on 2026-04-07.', sourceUrls: ['https://ir.spacex.com/updates/releases-details/2026/Space-Exploration-Technologies-Corp--Announces-Closing-of-Initial-Public-Offering-Including-Full-Exercise-of-Underwriters-Option-to-Purchase-Additional-Shares-2026-RgoR-Y1Vwh/default.aspx', 'https://www.nasdaq.com/press-release/tuttle-capitals-spac-and-new-issue-etf-change-ticker-spck-2026-04-07'] },
    caveats: ['The company still reported a quarterly loss; revenue growth does not mean it was profitable.', 'Reported figures cover Space, Connectivity and AI. Comparisons use the company’s presented consolidated 2025 figures; the filing also describes common-control mergers.', 'SpaceX began public trading on June 12, 2026. Earlier prices under the reused SPCX ticker must not be treated as SpaceX history.'],
  }),
});

function validDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)
    && Number.isFinite(Date.parse(value + 'T00:00:00Z'))
    && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;
}

// Date-level report enrichment only: not suitable for intraday or signal backtests.
// An older report must never receive results released after its analysis date.
export function getCompanyFacts(ticker, reportDate = COMPANY_FACTS_AS_OF) {
  if (typeof ticker !== 'string' || !validDate(reportDate)) return null;
  const symbol = ticker.trim().toUpperCase();
  if (!Object.hasOwn(COMPANY_FACTS, symbol)) return null;
  const facts = COMPANY_FACTS[symbol];
  if (facts.releaseDate > reportDate) return null;
  return { ...facts, requestedAsOfDate: reportDate,
    latestAvailableChecked: reportDate <= COMPANY_FACTS_AS_OF,
    freshness: reportDate > COMPANY_FACTS_AS_OF ? 'snapshot_not_refreshed' : 'maintained_snapshot',
  };
}
