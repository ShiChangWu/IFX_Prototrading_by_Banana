// Team-defined educational rule tests, not a claim to reproduce an entire school.
export const SCHOOL_TESTS = {
  defensive:{label:'Steady foundation',aliases:'\u9632\u5b88 \u914d\u7f6e \u7a33\u5065',summary:'Keep a large reserve and learn how a smaller stock holding behaves.',tickers:['AAPL','MSFT','SPY'],mode:'hold',warmup:0,scope:'Single-stock buy-and-hold comparison; it does not test the defensive multi-asset allocation.',entry:'Buy at the first available open in the selected period.',exit:'Sell at the final close. Cash interest is zero.'},
  balanced:{label:'Everyday balance',aliases:'\u5747\u8861 \u5e73\u8861 \u914d\u7f6e',summary:'Spread the money across different assets and review it regularly.',tickers:['MSFT','AAPL','SPY','QQQ'],mode:'hold',warmup:0,scope:'Single-stock buy-and-hold comparison; it does not test the balanced multi-asset allocation.',entry:'Buy at the first available open in the selected period.',exit:'Sell at the final close. Use the portfolio report for the separate multi-asset comparison.'},
  trend:{label:'Moving-average trend',aliases:'\u5747\u7ebf \u8d8b\u52bf ma sma',summary:'Follow an established upward trend; accept that the signal can arrive late.',tickers:['AAPL','MSFT','NVDA','AMD'],mode:'trend',warmup:100,scope:'Team 20/100-day moving-average crossover test.',entry:'After the 20-day average crosses above the 100-day average, buy at the next session open.',exit:'After the 20-day average crosses below or equals the 100-day average, sell at the next open.'},
  mean_reversion:{label:'Bollinger pullback',aliases:'\u5e03\u6797\u5e26 \u5747\u503c\u56de\u5f52 bollinger',summary:'Wait for a sharp pullback to start recovering; a cheap-looking price can still fall.',tickers:['QQQ','AMD','MSFT'],mode:'bands',warmup:20,scope:'Team Bollinger recovery test; not the source script or its results.',entry:'A close below the lower 20-day, 2-standard-deviation band, then a close back at or above it: buy next open.',exit:'Sell next open after a close reaches the 20-day mean, falls 5% below entry, or after 20 holding sessions.'},
  rsi:{label:'RSI recovery',aliases:'\u8d85\u5356 \u5f3a\u5f31 \u76f8\u5bf9\u5f3a\u5f31',summary:'Look for weakness to ease before acting. RSI below 30 alone is not a buy.',tickers:['QQQ','AMD','NVDA','SPCX'],mode:'rsi',warmup:15,scope:'Team RSI recovery test; not every possible RSI strategy.',entry:'After 14-day Wilder RSI crosses from 30 or below to above 30, buy next open.',exit:'Sell next open after RSI reaches 70, a close falls 5% below entry, or after 20 holding sessions.'},
  price_action:{label:'Price Action',aliases:'\u88f8k \u4ef7\u683c\u884c\u4e3a pin bar retest',summary:'Watch how a price reacts near an earlier low or breakout level.',tickers:['NVDA','AMD','SPCX'],mode:'price_action',warmup:21,scope:'Team daily pin-bar/retest test, with explicit exit rules added for this simulation.',entry:'A support pin bar or one-session breakout retest at a fixed prior 20-day level: buy next open.',exit:'Use 1.5× signal-day ATR as a distance. After a close is 1 distance below or 2 distances above entry, sell next open; otherwise exit after 20 holding sessions.'},
  atr:{label:'ATR risk tool',aliases:'\u6ce2\u52a8 \u98ce\u63a7 \u6b62\u635f',summary:'ATR measures the size of daily moves. It does not tell you which direction to buy.',tickers:['NVDA','AMD','SPCX'],mode:'atr',warmup:15,scope:'One initial purchase plus an ATR exit illustration; this is not an ATR entry signal.',entry:'Buy once at the first available open, using only earlier data to establish that ATR history is available.',exit:'When a close is below the highest close since entry minus 1.5× current ATR, sell next open. No re-entry. This close-based review is not an intraday stop order.'},
  wyckoff:{label:'Wyckoff spring study',aliases:'\u5a01\u79d1\u592b spring \u6210\u4ea4\u91cf',summary:'Study a failed break below an earlier range, together with volume.',tickers:['AMD','NVDA','MSFT'],mode:'wyckoff',warmup:20,scope:'A team-defined daily spring proxy only. It does not identify full Wyckoff phases or institutional intentions.',entry:'Price goes below the preceding 20-day low, closes above it, and volume exceeds the preceding 20-day median: buy next open.',exit:'Use the same ATR-distance, close-based exits and 20-session holding limit as the Price Action test.'},
  ict:{label:'ICT learning guide',aliases:'\u6d41\u52a8\u6027 fvg \u7f3a\u53e3',summary:'Learn why intraday traders watch old highs, lows and price gaps.',tickers:['NVDA','AMD','SPCX'],mode:null,scope:'Intraday/session-aware rules and data have not been implemented. Daily closes cannot verify this school’s intraday claims.'},
  order_flow:{label:'Order Flow learning guide',aliases:'\u8ba2\u5355\u6d41 footprint delta \u76d8\u53e3',summary:'Study actual trades and orders to understand very short-term buying and selling.',tickers:['AAPL','AMD','MSFT'],mode:null,scope:'Requires tick trades and order-book evidence. This app has daily OHLCV only, so no order-flow backtest or return is fabricated.'},
};

const finite=Number.isFinite;
const day=value=>typeof value==='string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && finite(Date.parse(value+'T00:00:00Z')) && new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
const average=values=>values.reduce((sum,n)=>sum+n,0)/values.length;
const median=values=>{const v=[...values].sort((a,b)=>a-b);const mid=Math.floor(v.length/2);return v.length%2?v[mid]:(v[mid-1]+v[mid])/2;};
export function schoolIndicators(bars){
  const rows=[];let gains=0,losses=0,atr=0;
  for(let i=0;i<bars.length;i++){
    const closes=bars.slice(Math.max(0,i-19),i+1).map(bar=>bar.close);
    const mean=closes.length===20?average(closes):null;
    const deviation=mean===null?null:Math.sqrt(average(closes.map(value=>(value-mean)**2)));
    let rsi=null;
    if(i>0){const diff=bars[i].close-bars[i-1].close;const gain=Math.max(diff,0),loss=Math.max(-diff,0);if(i<=14){gains+=gain/14;losses+=loss/14;}else{gains=(gains*13+gain)/14;losses=(losses*13+loss)/14;}if(i>=14)rsi=losses===0?(gains===0?50:100):100-100/(1+gains/losses);}
    const tr=i===0?bars[i].high-bars[i].low:Math.max(bars[i].high-bars[i].low,Math.abs(bars[i].high-bars[i-1].close),Math.abs(bars[i].low-bars[i-1].close));
    if(i<14)atr+=tr/14;else atr=(atr*13+tr)/14;
    rows.push({sma20:mean,sma100:i>=99?average(bars.slice(i-99,i+1).map(bar=>bar.close)):null,lower:mean===null?null:mean-2*deviation,rsi,atr:i>=13?atr:null});
  }return rows;
}
export function schoolEntryCondition(mode,bars,ind,i){
  const current=ind[i],previous=ind[i-1],bar=bars[i];if(!previous)return false;
  if(mode==='trend')return finite(previous.sma100)&&previous.sma20<=previous.sma100&&current.sma20>current.sma100;
  if(mode==='rsi')return finite(previous.rsi)&&previous.rsi<=30&&current.rsi>30;
  if(mode==='bands')return finite(previous.lower)&&bars[i-1].close<previous.lower&&bar.close>=current.lower;
  if(mode==='wyckoff'){if(i<20)return false;const prior=bars.slice(i-20,i);const low=Math.min(...prior.map(row=>row.low));return bar.low<low&&bar.close>low&&bar.volume>median(prior.map(row=>row.volume));}
  if(mode==='price_action'){
    if(i<21)return false;const support=Math.min(...bars.slice(i-20,i).map(row=>row.low));const level=Math.max(...bars.slice(i-21,i-1).map(row=>row.high));
    const body=Math.abs(bar.close-bar.open),range=bar.high-bar.low,lower=Math.min(bar.open,bar.close)-bar.low,upper=bar.high-Math.max(bar.open,bar.close);
    const pin=range>0&&body>0&&lower>=2*body&&upper<=body&&(bar.close-bar.low)/range>=2/3&&bar.low<=support&&bar.close>support;
    const retest=bars[i-1].close>level&&bars[i-2].close<=level&&bar.low<=level&&bar.close>level;
    return (pin||retest)&&current.atr>0;
  }return false;
}
export function runSchoolBacktest({schoolId,ticker,startDate,endDate,feePct=0.1,budget=10000,allowedTickers},dataset){
  const school=SCHOOL_TESTS[schoolId];if(!school)throw new Error('Choose a maintained strategy.');
  if(!school.mode)throw new Error(school.scope);
  if(allowedTickers!==undefined&&(!Array.isArray(allowedTickers)||allowedTickers.length>8||new Set(allowedTickers).size!==allowedTickers.length||!allowedTickers.every(t=>typeof t==='string'&&/^[A-Z0-9][A-Z0-9.\-^=]{0,14}$/.test(t)&&t!=='CASH')))throw new Error('Choose up to eight valid stocks or ETFs.');
  if(!(allowedTickers??school.tickers).includes(ticker))throw new Error('Choose a stock from your current selection.');
  if(!day(startDate)||!day(endDate)||startDate>=endDate)throw new Error('Choose a valid start date before the end date.');
  if(!finite(feePct)||feePct<0||feePct>5||!finite(budget)||budget<100||budget>1000000)throw new Error('Use a fee from 0% to 5% per trade side and a budget from $100 to $1,000,000.');
  const data=dataset?.stocks?.[ticker];if(!data||data.currency!=='USD'||data.currencyVerified!==true||data.adjusted!==true)throw new Error('Verified adjusted USD history is unavailable for this ticker.');
  if(!day(dataset.cutoffDate)||endDate>dataset.cutoffDate)throw new Error(`Saved data ends on ${dataset?.cutoffDate||'an unknown date'}. Choose an end date within the data window.`);
  const issuerStart=ticker==='SPCX'?'2026-06-12':data.firstTradingDate;
  if(issuerStart&&startDate<issuerStart)throw new Error(`${ticker} means SpaceX here. Its history starts ${issuerStart}; earlier prices belong to a different security.`);
  if(!Array.isArray(data.bars)||data.bars.length>6000)throw new Error('The saved price series is invalid.');
  const bars=data.bars.map((row,i)=>{
    if(!Array.isArray(row)||row.length!==6||!day(row[0])||(i&&data.bars[i-1][0]>=row[0])||row[0]>dataset.cutoffDate||(issuerStart&&row[0]<issuerStart)||![1,2,3,4].every(n=>finite(row[n])&&row[n]>0)||!finite(row[5])||row[5]<0||row[2]<Math.max(row[1],row[3],row[4])||row[3]>Math.min(row[1],row[4]))throw new Error('Saved OHLCV or security identity failed validation.');
    return {date:row[0],open:row[1],high:row[2],low:row[3],close:row[4],volume:row[5]};
  });
  if(!bars.length||startDate<bars[0].date||endDate>bars.at(-1).date)throw new Error(`Available history: ${bars[0]?.date||'none'} to ${bars.at(-1)?.date||'none'}. No missing history is filled in.`);
  const first=bars.findIndex(bar=>bar.date>=startDate),last=bars.findLastIndex(bar=>bar.date<=endDate);
  if(first<school.warmup)throw new Error(`${school.label} needs ${school.warmup} earlier trading sessions. Choose a later start; newly listed stocks may not have enough history.`);
  if(first<0||last-first<1)throw new Error('Choose a window with at least two recorded trading sessions.');
  const ind=schoolIndicators(bars.slice(0,last+1)),fee=feePct/100,orders=[],series=[],closed=[];
  let cash=budget,units=0,pending=['hold','atr'].includes(school.mode)?{side:'buy',signalDate:null,reason:'Defined initial purchase'}:null;
  let entryPrice=0,entryCost=0,entryIndex=-1,distance=0,highestClose=0,everBought=false,fees=0,peak=budget,worst=0;
  const benchmarkUnits=budget/(bars[first].open*(1+fee));let benchmarkFees=benchmarkUnits*bars[first].open*fee;
  const transact=(side,price,index,signalDate,reason)=>{
    if(side==='buy'&&units===0){const qty=cash/(price*(1+fee));const cost=qty*price*fee;entryCost=cash;cash=0;units=qty;entryPrice=price;entryIndex=index;highestClose=Number.NEGATIVE_INFINITY;distance=1.5*(ind[Math.max(0,index-1)].atr||0);everBought=true;fees+=cost;orders.push({side,date:bars[index].date,signalDate,price,shares:qty,fee:cost,reason});}
    else if(side==='sell'&&units>0){const cost=units*price*fee;cash=units*price-cost;fees+=cost;closed.push(cash-entryCost);orders.push({side,date:bars[index].date,signalDate,price,shares:units,fee:cost,reason});units=0;}
  };
  for(let i=first;i<=last;i++){
    const bar=bars[i];if(pending){transact(pending.side,bar.open,i,pending.signalDate,pending.reason);pending=null;}
    if(i===last&&units>0)transact('sell',bar.close,i,null,'End-of-test liquidation at the final close');
    const value=cash+units*bar.close;let benchmark=benchmarkUnits*bar.close;if(i===last){const finalFee=benchmark*fee;benchmark-=finalFee;benchmarkFees+=finalFee;}
    peak=Math.max(peak,value);worst=Math.min(worst,value/peak-1);series.push({date:bar.date,value,benchmark});
    if(i===last)break;
    if(units>0){
      highestClose=Math.max(highestClose,bar.close);let reason='';
      if(school.mode==='trend'&&ind[i].sma20<=ind[i].sma100)reason='Downward moving-average condition';
      if(['rsi','bands'].includes(school.mode)){
        if(school.mode==='rsi'&&ind[i].rsi>=70)reason='RSI reached 70';
        if(school.mode==='bands'&&bar.close>=ind[i].sma20)reason='Close reached the 20-day mean';
        if(bar.close<=entryPrice*.95)reason='Close-based 5% loss review';
      }
      if(['price_action','wyckoff'].includes(school.mode)&&distance>0){if(bar.close<=entryPrice-distance)reason='Close-based ATR loss review';else if(bar.close>=entryPrice+2*distance)reason='Close-based 2R target review';}
      if(school.mode==='atr'&&ind[i].atr>0&&bar.close<highestClose-1.5*ind[i].atr)reason='Close-based trailing ATR review';
      if(['rsi','bands','price_action','wyckoff'].includes(school.mode)&&i-entryIndex+1>=20)reason='20-session holding limit';
      if(reason)pending={side:'sell',signalDate:bar.date,reason};
    }else if(!(school.mode==='atr'&&everBought)&&schoolEntryCondition(school.mode,bars,ind,i))pending={side:'buy',signalDate:bar.date,reason:'Completed-session entry condition'};
  }
  const final=series.at(-1),warnings=['This tests one stock at a time with the entire hypothetical budget, not the matched multi-asset portfolio.','Daily adjusted OHLC approximates splits and distributions. Taxes, bid/ask spreads, slippage and cash interest are excluded.','Signals use completed daily bars and execute at the next recorded open; close-based exits are not intraday stop orders. Gaps can exceed the stated loss review.','The final position is liquidated at the last close, with a fee, to compare equal ending cash.','This retrospective, selected-universe test is not out-of-sample validation and does not predict future returns.'];
  if(orders.length===0)warnings.unshift('No entry condition occurred in this window; the strategy stayed in cash.');
  if(startDate!==series[0].date||endDate!==final.date)warnings.unshift('Requested dates include non-recorded sessions. Actual first and last trading dates are shown.');
  return {status:'complete',version:'school-test-v1',schoolId,ticker,start:series[0].date,end:final.date,requested:{startDate,endDate},parameters:{feePct,budget},scope:school.scope,rules:{entry:school.entry,exit:school.exit},metrics:{startingValue:budget,endingValue:final.value,totalReturnPct:(final.value/budget-1)*100,maxDrawdownPct:worst*100,transactionCosts:fees,completedTrades:closed.length,winRatePct:closed.length?closed.filter(p=>p>0).length/closed.length*100:null,observations:series.length},benchmark:{ticker,label:`${ticker} buy & hold`,totalReturnPct:(final.benchmark/budget-1)*100,endingValue:final.benchmark,transactionCosts:benchmarkFees},series,orders,warnings,source:{name:data.source,url:data.sourceUrl,fetchedAt:dataset.fetchedAt,cutoffDate:dataset.cutoffDate,basis:dataset.basis}};
}
