export const MAX_UPLOAD_BYTES = 2 * 1024 * 1024;
export const UPLOADED_SOURCE_LABEL = 'Uploaded document — not a fresh analysis';
const extensions = new Set(['md', 'markdown', 'txt', 'json']);
const fail = message => { throw new Error(message); };
const validDate = value => /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(Date.parse(value)) && new Date(value).toISOString().slice(0, 10) === value;

export function validateUploadFile(file) {
  if (!file || typeof file.name !== 'string' || !file.name.trim() || file.name.length > 240) fail('Choose a report file with a filename of 240 characters or fewer.');
  const extension = file.name.toLowerCase().split('.').at(-1);
  if (!extensions.has(extension)) fail('Choose a Markdown (.md), plain text (.txt) or JSON (.json) report.');
  if (!Number.isInteger(file.size) || file.size <= 0) fail('The report file is empty.');
  if (file.size > MAX_UPLOAD_BYTES) fail('The report must be 2 MiB or smaller.');
  return extension === 'markdown' ? 'md' : extension;
}

function horizonOf(heading) {
  const value = heading.toLowerCase().replace(/[–—~\u81f3]/g, '-');
  if (/maturit|duration|tenor|\u5230\u671f|\u4e45\u671f/.test(value) && !/outlook|forecast|horizon|view|\u5c55\u671b|\u9884\u6d4b/.test(value)) return null;
  if (/6\s*(?:-|to)\s*12\s*(?:months?|mos?\b|\u4e2a\u6708|\u6708)/i.test(value)) return '6–12 months';
  if (/1\s*(?:-|to)\s*3\s*(?:months?|mos?\b|\u4e2a\u6708|\u6708)/i.test(value)) return '1–3 months';
  if (/\blong[ -]?term\b|\u957f\u671f/.test(value)) return 'Long-term (as stated in document)';
  if (/\bmedium[ -]?term\b|\u4e2d\u671f/.test(value)) return 'Medium-term (as stated in document)';
  return null;
}
function headingAt(lines, index) {
  const raw = lines[index];
  const markdown = raw.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
  if (markdown) return {title:markdown[2], level:markdown[1].length, detection:'Markdown heading'};
  const explicitLabel = value => /^(?:(?:1\s*(?:[-–—~]|to|\u81f3)\s*3|6\s*(?:[-–—~]|to|\u81f3)\s*12)\s*(?:months?|mos?\b|\u4e2a\u6708|\u6708))(?:\s*\((?:medium|long|\u4e2d\u671f|\u957f\u671f)\))?(?:\s*$|\s*[:：—–-])/i.test(value) || /^(?:long[ -]?term|medium[ -]?term|\u957f\u671f|\u4e2d\u671f)(?:\s+(?:outlook|view|analysis|forecast)|\u5c55\u671b|\u5206\u6790)?(?:\s*\([^)]{0,60}\))?(?:\s*$|\s*[:：—–-])/i.test(value);
  const table = raw.match(/^\s*\|\s*([^|]+?)\s*\|/);
  if (table) {
    const firstCell = table[1].trim().replace(/^(?:\*\*|__)|(?:\*\*|__)$/g, '').trim();
    if (explicitLabel(firstCell) && horizonOf(firstCell)) return {title:firstCell, level:6, detection:'Explicit horizon table row', singleLine:true};
    return null;
  }
  const bold = raw.match(/^\s*(?:\*\*|__)(.+?)(?:\*\*|__)\s*$/);
  if (bold && bold[1].length <= 400 && explicitLabel(bold[1])) return {title:bold[1], level:4, detection:'Standalone bold horizon heading'};
  const title = raw.trim();
  if (title.length > 150 || !title) return null;
  // Only explicit standalone heading forms are recognized in TXT; prose is never promoted to a forecast.
  if (/^(?:\*\*|__)?(?:long[ -]?term|medium[ -]?term|short[ -]?term|\u957f\u671f|\u4e2d\u671f|\u77ed\u671f)(?:\s+(?:outlook|view|thesis|analysis|forecast|strategy)|\u5c55\u671b|\u5206\u6790)?(?:\s*\([^)]{0,60}\))?\s*[:：]?(?:\*\*|__)?$/i.test(title) || /^(?:[16]\s*(?:[-–—~]|to|\u81f3)\s*(?:3|12)\s*(?:months?|mos?\b|\u4e2a\u6708|\u6708))(?:\s*[:：—-]\s*(?:outlook|view|thesis|analysis|\u5c55\u671b|\u5206\u6790))?\s*[:：]?$/i.test(title)) {
    if (!/[.!?。！？]$/.test(title)) return {title:title.replace(/^(?:\*\*|__)|(?:\*\*|__)$/g, ''), level:2, detection:'Standalone text heading'};
  }
  if (/^(?:Risks?|Sources?|References|Conclusion|Investment thesis|Analysis|Outlook|\u98ce\u9669|\u8d44\u6599\u6765\u6e90|\u7ed3\u8bba)\s*:?$/i.test(title)) return {title, level:2};
  return null;
}
export function extractHorizonExcerpts(text, format = 'md') {
  if (format === 'json') return [];
  const lines = text.split(/\r?\n/);
  const headings = [];
  let fence = null;
  for (let index = 0; index < lines.length; index++) {
    const marker = lines[index].match(/^\s{0,3}(`{3,}|~{3,})/);
    if (marker) {
      if (!fence) fence = {character:marker[1][0], length:marker[1].length};
      else if (marker[1][0] === fence.character && marker[1].length >= fence.length && lines[index].slice(marker[0].length).trim() === '') fence = null;
      continue;
    }
    if (fence) continue;
    const heading = headingAt(lines, index);
    if (heading) headings.push({...heading, index, horizon:horizonOf(heading.title)});
  }
  return headings.filter(heading => heading.horizon).slice(0, 12).map(heading => {
    const next = headings.find(candidate => candidate.index > heading.index && candidate.level <= heading.level);
    const end = heading.singleLine ? heading.index + 1 : next?.index ?? lines.length;
    return {heading:heading.title, horizon:heading.horizon, detection:heading.detection, lineStart:heading.index + 1, lineEnd:end, text:lines.slice(heading.index, end).join('\n')};
  });
}
export function parseUploadedReport({filename, text, title = '', reportDate = '', id, importedAt = new Date().toISOString()}) {
  if (typeof text !== 'string') fail('The report must contain readable UTF-8 text.');
  const size = new TextEncoder().encode(text).byteLength;
  const format = validateUploadFile({name:filename, size});
  if (!text.trim()) fail('The report contains no readable text.');
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/.test(text)) fail('The file contains binary or unsupported control characters. Export it as UTF-8 Markdown or text.');
  if (typeof title !== 'string' || title.trim().length > 160) fail('Use a report title of 160 characters or fewer.');
  if (typeof reportDate !== 'string' || (reportDate && !validDate(reportDate))) fail('Enter a valid report date in YYYY-MM-DD format.');
  if (typeof id !== 'string' || !id || id.length > 128) fail('A local document identifier is required.');
  if (typeof importedAt !== 'string' || Number.isNaN(Date.parse(importedAt))) fail('The import timestamp is invalid.');
  if (format === 'json') { try { JSON.parse(text); } catch { fail('This JSON file is not valid JSON. Save the original text as .txt instead.'); } }
  let detectedReportDate = null;
  const lines = text.split(/\r?\n/);
  if (format !== 'json') {
    for (const [index, line] of lines.entries()) {
      const dateMatch = line.match(/^\s*(?:[-*+]\s+)?(?:\*\*)?(analysis date|report date|as of|date|\u5206\u6790\u65e5\u671f|\u62a5\u544a\u65e5\u671f|\u65e5\u671f)(?:\*\*)?\s*[:：]\s*(?:\*\*)?(\d{4}-\d{2}-\d{2})(?:\*\*)?\s*(?:\([^)]*\))?\s*$/i);
      if (dateMatch && validDate(dateMatch[2])) { detectedReportDate = {value:dateMatch[2], label:dateMatch[1], lineNumber:index + 1, verified:false}; break; }
    }
  }
  const firstHeading = format === 'json' ? null : lines.map(line => line.match(/^#\s+(.+)\s*$/)).find(Boolean)?.[1];
  return {id, kind:'uploaded-document', version:1, title:title.trim() || firstHeading?.slice(0, 160) || filename.replace(/\.[^.]+$/, ''), filename, format, bytes:size, importedAt, userReportDate:reportDate || null, detectedReportDate, originalText:text, horizonExcerpts:extractHorizonExcerpts(text, format), sourceLabel:UPLOADED_SOURCE_LABEL};
}

export function validateStoredDocument(value) {
  if (!value || value.kind !== 'uploaded-document' || value.version !== 1) fail('This stored document format is unavailable.');
  return parseUploadedReport({filename:value.filename, text:value.originalText, title:value.title, reportDate:value.userReportDate || '', id:value.id, importedAt:value.importedAt});
}
