import {TEMPLATES,TEMPLATE_VERSION} from './templates.mjs';
export {TEMPLATES,TEMPLATE_VERSION};

const issuerSources = {
  VTI:{title:'Vanguard: VTI fund information',url:'https://advisors.vanguard.com/investments/products/vti/vanguard-total-stock-market-etf'},
  SGOV:{title:'iShares: SGOV fund information',url:'https://www.ishares.com/us/products/314116/ishares-0-3-month'},
  MSFT:{title:'Microsoft: stock information',url:'https://www.microsoft.com/en-us/investor/stock-lookup'},
  AAPL:{title:'Apple: investor FAQ',url:'https://investor.apple.com/faq./default.aspx'},
  NVDA:{title:'NVIDIA: investor FAQ',url:'https://investor.nvidia.com/investor-resources/faqs/default.aspx'},
  AMD:{title:'AMD: investor FAQ',url:'https://ir.amd.com/contacts-faq/faq'},
  AMZN:{title:'Amazon: investor FAQ',url:'https://ir.aboutamazon.com/faqs/'},
  GOOGL:{title:'Alphabet: Class A GOOGL listing',url:'https://abc.xyz/assets/53/aa/c8121b9b5900f38838f4cfe6b7b6/fdab9de6a195d67ce5861b525627ac73.pdf'},
  META:{title:'Meta Platforms: stock information',url:'https://investor.atmeta.com/stock-info/default.aspx'},
  AVGO:{title:'Broadcom: investor FAQ',url:'https://investors.broadcom.com/company-information/faqs'},
  SPCX:{title:'SpaceX: June 2026 listing announcement',url:'https://ir.spacex.com/updates/releases-details/2026/Space-Exploration-Technologies-Corp--Announces-Closing-of-Initial-Public-Offering-Including-Full-Exercise-of-Underwriters-Option-to-Purchase-Additional-Shares-2026-RgoR-Y1Vwh/default.aspx'},
};

export const ASSETS = [
  {ticker:'VTI',name:'Vanguard Morningstar Total Stock Market ETF',assetClass:'equity_etf',shock:-40},
  {ticker:'SCHD',name:'Schwab US Dividend Equity ETF',assetClass:'equity_etf',shock:-40},
  {ticker:'QQQ',name:'Invesco QQQ Trust',assetClass:'equity_etf',shock:-50},
  {ticker:'SGOV',name:'iShares 0–3 Month Treasury Bond ETF',assetClass:'short_treasury_etf',shock:-2},
  {ticker:'IEF',name:'iShares 7–10 Year Treasury Bond ETF',assetClass:'treasury_etf',shock:-12},
  {ticker:'GLD',name:'SPDR Gold Shares',assetClass:'gold_etf',shock:-20},
  {ticker:'MSFT',name:'Microsoft',assetClass:'stock',shock:-55},
  {ticker:'AAPL',name:'Apple',assetClass:'stock',shock:-55},
  {ticker:'NVDA',name:'NVIDIA',assetClass:'stock',shock:-65},
  {ticker:'AMD',name:'Advanced Micro Devices',assetClass:'stock',shock:-70},
  {ticker:'AMZN',name:'Amazon',assetClass:'stock',shock:-60},
  {ticker:'GOOGL',name:'Alphabet Class A',assetClass:'stock',shock:-60},
  {ticker:'META',name:'Meta Platforms',assetClass:'stock',shock:-60},
  {ticker:'AVGO',name:'Broadcom',assetClass:'stock',shock:-65},
  {ticker:'SPCX',name:'SpaceX Class A',assetClass:'stock',shock:-80,firstTradingDate:'2026-06-12',newlyListed:true,identityNote:'Space Exploration Technologies Corp. Class A. Do not combine its post-IPO prices with the earlier unrelated ETF that used SPCX.'},
  {ticker:'CASH',name:'Uninvested USD cash',assetClass:'cash',shock:0}
].map(asset=>({...asset,...(issuerSources[asset.ticker]?{listingSource:issuerSources[asset.ticker],listingCheckedAt:'2026-10-04'}:{})}));

// Maintained examples for an explicit user-controlled remix. They are not
// eligible questionnaire templates, optimized weights or automatic allocations.
const portfolioIdeas = [
  {
    id:'etf_ai_satellites',name:'ETF core + AI stocks',
    summary:'A broad-market core with small Microsoft, NVIDIA and AMD positions.',
    weights:{VTI:35,SGOV:30,MSFT:5,NVDA:5,AMD:5,CASH:20},
    rationale:['VTI provides broad US-stock exposure rather than relying entirely on three companies.','The three named stocks each receive 5% so their effect on the example is easy to compare.','Short Treasury exposure and uninvested cash make up half of this illustrative mix.'],
    limits:['VTI already includes many large technology companies, so the individual positions add overlapping exposure.','AI-related shares can decline together; small positions do not eliminate company or valuation risk.'],
  },
  {
    id:'large_company_sampler',name:'Large-company sampler',
    summary:'Compare Apple, Microsoft, Amazon, Alphabet and Meta alongside an ETF and a reserve.',
    weights:{VTI:25,SGOV:25,AAPL:5,MSFT:5,AMZN:5,GOOGL:5,META:5,CASH:25},
    rationale:['Equal 5% company positions help beginners compare each business without one dominating this example.','VTI keeps some broader market exposure alongside the company basket.','The reserve remains split between short Treasury exposure and cash.'],
    limits:['These companies are still exposed to related technology, internet and consumer-demand risks; five names are not five independent markets.','The ETF overlaps with the company basket. This is not a broadly balanced sector portfolio.'],
  },
  {
    id:'chip_theme_lab',name:'Chip-company research mix',
    summary:'Explore NVIDIA, AMD and Broadcom as a deliberately concentrated theme.',
    weights:{VTI:20,SGOV:30,NVDA:10,AMD:10,AVGO:10,CASH:20},
    rationale:['Three 10% company sleeves show how a semiconductor theme changes the overall mix.','A broad US ETF remains separate from the direct chip-company positions.','Half remains in short Treasury exposure and cash for comparison with a more concentrated stock-only basket.'],
    limits:['Semiconductor demand, export restrictions and supply-chain events can affect all three companies at once.','This thematic mix can experience large losses and is not the default beginner plan.'],
  },
  {
    id:'space_innovation_lab',name:'Space + innovation research mix',
    summary:'A small SpaceX position beside Microsoft, NVIDIA, a broad ETF and a reserve.',
    weights:{VTI:30,SGOV:35,SPCX:5,MSFT:5,NVDA:5,CASH:20},
    rationale:['SPCX is limited to 5% in this example so a newly listed company does not dominate the whole mix.','VTI and the other company sleeves provide a comparison with the new space-company position.','The reserve is kept visible rather than treating every available dollar as a stock purchase.'],
    limits:['SpaceX began public trading on 12 June 2026; a multi-year public-share backtest is unavailable.','SPCX previously identified an unrelated ETF. Research must verify issuer identity and exclude every price before the SpaceX listing.'],
  },
];
export const PORTFOLIO_IDEAS = portfolioIdeas.map(idea=>({
  kind:'illustrative_stock_mix',version:TEMPLATE_VERSION,allocationMethod:'Team-authored example weights',
  suitabilityNote:'An editable learning example, not your questionnaire-matched plan. Check the amounts, concentration and risk before using it; it places no orders.',
  reviewRule:'Review monthly and after important company news. Record a reason before changing any target weight.',
  returnEvidence:'No expected returns, forecasts or backtest results are claimed for this example.',
  ...idea,
  sources:Object.keys(idea.weights).filter(ticker=>issuerSources[ticker]).map(ticker=>({ticker,...issuerSources[ticker]})),
}));
const ALLOWED = {
  goal:['defensive','balanced','growth'],horizon:['under1','1to3','3plus'],review:['monthly','weekly','daily'],
  assetPreference:['broad','value','growth','unsure'],experience:['new','some'],inverseInterest:['none','minus1','minus2','minus3'],startingPortfolio:['cash']
};
export const DEFAULT_PROFILE = Object.freeze({budget:10000,goal:'balanced',horizon:'3plus',review:'monthly',assetPreference:'broad',lossTolerance:15,lossCapacity:15,essentialMoney:false,experience:'new',inverseInterest:'none',prompt:'',startingPortfolio:'cash'});
function bad(message) { const err = new Error(message); err.status=400; throw err; }
export function validateProfile(input) {
  if (!input || typeof input!=='object' || Array.isArray(input)) bad('Complete the questionnaire before matching.');
  const p={};
  for(const [key,values] of Object.entries(ALLOWED)) {
    if(!values.includes(input[key])) bad('Choose a valid '+key+'.');
    p[key]=input[key];
  }
  if(typeof input.budget !== 'number' || !Number.isFinite(input.budget) || input.budget<100 || input.budget>1000000) bad('Budget must be between $100 and $1,000,000.');
  p.budget=Math.round(input.budget*100)/100;
  for(const key of ['lossTolerance','lossCapacity']) {
    if(![5,10,15,20,30].includes(input[key])) bad('Choose a loss preference and financial capacity.');
    p[key]=input[key];
  }
  if(typeof input.essentialMoney!=='boolean') bad('Tell us whether this money is needed for essentials.');
  p.essentialMoney=input.essentialMoney;
  if(typeof input.prompt!=='string'||input.prompt.length>1500) bad('Describe your preference in at most 1,500 characters.');
  p.prompt=input.prompt.trim();
  if(input.templateId && input.templateId!=='auto') {
    if(!TEMPLATES.some(t=>t.id===input.templateId)) bad('Choose a maintained strategy template.');
    p.templateId=input.templateId;
  }
  return p;
}
const round = n=>Math.round(n*100)/100;
function stableId(p) {
  const text=JSON.stringify({v:TEMPLATE_VERSION,p});let h=2166136261;
  for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}
  return 'match-'+(h>>>0).toString(16); // Identifier only; never an authentication secret.
}
export function allocationAmounts(weights,budget) {
  const positive=Object.entries(weights).filter(([,v])=>v>0);
  let centsRemaining=Math.round(budget*100);
  return positive.map(([ticker,weight],i)=>{
    const asset=ASSETS.find(a=>a.ticker===ticker);if(!asset)bad('Unsupported asset.');
    const cents=i===positive.length-1?centsRemaining:Math.round(budget*weight);
    centsRemaining-=cents;
    return {ticker,name:asset.name,assetClass:asset.assetClass,weight,amount:cents/100};
  });
}
export function stressAllocation(allocations,budget) {
  const assumptions=allocations.map(a=>({ticker:a.ticker,returnPct:ASSETS.find(x=>x.ticker===a.ticker)?.shock??0}));
  const lossPct=round(-allocations.reduce((n,a,i)=>n+a.weight*assumptions[i].returnPct/100,0));
  const lossAmount=round(budget*lossPct/100);
  return {label:'Illustrative simultaneous market shock — not a forecast or loss limit',assumptions,lossPct,lossAmount,endingValue:round(budget-lossAmount)};
}
export function createMatch(input) {
  const p=validateProfile(input), limit=Math.min(p.lossTolerance,p.lossCapacity), warnings=[],reasons=[];
  const reviewRank={monthly:0,weekly:1,daily:2};
  const cautious=p.goal==='defensive'||p.horizon==='under1'||limit<=10;
  const candidates=TEMPLATES.filter(t=>{
    if(p.essentialMoney)return false;
    if(t.matchable!==true || t.implementationStatus!=='implemented' || t.role==='risk_tool')return false;
    if(t.id==='defensive')return true;
    if(cautious)return false;
    return reviewRank[p.review]>=reviewRank[t.suitability.minimumReview]&&limit>=t.suitability.minimumLossCapacity;
  }).map(t=>t.id);
  let id=cautious?'defensive':p.goal==='growth'&&p.review!=='monthly'?'trend':'balanced';
  if(!candidates.includes(id))id='defensive';
  if(/bollinger|mean.?rever|\u5e03\u6797|\u5747\u503c\u56de\u5f52/i.test(p.prompt)&&candidates.includes('mean_reversion'))id='mean_reversion';
  else if(/trend|moving.?average|\u8d8b\u52bf|\u5747\u7ebf/i.test(p.prompt)&&candidates.includes('trend'))id='trend';
  else if(/\brsi\b|\u76f8\u5bf9\u5f3a\u5f31/i.test(p.prompt)&&candidates.includes('rsi'))id='rsi';
  else if(/price.?action|pin.?bar|\u4ef7\u683c\u884c\u4e3a|\u88f8.?k/i.test(p.prompt)&&candidates.includes('price_action'))id='price_action';
  if(p.templateId) {
    if(candidates.includes(p.templateId))id=p.templateId;
    else warnings.push('The requested school is educational, a risk tool, or needs more monitoring or loss capacity than this profile allows. An eligible allocation template was used.');
  }
  const template=TEMPLATES.find(t=>t.id===id);
  let weights;
  if(p.horizon==='under1') {
    weights={SGOV:30,CASH:70};reasons.push('A horizon under one year keeps this illustration in short Treasury exposure and cash.');
  } else if(limit<=5) {
    weights={VTI:5,SGOV:50,IEF:5,GLD:5,CASH:35};reasons.push('The lower of loss willingness and financial capacity limits equity exposure.');
  } else if(cautious||id==='defensive') {
    weights={VTI:10,SGOV:50,IEF:10,GLD:5,CASH:25};reasons.push('Your goal or loss capacity calls for a Treasury and cash-heavy example.');
  } else if(p.horizon==='1to3') {
    weights={VTI:25,SGOV:35,IEF:15,GLD:10,CASH:15};reasons.push('A one-to-three-year horizon reduces equity exposure in this example.');
  } else if(p.goal==='growth'&&limit>=20) {
    weights={VTI:40,QQQ:25,SGOV:15,GLD:10,CASH:10};reasons.push('A longer horizon and higher stated capacity allow a larger equity sleeve, with a retained reserve.');
  } else {
    weights={VTI:35,SCHD:10,IEF:20,SGOV:15,GLD:10,CASH:10};reasons.push('This balanced illustration splits equity exposure from Treasuries, gold and cash.');
  }
  // Asset preference modifies an existing equity sleeve, never raises its total risk budget.
  if(p.assetPreference==='value'&&(weights.VTI||0)>=20) {
    weights.VTI-=10;weights.SCHD=(weights.SCHD||0)+10;
    if(p.experience==='some'&&limit>=20&&p.horizon==='3plus'){weights.VTI-=5;weights.AAPL=5;}
    reasons.push('Your value preference shifts part of the equity sleeve toward dividend equities; dividends do not protect against price losses.');
  }
  if(p.assetPreference==='growth'&&!cautious&&id!=='defensive'&&p.horizon==='3plus'&&limit>=20) {
    weights.VTI-=10;weights.MSFT=5;weights.NVDA=5;
    warnings.push('Individual technology stocks overlap with broad and Nasdaq funds. Concentration is higher than the ticker count suggests.');
  }
  if(p.lossCapacity<p.lossTolerance)reasons.push('Financial loss capacity is lower than willingness, so the stricter answer controls the allocation.');
  const initialShock=-Object.entries(weights).reduce((n,[ticker,w])=>n+w*ASSETS.find(a=>a.ticker===ticker).shock/100,0);
  if(!p.essentialMoney&&initialShock>limit){
    const ratio=limit/initialShock;
    for(const ticker of Object.keys(weights))if(ticker!=='CASH')weights[ticker]=Math.floor(weights[ticker]*ratio*10)/10;
    weights.CASH=round(100-Object.entries(weights).reduce((n,[ticker,w])=>n+(ticker==='CASH'?0:w),0));
    reasons.push('A larger cash reserve keeps this specific illustrative shock within your lower stated loss threshold. It does not cap actual losses or establish suitability.');
  }
  reasons.push('Template selection considers your review schedule. Allocation percentages come from maintained team rules, not an optimizer or a return forecast.');
  if(['rsi','price_action'].includes(id)) reasons.push('This daily learning style is available to beginners. It adds observations to the same allocation rules and places no orders.');
  if(template.rules.type.includes('research')) warnings.push('This signal template is a research overlay. The allocation shown is not a confirmed trade signal; its historical comparison does not test the overlay.');
  const allocations=p.essentialMoney?[]:allocationAmounts(weights,p.budget),stress=stressAllocation(allocations,p.budget);
  if(!p.essentialMoney&&stress.lossPct>limit)warnings.push('The illustrative shock exceeds your stated loss threshold. Review a smaller invested amount or more cash before considering this mix. Actual losses could be larger.');
  warnings.push('Amounts are target dollar allocations, not executable orders. Share quantities require a current quote and your broker’s fractional-share rules.');
  if(p.essentialMoney){warnings.unshift('You marked this money as needed for essentials. No investment allocation is generated.');reasons.splice(0,reasons.length,'Keep essential spending needs separate before exploring an investment allocation.');}
  const hedgeReview={interest:p.inverseInterest,allocated:false,message:p.inverseInterest==='none'?'No inverse ETF exposure requested.':'Inverse ETFs are research-only in this beginner version. Daily reset and compounding can make multi-day returns differ substantially from the stated multiple. Compare reducing equity exposure first; no inverse product is automatically allocated.',
    comparators:p.inverseInterest==='none'?[]:[
      {ticker:'CASH',label:'Reduce equity exposure / retain cash',dailyMultiple:0},
      {ticker:'SH',label:'S&P 500 daily inverse research',dailyMultiple:-1},
      ...(p.inverseInterest==='minus2'||p.inverseInterest==='minus3'?[{ticker:'SDS',label:'S&P 500 daily leveraged inverse research',dailyMultiple:-2}]:[]),
      ...(p.inverseInterest==='minus3'?[{ticker:'SPXU',label:'S&P 500 daily leveraged inverse research',dailyMultiple:-3}]:[])
    ],sources:[{title:'SEC investor bulletin: leveraged and inverse ETFs',url:'https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-alerts/sec'}]};
  return {id:stableId(p),eligible:!p.essentialMoney,profile:p,template,candidateTemplateIds:candidates,selection:{method:'rules',requestedTemplateId:p.templateId||'auto'},
    allocations,reasons,warnings,rebalance:{cadence:template.cadence,conditions:[
      'Review the allocation monthly and after a material change in your needs.',
      'At review, consider rebalancing if an asset sleeve differs from its target by 5 percentage points; check costs first.',
      ...(template.rules.type==='trend_research'?['Review completed 20/100-day moving-average observations weekly; any action is no earlier than the next session after review.']:[]),
      ...(template.rules.type==='mean_reversion_research'?['Review completed 20-day Bollinger Band observations daily; a low band reading alone is insufficient to trade.']:[]),
      ...(template.rules.type==='rsi_research'?['Review completed 14-day RSI daily; crossing back above 30 is a recovery watch, never a stand-alone buy instruction.']:[]),
      ...(template.rules.type==='price_action_research'?['Review completed daily candles against fixed prior levels; pin-bar and breakout-retest observations need next-session review and separate execution rules.']:[]),
      'This app creates research and proposed allocations; it does not place orders.'
    ]},stress,hedgeReview,backtest:{status:'pending',message:'Real historical allocation comparison is generated by the research worker. No historical metrics are assumed.'},createdAt:new Date().toISOString()};
}
