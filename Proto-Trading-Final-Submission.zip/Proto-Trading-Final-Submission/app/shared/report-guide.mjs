// Explicit user assumptions only. This calculator does not forecast returns.
export function returnScenario(budget, annualPct, months) {
  if (![budget, annualPct, months].every(Number.isFinite) || budget <= 0 || budget > 1000000 || annualPct <= -100 || annualPct > 100 || ![1,3,6,12,24,36].includes(months)) throw new Error('Choose a valid budget, annual assumption and time period.');
  const endingValue = budget * Math.pow(1 + annualPct / 100, months / 12);
  return { budget, annualPct, months, endingValue: Math.round(endingValue * 100) / 100, change: Math.round((endingValue - budget) * 100) / 100, periodPct: (endingValue / budget - 1) * 100, basis: 'user_assumption', forecast: false };
}

export function guideAllocations(rows) {
  if (!Array.isArray(rows) || !rows.length || rows.length > 30) return [];
  const seen = new Set();
  for (const row of rows) {
    if (!row || !/^[A-Z][A-Z0-9.-]{0,11}$/.test(row.ticker) || seen.has(row.ticker) || !Number.isFinite(row.weight) || row.weight < 0 || row.weight > 100) return [];
    seen.add(row.ticker);
  }
  if (Math.abs(rows.reduce((sum,row)=>sum+row.weight,0)-100) > .00001) return [];
  return rows.filter(row=>row.weight>0).map(row=>({ticker:row.ticker,name:row.name || row.ticker,weight:row.weight}));
}
