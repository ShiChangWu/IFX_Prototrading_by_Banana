// Deterministic, browser-compatible short-term checklist. No model or report is required.
// Template prompts are maintained separately; signal claims require measured observations.
const DAY = 86_400_000;
const finite = Number.isFinite;
const positive = value => finite(value) && value > 0;
const strings = value => Array.isArray(value) ? value.filter(x => typeof x === 'string').slice(0, 12) : [];
const equity = asset => ['stock', 'equity_etf'].includes(asset.assetClass);
const calendarDate = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && finite(Date.parse(value + 'T00:00:00Z')) && new Date(value + 'T00:00:00Z').toISOString().slice(0, 10) === value;

function inspectMarket(row, snapshot, now) {
  if (!row || row.status !== 'complete') return { reason: 'A completed daily-price snapshot is not available for this asset.' };
  if (row.currency !== 'USD' || row.currencyVerified !== true) return { reason: 'The data provider has not confirmed the quote currency as USD.' };
  if (!calendarDate(row.priceDate) || !calendarDate(snapshot.cutoffDate) || row.priceDate > snapshot.cutoffDate || row.priceDate > now.toISOString().slice(0, 10)) return { reason: 'The price date is missing, invalid or later than the completed-session cutoff.' };
  const age = (Date.parse(now.toISOString().slice(0, 10)) - Date.parse(row.priceDate)) / DAY;
  if (age > 4) return { reason: 'The latest recorded close is more than four calendar days old. Refresh data before using an observation.' };
  if (!positive(row.latestClose) || row.adjusted !== true || !Number.isInteger(row.observations) || row.observations < 2) return { reason: 'The completed adjusted-price history is missing required observations.' };
  const fetchedAt = row.fetchedAt || snapshot.fetchedAt;
  const fetched = Date.parse(fetchedAt);
  if (!finite(fetched) || fetched > now.getTime() + 5 * 60_000 || now.getTime() - fetched > DAY) return { reason: 'This saved snapshot needs a fresh data check before it can support a short-term observation.' };
  return { market: {
    priceDate: row.priceDate, close: row.latestClose, adjusted: true, currency: 'USD',
    source: typeof row.source === 'string' ? row.source : row.source?.name ? { name: row.source.name, url: row.source.url } : 'Market data provider',
    priceBasis: row.priceBasis || null, adjustmentMethod: row.adjustmentMethod || null,
    preferredSource: row.preferredSource || null, fallbackReason: row.fallbackReason || null,
    providerReference: row.providerReference ? {
      ticker: row.ticker, status: row.providerReference.status, source: row.providerReference.source,
      priceDate: row.providerReference.priceDate, latestClose: row.providerReference.latestClose,
      adjustmentMethod: row.providerReference.adjustmentMethod,
      currencyVerified: row.providerReference.currencyVerified === true,
      eligibleForSignals: false, fallbackReason: row.providerReference.fallbackReason,
    } : null,
    sma20: finite(row.sma20) ? row.sma20 : null, sma100: finite(row.sma100) ? row.sma100 : null,
    bollingerUpper: finite(row.bollingerUpper) ? row.bollingerUpper : null,
    bollingerLower: finite(row.bollingerLower) ? row.bollingerLower : null,
    rsi14: finite(row.rsi14) && row.rsi14 >= 0 && row.rsi14 <= 100 ? row.rsi14 : null,
    atr14: positive(row.atr14) ? row.atr14 : null,
  } };
}

function validCandle(bar) {
  return bar && calendarDate(bar.date) && [bar.open,bar.high,bar.low,bar.close].every(positive)
    && bar.high >= Math.max(bar.open,bar.close,bar.low) && bar.low <= Math.min(bar.open,bar.close);
}

function priceActionObservation(row) {
  // Use the actual dated bars, excluding the observation bar from reference levels.
  // Reconstructing levels here keeps a changed historical window from making a fake retest.
  const bars = Array.isArray(row.bars) ? row.bars.slice(-22) : [];
  if (bars.length !== 22 || !bars.every(validCandle) || bars.some((bar,i) => i && bar.date <= bars[i-1].date)) return null;
  const current = bars.at(-1), previous = bars.at(-2), before = bars.at(-3);
  if (current.date !== row.priceDate || current.close !== row.latestClose) return null;
  const support = Math.min(...bars.slice(-21,-1).map(bar=>bar.low));
  const breakoutLevel = Math.max(...bars.slice(-22,-2).map(bar=>bar.high));
  const body = Math.abs(current.close-current.open), range = current.high-current.low;
  const lowerWick = Math.min(current.open,current.close)-current.low;
  const upperWick = current.high-Math.max(current.open,current.close);
  const pinbar = range > 0 && body > 0 && lowerWick >= 2*body && upperWick <= body
    && (current.close-current.low)/range >= 2/3 && current.low <= support && current.close > support;
  const retest = previous.close > breakoutLevel && before.close <= breakoutLevel
    && current.low <= breakoutLevel && current.close > breakoutLevel;
  return {pinbar,retest,support,breakoutLevel,breakoutDate:previous.date,observationDate:current.date};
}

function volatilityContext(row) {
  const validOhlc = [row.latestOpen,row.latestHigh,row.latestLow,row.latestClose].every(positive)
    && row.latestHigh >= Math.max(row.latestOpen,row.latestClose,row.latestLow)
    && row.latestLow <= Math.min(row.latestOpen,row.latestClose);
  if (!positive(row.atr14) || row.observations < 15 || !validOhlc) return null;
  return {
    tool:'atr',status:'observed',atr14:row.atr14,percentOfClose:row.atr14/row.latestClose*100,
    illustrativeMultiplier:1.5,illustrativeDistance:row.atr14*1.5,currency:'USD',priceDate:row.priceDate,
    title:'How much has the price been moving?',
    explanation:'ATR describes recent daily movement, not its direction. The 1.5-times-ATR distance is an illustration, not a recommended stop, an order or a maximum loss. A trade needs a current executable price and a separate risk budget; price gaps can exceed a planned stop.',
  };
}

function ruleConditions(type, asset) {
  if (!equity(asset)) return ['Review this sleeve against its target allocation; an equity indicator does not create an entry signal for this asset.'];
  if (type === 'trend_research') return [
    'Candidate entry review: the completed 20-day average crosses from at or below the 100-day average to above it.',
    'If the trend weakens, pause new additions and reassess at your scheduled review. With an empty portfolio there is no position to sell.',
    'Any decision follows review of a completed daily bar; the next eligible session is the earliest possible action.',
  ];
  if (type === 'mean_reversion_research') return [
    'A completed close below the 20-day lower Bollinger Band is a pullback observation, not sufficient evidence to buy.',
    'Recheck the next completed session for recovery and a continuing decline. Do not average down.',
    'A close above the upper band is an exit-review observation only for an existing position; this profile starts in cash.',
  ];
  if (type === 'rsi_research') return [
    'Watch a completed 14-day RSI crossing from at or below 30 to above 30; this shows easing weakness, not a confirmed reversal.',
    'Below 30 can persist during a decline. Above 70 calls for a review of momentum and any existing exposure, not an automatic sale.',
    'This empty portfolio has no holdings to sell. Any decision follows a completed session and a separate risk review.',
  ];
  if (type === 'price_action_research') return [
    'Pin-bar watch: touch the previous 20-session low and close back above it, with lower wick at least twice the nonzero body, upper wick no larger than the body, and close in the upper third.',
    'Retest watch: yesterday first closed above its preceding 20-session high; today touches that fixed level and closes above it.',
    'These team-defined daily observations do not identify institutional buying or guarantee a bounce. Review a later entry, invalidation and costs separately.',
  ];
  return [
    'Compare the target amount with your available investment budget before considering any allocation.',
    'Review monthly and after a change in your needs; consider rebalancing at a five-percentage-point deviation, after costs.',
    'This allocation template has no short-term price-entry signal. A recent quote alone is not a buy instruction.',
  ];
}

export function createShortPlan(match, snapshot = null, { now = new Date() } = {}) {
  now = new Date(now);
  if (!finite(now.getTime())) throw new Error('A valid current date is required.');
  if (!match || !Array.isArray(match.allocations) || !match.template) throw new Error('A confirmed strategy match is required.');
  const template = match.template, type = template.rules?.type || 'allocation';
  const hasSnapshot = snapshot && typeof snapshot === 'object';
  const plan = {
    version: '2', status: match.eligible ? 'preliminary' : 'blocked', horizon: 'Next 1–4 weeks',
    basis: 'Maintained template rules; market observations pending', generatedAt: now.toISOString(), matchId: match.id,
    template: { id: template.id, name: template.name, version: template.version },
    summary: 'Start with the matched strategy checklist. Dated market observations can refine what to watch while the longer-term report is being prepared.',
    steps: [], assets: [], coverage: { requested: [], available: [], missing: [] }, dataAsOf: [],
    source: { type: 'rules', fetchedAt: hasSnapshot ? snapshot.fetchedAt || null : null, cutoffDate: hasSnapshot ? snapshot.cutoffDate || null : null, templateSource: template.source || null },
    warnings: ['These are review instructions and conditional observations, not orders or a forecast.', 'Dollar amounts are the matched target allocation. Adjusted historical closes are not executable live quotes.'],
    execution: 'Research checklist; no broker order', independentFromLongTermReport: true,
  };
  if (!match.eligible) {
    plan.summary = 'No investment instructions are generated for money needed for essential expenses.';
    plan.steps = [{ title: 'Keep essential funds separate', detail: 'Revisit the profile only after identifying money that is available for investment.' }];
    return plan;
  }
  plan.steps = [
    { title: 'Confirm your starting point', detail: 'This profile starts with cash and no holdings. Check the proposed amounts and the stress scenario before considering an entry.' },
    { title: type === 'allocation' ? 'Use the allocation review rule' : 'Check the template condition', detail: type === 'allocation' ? 'The matched template sets allocation targets and a review routine. It does not claim a short-term market-timing advantage.' : 'Use completed daily prices to check the stated condition. A watch condition is a reason to review, not permission to ignore your loss capacity.' },
    { title: 'Keep the longer-term view separate', detail: 'Use a saved or new TradingAgents report for medium- and long-term context. An uploaded report does not update these prices or silently change the allocation.' },
  ];
  const rows = Array.isArray(snapshot?.snapshots) ? snapshot.snapshots : [];
  for (const asset of match.allocations) {
    const item = {
      ticker: asset.ticker, name: asset.name, targetWeight: asset.weight, targetAmount: asset.amount,
      status: 'waiting', actionCode: 'await_data', actionTitle: 'Check data before acting',
      explanation: 'The template checklist is available now; a dated market observation is still needed.',
      conditions: ruleConditions(type, asset), market: null, volatility: null,
    };
    if (asset.ticker === 'CASH') {
      Object.assign(item, { status: 'not_required', actionCode: 'retain_reserve', actionTitle: 'Keep the planned cash reserve', explanation: 'Cash remains separate from investment positions. No equity signal or live quote is needed for this reserve.', conditions: ['Keep essential spending needs separate from the investment budget.'] });
      plan.assets.push(item); continue;
    }
    plan.coverage.requested.push(asset.ticker);
    const row = rows.find(x => x && x.ticker === asset.ticker);
    const checked = hasSnapshot ? inspectMarket(row, snapshot, now) : {};
    if (checked.market) {
      item.market = checked.market;
      item.volatility = volatilityContext(row);
      item.status = 'observed'; item.actionCode = 'review_targets'; item.actionTitle = 'Review the target allocation';
      item.explanation = 'A recent completed close is available. This allocation rule does not turn a price observation into an entry signal.';
      if (equity(asset) && type === 'trend_research') {
        if (![row.sma20, row.sma100, row.previousSma20, row.previousSma100].every(positive) || row.observations < 101) {
          Object.assign(item, { status: 'waiting', actionCode: 'insufficient_history', actionTitle: 'Wait for enough indicator history', explanation: 'The price is available, but both current and previous 20/100-day averages are required to identify a crossover.' });
        } else if (row.previousSma20 <= row.previousSma100 && row.sma20 > row.sma100) {
          Object.assign(item, { actionCode: 'trend_entry_watch', actionTitle: 'Upward crossover observed — review only', explanation: 'The completed 20-day average crossed above the 100-day average. Review the candidate against the target amount and your routine before considering a next-session entry.' });
        } else if (row.sma20 <= row.sma100) {
          Object.assign(item, { actionCode: 'trend_pause', actionTitle: 'Weak trend — pause new additions', explanation: 'The 20-day average is at or below the 100-day average. The template does not currently show its upward-crossover entry condition.' });
        } else {
          Object.assign(item, { actionCode: 'trend_watch', actionTitle: 'Trend above the slow average — keep watching', explanation: 'The 20-day average is above the 100-day average, but a new upward crossover was not observed in the latest completed session.' });
        }
      } else if (equity(asset) && type === 'mean_reversion_research') {
        if (!finite(row.bollingerLower) || !positive(row.bollingerUpper) || row.bollingerLower > row.bollingerUpper || row.observations < 20) {
          Object.assign(item, { status: 'waiting', actionCode: 'insufficient_history', actionTitle: 'Wait for valid band data', explanation: 'The price is available, but a valid 20-day Bollinger Band observation is missing.' });
        } else if (row.latestClose < row.bollingerLower) {
          Object.assign(item, { actionCode: 'pullback_watch', actionTitle: 'Below the lower band — watch for recovery', explanation: 'The pullback condition is observed. A continuing decline can invalidate the premise; this observation alone is not an entry instruction.' });
        } else if (row.latestClose > row.bollingerUpper) {
          Object.assign(item, { actionCode: 'upper_band_review', actionTitle: 'Above the upper band — no new entry signal', explanation: 'The template treats this as an exit-review observation for existing holdings. This empty starting portfolio has no position to sell.' });
        } else {
          Object.assign(item, { actionCode: 'inside_bands', actionTitle: 'Inside the bands — no pullback condition', explanation: 'The completed close lies within the bands. The template has not observed its lower-band pullback condition.' });
        }
      } else if (equity(asset) && type === 'rsi_research') {
        const validRsi = value => finite(value) && value >= 0 && value <= 100;
        if (![row.rsi14,row.previousRsi14].every(validRsi) || row.observations < 16) {
          Object.assign(item,{status:'waiting',actionCode:'insufficient_history',actionTitle:'Wait for RSI history',explanation:'Both current and previous completed 14-day RSI readings are required. No recovery is inferred from missing data.'});
        } else if (row.previousRsi14 <= 30 && row.rsi14 > 30) {
          Object.assign(item,{actionCode:'rsi_recovery_watch',actionTitle:'Weakness is easing — keep watching',explanation:'RSI crossed back above 30 in the latest completed session. This is a recovery-watch condition, not a confirmed reversal or an instruction to buy.'});
        } else if (row.rsi14 < 30) {
          Object.assign(item,{actionCode:'rsi_weakness_watch',actionTitle:'Price momentum is weak — wait for recovery',explanation:'RSI is below 30. Weakness can continue; the rule has not observed a recovery back above 30.'});
        } else if (row.rsi14 > 70) {
          Object.assign(item,{actionCode:'rsi_high_review',actionTitle:'Strong momentum — review before adding',explanation:'RSI is above 70, which can persist in a strong trend. It does not predict a decline or create an automatic sell. This starting portfolio has no position to sell.'});
        } else {
          Object.assign(item,{actionCode:'rsi_no_recovery',actionTitle:'No new recovery condition',explanation:'The current and previous RSI readings do not show a fresh crossing back above 30. Keep the planned review routine.'});
        }
      } else if (equity(asset) && type === 'price_action_research') {
        const observation = priceActionObservation(row);
        if (!observation) {
          Object.assign(item,{status:'waiting',actionCode:'insufficient_history',actionTitle:'Wait for complete daily candles',explanation:'This check needs 22 valid, ordered, completed daily candles from one adjusted series. A recent close alone cannot identify a pin bar or retest.'});
        } else {
          item.priceAction = observation;
          if (observation.retest) Object.assign(item,{actionCode:'price_retest_watch',actionTitle:'Prior breakout level held — review only',explanation:'The previous completed session broke above its prior 20-session high. The latest session touched that same fixed level and closed above it. This one-session retest is a watch condition, not a guaranteed support level.'});
          else if (observation.pinbar) Object.assign(item,{actionCode:'price_pinbar_watch',actionTitle:'Recovery-shaped candle at a prior low',explanation:'The daily candle meets the team pin-bar ratios and recovered above the preceding 20-session low. Review later confirmation and invalidation; the candle does not establish who traded or predict a bounce.'});
          else Object.assign(item,{actionCode:'price_no_setup',actionTitle:'No defined price pattern today',explanation:'The latest completed candle does not meet the team support pin-bar or one-session breakout-retest conditions. No entry is inferred.'});
        }
      }
    } else if (checked.reason) item.explanation = checked.reason;
    if (item.status === 'observed') plan.coverage.available.push(asset.ticker);
    else plan.coverage.missing.push(asset.ticker);
    if (item.market) plan.dataAsOf.push(item.market.priceDate);
    plan.assets.push(item);
  }
  plan.dataAsOf = [...new Set(plan.dataAsOf)].sort();
  if (hasSnapshot) {
    const available = plan.coverage.available.length, missing = plan.coverage.missing.length;
    plan.status = !missing ? 'ready' : available ? 'partial' : 'unavailable';
    plan.source.type = available ? 'rules_and_market_data' : 'rules';
    plan.basis = available ? 'Maintained template rules + completed daily prices' : 'Maintained template rules; current data unavailable';
    plan.summary = !missing ? 'The short-term checklist now includes dated observations. Review only the conditions supported below; the longer-term report remains a separate source.' : 'Keep the template checklist, but wait on assets whose data or indicators are missing. Available observations are identified individually.';
    plan.warnings.push(...strings(snapshot.warnings));
    if (missing) plan.warnings.push('No current action signal is inferred for: ' + plan.coverage.missing.join(', ') + '.');
  }
  if (!plan.coverage.requested.length) { plan.status = 'ready'; plan.summary = 'This match retains cash only. No market-triggered entry is proposed.'; }
  return plan;
}
