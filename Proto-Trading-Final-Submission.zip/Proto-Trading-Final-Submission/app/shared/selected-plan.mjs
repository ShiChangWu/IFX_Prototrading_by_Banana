import { ASSETS } from './strategy.mjs';

// Selection is an exploration state, separate from the authenticated AI match.
export function selectedPlan(match, selection, weights = {}) {
  const budget = Number(match?.profile?.budget || selection?.budget || 10000);
  if (!Number.isFinite(budget) || budget < 100 || budget > 1000000) throw new Error('Enter a valid budget first.');
  const tickers = [...new Set(selection?.tickers || [])].filter(t => t !== 'CASH');
  if (tickers.length > 8 || tickers.some(t => typeof t !== 'string' || !/^[A-Z0-9][A-Z0-9.\-^=]{0,14}$/.test(t))) throw new Error('Choose up to eight valid stocks or ETFs.');
  const allocations = tickers.map(ticker => {
    const original = match?.allocations?.find(a => a.ticker === ticker);
    const asset = selection?.assets?.find(a => a.ticker === ticker) || ASSETS.find(a => a.ticker === ticker);
    const weight = Object.hasOwn(weights, ticker) ? Number(weights[ticker]) : Number(original?.weight || 0);
    if (!Number.isFinite(weight) || weight < 0 || weight > 100) throw new Error('Each simulated weight must be between 0% and 100%.');
    return { ticker, name: asset?.name || original?.name || ticker, weight, amount: Math.round(budget * weight) / 100 };
  });
  const total = allocations.reduce((s, a) => s + a.weight, 0);
  if (total > 100.000001) throw new Error('Selected weights exceed 100%. Reduce an amount before continuing.');
  const cash = Math.round((budget - allocations.reduce((s, a) => s + a.amount, 0)) * 100) / 100;
  if(cash<0) throw new Error('Rounded amounts exceed the available budget.');
  allocations.push({ ticker: 'CASH', name: 'Unallocated cash', weight: Math.max(0, Math.round((100-total)*10000)/10000), amount: cash });
  const assumptions = allocations.map(a => ({ ticker: a.ticker, returnPct: a.ticker === 'CASH' ? 0 : (ASSETS.find(x => x.ticker === a.ticker)?.shock ?? -50) }));
  const lossAmount = Math.round(-allocations.reduce((sum, a, i) => sum + a.amount * assumptions[i].returnPct / 100, 0) * 100) / 100;
  return { budget, allocations, stress: { assumptions, lossAmount, lossPct: Math.round(lossAmount / budget * 10000) / 100, endingValue: Math.round((budget-lossAmount)*100)/100 }, tickers, hypothetical: true };
}
