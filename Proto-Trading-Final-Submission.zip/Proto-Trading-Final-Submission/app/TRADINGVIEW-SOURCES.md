# Strategies, indicators and data sources

Reviewed on 2026-10-04. The template version is defined by `TEMPLATE_VERSION` in `shared/templates.mjs`. The website gives absolute beginners a short explanation, with specific rules, data requirements and limitations under **Learn more**. The team maintains these rules. No TradingView Pine source is imported or executed.

## Ten strategies and tools

| Display name / ID | Availability | Source and current implementation |
| --- | --- | --- |
| Steady start / `defensive` | Matchable when eligible | Team-maintained defensive allocation, dollar amounts, assumed stress scenarios and review rules; not presented as a TradingView strategy |
| Balanced mix / `balanced` | Matchable when eligible | Team-maintained multi-asset allocation and five-percentage-point drift review |
| Moving averages / `trend` | Matchable when eligible | [D_Rockefeller's public description](https://www.tradingview.com/script/uNIA4siU-Moving-Average-Crossover-Swing-Strategy/); the team's completed-daily-bar 20/100-day average observation distinguishes a new crossing from an already established ordering |
| Bollinger Bands / `mean_reversion` | Matchable when eligible | [EdgeTools / Kevin Davey's public description](https://www.tradingview.com/script/umOCSa0t/); 20-day bands using two population standard deviations. A price below the lower band is not itself a purchase instruction |
| RSI / `rsi` | Matchable when eligible | [TradingView's RSI definition](https://www.tradingview.com/support/solutions/43000502338-relative-strength-index-rsi/); the team's RSI14 observation crosses from at or below 30 to above 30. It does not claim a confirmed reversal or Wilder's complete failure-swing pattern |
| Price Action / `price_action` | Matchable when eligible | [TradingView's hammer shape](https://www.tradingview.com/support/solutions/43000583775-hammer-bullish/) is a shape reference only; the 20-day range, pin-bar ratios and one-day breakout/retest are team-defined |
| ATR / `atr` | Implemented supporting risk tool; not allocation-matchable | [TradingView's ATR definition](https://www.tradingview.com/support/solutions/43000501823-average-true-range-atr/); Wilder ATR14, its percentage of the close and an illustrative 1.5-times distance. No directional forecast or automatic stop order |
| Wyckoff / `wyckoff` | Learning content; not allocation-matchable | [Wyckoff Analytics method overview](https://www.wyckoffanalytics.com/wyckoff-method/); ranges, price/volume, Spring, SOS and LPS. No automated full-phase recognition or point-and-figure targets |
| ICT / `ict` | Learning content; not allocation-matchable | [Original ICT course](https://www.youtube.com/watch?v=Bkt8B3kLATQ); high/low sweeps, structure changes and three-candle fair value gaps. No connected minute-level scanner |
| Order Flow / `order_flow` | Learning content; not allocation-matchable | [TradingView footprint calculation and limits](https://www.tradingview.com/support/solutions/43000726164-volume-footprint-charts-a-complete-guide/); trades, quotes, book depth and potential absorption. No synchronized tick/depth feed; daily volume is not treated as order flow |

The six matchable templates remain subject to questionnaire, use-of-funds, review-frequency and loss-capacity constraints. RSI and Price Action require daily review and answers of at least 15% on both loss questions; these answers are not actual loss caps. A beginner can deliberately explore and request a suitability check, while default automatic matching starts with foundational allocations. Educational entries and ATR do not offer allocation matching and are excluded from the backend's matchable candidates.

Learning examples include NVDA for Price Action, QQQ for RSI and TSLA for ATR. They are not mandatory holdings or current purchase recommendations. The app does not reuse fixed support levels, volatility amounts or account-protection claims from reference images. Candles and volume do not establish an institution's intentions.

## Explicitly measured daily observations

These descriptions document this project's code. They do not claim that the linked sources guarantee an effective trading system.

- **Moving averages:** at least 101 completed trading days of adjusted closes. Compare yesterday's and today's SMA20/SMA100; a new upward-cross observation requires the previous fast average to be at or below the slow average and the current fast average to be above it.
- **Bollinger Bands:** at least 20 adjusted closes; 20-day mean plus or minus two population standard deviations. A close outside the lower band is an observation while awaiting recovery; the upper band calls for review of an existing holding. With no holding, there are no shares available to sell.
- **RSI:** 14-day Wilder smoothing and at least 16 adjusted closes for current/previous comparison. Previous RSI at or below 30 and current RSI above 30 indicate an easing-weakness observation. Staying below 30 is not an automatic dip-buy, and exceeding 70 is not an automatic sale.
- **Price Action:** 22 complete, correctly ordered daily bars from a single adjusted series. The pin-bar reference is the preceding 20-day low, fixed before today's candle. The candle must touch or cross that low and recover, have a nonzero body, a lower wick at least twice the body, an upper wick no longer than the body, and a close in the top third of its full range. The one-day retest requires yesterday's first close above its preceding 20-day high, followed by today's touch of that same fixed level and a close above it. No qualifying pattern means no observation; the reference cannot be redrawn afterward to hide a failed condition.
- **ATR:** 14-day Wilder smoothing, at least 15 daily observations and valid OHLC. True range includes the intraday range and gaps from the previous close. A 1.5-times ATR value is an illustrative distance, not an optimal stop, position size, executable price or loss guarantee. A gap can cross a planned stop.

Observations appear only when data completeness, currency and date checks pass. Directional indicators apply only to the relevant template's stock/stock-ETF portion. A single price does not create a defensive-allocation buy signal. Adjusted historical prices are not current broker execution prices.

## AKShare reference versus adjusted indicator data

The integrated version is **AKShare 1.19.1**. Sina US `stock_us_daily(symbol=..., adjust='')` has returned actual reference daily data. The official documentation describes unadjusted daily output for that parameter: [AKShare stock documentation](https://akshare.akfamily.xyz/data/stock/stock.html).

`worker/akshare_reference.py` requests explicit US symbols, validates OHLCV and excludes records beyond the completed-session cutoff. Its results are labeled `reference_only` and `eligibleForSignals=false`. The endpoint does not supply per-instrument currency metadata, so `currency=null` and `currencyVerified=false` are retained. An endpoint's US-stock label is not proof of currency.

`worker/quick_market.py` separately obtains a currency-verified adjusted Yahoo Finance daily series for all indicator calculations. Each source retains dates, adjustment basis and failure reasons. Raw reference prices are never spliced into or substituted for the adjusted indicator series. An AKShare timeout does not remove the maintained rules; an invalid primary adjusted series never produces fabricated indicators. Successful requests for several tickers do not establish full-market coverage or continuous real-time availability.

Stock-directory search prefers AKShare and can use a labeled Nasdaq Trader fallback. The connected intraday display uses Yahoo Finance/yfinance completed minute bars, with source, observed time, delay and market status. The minute feed is separate from daily strategy confirmation and the bundled historical dataset. Current selected stocks drive exploration, while a ticker without appropriate historical coverage is labeled unavailable for a rule test.

## Research, strategy tests and maintenance

The saved report's historical calculation is a **fixed-target-weight, monthly-rebalanced allocation comparison**. It preserves the sample window, 10 bps trading cost and contemporaneous SPY. It is not the return of TradingAgents forecasts or a full moving-average/Bollinger/RSI/Price Action signal system.

The separate strategy lab in `shared/school-backtest.mjs` tests disclosed rules against the saved adjusted daily history in `shared/school-prices.mjs`. It supports date selection and fees per buy or sell. Indicators use earlier observations; completed-close signals execute at the following available open, including gaps. Final liquidation uses the last test close with the selected fee. The results exclude taxes, bid/ask spreads, slippage and cash interest. ATR is a single-entry risk-exit illustration; Wyckoff is an experimental daily spring proxy. ICT and order flow have no fabricated performance series. See [TradingView's strategy-testing documentation](https://www.tradingview.com/pine-script-docs/concepts/strategies/) for methodological background only.

Hypothetical future price scenarios for selected stocks are illustrations of stated assumptions and possible review actions. They are not forecasts, validated strategy returns or broker orders. Recording actual shares and execution prices is separate from these scenarios.

The two community-script descriptions provide learning references. This project did not copy their Pine source or reproduce their claimed returns. Historical performance, likes and an author's claims are not recommendation evidence. A future code port would require license-specific attribution.

Maintain each template's ID, version, author/source, eligibility, explicit measured rules, research prompt, role, matchable status, data requirements and missing-data behavior together. User text and external material cannot override risk constraints. The saved real demonstration report keeps its original inputs, date and **partial** macro-source status. UI and indicator changes do not by themselves rerun paid AI research, complete public deployment or establish browser visual acceptance.
