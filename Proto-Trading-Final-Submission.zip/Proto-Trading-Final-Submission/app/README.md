# Proto-Trading — Smart Trading for Everyone.

Built specifically for iFX Hack Hong Kong 2026. The original website structure and four-person team page are retained. The project aims to make financial tools easier for absolute beginners to understand: questionnaire, strategy matching, stock selection, hypothetical actions, risk explanations and sourced research.

## Start with the shared package

Extract the entire ZIP before opening its root `START-HERE.html`. The `web/` folder is the portable demonstration website: local questionnaire, maintained rules, stock selection, saved-data strategy tests, report uploads and saved examples. The `reports/` folder contains deliberately shared, dated research. Opening the offline HTML does not make new DeepSeek, market-data or TradingAgents requests.

The `app/` folder contains the connected app source and a pinned TradingAgents source copy. Follow `SETUP.html` or `PORTABILITY.md` to run the backend using your own credentials. No Codex installation, GitHub account or cloud project is required for local use. See `DELIVERY-REVIEW.md` for the full workflow, remaining limits and a three-minute demonstration outline. A delivered folder is not a public deployment.

## Open the local app

After starting the server, open **http://127.0.0.1:8787**. Get started opens the workspace, also available directly at **http://127.0.0.1:8787/workspace.html**.

On Windows, double-click `Start-Local.cmd`. It builds the website and starts the local API and any available research worker in the background. Use `Stop-Local.ps1` to stop verified processes managed by this launcher. For foreground logs, run `Start-App.ps1` in one terminal and `Start-Research.ps1` in another. Keep the app and research worker running; computer sleep interrupts new work, while saved reports remain on disk. The background launcher checks default port 8787.

If DeepSeek seems unavailable, check the mode banner first. A `file:///.../web/` page is the offline backup and cannot make AI requests. In the connected app, **Show my starting plan** requests a quick DeepSeek explanation; **Research → More options → Generate deep research** starts the separate TradingAgents job. **Open prepared report** instead opens the saved evidence immediately, without a new model call. Keep the worker awake while progress is shown. The verified three-asset run on 2026-10-04 took 7 minutes 23 seconds; this is a measured example, not a promised duration. A partial result retains missing evidence explicitly.

The AI explanation now stays visible and is saved in the current browser tab with its received time. Refresh AI match requests a new answer. Opening an example or an uploaded report does not discard access to the generated report: choose **Open generated report** on the job card. Market refreshes preserve strategy-lab backtest results. A stock at 0% is **Watch only**, with no simulated investment; it is not a failed AI response.

Put credentials only in `.env.local`. Do not upload `.env.local`, `.local/`, private `data/` or `.venv/`. The app generates a random worker secret for a new local installation. DeepSeek and worker secrets are never sent to the frontend. `dist/` is the connected website build; the packaged `web/` version is separately prepared for direct file opening.

## Beginner flow and selected stocks

The first visit includes a four-step introduction: purpose, preferred starting point, feature guide and begin. Skip introduction remains available; Quick tour reopens the guide. The tour chooses a page, not risk answers, and makes no AI request.

1. Complete **About you** with your goal, amount, time horizon, willingness to lose money, financial ability to absorb loss and essential-money confirmation. Extra settings are under More choices.
2. Choose **Show my starting plan**. A maintained strategy appears immediately with a plain-language explanation; a connected DeepSeek response may choose among templates that satisfy the questionnaire constraints.
3. Check the stocks you want to follow. Search by ticker or company name to add others. The selected-stock details and **Find an approach you understand** exploration follow your current selection, including changes made before saving. Your selected list is different from a completed trade record.
4. Review the selected-stock illustration and hypothetical price scenarios. A stated future price and suggested review action describe a conditional example, not a predicted price, broker order or guaranteed return. Where data is unavailable, the app shows that limit rather than fabricating a quote.
5. Save the stocks to follow before refreshing connected prices or configuring backend reminders. Record shares and actual price only after making a trade with your broker.
6. Open Research and choose **Open prepared report** for the immediate popup. It contains the real saved 4 October 2026, 15:27 HKT report. Close or Escape returns to the app; a normal link remains available without dialog support. Use **More options** to generate, upload or reopen other reports. Before generating, inspect **Research inputs**: one to eight selected stocks, their exact hypothetical weights, remaining cash and the confirmed matched approach. Every selected stock is researched, including 0% watch-only ideas. The accepted job freezes those inputs; later edits do not alter it. **Open generated report** opens that actual completed result, separately from the prepared example.

The original questionnaire match remains the context for eligibility and strategy choice. New research explicitly uses the current selected stocks and user-entered weights; it does not reuse removed template assets. Merely exploring another approach does not change the matched approach used for research. Update the questionnaire match to change that input. User-selected weights are hypothetical, not a newly optimized allocation or AI suitability approval. Saved reports, uploads and creator combinations retain their own labels and inputs.

## Strategy exploration and backtests

Each strategy now has its own hypothetical inputs: scheduled weights, moving-average crossovers, RSI recovery, Bollinger recovery, ATR trailing levels, confirmed pin bars/retests or a spring with volume. ICT and Order Flow provide learning checklists only. Saved historical indicators are dated separately from assumed future conditions. Recorded holdings distinguish entry from exit examples; these examples do not execute trades.

Every approach shows one short introduction and a 0–100 learning-fit score for the selected stocks. The transparent team rubric combines maintained asset-type compatibility (45%), beginner rule simplicity (30%) and validated saved-history coverage (25%). Each selected stock counts equally; its individual score is visible after opening an approach. These are teaching preferences, not expected returns, win rates, AI predictions or personal suitability. Missing history and unknown asset classes lower the result. ICT and Order Flow are capped at 20 because their required execution/data paths are absent; ATR is a risk tool. The rubric is maintained in `shared/school-fit.mjs`.

- **Defensive:** keep more cash and begin with smaller investments.
- **Balanced:** spread the budget across assets and review their weights.
- **Moving averages:** follow a trend when shorter and longer averages cross.
- **Bollinger Bands:** watch a sharp drop recover toward its recent range.
- **RSI:** check whether recent selling pressure is easing.
- **Price Action:** inspect reactions around previous turning points.
- **ATR:** use typical price movement to understand exit-review distances.
- **Wyckoff:** study failed breakdowns with volume; only a daily proxy is tested.
- **ICT:** learn about intraday highs, lows and gaps; no verified scanner.
- **Order Flow:** learn from trades and orders; required tick/depth data is absent.

Read the recommended strategy and other eligible approaches in everyday language. Explore stocks & backtest opens the strategy lab. Search for an approach, choose a selected stock where history is available, set start and end dates, a fee per buy or sell, and the hypothetical test amount. Run this rule test recalculates the curve, same-stock buy-and-hold comparison, maximum daily-close drawdown, trade count and fees. Open individual trades or download the result as JSON. Changing parameters marks an old result as needing recalculation.

- Saved actual daily history covers VTI, SCHD, QQQ, SGOV, IEF, GLD, MSFT, AAPL, NVDA, AMD, AMZN, GOOGL, META, AVGO and SPY from 2023-05-01 through 2026-10-02. SPCX begins on its 2026-06-12 first trading date and ends on 2026-10-02. Data comes from Yahoo Finance/yfinance adjusted daily bars with retrieval times and USD checks; it is not a live feed. The portable HTML can recalculate within the included history without a model key. A searchable stock does not necessarily have bundled backtest history.
- Tested rules include 20/100-day moving averages, RSI crossing back above 30, Bollinger recovery and defined daily Price Action. ATR is explicitly a single-entry risk-exit illustration, and Wyckoff is an experimental daily spring proxy. Defensive and balanced pages show a single-asset buy-and-hold comparison, not a backtest of their complete multi-asset allocation. ICT and order flow lack the required intraday/tick data and full executable rules; their limits are visible and returns are not fabricated.
- Indicators use earlier warm-up data. A completed-close signal executes at the following trading day's open. A close-based stop review cannot assume a perfect stop fill; overnight gaps use the actual next opening price. The test liquidates at its final close and charges the chosen fee on each purchase and sale. It excludes taxes, slippage, bid/ask spreads and cash interest. Historical in-sample results do not predict future returns.
- Four educational stock combinations cover ETF plus AI stocks, large companies, a chip theme and space innovation. Read a simple report, adjust percentages and save locally. These combinations are labeled examples and do not create new TradingAgents research.
- Simple reports include a visual allocation breakdown, dollar amounts, time-horizon explanations and an adjustable annual-return assumption calculator. There is no validated forecast of future return; calculated scenarios are mathematical assumptions, not return targets or profit deadlines.
- Company references cover AMD, NVDA, AAPL, MSFT and SPCX: quarterly revenue, year-over-year growth and GAAP diluted earnings or loss per share, with periods, release dates and company IR/SEC links. This snapshot was maintained as of 2026-10-04; it is not a live earnings API. An older report cannot use results released after its research date. References accompanying an uploaded document are separate from its unverified text.
- SPCX is SpaceX, first traded on 2026-06-12. An unrelated ETF formerly used that ticker. Market and backtest guards reject pre-listing history instead of reusing the old ETF's prices.

Maintain rules and covered stocks in `shared/school-backtest.mjs` and saved history in `shared/school-prices.mjs`. With the configured Python environment and an internet connection, run `python -m worker.export_school_prices` to refresh public historical data, then rebuild and package. This requests public tickers and does not use private questionnaires or paid AI.

## Implemented features and boundaries

- **Questionnaire:** US stocks and US-listed ETFs in USD, default $10,000 and no initial holdings. Risk willingness and financial loss capacity are asked separately.
- **Matching:** DeepSeek selects only from maintained templates allowed by the questionnaire. Code calculates tickers, weights, amounts and stress scenarios. AI cannot override hard eligibility constraints.
- **Ten strategy entries:** defensive allocation, balanced allocation, moving averages, Bollinger Bands, RSI, Price Action, ATR, Wyckoff, ICT and order flow. The first six can match when eligible. ATR is an additional risk tool; Wyckoff, ICT and order flow are learning entries, not automatically allocated portfolios or claims of detected signals. Rules and sources are in `TRADINGVIEW-SOURCES.md`; maintained prompts are in `shared/templates.mjs`.
- **Short-term observations:** immediately available strategy checklists, followed by conditional observations from completed daily data when available. Rules include 20/100-day averages, 20-day Bollinger Bands, 14-day Wilder RSI recovery above 30, and team-defined pin-bar or one-day breakout/retest patterns. Directional observations apply only to the relevant stock portion of a template. Wilder ATR14 shows measured range and an illustrative 1.5-times distance, not direction, an actual stop order or a guaranteed loss cap.
- **Generated research:** new selected-stock requests cover one to eight verified US stock/ETF codes, including 0% watch-only entries. The backend recalculates amounts and cash from the submitted weights, verifies the confirmed profile and match, and freezes a job input snapshot. Portfolio history uses positive-weight holdings only; watch-only names do not affect its returns. Each selected ticker receives research or an explicit error, with source coverage recorded. Legacy questionnaire-only requests and the prepared example retain their original, narrower scope. Research provides 1–3-month and 6–12-month context only when the evidence supports those horizons; missing summaries remain unavailable. More selected stocks require more processing time and API calls.
- **Uploads:** UTF-8 Markdown/TXT, up to 2 MiB per file; JSON is readable as a source document. Uploads stay in the current browser, with reopen, download and delete controls. Files are not sent to the server or DeepSeek and do not automatically become personalized analysis. Extracted dates and horizon excerpts are unverified source information, without invented allocations or backtests.
- **Saved report history comparison:** actual adjusted closes, fixed target weights, monthly rebalancing, 10 basis points per traded dollar, and contemporaneous SPY; cash earns zero. This is distinct from strategy-lab signal tests and is not the past return of TradingAgents forecasts.
- **Inverse ETFs:** research can compare -1x, -2x and -3x products. They are not automatically allocated to beginners. Daily reset and multi-day path dependence remain relevant.
- **Creator area:** adjust, name, save and reopen browser-local combinations. Public community publishing remains future work.
- **Execution:** there is no broker connection and no order placement. Illustrative amounts are not executable live orders. A questionnaire loss tolerance is not a maximum-loss guarantee.

Without keys, maintained rule matching still works and AI panels accurately show the missing connection. An offline research computer does not appear to be analyzing. Network, price and model failures retain their reasons rather than producing invented returns or reports.

## Progressive detail for beginners

The workspace uses About you, Your strategy, Research and Explore strategies. Optional frequency, experience, asset preferences, inverse-ETF research, free text and manual strategy choices are grouped under More choices. Main risks, dates, source gaps and next review steps stay visible. Calculation assumptions, indicator details, full sources and report text are available through keyboard-accessible expandable panels.

Learning examples explain Price Action, RSI or ATR; they do not carry over the fixed support prices, volatility amounts or profit-protection claims from reference images. Uploaded text is displayed as non-executable plain text. Changing dates, selections or costs does not silently relabel an old research report as new analysis.

## Market data, search and measurement

AKShare 1.19.1 provides stock-directory integration and a Sina US daily reference through `stock_us_daily(symbol=..., adjust='')`. See the [official AKShare stock documentation](https://akshare.akfamily.xyz/data/stock/stock.html). This raw daily reference lacks per-instrument currency metadata: it is marked `currencyVerified=false`, is not described as verified USD and is not used for strategy indicators or dollar calculations. Directory failures can fall back to a clearly labeled Nasdaq Trader directory.

RSI, Price Action, ATR, moving averages and Bollinger Bands use one consistent, currency-verified Yahoo adjusted daily series. Raw AKShare reference data is never spliced into that adjusted series. More detail exposes source, dates, basis and fallback reasons. When completeness, currency or freshness checks fail, the app shows rules and waiting messages instead of directional observations.

Yahoo Finance/yfinance provides completed minute bars for the connected intraday display without an Alpaca key. Quotes show their source, timestamp and available, delayed, closed-market or unavailable state. They are not guaranteed current execution prices. Stale or incomplete prices cannot create a valid current price alert. Checking during the trading day does not transform a daily rule into an intraday strategy.

The lightweight daily market process runs independently of TradingAgents. It queries at most five holdings, caches valid snapshots for 15 minutes and suppresses directional observations if processing times out or data is over four calendar days old. Arbitrary natural-language prompts are not automatically converted into verified executable rules; maintainers must align structured conditions and research prompts.

## Gmail reminders and trade records

The sidebar Subscribe (demo) form saves a consented email address on this device only. It can show a sample message and delete the local record. Default `EMAIL_DELIVERY_ENABLED=false` keeps actual sending disabled in the application, even if credentials are present.

The backend source includes `server/gmail.mjs`, `worker/send_gmail.py`, tracking rules, an outbox, recipient verification, private trade-recording links and unsubscribe links. The package therefore includes the sending implementation, not just a visual form. To enable it, set up the local Python environment, configure your own `GMAIL_USER` and `GMAIL_APP_PASSWORD` in `.env.local`, choose a reachable `ALERT_BASE_URL`, explicitly set `EMAIL_DELIVERY_ENABLED=true`, and restart. See `/email-setup.html` for the complete recipient verification and activation sequence. The default Yahoo provider is `INTRADAY_PROVIDER=yahoo`.

Recipients must consent, verify their email and enable reminders for saved stocks. A sell reminder needs a recorded holding. Only record a purchase or sale after a real broker trade, using actual quantity, execution price and time. The app does not read email replies; the message contains a private form link. SMTP acceptance is not proof of inbox delivery. An uncertain send outcome is not automatically retried. The ledger does not automatically adjust splits, taxes, fees or corporate actions.

Automatic checks require the configured backend to remain awake and connected. Private sessions expire after seven days; re-match in the original tab to renew. Default localhost links are usable only on that computer. A public service needs deployed APIs, persistent user storage, a running backend and appropriate market-data permissions. Static HTML alone cannot continuously check markets or send emails. Private addresses, holdings, credentials and sending records are excluded from the package.

## Saved demo report and presentation

Carry a genuinely generated report before presenting. The included example was generated on 2026-10-04 at 15:27 HKT, starts with $10,000 and no holdings, and contains VTI, IEF and SGOV TradingAgents research plus a 2023-10-02 to 2026-10-02 historical allocation comparison. It remains **partial** because of missing evidence and unavailable horizon summaries. Its recorded TradingAgents commit is **unknown**; the separate packaged source pin must not be presented as proof of the revision used for that saved run.

Open the package's `reports/Proto-Trading-Demo-Report.html` without a server or new model call. Upload `reports/TradingAgents-VTI-demo.md` to show VTI source excerpts from that report. The reviewed JSON is in `examples/prepared-report.json`, also copied to `examples/demo-report.json` for first-launch seeding. These files preserve their original inputs and dates. Use `node scripts/export-report.mjs INPUT.json OUTPUT.html` to export a newly reviewed report.

The approved public example is also bundled as `examples/demo-report.json`. First launch imports it only when there is no existing local task state; it does not overwrite existing private state. Upload libraries belong to a browser and site origin. Clearing site storage, changing browsers or switching between `127.0.0.1` and `localhost` does not carry the library along; retain original MD/TXT files. If storage is unavailable, the current document can still be read in the page.

For a short demonstration, complete About you, select stocks, show the matching scenarios, adjust a strategy test, then open the dated report. Preview the Gmail flow with delivery off and accurately label its status. Explain that public community features and cloud deployment are future work.

## Save and publish research reports

Private jobs require a browser-session access token. Refreshing the browser can resume access; after session data is cleared, the local operator can export a report.

```text
node server/reports.mjs list
node server/reports.mjs export JOB_ID NEW_FILE.json
```

To deliberately publish your own reviewed demo case, stop the website, run `node server/reports.mjs publish JOB_ID`, then restart. Publication includes that case's questionnaire and research. Do not publish other visitors' personal information. Use `unpublish` to remove a public example.

## Future public deployment and AWS

1. Deploy the website and API to Netlify using the supplied `netlify.toml` and Functions adapter.
2. Create Supabase and apply `supabase/001_private_state.sql`. The current private state uses version-checked updates for a small single-worker demonstration; a multi-user product needs per-job storage and a queue.
3. Set the backend DeepSeek, Supabase and `WORKER_SECRET` configuration from `.env.example`; never embed secrets in web assets.
4. Point the local worker's `APP_BASE_URL` at the public HTTPS origin and use the matching worker secret. The worker claims jobs outbound, without an open inbound port.
5. An AWS migration can host the same Python worker persistently, preserve the job/report interfaces and later move storage or queues as needed. Permissions, persistence and monitoring still require deployment work.

The lightweight local Python market process needs a separate service when deploying to Netlify, or it can move to an always-running host. Without it, show the strategy checklist and missing market connection accurately. Netlify/Supabase public deployment and real cloud storage have not been accepted as working. A local success is not evidence of cloud availability.

## Confirmed team portraits

The supplied team order and names are WU Shi Chang (Initiator, orange hat and blue jacket), YU Zhuowei (Hipster, white Nike T-shirt), HUANG Weiting (Hacker, black shirt at the seaside) and WEN Wai Hai (Hacker, white knitted top and glasses). Their original images are in `public/assets/team`; the website uses display crops and retains clickable introductions. WU is described as Initiator, not a team hierarchy.

## Validation and source attribution

Run from the `app` directory:

```text
node --test tests/*.test.mjs
node tests/ui-contract.mjs
.venv/Scripts/python.exe -m unittest discover -s tests -p "test_*.py"
```

Offline UI and data-boundary tests do not constitute browser visual acceptance. The latest delivered package records the actual checks and remaining limits in `VALIDATION.txt`. The optional `scripts/smoke-ai.mjs` calls DeepSeek and can incur API charges; it is not an offline unit test. Personal-computer launch wrappers and one-off demo job scripts are excluded from the shared package.

Official TradingAgents source is pinned to `1394a3f72aa4393e1a98f51b382434c4b4c2d972` (v0.6.0) in `vendor/TradingAgents`. Its license is preserved at `vendor/TradingAgents/LICENSE`; `VENDOR-REVISION.txt` records the bundled revision without requiring Git history. The website shell is kept in `shell/proto-trading.html`, so the complete app folder can build independently. The build writes the generated `dist/` directory. Third-party source is attributed to its original authors.
