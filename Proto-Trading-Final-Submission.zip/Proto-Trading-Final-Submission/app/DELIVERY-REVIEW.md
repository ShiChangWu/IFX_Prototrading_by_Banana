# Proto-Trading — Delivery and demonstration review

**Smart Trading for Everyone.** An AI financial-access prototype built specifically for iFX Hack Hong Kong 2026. It helps people without a quantitative background understand strategies, selected stocks, amounts, conditional actions and research evidence. Broader access means lower barriers to understanding and use, not equal returns or equal risk.

This review reflects the application and saved research as of 2026-10-04. Items described as awaiting acceptance are not completed features. Use the package's startup instructions and `VALIDATION.txt` for the final packaged checks and limitations.

## Demonstration route

1. Show the skippable introduction. Users can start with a plan, stock exploration or a report; Quick tour replays it.
2. Complete About you and choose Show my starting plan. The app immediately explains a matched approach in everyday language, then offers stocks to follow.
3. Check stocks or search for others. Selected-stock details and Find an approach you understand follow the same current selection. Show the chosen strategy's hypothetical condition, such as an average crossover, RSI recovery or an ATR risk level, and the corresponding review action. This is a conditional illustration, not a predicted price or an executable order.
4. Open the strategy lab, choose an approach and a selected stock with included history, change dates or the fee per side, then rerun. Show the real recalculated curve, same-stock buy-and-hold comparison, daily-close drawdown, trades and costs.
5. Open Research and click Open prepared report. The saved document opens immediately, with no new analysis; Close or Escape returns to the app. Company references include AMD, NVDA, AAPL, MSFT and SPCX, with publication dates and sources. An annual-return assumption calculator produces mathematical scenarios only. A saved TradingAgents report retains its original inputs and partial status.
6. Preview the sidebar Gmail subscription, with delivery off. The connected backend includes a real sending implementation and trade-recording links, but it requires the operator's credentials and explicit activation.

Strategy-lab tests are separate from the saved report's fixed-weight allocation comparison. Moving-average, RSI, Bollinger and Price Action tests implement disclosed team rules. ATR is a single-entry risk-exit illustration; Wyckoff is a daily spring proxy, not full phase detection. ICT and order flow lack the required intraday/tick data and complete test rules, so they provide learning content without invented results.

Bundled price history ends on 2026-10-02. SPCX starts at its 2026-06-12 listing; the former unrelated ETF's prices are rejected. Fees apply to purchases, sales and final liquidation. Close-generated signals execute at the next trading day's open. Close-based risk reviews are not guarantees of an intraday stop fill. Date and fee changes recalculate actual rules rather than switch between prepared performance figures.

## User workflow

1. **About you:** goal, budget, time horizon, willingness to lose money, ability to absorb loss and essential-money confirmation. More choices holds optional settings. The user need not understand strategy terminology first. The initial scope is USD, US stocks, US-listed ETFs and cash, with $10,000 and no holdings by default.
2. **Your strategy:** an immediate maintained-rule match. When connected, DeepSeek selects and explains an eligible template; code remains responsible for hard constraints, original template weights and amounts. The user chooses stocks for tracking and scenario exploration.
3. **Selected stocks and scenarios:** the detail and exploration views follow the current stock selection. Hypothetical actions show the price assumption and a review condition. Selecting a stock is not a new suitability assessment or confirmation that it has been purchased. An old report is never silently relabeled as research on a new selection.
4. **Short-term observations:** the strategy checklist appears without waiting for research. Valid daily data adds observations for conditional review over roughly 1–4 weeks. ATR measures range, not direction. Yahoo minute prices remain distinct from daily confirmation signals.
5. **Research:** open the prepared report immediately. Generate/upload tools are under More options. For a new request, review the selected one to eight stocks, their exact hypothetical weights and cash, plus the confirmed approach. Every selected ticker is researched, including 0% watch-only ideas; the accepted job freezes those inputs. Open generated report displays the actual cached result, separately from the prepared example. Sourced 1–3-month and 6–12-month material requires matching horizon evidence. Research needs a running worker and may take several minutes per stock, so prepare it before presenting.
6. **Explore strategies:** read short explanations and expand rules, examples and limitations. Test covered stocks or adjust and save a named browser-local combination. This is not a public creator marketplace.
7. **Reminders and trade records:** save selected stocks; real email requires configured Gmail, verification, consent and activation. Record actual shares, execution price and time only after a completed broker trade.

## Evidence and limits

| Feature | What can be demonstrated | Limit that must remain clear |
| --- | --- | --- |
| Matching | Maintained rules; real DeepSeek when configured; original allocation in maintained stocks, ETFs, Treasuries, gold and cash | AI stays within allowed templates; arbitrary prompts are not automatically verified trading systems |
| Selected stocks | Search, checkboxes, linked detail and strategy exploration, conditional price scenarios | A selection is not an executed holding, optimized allocation or automatic suitability approval |
| Risk display | Dollar amounts and stated stress or hypothetical price assumptions | A user's loss tolerance is not a loss cap; scenarios are not forecasts |
| Daily market observations | Up to five non-cash allocation assets; adjusted daily bars, moving averages, Bollinger, Wilder RSI14, defined Price Action and Wilder ATR14 | Incomplete, stale or currency-unverified data cannot generate observations; 1.5-times ATR is only an example distance |
| Yahoo intraday display | Completed minute bars with source, time, delay, closed-market or unavailable status | Not guaranteed live execution prices; a minute quote does not confirm a daily strategy |
| AKShare | Preferred stock-directory search and raw Sina daily reference; labeled Nasdaq Trader directory fallback | Raw reference data lacks per-instrument currency verification and is not used for adjusted indicators |
| Strategies | Ten entries: defensive, balanced, moving averages, Bollinger, RSI, Price Action, ATR, Wyckoff, ICT and order flow | First six can match when eligible; ATR is a risk tool; remaining advanced entries are educational |
| TradingAgents | New requests research all one to eight selected tickers, including 0% watch-only ideas, with frozen weights/cash, questionnaire and matched approach | User weights are hypothetical and not a new suitability approval; more stocks take longer; missing evidence and unknown instrument classification stay explicit. ETF holdings, expenses and tracking error are not fully modeled |
| Saved real example | The 4 Oct 2026, 15:27 HKT report contains VTI, IEF and SGOV research and allocation history | Marked **partial** for missing evidence and unavailable horizon summaries; generation commit is unknown. It keeps its original narrower inputs and never becomes research on newly selected stocks |
| Saved allocation comparison | 2023-10-02 through 2026-10-02 adjusted closes, fixed targets, monthly rebalance, 10 bps on traded dollars and SPY comparison | Zero cash interest and fractional shares; not the return of TradingAgents forecasts or a complete strategy signal system |
| Strategy-lab tests | Actual included daily data, causal indicators, next-open execution, dates and fees that recalculate | Limited stock/history coverage; no tax, slippage, spread or cash interest model; no claimed ICT/order-flow return |
| Inverse ETF research | SH/SDS/SPXU daily-history comparison with SPY and explicit scenarios | Daily reset and path dependence; not automatically allocated or shown suitable for beginner long-term holding |
| Uploads and creation | Markdown/TXT, JSON as source text, 2 MiB upload limit and browser-local combinations | No server/model upload, independent document verification, new personalized research, cross-browser sync or guaranteed storage retention |
| Gmail | Included SMTP adapter, verification, outbox, private trade links and unsubscribe flow | Sending off by default; sender setup and recipient consent required; SMTP acceptance is not confirmed inbox delivery |
| Execution and community | Review, research, download, save local combinations and record completed trades | No broker connection, order placement, public accounts, cross-device community publishing, paid marketplace or creator revenue sharing |

A traceable quotation does not by itself establish that the original research is correct. Long-term summaries need exact supporting material for the stated horizon. Saved reports retain their original input and generation time. Legacy requests without a selected-stock payload keep their original top-three scope. The current interface shows selected-stock inputs before submitting and the server's accepted snapshot afterward; changing checkboxes while a job runs does not change its research. Exploring a different school does not change the matched approach used for the job.

The interface keeps primary risks, source gaps, observation dates and next steps visible, with technical details and full sources under expandable panels. Native summary controls support keyboard operation. Uploaded source text is non-executable. See `TRADINGVIEW-SOURCES.md` and the [official AKShare documentation](https://akshare.akfamily.xyz/data/stock/stock.html).

## Checks before presenting or sharing

- **Opening the extracted package:** verify its double-click entry and saved reports in a separate extracted folder. The normal `dist/` uses root paths and modules; it is not made file-compatible by renaming. The portable version needs separate checks.
- **Accurate state labels:** show report dates, original questionnaire, coverage and source gaps. Offline mode provides included content and local calculations. New AI, market checks and research require their services.
- **Browser visual acceptance:** manually check the questionnaire, selected-stock synchronization, scenarios, report upload/reopen/delete, saved combinations, narrow-screen scrolling and connection failures. Static parsing and unit tests do not replace these checks.
- **Recoverable material:** carry the standalone report HTML and original MD/TXT files. Open them on the demonstration computer in advance; do not rely only on another computer's browser storage or private jobs.
- **Recipient installation:** verify a new configuration and environment, rules-only mode, dependencies and connection checks. Do not copy `.venv`. The app requires Node.js 22+; the research setup accepts Python 3.11–3.13, with 3.12 as the reference environment.
- **Package contents:** allowlisted source and approved examples only. Exclude keys, session tokens, task state, cookies, caches and logs, and verify the manifest. Refer to the package's final `VALIDATION.txt` for checks actually completed.

## Next stage

- Finalize strategy prompts and keep them aligned with structured eligibility, entry/exit conditions, risk review and template versions.
- Extend rule-specific historical coverage and out-of-sample validation. The existing lab does not validate every strategy variation, intraday stop execution or portfolio drift rule.
- Improve market/macro coverage and source reliability, complete ETF details, reduce multi-stock research latency and test whether beginners understand the explanations.
- Complete public Netlify/Supabase deployment and an independent market service. The Python worker can migrate to a persistent AWS environment; prepared adapters do not constitute an accepted cloud deployment.
- Replace small-demo state storage with user accounts, per-job persistence and queues as needed. Add operational monitoring and cost controls. Community publication, moderation and creator business features remain future work.

## Business hypotheses to test

**Problem:** beginners face unfamiliar strategy terminology, fragmented information and risks that are difficult to interpret. The product helps them translate a goal into understandable, reviewable steps and inspect the supporting evidence.

**Potential users:** individuals learning USD stock/ETF investing who can review periodically but cannot write quantitative code, and financial education or service teams that need an explainable research workflow.

**Potential revenue:** free basic matching and explanation, with deeper research, saved comparisons or team workflows supporting a premium subscription or B2B service. Willingness to pay, acquisition cost, retention, research unit costs and institutional demand have not been validated. There are no claimed revenue, customer or traction figures. Beginner usability tests and small pilots should test understanding, review habits and willingness to pay.

## Three-minute presentation

| Time | Screen and message |
| --- | --- |
| 0:00–0:25 | Explain the beginner problem and say “Smart Trading for Everyone.” State that the project was built for this hackathon. |
| 0:25–1:15 | Complete About you, show the matched strategy, select stocks and show matching hypothetical actions. Distinguish maintained rules, real data and AI explanation. |
| 1:15–2:15 | Open the prepared real report. Show dates, inputs, horizon evidence and missing sources. Briefly distinguish saved allocation history from strategy-lab tests. |
| 2:15–2:40 | Adjust a date or fee and rerun a covered-stock test, or preview the Gmail subscription with actual delivery off. |
| 2:40–3:00 | Explain the next steps: validate beginner understanding and demand, improve data and rule coverage, deploy publicly and build the community. Revenue remains a hypothesis. |

For the two-minute Q&A: **What is live?** Connected matching and market requests use configured services; the long report is a dated saved result. **What is AI?** DeepSeek chooses/explains allowed templates; TradingAgents provides sourced research; code calculates allocations and tests. **Does it trade?** No. **Why partial?** Specific source gaps are disclosed. **Does Gmail send?** The implementation is included but defaults to off and needs sender configuration and recipient verification. **Who pays?** Subscription/B2B demand is still a hypothesis.

The judging criteria are addressed through real interaction and saved evidence for working functionality (35%), a concrete beginner problem and testable business case (35%), a concise presentation (15%), and the combination of immediate rules, independent research and editable selections (15%). The presentation must not claim incomplete features.

## Source package and dependencies

Keep source, launch/setup scripts, `.env.example`, dependency locks, documentation and reviewed public examples. A first local launch creates a new configuration; each recipient supplies their own backend DeepSeek key. Rule matching does not need that key, but new AI research cannot run offline. Python setup needs network access and a compatible installed runtime.

Windows uses PowerShell/CMD launchers. macOS/Linux scripts include `Start-Local.sh`, `Setup-Research.sh` and `Start-Research.sh`, called through `bash`. Their presence does not prove a fresh-machine installation has been accepted on every platform; see `PORTABILITY.md` and `VALIDATION.txt`.

TradingAgents is pinned to `1394a3f72aa4393e1a98f51b382434c4b4c2d972` (v0.6.0). Preserve `tradingagents/`, `cli/`, `pyproject.toml`, `README.md` and `LICENSE`, including runtime assets `tradingagents/assets/tauric-logo.svg` and `cli/static/welcome.txt`. Keep Apache-2.0 attribution and source notices. Third-party source is not described as the team's original work.

Vendor Git history, GitHub metadata, tests, top-level promotional images, generated egg-info and Python caches need not ship. Do not arbitrarily remove analysts, data providers or reporting modules. Without Git history, `VENDOR-REVISION.txt` records the verified bundled revision. The prepared report itself records **unknown** generation revision, preserved without substitution; a source pin is not proof of which commit generated that historical report.

Exclude `.env.local`, `.env`, `.local/`, `.venv/`, `data/worker/`, market cookies/databases/CA caches, `data/demo-session.json`, logs, locks, personal Demo wrappers and unreviewed report backups. Never copy all of `data/`. Approved examples are `examples/prepared-report.json`, its `demo-report.json` seeding copy, the exported `Proto-Trading-Demo-Report.html` and `TradingAgents-VTI-demo.md` source excerpts; they intentionally include the same saved example's inputs and research.

Documentation review used source files, public source notes and saved-example status fields, without reading credential values or private session state. UI and rule checks use offline tests and DOM doubles; they do not establish visual browser acceptance. The final ZIP, portable entry and clean-copy installation checks are reported in the package's `VALIDATION.txt`, with remaining checks explicitly identified.

## Email defaults, data and team confirmation

The sidebar Subscribe (demo) saves a consented address only on the current device. It previews a sample email and can remove the saved address. Actual delivery is off by default: `EMAIL_DELIVERY_ENABLED=false`. The connected package includes `server/gmail.mjs` and `worker/send_gmail.py`, verification, reminders, trade-recording links and unsubscribe support. Real sending requires the operator to configure Gmail, explicitly enable delivery, restart and complete recipient verification. No private email address, holding, credential or sending history is included in the package.

Yahoo Finance/yfinance minute bars are used for the intraday display, without an Alpaca key. Times, source and delayed/closed/unavailable states remain visible. AKShare is the preferred directory source, with a labeled Nasdaq Trader fallback. Public deployment requires backend persistence and market-data permissions; a static ZIP does not provide continuous checks or mail delivery. Default local links work only on the same computer. See `/email-setup.html`.

Team names and portrait order match the supplied reference: WU Shi Chang (Initiator, orange hat and blue jacket), YU Zhuowei (Hipster, white Nike T-shirt), HUANG Weiting (Hacker, black shirt at the seaside), and WEN Wai Hai (Hacker, white knitted top and glasses). Original images remain in `public/assets/team`, with clickable introductions and display-only cropping.
