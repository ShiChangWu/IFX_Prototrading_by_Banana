#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
[[ "$SCRIPT_DIR" != "${BASH_SOURCE[0]}" ]] || SCRIPT_DIR=.
APP_DIR="$(cd -- "$SCRIPT_DIR" && pwd -P)"
source "$APP_DIR/scripts/runtime.sh"
cd "$APP_DIR"
"$NODE_RUNTIME" scripts/configure.mjs
"$NODE_RUNTIME" scripts/build.mjs
printf '%s\n' 'Local website: http://127.0.0.1:8787' 'This terminal runs the website in the foreground. Press Ctrl+C here to stop it.'
printf 'For Python research, open a second terminal and run: bash "%s/Start-Research.sh"\n' "$APP_DIR"
exec "$NODE_RUNTIME" server/index.mjs
