# Run the shared folder on another computer

Extract the entire ZIP to a writable folder first. Do not run from inside the ZIP.
Keep the app, its `shell/`, `public/`, `shared/`, scripts and bundled
`vendor/TradingAgents/` together. No Codex installation, GitHub account, Git,
Netlify project or Supabase account is required for local use.

The package's offline HTML can be opened immediately without installing anything.
It contains the offline experience supplied with the package; opening a file does
not connect DeepSeek or start Python research. Use the connected app below for new
AI matches and current market checks.

## What each level needs

| Experience | Requirements |
| --- | --- |
| Offline HTML | A current desktop browser; no Node, Python or API key |
| Local website, questionnaire and maintained rules | Node.js 22 or later |
| Live DeepSeek matching | Node.js 22+, internet and your own DeepSeek key |
| Short-term market observations | The local Python environment and internet; no LLM call |
| New TradingAgents reports | The Python environment, internet, DeepSeek key, and running research worker |

Each recipient configures their own key. The shared ZIP must not include
`.env.local`, `.local/`, private `data/`, `.venv/` or another person's saved profile.
The first local launch creates `.env.local` from `.env.example` and generates a
random worker secret. Open that file in a text editor to set `DEEPSEEK_API_KEY`.
Do not paste keys into the website, reports or a shared message.

If `examples/demo-report.json` is included, the first launch imports that approved,
dated report into the saved examples. It creates fresh local storage with no
inherited visitor sessions, worker registrations or access tokens. Existing local
storage is never merged into or overwritten, and no missing example is fabricated.

## Windows

1. Install Node.js **22+** from <https://nodejs.org/> with its PATH option enabled.
   Reopen the launcher afterward. An already installed Node in PATH is preferred;
   an existing optional local runtime can be used, but nothing is downloaded by
   the launcher. `PROTO_NODE` can name a full executable path if needed.
2. Double-click `Start-Local.cmd`. Open <http://127.0.0.1:8787>. The rules work
   before Python or an API key is configured. `Stop-Local.ps1` stops verified
   processes managed by this launcher.
3. For market observations and new reports, install Python **3.12** from
   <https://www.python.org/downloads/> with its PATH option enabled. Setup also
   accepts installed Python **3.11–3.13** after checking the actual executable.
   Python 3.12 is the tested reference environment.
4. From PowerShell in this folder, run:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Setup-Research.ps1
   ```

5. Add your DeepSeek key to `.env.local`. Stop and relaunch the app to load changed
   configuration. The launcher starts an available local research environment.

For visible logs, use `Start-App.ps1` in one terminal and `Start-Research.ps1` in
another. Press Ctrl+C in each terminal to stop foreground services. Do not mix
foreground and background launchers unnecessarily.

Setup checks regular Python commands and the Windows Python launcher's list of
already installed versions. It does not ask that launcher to fetch a missing
Python version. `PROTO_PYTHON` can point to an existing Python executable.

## macOS or Linux

Install Node.js **22+** and Python **3.12** yourself, using the official installers
or your operating system's package manager. Python 3.11–3.13 are accepted. On some
Linux distributions the Python `venv` package is a separate prerequisite. Then,
from the extracted app folder:

```bash
bash Setup-Research.sh
bash Start-Local.sh
```

`Start-Local.sh` runs the website in that terminal. Open
<http://127.0.0.1:8787>. After configuring `.env.local`, open a **second terminal**
in the same folder and run:

```bash
bash Start-Research.sh
```

Press **Ctrl+C in both terminals** to stop them. `Stop-Local.sh` prints these
instructions; it deliberately does not guess process identities or kill a daemon.
Calling the scripts with `bash` also works when ZIP extraction did not preserve
executable permissions. The website can run before Python setup is complete.

## Dependency and source reproducibility

`requirements-lock.txt` pins the tested Python runtime dependencies. Setup installs
that file, installs the **bundled** TradingAgents source with `--no-deps`, then
runs `pip check`. It never substitutes a newer dependency version to make an
installation appear successful. Python packaging/build tools may be downloaded
by pip while building the bundled package; those are separate from the pinned
runtime dependencies. Package installation needs internet access.

The bundled official TradingAgents source is from commit
`1394a3f72aa4393e1a98f51b382434c4b4c2d972`. Keep its license, source and revision
metadata in the shared package. Setup requires no Git clone when this source is
present. A missing vendor folder is treated as an incomplete extraction.

Windows with Python 3.12 is the reference environment tested during this project.
The macOS/Linux scripts are portable foreground launchers; an actual fresh-machine
installation on each platform still needs verification. Package wheel availability
or system build prerequisites can vary. If installation fails, retain the exact
pins and the displayed error; the offline HTML and Node-only rules remain usable.

## Troubleshooting and sharing again

- **Missing runtime:** install the required Node/Python yourself and reopen the
  terminal. Setup never silently downloads an executable runtime.
- **Copied `.venv`:** virtual environments contain machine-specific paths. Use a
  fresh extracted folder and run setup on the recipient's computer. Do not copy
  your own `.venv` into a new ZIP.
- **Python 3.14+ or 3.10:** install a supported 3.11–3.13 version; prefer 3.12.
- **Occupied port 8787:** stop the other local app instance. The Windows background
  launcher uses this default port; use the foreground server for custom settings.
- **Worker offline:** launch the Python worker and keep its terminal/computer awake.
  Saved reports remain dated examples; an offline computer cannot produce new
  TradingAgents research.
- **Share a new ZIP:** exclude credentials, runtime environments, process records
  and private reports. Include only deliberately approved public examples.
