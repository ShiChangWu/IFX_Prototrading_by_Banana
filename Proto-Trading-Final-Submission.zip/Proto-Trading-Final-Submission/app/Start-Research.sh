#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
[[ "$SCRIPT_DIR" != "${BASH_SOURCE[0]}" ]] || SCRIPT_DIR=.
APP_DIR="$(cd -- "$SCRIPT_DIR" && pwd -P)"
source "$APP_DIR/scripts/python-runtime.sh"
PYTHON_RUNTIME="$APP_DIR/.venv/bin/python"
if ! proto_python_version "$PYTHON_RUNTIME" >/dev/null; then
  printf '%s\n' 'The local Python 3.11-3.13 research environment is missing or cannot run. First execute: bash Setup-Research.sh' >&2
  exit 1
fi
cd "$APP_DIR"
printf '%s\n' 'Research runs in this terminal. Keep the computer awake. Press Ctrl+C here to stop the worker and its active analysis.'
export PYTHONUTF8=1 PYTHONUNBUFFERED=1
exec "$PYTHON_RUNTIME" -m worker.main
