import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import { getIntradayQuotes, getAlpacaAsset, validateMinuteBar } from '../server/intraday.mjs';
import { sendPlainEmail } from '../server/gmail.mjs';

const NOW = Date.parse('2026-10-02T15:01:20Z');
const KEYS = { alpacaKey: 'test-key', alpacaSecret: 'test-secret', alpacaFeed: 'iex' };
const CLOCK = { is_open: true, timestamp: new Date(NOW).toISOString(), next_close: '2026-10-02T20:00:00Z' };
const BAR = { t: '2026-10-02T15:00:00Z', o: 101, h: 103, l: 100, c: 102, v: 200 };
const EMAIL = { id: 'an-alert-1', to: 'someone@example.com', subject: 'Your saved rule was met', text: 'Record your actual quantity and price using the private link.' };
const MAIL_CONFIG = { gmailUser: 'demo@gmail.com', gmailAppPassword: 'abcd efgh ijkl mnop' };
const response = body => new Response(JSON.stringify(body), { headers: { 'content-type': 'application/json' } });
function quotesFetch(overrides = {}) {
  const calls = [];
  const fetchImpl = async (url, options) => {
    calls.push({ url, options });
    if (url.endsWith('/clock')) return response(overrides.clock ?? CLOCK);
    return response(overrides.data ?? { bars: { NVDA: BAR } });
  };
  return { fetchImpl, calls, now: () => NOW };
}

test('intraday adapter makes no network call without credentials or outside regular hours', async () => {
  const options = quotesFetch();
  assert.equal((await getIntradayQuotes(['NVDA'], {}, options)).code, 'ALPACA_NOT_CONFIGURED');
  assert.equal((await getIntradayQuotes(['NVDA'], KEYS, { ...options, now: () => Date.parse('2026-10-04T15:00:00Z') })).code, 'MARKET_CLOSED');
  assert.equal((await getIntradayQuotes(['NVDA'], KEYS, { ...options, now: () => Date.parse('2026-10-02T20:00:00Z') })).code, 'MARKET_CLOSED');
  assert.equal(options.calls.length, 0);
});

test('quotes carry explicit feed, USD and completed-minute evidence, using only read endpoints', async () => {
  const options = quotesFetch();
  const result = await getIntradayQuotes(['NVDA'], KEYS, options);
  assert.equal(result.status, 'complete');
  assert.equal(result.quotes.NVDA.price, 102);
  assert.equal(result.quotes.NVDA.barEnd, '2026-10-02T15:01:00.000Z');
  assert.equal(result.quotes.NVDA.currency, 'USD');
  assert.equal(result.quotes.NVDA.feed, 'iex');
  assert.match(result.warnings[0], /one exchange/);
  assert.equal(options.calls[0].url, 'https://paper-api.alpaca.markets/v2/clock');
  assert.match(options.calls[1].url, /^https:\/\/data\.alpaca\.markets\/v2\/stocks\/bars\/latest\?/);
  assert.equal(new URL(options.calls[1].url).searchParams.get('feed'), 'iex');
  assert.equal(new URL(options.calls[1].url).searchParams.get('currency'), 'USD');
  assert.ok(options.calls.every(call => call.options.method === 'GET' && call.options.redirect === 'error'));
});

test('clock verifies holidays and early closes before requesting any bars', async () => {
  for (const clock of [{ ...CLOCK, is_open: false }, { ...CLOCK, timestamp: '2026-10-01T15:01:20Z' }, { ...CLOCK, next_close: '2026-10-02T15:00:00Z' }, { ...CLOCK, next_close: '2026-10-05T20:00:00Z' }]) {
    const options = quotesFetch({ clock });
    const result = await getIntradayQuotes(['NVDA'], KEYS, options);
    assert.equal(result.status, 'unavailable');
    assert.equal(options.calls.length, 1);
    assert.equal(result.quotes.NVDA.price, undefined);
  }
});

test('stale, future, incomplete, malformed and outside-session bars cannot become actionable prices', () => {
  const check = (bar, now = NOW) => validateMinuteBar(bar, { ticker: 'NVDA', now, nextClose: Date.parse(CLOCK.next_close) });
  assert.equal(check({ ...BAR, t: '2026-10-02T14:54:00Z' }).code, 'STALE_BAR');
  assert.equal(check({ ...BAR, t: '2026-10-02T15:01:00Z' }).code, 'INCOMPLETE_BAR');
  assert.equal(check({ ...BAR, t: '2026-10-02T15:02:00Z' }).code, 'INCOMPLETE_BAR');
  assert.equal(check({ ...BAR, t: '2026-10-02T15:00:02Z' }).code, 'INVALID_BAR');
  assert.equal(check({ ...BAR, l: 105 }).code, 'INVALID_BAR');
  assert.equal(check({ ...BAR, v: 0 }).code, 'INVALID_BAR');
  assert.equal(check({ ...BAR, c: '102' }).code, 'INVALID_BAR');
  assert.equal(check({ ...BAR, t: '2026-10-02T13:29:00Z' }, Date.parse('2026-10-02T13:30:20Z')).code, 'OUTSIDE_SESSION');
  assert.equal(check({ ...BAR, t: '2026-10-02T14:55:00Z' }, Date.parse('2026-10-02T15:01:00Z')).status, 'complete');
});

test('missing or invalid rows remain unavailable while valid requested rows survive', async () => {
  const result = await getIntradayQuotes(['NVDA', 'AMD'], KEYS, quotesFetch());
  assert.equal(result.status, 'partial');
  assert.equal(result.quotes.AMD.code, 'MISSING_BAR');
  await assert.rejects(() => getIntradayQuotes(['NVDA', 'NVDA'], KEYS), /unique/);
  await assert.rejects(() => getIntradayQuotes(['NVDA&feed=sip'], KEYS), /ticker/);
  const options = quotesFetch();
  assert.equal((await getIntradayQuotes(['NVDA'], { ...KEYS, alpacaFeed: 'delayed_sip' }, options)).code, 'INVALID_FEED');
  assert.equal(options.calls.length, 0);
});

test('provider failures never reflect private response messages or credentials', async () => {
  const result = await getIntradayQuotes(['NVDA'], KEYS, { now: () => NOW, fetchImpl: async () => new Response('secret account response', { status: 403 }) });
  assert.equal(result.code, 'ALPACA_ACCESS_DENIED');
  assert.doesNotMatch(JSON.stringify(result), /secret account response|test-secret/);
  const oversized = await getIntradayQuotes(['NVDA'], KEYS, { now: () => NOW, fetchImpl: async () => new Response('x'.repeat(140000)) });
  assert.equal(oversized.code, 'ALPACA_RESPONSE_LIMIT');
});

test('asset verification allows only exact active exchange-listed US equities from the read-only registry', async () => {
  const asset = { symbol: 'AMD', class: 'us_equity', status: 'active', tradable: true, name: 'Advanced Micro Devices Inc.', exchange: 'NASDAQ' };
  let called = '';
  const fetchImpl = async url => { called = url; return response(asset); };
  assert.equal((await getAlpacaAsset('AMD', KEYS, { fetchImpl })).status, 'complete');
  assert.equal(called, 'https://paper-api.alpaca.markets/v2/assets/AMD');
  for (const change of [{ symbol: 'NVDA' }, { status: 'inactive' }, { class: 'crypto' }, { exchange: 'OTC' }, { tradable: false }]) {
    assert.equal((await getAlpacaAsset('AMD', KEYS, { fetchImpl: async () => response({ ...asset, ...change }) })).code, 'UNSUPPORTED_ASSET');
  }
  called = '';
  assert.equal((await getAlpacaAsset('AMD', {}, { fetchImpl })).code, 'ALPACA_NOT_CONFIGURED');
  assert.equal(called, '');
});

function mailProcess(result, { stderr = '', code = 0, hang = false } = {}) {
  let invocation;
  const spawnImpl = (command, args, options) => {
    const child = new EventEmitter(); child.stdin = new PassThrough(); child.stdout = new PassThrough(); child.stderr = new PassThrough();
    child.kill = () => true;
    let input = '';
    child.stdin.on('data', chunk => { input += chunk.toString(); });
    child.stdin.on('finish', () => {
      invocation.payload = JSON.parse(input);
      if (hang) return;
      if (stderr) child.stderr.write(stderr);
      child.stdout.write(typeof result === 'string' ? result : JSON.stringify(result));
      child.exitCode = code;
      child.emit('close', code);
    });
    invocation = { command, args, options };
    return child;
  };
  return { spawnImpl, get invocation() { return invocation; } };
}

test('Gmail is unavailable without valid credentials; address and header injection fail before process launch', async () => {
  const process = mailProcess({ status: 'accepted', code: 'SMTP_ACCEPTED' });
  assert.equal((await sendPlainEmail(EMAIL, {}, process)).status, 'unavailable');
  for (const change of [{ to: 'x@example.com,y@example.com' }, { to: 'x@example.com\r\nBcc: y@example.com' }, { subject: 'Alert\r\nBcc: y@example.com' }, { to: 'Label <x@example.com>' }, { id: '' }, { text: 'x'.repeat(48001) }]) {
    assert.equal((await sendPlainEmail({ ...EMAIL, ...change }, MAIL_CONFIG, process)).code, 'INVALID_EMAIL');
  }
  assert.equal(process.invocation, undefined);
});

test('Gmail secrets and private content travel only by stdin, and success means SMTP acceptance', async () => {
  const process = mailProcess({ status: 'accepted', code: 'SMTP_ACCEPTED', unexpected: 'private details' });
  const result = await sendPlainEmail(EMAIL, MAIL_CONFIG, { ...process, env: { PATH: '/bin', DEEPSEEK_API_KEY: 'secret', GMAIL_APP_PASSWORD: 'othersecret', NODE_OPTIONS: '--inspect' } });
  assert.equal(result.status, 'accepted');
  assert.equal(result.code, 'SMTP_ACCEPTED');
  assert.match(result.messageId, /^<proto\.[a-f0-9]{64}@proto-trading\.local>$/);
  assert.deepEqual(process.invocation.args, ['-m', 'worker.send_gmail']);
  assert.equal(process.invocation.payload.password, 'abcdefghijklmnop');
  assert.equal(process.invocation.payload.to, EMAIL.to);
  assert.equal(process.invocation.options.windowsHide, true);
  assert.equal(process.invocation.options.shell, false);
  assert.doesNotMatch(JSON.stringify(process.invocation.options.env), /secret|NODE_OPTIONS|GMAIL|DEEPSEEK/);
  assert.doesNotMatch(JSON.stringify(result), /private details|abcdefghijklmnop/);
  const second = await sendPlainEmail(EMAIL, MAIL_CONFIG, mailProcess({ status: 'accepted', code: 'SMTP_ACCEPTED' }));
  assert.equal(result.messageId, second.messageId);
});

test('lost acknowledgements, invalid output and timeouts stay uncertain without retries', async () => {
  for (const mocked of [mailProcess('unexpected output'), mailProcess({}, { code: 1 }), mailProcess({}, { hang: true }), mailProcess({ status: 'accepted', code: 'WRONG' }), mailProcess({ status: 'uncertain', code: 'SMTP_OUTCOME_UNKNOWN' })]) {
    const result = await sendPlainEmail(EMAIL, MAIL_CONFIG, { ...mocked, timeoutMs: 5 });
    assert.equal(result.status, 'uncertain');
  }
  assert.equal((await sendPlainEmail(EMAIL, MAIL_CONFIG, mailProcess({ status: 'failed', code: 'SMTP_AUTH_FAILED' }))).status, 'failed');
});
