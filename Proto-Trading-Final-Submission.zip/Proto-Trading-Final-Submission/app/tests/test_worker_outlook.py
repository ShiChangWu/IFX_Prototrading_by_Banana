import unittest

from worker.outlook import canonical_horizon, evidence_sources, supports_horizon, validate_outlook


class OutlookEvidenceTests(unittest.TestCase):
    def test_summary_cannot_mention_uncited_researched_asset(self):
        vti_quote = "For the next 1–3 months, VTI's research view is cautious."
        sgov_quote = "For the next 1–3 months, SGOV's research view has insufficient evidence."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": vti_quote},
                   "SGOV:0": {"ticker": "SGOV", "section": "Market", "text": sgov_quote}}
        payload = {"outlook": [{"horizon": "1-3 months", "status": "available", "summary": "VTI is cautious. SGOV is stable.",
                                "evidence": [{"sourceId": "VTI:0", "quote": vti_quote}]}]}
        row = validate_outlook(payload, sources)[1]
        self.assertEqual(row["status"], "unavailable")
        self.assertEqual(row["validationIssue"], "uncited_researched_ticker")

    def test_other_horizon_citation_does_not_cover_ticker_in_this_horizon(self):
        vti_quote = "For the next 1–3 months, VTI's research view is cautious."
        sgov_quote = "For the next 6–12 months, SGOV has insufficient directional evidence."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": vti_quote},
                   "SGOV:0": {"ticker": "SGOV", "section": "Market", "text": sgov_quote}}
        payload = {"outlook": [{"horizon": "1-3 months", "status": "available", "summary": "VTI is cautious. sgov has no supported direction.",
                                "evidence": [{"sourceId": "VTI:0", "quote": vti_quote}, {"sourceId": "SGOV:0", "quote": sgov_quote}]}]}
        self.assertEqual(validate_outlook(payload, sources)[1]["status"], "unavailable")

    def test_all_mentioned_assets_need_and_accept_same_horizon_quotes(self):
        vti_quote = "For the next 1–3 months, VTI's research view is cautious."
        sgov_quote = "For the next 1–3 months, SGOV's research view has insufficient evidence."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": vti_quote},
                   "SGOV:0": {"ticker": "SGOV", "section": "Market", "text": sgov_quote}}
        payload = {"outlook": [{"horizon": "1-3 months", "status": "available", "summary": "VTI's research is cautious. SGOV lacks sufficient evidence.",
                                "evidence": [{"sourceId": "VTI:0", "quote": vti_quote}, {"sourceId": "SGOV:0", "quote": sgov_quote}]}]}
        self.assertEqual(validate_outlook(payload, sources)[1]["status"], "available")

    def test_conditions_must_be_in_attached_same_horizon_quote(self):
        quote = "For the next 1–3 months, VTI's view depends on sustained earnings growth."
        unattached = "Wait for volume-confirmed strength above the upper band."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": quote + " " + unattached}}
        payload = {"outlook": [{"horizon": "1-3 months", "status": "available", "summary": "VTI's outlook depends on earnings.",
            "evidence": [{"sourceId": "VTI:0", "quote": quote}],
            "conditions": ["sustained earnings growth", unattached]}]}
        self.assertEqual(validate_outlook(payload, sources)[1]["conditions"], ["sustained earnings growth"])

    def test_ascii_horizon_keeps_valid_source_evidence(self):
        quote = "For the next 2 weeks, the report describes a conditional trend view."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": quote}}
        payload = {"outlook": [{"horizon": "1-4 weeks", "status": "available", "summary": "A conditional near-term trend view.",
                                "evidence": [{"sourceId": "VTI:0", "quote": quote}], "conditions": None}]}
        result = validate_outlook(payload, sources)
        self.assertEqual(result[0]["status"], "available")
        self.assertEqual(result[0]["horizon"], "1–4 weeks")
        self.assertEqual(canonical_horizon("6 to 12 months"), "6–12 months")
        self.assertIsNone(canonical_horizon("3-6 months"))

    def test_tail_conclusion_is_available_as_exact_separate_source(self):
        quote = "For the next 6–12 months, the outlook remains conditional on sustained earnings growth."
        text = "Opening section. " + "Historical context. " * 800 + quote
        research = [{"ticker": "VTI", "status": "complete", "sections": [{"title": "Market", "text": text}]}]
        sources = evidence_sources(research)
        self.assertIn("VTI:0:tail", sources)
        self.assertNotIn(quote, sources["VTI:0"]["text"])
        self.assertIn(quote, sources["VTI:0:tail"]["text"])
        payload = {"outlook": [{"horizon": "6-12 months", "status": "available", "summary": "Long-term outlook is conditional.",
                                "evidence": [{"sourceId": "VTI:0:tail", "quote": quote}]}]}
        self.assertEqual(validate_outlook(payload, sources)[2]["status"], "available")

    def test_spliced_opening_and_conclusion_cannot_be_used_as_quote(self):
        text = "Opening outlook for 6–12 months. " + "x" * 15000 + "Conditional closing assessment."
        sources = evidence_sources([{"ticker": "VTI", "status": "complete", "sections": [{"title": "Market", "text": text}]}])
        fake_join = "Opening outlook for 6–12 months. Conditional closing assessment."
        payload = {"outlook": [{"horizon": "6-12 months", "status": "available", "summary": "Unsupported joined quote.",
                                "evidence": [{"sourceId": "VTI:0", "quote": fake_join}]}]}
        self.assertEqual(validate_outlook(payload, sources)[2]["status"], "unavailable")

    def test_instrument_maturity_or_lookback_is_not_horizon_evidence(self):
        self.assertFalse(supports_horizon("SGOV holds Treasury bills with maturities of 0–3 months.", "1–3 months"))
        self.assertFalse(supports_horizon("This instrument has a tenor of 1–3 months.", "1–3 months"))
        self.assertFalse(supports_horizon("The indicator lookback spans 6–12 months of historical data.", "6–12 months"))
        self.assertTrue(supports_horizon("Over the next 1–3 months, the outlook for funds holding 0–3 month bills depends on rate changes.", "1–3 months"))

    def test_malformed_one_horizon_does_not_discard_other_valid_horizon(self):
        quote = "Over the next 2 weeks, the report describes a conditional trend view."
        sources = {"VTI:0": {"ticker": "VTI", "section": "Market", "text": quote}}
        payload = {"outlook": [{"horizon": "1-4 weeks", "status": "available", "summary": "Conditional trend.",
                                "evidence": [{"sourceId": "VTI:0", "quote": quote}]},
                               {"horizon": "1-3 months", "status": "available", "summary": "Malformed.", "evidence": None}]}
        result = validate_outlook(payload, sources)
        self.assertEqual(result[0]["status"], "available")
        self.assertEqual(result[1]["status"], "unavailable")


if __name__ == "__main__":
    unittest.main()
