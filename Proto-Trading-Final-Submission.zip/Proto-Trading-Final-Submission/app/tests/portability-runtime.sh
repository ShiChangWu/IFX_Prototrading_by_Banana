#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
[[ "$SCRIPT_DIR" != "${BASH_SOURCE[0]}" ]] || SCRIPT_DIR=.
APP_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd -P)"
if output="$(PROTO_NODE="$APP_DIR/missing-test-only-node" source "$APP_DIR/scripts/runtime.sh" 2>&1)"; then
  printf '%s\n' 'FAIL: missing Node runtime accepted.' >&2; exit 1
fi
[[ "$output" == *'Node.js 22+'* && "$output" == *'Nothing was downloaded'* ]] || { printf '%s\n' 'FAIL: missing Node error is not actionable.' >&2; exit 1; }
source "$APP_DIR/scripts/python-runtime.sh"
if output="$(PROTO_PYTHON="$APP_DIR/missing-test-only-python" find_proto_python 2>&1)"; then
  printf '%s\n' 'FAIL: missing Python runtime accepted.' >&2; exit 1
fi
[[ "$output" == *'PROTO_PYTHON'* && "$output" == *'3.12'* ]] || { printf '%s\n' 'FAIL: missing Python error is not actionable.' >&2; exit 1; }
printf '%s\n' 'PASS: shell missing-runtime errors; no downloads, setup or service changes.'
