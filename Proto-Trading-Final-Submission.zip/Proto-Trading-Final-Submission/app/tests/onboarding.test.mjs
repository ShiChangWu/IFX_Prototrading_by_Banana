import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../public/onboarding.js',import.meta.url),'utf8');
function harness({stored=null,blocked=false,native=false}={}){
  let document;const events=[],storage=new Map(stored?[['proto-trading-introduction-v1',stored]]:[]);
  class Element{constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.style={};this.events={};this.hidden=false;this.disabled=false;this._text='';if(tag==='dialog'&&native){this.showModal=()=>{this.open=true;};this.close=()=>{this.open=false;};}}
    append(...items){for(const child of items){child.parentElement=this;this.children.push(child);}}replaceChildren(...items){this.children=[];this._text='';this.append(...items);}set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join(' ');}setAttribute(k,v){this.attributes[k]=v;}removeAttribute(k){delete this.attributes[k];}addEventListener(k,fn){this.events[k]=fn;}removeEventListener(k){delete this.events[k];}focus(){document.activeElement=this;}querySelectorAll(){return all(this,item=>['button','summary'].includes(item.tagName));}remove(){if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(child=>child!==this);}click(){this.events.click?.();}}
  const all=(root,predicate)=>[...(predicate(root)?[root]:[]),...root.children.flatMap(child=>all(child,predicate))];
  const body=new Element('body'),workspace=new Element('main'),replay=new Element('button');body.append(workspace,replay);
  document={body,activeElement:replay,events:{},createElement:tag=>new Element(tag),getElementById:id=>id==='open-introduction'?replay:null,querySelector:()=>workspace,addEventListener(k,fn){this.events[k]=fn;},removeEventListener(k){delete this.events[k];}};
  const window={localStorage:{getItem(k){if(blocked)throw Error('blocked');return storage.get(k);},setItem(k,v){if(blocked)throw Error('blocked');storage.set(k,v);}},CustomEvent:class{constructor(type,{detail}){this.type=type;this.detail=detail;}},dispatchEvent:e=>events.push(e)};
  const context=vm.createContext({document,window});vm.runInContext(source.replace('export function','function')+'\nglobalThis.instance=initOnboarding();',context);
  const dialog=body.children.find(child=>child.tagName==='dialog');
  return{document,window,workspace,replay,events,storage,dialog,instance:context.instance,find:predicate=>all(dialog,predicate)[0],key(key,shiftKey=false){let prevented=false;document.events.keydown?.({key,shiftKey,preventDefault(){prevented=true;}});return prevented;}};
}
test('first-visit tour blocks background, lets a user choose a destination and records only completion',()=>{
  const h=harness({native:true});assert.equal(h.dialog.hidden,false);assert.equal(h.workspace.inert,true);
  const next=()=>h.find(e=>e.className==='proto-intro-next').click();next();
  h.find(e=>e.tagName==='button'&&e.textContent.includes('Explore stock examples')).click();next();
  assert.match(h.dialog.textContent,/About you/);assert.match(h.dialog.textContent,/Research/);next();next();
  assert.equal(h.dialog.hidden,true);assert.equal(h.workspace.inert,false);assert.equal(h.events.length,1);
  assert.equal(h.events[0].detail.destination,'community');assert.equal(h.events[0].detail.skipped,false);
  assert.equal(h.storage.get('proto-trading-introduction-v1'),'complete');assert.equal(h.storage.size,1);
});
test('Skip, Escape and replay work even when browser storage is unavailable',()=>{
  const h=harness({blocked:true});h.find(e=>e.className==='proto-intro-skip').click();assert.equal(h.dialog.hidden,true);assert.equal(h.events[0].detail.skipped,true);
  h.replay.click();assert.equal(h.dialog.hidden,false);assert(h.key('Escape'));assert.equal(h.dialog.hidden,true);assert.equal(h.events.length,2);
});
test('returning visitors can replay; focus wraps and destroy restores page state',()=>{
  const h=harness({stored:'complete'});assert.equal(h.dialog.hidden,true);h.replay.click();
  const skip=h.find(e=>e.className==='proto-intro-skip'),next=h.find(e=>e.className==='proto-intro-next');
  next.focus();assert(h.key('Tab'));assert.equal(h.document.activeElement,skip);
  skip.focus();assert(h.key('Tab',true));assert.equal(h.document.activeElement,next);
  h.instance.destroy();assert.equal(h.workspace.inert,false);assert.equal(h.document.body.style.overflow,'');assert.equal(h.document.events.keydown,undefined);
});
