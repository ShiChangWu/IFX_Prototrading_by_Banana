"""Synthetic issuer histories only; no market requests or publishable returns."""
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import re
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import pandas as pd

from worker.backtest import historical_backtest, simulate_fixed_allocation
from worker.quick_market import SnapshotError, create_snapshots, snapshot_from_history
from worker.security_identity import IssuerHistoryError, first_trading_date
from tests.test_quick_market import weekday_history


LISTED = date(2026, 6, 12)
NOW = datetime(2026, 10, 4, 12, 0, tzinfo=timezone.utc)


def post_listing_bars(count=105):
    result, day = [], LISTED
    while len(result) < count:
        if day.weekday() < 5:
            result.append(dict(date=day, open=100.0, high=101.0, low=99.0,
                               close=100.0, volume=1000.0))
        day += timedelta(days=1)
    return result


class SecurityIdentityTests(unittest.TestCase):
    def test_public_asset_and_worker_share_the_same_first_trading_date(self):
        source = (Path(__file__).resolve().parents[1] / 'shared' / 'strategy.mjs').read_text(encoding='utf-8')
        definition = re.search(r"ticker:'SPCX'.*?firstTradingDate:'([^']+)'", source)
        self.assertIsNotNone(definition)
        self.assertEqual(definition.group(1), first_trading_date('SPCX').isoformat())

    def test_pre_ipo_rows_cannot_supply_the_101_observation_requirement(self):
        history = weekday_history(count=200)
        with self.assertRaises(SnapshotError) as caught:
            snapshot_from_history('SPCX', history, '2026-10-02', 'time', 'USD')
        self.assertEqual(caught.exception.code, 'insufficient_history')
        self.assertIn('2026-06-12', str(caught.exception))
        self.assertIn('unrelated ticker user were excluded', str(caught.exception))

    def test_old_security_rows_never_change_any_spacex_indicator_or_bar(self):
        post = post_listing_bars()
        cutoff = post[-1]['date']
        expected = snapshot_from_history('SPCX', post, cutoff, 'time', 'USD')
        # Even malformed old-issuer prices are discarded before price handling.
        old = [dict(date=date(2026, 6, 10), close=float('nan')),
               dict(date=date(2026, 6, 11), open=9000.0, high=10000.0,
                    low=1.0, close=9999.0, volume=999999.0)]
        actual = snapshot_from_history('SPCX', old + post, cutoff, 'time', 'USD')
        self.assertEqual(actual, expected)
        self.assertEqual(actual['observations'], 105)
        self.assertEqual(actual['rsi14'], 50)
        self.assertEqual(actual['atr14'], 2)
        self.assertEqual(actual['sma100'], 100)
        self.assertTrue(all(bar['date'] >= LISTED.isoformat() for bar in actual['bars']))

    def test_current_fetch_is_bounded_by_ipo_and_other_assets_are_unchanged(self):
        requests = {}

        def fetch(ticker, start, end):
            requests[ticker] = (start, end)
            return {'history': weekday_history(count=200), 'currency': 'USD'}

        result = create_snapshots({'tickers': ['SPCX', 'VTI']}, now=NOW, history_fetcher=fetch)
        self.assertEqual(requests['SPCX'][0], LISTED)
        self.assertEqual(requests['VTI'][0], date(2026, 10, 2) - timedelta(days=400))
        self.assertEqual(result['status'], 'partial')
        self.assertEqual(result['snapshots'][0]['error']['code'], 'insufficient_history')
        self.assertEqual(result['snapshots'][1]['status'], 'complete')

    def test_pre_listing_snapshot_does_not_fetch_an_old_security(self):
        with patch('worker.quick_market._make_history_fetcher') as factory:
            fetch = unittest.mock.Mock()
            result = create_snapshots({'tickers': ['SPCX'], 'analysisDate': '2026-06-11'},
                                      now=NOW, history_fetcher=fetch)
        factory.assert_not_called()
        fetch.assert_not_called()
        self.assertEqual(result['snapshots'][0]['error']['code'], 'issuer_not_yet_listed')

    def test_three_year_backtest_is_explicitly_unavailable_before_provider_setup(self):
        match = {'allocations': [{'ticker': 'SPCX', 'weight': 5}, {'ticker': 'CASH', 'weight': 95}],
                 'profile': {'budget': 10000}}
        with patch('worker.tls.configure_trusted_ca') as configure:
            result = historical_backtest(match, years=3, now=NOW)
        configure.assert_not_called()
        self.assertEqual(result['status'], 'unavailable')
        self.assertEqual(result['errorCode'], 'issuer_history_unavailable')
        self.assertIn('2026-06-12', result['error'])
        self.assertIn('window was not shortened', result['error'])
        self.assertNotIn('metrics', result)
        self.assertNotIn('series', result)

    def test_direct_simulator_rejects_pre_ipo_prices_instead_of_intersecting_them_away(self):
        prices = {'SPCX': {'2026-06-11': 10, '2026-06-12': 100, '2026-06-15': 101},
                  'SPY': {'2026-06-12': 100, '2026-06-15': 101}}
        with self.assertRaises(IssuerHistoryError):
            simulate_fixed_allocation(prices, {'SPCX': .05, 'CASH': .95})
        del prices['SPCX']['2026-06-11']
        result = simulate_fixed_allocation(prices, {'SPCX': .05, 'CASH': .95})
        self.assertEqual(result['status'], 'complete')
        self.assertEqual(result['start'], '2026-06-12')

    def test_injected_pre_listing_provider_rows_are_rejected_for_a_later_requested_window(self):
        frame = pd.DataFrame({'Close': [10, 100, 102]},
                             index=pd.to_datetime(['2026-06-11', '2026-09-01', '2026-10-02']))
        fake_yf = SimpleNamespace(set_tz_cache_location=lambda *_: None,
                                  Ticker=lambda _: SimpleNamespace(history=lambda **_: frame))
        match = {'allocations': [{'ticker': 'SPCX', 'weight': 5}, {'ticker': 'CASH', 'weight': 95}],
                 'profile': {'budget': 10000}}
        with tempfile.TemporaryDirectory() as cache, patch.dict('sys.modules', {'yfinance': fake_yf}), patch('worker.tls.configure_trusted_ca'):
            result = historical_backtest(match, years=.1, now=NOW, cache_dir=cache)
        self.assertEqual(result['status'], 'unavailable')
        self.assertEqual(result['errorCode'], 'issuer_history_unavailable')
        self.assertNotIn('metrics', result)


if __name__ == '__main__':
    unittest.main()
