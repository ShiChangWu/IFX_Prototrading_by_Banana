import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { selectedPlan } from '../shared/selected-plan.mjs';
import { createMatch, DEFAULT_PROFILE } from '../shared/strategy.mjs';

const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
function functionSource(name) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  assert(start >= 0, `${name} must exist`);
  const rest = source.slice(start), end = rest.indexOf('\n}\n') + 2;
  assert(end > 1);
  return rest.slice(0, end);
}
class Element {
  constructor(tag = 'div', text = '') { this.tagName = tag; this.children = []; this._text = text; this.disabled = false; }
  append(...children) { this.children.push(...children.filter(Boolean)); }
  replaceChildren(...children) { this.children = children; this._text = ''; }
  get textContent() { return this._text + this.children.map(child => child.textContent || '').join(' '); }
}
const plain = value => JSON.parse(JSON.stringify(value));
function harness() {
  const nodes = new Map(), selection = { tickers: ['AMD', 'NVDA'], assets: [], saved: false }, weights = {};
  const profile = { ...DEFAULT_PROFILE }, match = createMatch(profile);
  const state = { profile, match, signature: JSON.stringify(profile), health: { selectedStockResearch: true, researchConfigured: true, worker: { online: true } }, sessionToken: 'confirmed-session' };
  const $ = id => { if (!nodes.has(id)) nodes.set(id, new Element()); return nodes.get(id); };
  const context = vm.createContext({
    state, selectedSnapshot: selection, selectionWeights: weights, selectedPlan, $, portableMode: false, portableReports: [],
    node: (tag, _className, text) => new Element(tag, text),
    append: (parent, ...children) => { parent.append(...children); return parent; },
    button: (label, _className, action) => { const result = new Element('button', label); result.click = action; return result; },
    more: (label, _key, ...children) => { const result = new Element('details', label); result.append(...children); return result; },
    allocationTable: rows => new Element('table', rows.map(row => `${row.ticker}: ${row.weight}% / $${row.amount}`).join(' ')),
    isStale: () => false, setTab() {}, refreshHealth() {}, submitProfile() {}, startResearch() {}, loadExample() {},
    pct: value => `${value}%`, usd: { format: value => `$${value}` },
  });
  vm.runInContext(`${functionSource('readResearchSelection')}\n${functionSource('updateResearchAction')}\nglobalThis.ui={readResearchSelection,updateResearchAction};`, context);
  return { ui: context.ui, state, selection, weights, $ };
}

test('research selection follows checked AMD and NVDA, including zero-dollar watch items', () => {
  const h = harness(), result = h.ui.readResearchSelection();
  assert.deepEqual(plain(result.tickers), ['AMD', 'NVDA']);
  assert.deepEqual(plain(result.weights), { AMD: 0, NVDA: 0 });
  assert.deepEqual(plain(result.plan.allocations.map(row => [row.ticker, row.amount])), [['AMD', 0], ['NVDA', 0], ['CASH', 10000]]);
  assert(result.plan.allocations.every(row => !['VTI', 'SCHD', 'IEF', 'SGOV', 'GLD'].includes(row.ticker)));
  result.tickers.push('TSLA'); result.weights.AMD = 50;
  assert.deepEqual(h.selection.tickers, ['AMD', 'NVDA']); assert.equal(h.weights.AMD, undefined, 'Returned request data cannot mutate UI selection weights');
});

test('research action displays current tickers, confirmed template and cash rather than removed default stocks', () => {
  const h = harness(); h.weights.AMD = 20; h.weights.NVDA = 10;
  h.ui.updateResearchAction();
  const area = h.$('research-action');
  assert.match(area.textContent, /AMD/); assert.match(area.textContent, /NVDA/);
  assert.doesNotMatch(area.textContent, /\bVTI\b|\bSCHD\b|\bIEF\b|\bSGOV\b|\bGLD\b/);
  assert(area.textContent.includes(h.state.match.template.name));
  assert.match(area.textContent, /70%|7000|7,000/);
  assert.equal(area.children.at(-1).disabled, false);
  h.selection.tickers.splice(0, 2, 'TSLA'); delete h.weights.AMD; delete h.weights.NVDA; h.weights.TSLA = 15;
  h.ui.updateResearchAction();
  assert.match(area.textContent, /TSLA/); assert.doesNotMatch(area.textContent, /AMD|NVDA/);
});

test('empty selections, malformed tickers and invalid weights cannot describe a valid new research request', () => {
  const empty = harness(); empty.selection.tickers = [];
  assert.throws(() => empty.ui.readResearchSelection());
  empty.ui.updateResearchAction(); assert.equal(empty.$('research-action').children.at(-1).textContent, 'Choose stocks and amounts');
  for (const ticker of ['<script>', 'AAPL/../../secret', '']) {
    const h = harness(); h.selection.tickers = [ticker]; assert.throws(() => h.ui.readResearchSelection());
  }
  for (const weight of [101, -1, NaN, Infinity]) {
    const h = harness(); h.weights.AMD = weight; assert.throws(() => h.ui.readResearchSelection());
  }
  const over = harness(); over.weights.AMD = 60; over.weights.NVDA = 60; assert.throws(() => over.ui.readResearchSelection());
});

test('an older backend cannot silently turn a selected-stock request into the default portfolio', () => {
  const h = harness(); h.state.health.selectedStockResearch = false; h.ui.updateResearchAction();
  const area = h.$('research-action');
  assert.notEqual(area.children.at(-1).textContent, 'Generate deep research →');
  assert.match(area.textContent, /update|restart|selected.stock|support/i);
});
