"""Synthetic fixtures are for calculation verification only, never published."""
import unittest

from worker.backtest import rebalance, simulate_fixed_allocation


class BacktestTests(unittest.TestCase):
    def test_cash_keeps_principal_and_has_no_cost_or_volatility(self):
        prices = {"SPY": {"2024-01-02": 100, "2024-01-03": 120, "2024-02-01": 90}}
        result = simulate_fixed_allocation(prices, {"CASH": 1}, cost_bps=10)
        self.assertEqual(result["metrics"]["endingValue"], 10000)
        self.assertEqual(result["metrics"]["totalReturnPct"], 0)
        self.assertEqual(result["metrics"]["transactionCosts"], 0)
        self.assertEqual(result["metrics"]["annualizedVolatilityPct"], 0)

    def test_exact_cash_and_trading_cost_accounting(self):
        targets, cash, fee = rebalance({"A": 8000, "B": 0}, 2000,
                                       {"A": .5, "B": .3, "CASH": .2}, .001)
        self.assertAlmostEqual(sum(targets.values()) + cash + fee, 10000, places=8)
        self.assertAlmostEqual(cash / (10000 - fee), .2, places=8)
        self.assertGreater(fee, 0)

    def test_initial_cost_is_included_in_returns_and_drawdown(self):
        prices = {"SPY": {"2024-01-02": 100, "2024-01-03": 100}}
        result = simulate_fixed_allocation(prices, {"SPY": 1}, cost_bps=10)
        self.assertAlmostEqual(result["metrics"]["endingValue"], 10000 / 1.001, places=2)
        self.assertLess(result["metrics"]["totalReturnPct"], 0)
        self.assertLess(result["metrics"]["maxDrawdownPct"], 0)

    def test_known_drawdown_and_monthly_return_timing(self):
        history = {"2024-01-02": 100, "2024-01-31": 120, "2024-02-01": 96}
        result = simulate_fixed_allocation({"SPY": history}, {"SPY": 1}, cost_bps=0)
        self.assertEqual(result["metrics"]["maxDrawdownPct"], -20)
        self.assertEqual(result["metrics"]["endingValue"], 9600)

    def test_new_weights_do_not_earn_rebalance_day_return(self):
        prices = {"A": {"2024-01-02": 100, "2024-01-31": 200, "2024-02-01": 400},
                  "SPY": {"2024-01-02": 100, "2024-01-31": 100, "2024-02-01": 100}}
        result = simulate_fixed_allocation(prices, {"A": .5, "CASH": .5}, cost_bps=0)
        # Old units: 50*400 + unchanged cash 5000. Rebalance happens AFTER the move.
        self.assertEqual(result["metrics"]["endingValue"], 25000)

    def test_future_prices_do_not_change_past_values(self):
        dates = ["2024-01-02", "2024-01-31", "2024-02-01", "2024-02-02"]
        prices = {"A": dict(zip(dates, [100, 110, 120, 130])),
                  "SPY": dict(zip(dates, [100, 101, 102, 103]))}
        full = simulate_fixed_allocation(prices, {"A": .6, "CASH": .4})
        truncated = {t: {d: p for d, p in h.items() if d != dates[-1]} for t, h in prices.items()}
        before = simulate_fixed_allocation(truncated, {"A": .6, "CASH": .4})
        self.assertEqual(full["series"][:-1], before["series"])
        prices["A"][dates[-1]] = 1_000_000
        changed = simulate_fixed_allocation(prices, {"A": .6, "CASH": .4})
        self.assertEqual(changed["series"][:-1], before["series"])

    def test_missing_price_series_is_not_substituted(self):
        with self.assertRaises(ValueError):
            simulate_fixed_allocation({"SPY": {"2024-01-02": 100, "2024-01-03": 101}}, {"MISSING": 1})


if __name__ == "__main__":
    unittest.main()
