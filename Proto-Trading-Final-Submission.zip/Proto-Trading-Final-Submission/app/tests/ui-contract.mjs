import { SCHOOL_BLURBS, scoreSchoolFit } from '../shared/school-fit.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { selectedPlan } from '../shared/selected-plan.mjs';
import { createSchoolLab } from '../public/school-lab.js';
import { createWatchlist } from '../public/watchlist.js';
import { SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { createReportCompanion } from '../public/report-guide.js';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createMatch, validateProfile, DEFAULT_PROFILE } from '../shared/strategy.mjs';
import { createShortPlan } from '../shared/short-plan.mjs';
import { MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument } from '../shared/report-import.mjs';

// A tiny DOM double exercises rendering and data boundaries without launching a browser.
class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.attributes = {}; this.style = {}; this.hidden = false; this.disabled = false; this._text = ''; }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this._text = ''; this.children = [...items]; }
  set textContent(text) { this._text = String(text); this.children = []; }
  get textContent() { return this._text + this.children.map((child) => child.textContent || '').join(''); }
  setAttribute(key, value) { this.attributes[key] = value; }
  addEventListener() {}
  get firstChild() { return this.children[0]; }
  get lastChild() { return this.children.at(-1); }
  querySelector() { return null; }
}
const elements = new Map();
const document = {
  createElement: (tag) => new Element(tag),
  createElementNS: (_ns, tag) => new Element(tag),
  createTextNode: (text) => { const el = new Element('#text'); el.textContent = text; return el; },
  getElementById: (id) => { if (!elements.has(id)) elements.set(id, new Element('div')); return elements.get(id); },
  querySelectorAll: () => [],
};
const input = { ...DEFAULT_PROFILE };
class FormDataDouble {
  get(key) { return input[key] ?? ''; }
  has(key) { return Boolean(input[key]); }
}
const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../public/workspace.html', import.meta.url), 'utf8');
assert(!/\.innerHTML|insertAdjacentHTML|document\.write\(/.test(source), 'Untrusted report content must never pass through an HTML parser');
for (const name of ['questionnaire', 'portfolio', 'research', 'community']) {
  assert(html.includes(`aria-controls="panel-${name}"`));
  assert(html.includes(`id="panel-${name}"`));
}
for (const key of Object.keys(DEFAULT_PROFILE).filter((key) => key !== 'startingPortfolio')) assert(html.includes(`name="${key}"`), `Missing profile control ${key}`);
const context = vm.createContext({ document, window:{}, setTimeout, clearTimeout, AbortController, DOMException, FormData: FormDataDouble, Intl, Date, URL, JSON, Number, String, Math, Object, Array, structuredClone, selectedPlan, SCHOOL_BLURBS, scoreSchoolFit, SCHOOL_PRICES, TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createReportCompanion, createSchoolLab, createWatchlist, SCHOOL_TESTS, createMatch, validateProfile, createShortPlan, MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument });
vm.runInContext(source.replace(/^import .*;\r?\n/gm, '').split('let heightFrame;')[0] + '\n globalThis.test = { state, safeLink, normalizeSeries, renderBacktest, renderReport, renderPortfolio, renderHedgeReview, renderShortPlan, refreshShortPlan, renderUploadedDocument, openDocumentDb, documentStore, drawChart, updateRemixTotals, updateResearchAction, startResearch, isStale, signature, syncSelection, renderTemplates };', context);
const ui = context.test;

assert.equal(ui.safeLink('javascript:alert(1)', 'unsafe').tagName, 'span');
assert.equal(ui.safeLink('data:text/html,hi', 'unsafe').tagName, 'span');
assert.equal(ui.safeLink('https://example.com/research', 'Research').href, 'https://example.com/research');
assert.equal(ui.safeLink('https://example.com', 'Research').rel, 'noopener noreferrer');

ui.state.signature = ui.signature(input);
assert.equal(ui.isStale(), false);
input.budget = 12000;
assert.equal(ui.isStale(), true, 'A budget change must invalidate the displayed match');
input.budget = DEFAULT_PROFILE.budget;
assert.equal(ui.isStale(), false);

assert.equal(ui.normalizeSeries([{ date: '2025-01-01', equity: 10000 }, { date: '2025-01-02', value: 10100 }, { date: '2025-01-03' }]).length, 2);
const missing = ui.renderBacktest({ status: 'unavailable', error: 'Price provider did not respond' });
assert(missing.textContent.includes('Price provider did not respond'));
assert(!JSON.stringify(missing).includes('polyline'), 'Missing historical data must not generate a chart');
const compared = ui.drawChart(ui.normalizeSeries([{ date: '2025-01-01', value: 10000, benchmark: 10000 }, { date: '2025-01-02', value: 10100, benchmark: 10200 }]), 'SPY');
assert.equal((JSON.stringify(compared).match(/"tagName":"polyline"/g) || []).length, 2, 'A real benchmark series must be shown beside the allocation');
assert(compared.textContent.includes('SPY · dashed'));
const singleSeries = ui.drawChart(ui.normalizeSeries([{ date: '2025-01-01', value: 10000 }, { date: '2025-01-02', value: 10100 }]));
assert.equal((JSON.stringify(singleSeries).match(/"tagName":"polyline"/g) || []).length, 1, 'A missing benchmark must not be replaced with a made-up series');
assert(!singleSeries.textContent.includes('Benchmark · dashed'));
const hedge = ui.renderHedgeReview({ allocated: false, historicalComparison: { status: 'complete', start: '2025-01-01', end: '2025-01-31', sessions: 20, scenarios: [{ label: 'Test-only equal-exposure example', weightsPct: { SPY: 90, SH: 5, CASH: 5 }, returnPct: 2.5, maxDrawdownPct: -1.2, endingValue: 10250 }, { label: 'Incomplete test row' }] } });
assert(hedge.textContent.includes('SPY 90% · SH 5% · CASH 5%'));
assert(hedge.textContent.includes('-1.2%'));
assert(hedge.textContent.includes('Unavailable'), 'Missing hedge comparison metrics must remain unavailable');

const malicious = '<img src=x onerror="alert(1)">';
ui.state.report = { id: 'test', title: malicious, status: 'partial', generatedAt: '2026-10-04T00:00:00Z', profile: input, provenance: { engine: 'TauricResearch/TradingAgents', repository: 'javascript:alert(1)', dataSources: [{ title: malicious, url: 'javascript:alert(2)' }] }, research: [{ ticker: 'VTI', status: 'complete', decision: 'Hold', sections: [{ title: 'Analysis', text: malicious }] }], outlook: [], backtest: { status: 'unavailable' }, limitations: [malicious] };
ui.renderReport();
const tree = elements.get('report-content');
assert(tree.textContent.includes(malicious), 'AI text must be displayed literally');
assert(!JSON.stringify(tree).includes('"href":"javascript:'), 'Report links must reject executable protocols');

ui.state.report.research[0].dataQuality = { status: 'limited', engineCompleted: true, affectedSections: ['Macro analysis'], message: 'FRED data unavailable. ' + malicious };
ui.state.report.research[0].warnings = ['Do not treat an engine finish as source verification.'];
ui.state.report.outlookMethod = { type: 'local-editorial-evidence-review', generatedAt: '2026-10-04T04:00:00Z', description: 'Local review of saved quotes. No new model or TradingAgents run was performed.' };
ui.renderReport();
const reviewed = elements.get('report-content');
assert(reviewed.textContent.includes('Local review of saved evidence'));
assert(reviewed.textContent.includes('No new model or TradingAgents run was performed.'));
assert(reviewed.textContent.includes('Affected sections: Macro analysis'));
function findNode(root, predicate) { if (predicate(root)) return root; for (const child of root.children) { const found = findNode(child, predicate); if (found) return found; } }
const assetResult = findNode(reviewed, element => element.tagName === 'article' && element.className === 'research-item');
const qualityIndex = assetResult.children.findIndex(child => child.textContent.includes('FRED data unavailable.'));
const detailsIndex = assetResult.children.findIndex(child => child.tagName === 'details');
assert(qualityIndex >= 0 && qualityIndex < detailsIndex, 'Per-asset source limitations must stay visible outside collapsed research text');
assert(assetResult.textContent.includes('Limited source coverage'));
ui.state.report.outlookMethod = { type: 'deepseek-evidence-extraction', model: 'test-model-only', generatedAt: '2026-10-04T03:00:00Z', description: 'Separate extraction from saved research evidence.' };
ui.renderReport();
assert(elements.get('report-content').textContent.includes('Model: test-model-only'));
assert(elements.get('report-content').textContent.includes('Separate extraction from saved research evidence.'));

const originalInput = ui.signature(input);
const uploaded = parseUploadedReport({filename:'test-only-upload.md',text:'# Uploaded research\nDate: 2026-10-01\n## 6–12 months\n' + malicious, id:'test-upload', importedAt:'2026-10-04T06:00:00Z'});
ui.state.uploadedDocument = uploaded;
ui.state.uploadedSaved = true;
ui.state.selectedResearchType = 'uploaded';
ui.renderUploadedDocument();
const uploadedTree = elements.get('uploaded-report-content');
assert(uploadedTree.textContent.includes(UPLOADED_SOURCE_LABEL));
assert(uploadedTree.textContent.includes('Unverified text extraction'));
assert(uploadedTree.textContent.includes(malicious));
const fullSource = findNode(uploadedTree, element => element.tagName === 'pre' && element.className === 'original-source');
assert.equal(fullSource.textContent, uploaded.originalText);
assert.equal(ui.signature(input), originalInput, 'Opening an uploaded document must not change the questionnaire');
ui.renderReport();
assert.equal(elements.get('report-content').hidden, true, 'A generated report update must not displace the selected uploaded document');
await assert.rejects(ui.openDocumentDb(), /does not provide local document storage/);
const persistedDocuments = new Map();
context.window.indexedDB = true;
context.indexedDB = {
  open() {
    const request = {};
    queueMicrotask(() => {
      request.result = {
        objectStoreNames:{contains:() => true}, close() {},
        transaction() {
          const transaction = {};
          const operation = action => {
            const result = {};
            queueMicrotask(() => { result.result = action(); result.onsuccess?.(); queueMicrotask(() => transaction.oncomplete?.()); });
            return result;
          };
          transaction.objectStore = () => ({put:document => operation(() => { persistedDocuments.set(document.id,structuredClone(document)); return document.id; }),getAll:() => operation(() => structuredClone([...persistedDocuments.values()])),delete:id => operation(() => persistedDocuments.delete(id))});
          return transaction;
        }
      };
      request.onsuccess?.();
    });
    return request;
  }
};
await ui.documentStore('readwrite',store => store.put(uploaded));
const reopened = await ui.documentStore('readonly',store => store.getAll());
assert.equal(reopened[0].originalText,uploaded.originalText,'The persistent library must reopen the full original text');
await ui.documentStore('readwrite',store => store.delete(uploaded.id));
assert.equal((await ui.documentStore('readonly',store => store.getAll())).length,0,'Removing a local document must delete only its own record');
ui.state.selectedResearchType = 'generated';

ui.state.shortPlan = createShortPlan(createMatch(input), null);
ui.state.shortPlanStatus = {cache:'cached',cutoffDate:'2026-10-02'};
const planTree = ui.renderShortPlan();
assert(planTree.textContent.includes('Rules ready'));
assert(planTree.textContent.includes('conditional') || planTree.textContent.includes('rules'));
assert(planTree.textContent.includes('Using cached market observations'));
assert(planTree.textContent.includes('independent of uploaded or generated long-term research'));

ui.state.profile = { ...input, essentialMoney: true };
ui.state.match = createMatch(ui.state.profile);
ui.renderPortfolio();
const blocked = elements.get('portfolio-content');
assert(blocked.textContent.includes('essential money'));
assert(!blocked.textContent.includes('Download allocation'), 'Essential-money profiles must not offer an investment allocation');

ui.state.remix = { budget: 10000, assets: [{ weight: 60 }, { weight: 50 }] };
ui.updateRemixTotals();
assert.equal(elements.get('save-remix').disabled, true, 'Weights over 100% must not be saved');
ui.state.remix.assets[1].weight = 40;
ui.updateRemixTotals();
assert.equal(elements.get('save-remix').disabled, false);
ui.state.remix.assets[1].weight = NaN;
ui.updateRemixTotals();
assert.equal(elements.get('save-remix').disabled, true, 'Missing weight must not be silently treated as zero');

ui.state.profile = { ...input };
ui.state.match = createMatch(input);
ui.state.signature = ui.signature(input);
ui.state.health = { worker: { online: true }, researchConfigured: true, deepseekConfigured: false, selectedStockResearch: true };
ui.state.job = null;
ui.state.matchController = {};
ui.state.sessionToken = 'prior-match-token';
ui.updateResearchAction();
assert.equal(elements.get('research-action').lastChild.disabled, true, 'An online worker must not enable research while matching is pending');
assert(elements.get('research-action').textContent.includes('Matching in progress'));
await ui.startResearch();
assert.equal(ui.state.job, null, 'The submit handler itself must block pending matches');

ui.state.matchController = null;
ui.state.sessionToken = null;
ui.updateResearchAction();
assert.equal(elements.get('research-action').lastChild.textContent, 'Finish matching', 'A local preview or failed server match must offer matching, not unauthenticated research');
await ui.startResearch();
assert.equal(ui.state.job, null, 'The submit handler must require the server-issued session');

ui.state.sessionToken = 'confirmed-current-match';
ui.syncSelection({tickers:['AMD','NVDA'],assets:ASSETS.filter(asset=>['AMD','NVDA'].includes(asset.ticker)),market:null,positions:[],saved:false,reason:'selection'});
ui.updateResearchAction();
assert.equal(elements.get('research-action').lastChild.disabled, false);
assert(elements.get('research-action').lastChild.textContent.includes('Generate deep research'), 'A confirmed rule-based server match may request research even if the explanation service is disabled');

ui.state.researchSubmitting = true;
ui.updateResearchAction();
assert.equal(elements.get('research-action').lastChild.disabled, true, 'Refreshing health must not re-enable a request while its submission is pending');
await ui.startResearch();
assert.equal(ui.state.job, null);
ui.state.researchSubmitting = false;

let requestedShortPlan, releaseShortPlan;
context.fetch = (url, options) => { requestedShortPlan = {url,options}; return new Promise(resolve => { releaseShortPlan = resolve; }); };
const priorSequence = ui.state.matchSequence;
const oldMatchId = ui.state.match.id;
const pendingShortPlan = ui.refreshShortPlan();
assert.equal(requestedShortPlan.url,'/api/short-plan');
assert.equal(requestedShortPlan.options.headers['X-Session-Token'],'confirmed-current-match');
assert.equal(JSON.parse(requestedShortPlan.options.body).matchId,oldMatchId);
ui.state.shortPlanController.abort();
ui.state.shortPlanController = null;
ui.state.matchSequence = priorSequence + 1;
const replacementPlan = {summary:'Replacement profile rules must remain visible'};
ui.state.shortPlan = replacementPlan;
releaseShortPlan({ok:true,json:async () => ({plan:{matchId:oldMatchId,assets:[],steps:[],summary:'Obsolete observations'}})});
await pendingShortPlan;
assert.equal(ui.state.shortPlan,replacementPlan,'A response for an aborted earlier match must not overwrite the current checklist');
const actualReportPath = new URL('../data/demo-report.json', import.meta.url);
if (fs.existsSync(actualReportPath)) {
  ui.state.report = JSON.parse(fs.readFileSync(actualReportPath, 'utf8'));
  ui.renderReport();
  assert(elements.get('report-content').textContent.includes('ALLOCATION AT REPORT GENERATION'));
  if (ui.state.report.backtest?.status === 'complete') assert(elements.get('report-content').textContent.includes('historical allocation comparison'));
}
console.log('UI contract checks passed: profile fields, tabs, stale inputs, safe text, visible data quality, outlook provenance, local source preservation, upload/generated selection, storage failure, immediate short plan, benchmark series, hedge comparisons, and authenticated research guards.');

ui.state.profile = validateProfile(DEFAULT_PROFILE);
ui.state.match = createMatch(DEFAULT_PROFILE);
ui.state.matchController = new AbortController();
ui.renderPortfolio();
const flow = document.getElementById("portfolio-content");
assert(flow.textContent.includes("Choose the stocks you want to follow"));
assert(flow.textContent.includes("Explore this strategy & backtests"));
assert(flow.children.findIndex(row=>row.tagName==="section") < flow.children.findIndex(row=>row.textContent.includes("See allocation, risk and research details")));
const descendants=(el,predicate)=>[...(predicate(el)?[el]:[]),...(el.children||[]).flatMap(child=>descendants(child,predicate))];
ui.renderTemplates();
ui.syncSelection({tickers:['AMD','NVDA'],assets:ASSETS.filter(a=>['AMD','NVDA'].includes(a.ticker)),market:null,positions:[],saved:false,reason:'selection'});
const selectedDetails=descendants(flow,e=>e.attributes?.['data-detail-key']==='full-plan-details')[0];
const allocationRows=descendants(selectedDetails,e=>e.className==='ticker').map(e=>e.textContent);
assert.deepEqual(allocationRows,['AMD','NVDA','CASH'],'Allocation must follow current checkboxes, without old template stocks');
const tickerSelect=descendants(elements.get('template-list'),e=>e.tagName==='select'&&e.id?.endsWith('-ticker'))[0];
assert.deepEqual(tickerSelect.children.map(e=>e.value),['AMD','NVDA'],'School lab must use the same selected stocks');
for(const badge of [...descendants(flow,e=>!!e.attributes?.['data-fit-school']),...descendants(elements.get('template-list'),e=>!!e.attributes?.['data-fit-school'])]){
  const expected=scoreSchoolFit(badge.attributes['data-fit-school'],{tickers:['AMD','NVDA']},SCHOOL_PRICES).score;
  assert(badge.textContent.includes(`${expected}/100 learning fit`),'All strategy overviews must refresh their selected-stock scores');
}
assert(selectedDetails.textContent.includes('newly added stocks start at 0%'));
ui.syncSelection({tickers:[],assets:[],market:null,positions:[],saved:false,reason:'selection'});
assert.deepEqual(descendants(selectedDetails,e=>e.className==='ticker').map(e=>e.textContent),['CASH'],'Empty selection must remove all prior stock amounts');
assert(elements.get('template-list').textContent.includes('Choose stocks in Your plan first'));
assert(descendants(flow,e=>!!e.attributes?.['data-fit-school']).every(e=>e.textContent==='Choose stocks'),'Clearing stocks must clear the overview scores');
ui.state.selectedResearchType='generated';
ui.state.report={id:'coverage-test',status:'partial',match:{allocations:[{ticker:'VTI',weight:100,amount:10000}]},research:[]};
ui.renderReport();
assert(selectedDetails.textContent.includes('Open report allocation: VTI'),'Loading a report immediately refreshes coverage');
ui.state.selectedResearchType='uploaded';
ui.state.uploadedDocument={...ui.state.uploadedDocument,filename:'nvda-review.md'};
ui.renderUploadedDocument();
assert(selectedDetails.textContent.includes('Open uploaded document: nvda-review.md'));
assert(!selectedDetails.textContent.includes('Open report allocation: VTI'),'An uploaded document cannot inherit the saved report coverage');
