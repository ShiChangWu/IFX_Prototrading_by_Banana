import { selectedPlan } from '../shared/selected-plan.mjs';
import { SCHOOL_BLURBS, scoreSchoolFit } from '../shared/school-fit.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { createWatchlist } from "../public/watchlist.js";
import { createSchoolLab } from '../public/school-lab.js';
import { SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { createReportCompanion } from '../public/report-guide.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createMatch, validateProfile, DEFAULT_PROFILE } from '../shared/strategy.mjs';
import { createShortPlan } from '../shared/short-plan.mjs';
import { MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument } from '../shared/report-import.mjs';

// Test-only DOM: no browser, HTTP server, provider or private report is opened.
class Element {
  constructor(tag) {
    this.tagName = tag; this.children = []; this.attributes = {}; this.style = {};
    this.hidden = false; this.disabled = false; this._text = ''; this.value = '';
    this.events = new Map(); this.scrollCount = 0;
  }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this._text = ''; this.children = [...items]; }
  set textContent(text) { this._text = String(text); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent || '').join(''); }
  setAttribute(key, value) { this.attributes[key] = value; }
  addEventListener(event, action) { this.events.set(event, action); }
  async click() { return this.events.get('click')?.({preventDefault() {}}); }
  scrollIntoView() { this.scrollCount += 1; }
  focus() {}
  get firstChild() { return this.children[0]; }
  get lastChild() { return this.children.at(-1); }
  get options() { return this.children; }
  querySelector(selector) { return findNode(this, item => item.tagName === selector); }
}

function findNode(root, predicate) {
  if (predicate(root)) return root;
  for (const child of root.children || []) { const found = findNode(child, predicate); if (found) return found; }
  return null;
}
const plain = value => JSON.parse(JSON.stringify(value));

function savedFixture() {
  const profile = {...DEFAULT_PROFILE, budget: 9000, prompt: 'Test-only original saved inputs'};
  return {
    id:'test-only-portable-report', title:'Test-only saved research', status:'partial',
    generatedAt:'2026-10-02T18:00:00Z', analysisDate:'2026-10-02', profile,
    match:createMatch(profile), provenance:{engine:'Test-only research fixture', dataSources:[], warnings:[]},
    research:[{ticker:'VTI', status:'complete', sections:[{title:'Test-only source', text:'Saved original evidence; not a fresh analysis.'}]}],
    outlook:[{horizon:'6–12 months', status:'unavailable', summary:'Test fixture has no supported outlook.'}],
    backtest:{status:'unavailable', error:'No historical fixture is supplied.'}, limitations:['Test-only saved report.'],
  };
}

const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8');
function harness({reports = [savedFixture()]} = {}) {
  const elements = new Map(), input = {...DEFAULT_PROFILE}, fetches = [];
  let sessionReads = 0;
  const document = {
    createElement: tag => new Element(tag), createElementNS: (_namespace, tag) => new Element(tag),
    createTextNode: text => { const element = new Element('#text'); element.textContent = text; return element; },
    getElementById: id => { if (!elements.has(id)) elements.set(id, new Element('div')); return elements.get(id); },
    querySelectorAll: () => [],
  };
  class FormDataDouble {
    get(key) { return input[key] ?? ''; }
    has(key) { return Boolean(input[key]); }
  }
  const window = {PROTO_PORTABLE:true, PROTO_DEMO_REPORTS:structuredClone(reports)};
  const context = vm.createContext({
    window, document, FormData:FormDataDouble, AbortController, DOMException,
    setTimeout, clearTimeout, Intl, Date, URL, JSON, Number, String, Math, Object, Array, structuredClone,
    selectedPlan, SCHOOL_BLURBS, scoreSchoolFit, SCHOOL_PRICES, TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createReportCompanion, createSchoolLab, createWatchlist, SCHOOL_TESTS, createMatch, validateProfile, createShortPlan, MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL,
    validateUploadFile, parseUploadedReport, validateStoredDocument,
    notifyHeight() {},
    fetch(...args) { fetches.push(args); throw new Error('Forbidden fetch in portable-mode test'); },
    sessionStorage:{
      getItem() {
        sessionReads += 1;
        return JSON.stringify({job:{id:'old-private-job',status:'running'},token:'test-only-private-token',profile:DEFAULT_PROFILE});
      },
      setItem() { throw new Error('Portable mode must not persist a live job'); },
    },
  });
  // Keep production function bodies intact, replacing only imports and browser
  // event/layout initialization; individual startup actions are tested below.
  const program = source.replace(/^import .*;\r?\n/gm, '').split('let heightFrame;')[0];
  assert(program.includes('function restoreJob()'), 'The portable test must retain the restore guard');
  vm.runInContext(program + '\n globalThis.ui = {state, request, refreshHealth, loadTemplates, loadExamples, loadExample, submitProfile, readProfile, signature, isStale, updateInputs, renderPortfolio, renderShortPlan, renderReport, renderUploadedDocument, updateResearchAction, startResearch, refreshShortPlan, restoreJob};', context);
  return {ui:context.ui, input, elements, window, fetches, sessionReads:() => sessionReads,
    element:id => document.getElementById(id), noFetch:() => assert.equal(fetches.length, 0, 'Portable mode attempted a network request')};
}

test('portable startup loads local status, templates and saved example cards without network or old private jobs', async () => {
  const h = harness();
  await Promise.all([h.ui.refreshHealth(), h.ui.loadTemplates(), h.ui.loadExamples()]);
  h.ui.restoreJob();
  assert.match(h.element('api-status').textContent, /Portable demo.*rules ready/);
  assert.match(h.element('capability-note').textContent, /Fresh AI explanations, prices and new TradingAgents reports require/);
  assert.equal(h.ui.state.templates.length, TEMPLATES.length);
  assert.equal(h.element('templateId').options.length, TEMPLATES.filter(template => template.matchable === true).length + 1);
  assert.match(h.element('examples-list').textContent, /Test-only saved research/);
  assert.match(h.element('examples-list').textContent, /saved example.*original inputs retained/);
  assert.equal(h.sessionReads(), 0, 'Offline startup must not restore a connected-mode private token');
  assert.equal(h.ui.state.job, null);
  h.noFetch();
});

test('portable request router clones saved reports and refuses every live API route without falling through to fetch', async () => {
  const h = harness();
  const result = await h.ui.request('/api/examples/test-only-portable-report');
  result.report.profile.budget = 1;
  result.report.research[0].sections[0].text = 'Changed test view';
  const reopened = await h.ui.request('/api/examples/test-only-portable-report');
  assert.equal(reopened.report.profile.budget, 9000);
  assert.equal(h.window.PROTO_DEMO_REPORTS[0].research[0].sections[0].text, 'Saved original evidence; not a fresh analysis.');
  for (const [path, options] of [
    ['/api/health', {}], ['/api/match', {method:'POST'}], ['/api/research', {method:'POST'}],
    ['/api/short-plan', {method:'POST'}], ['/api/research/old-private-job', {}],
    ['/api/templates', {method:'POST'}], ['/api/examples/missing', {}],
  ]) await assert.rejects(h.ui.request(path, options), /portable demo/);
  h.noFetch();
});

test('portable submission validates real profile rules before producing any allocation', async () => {
  const h = harness();
  for (const invalid of [{budget:0}, {goal:'unsupported'}, {prompt:'x'.repeat(1501)}]) {
    Object.assign(h.input, DEFAULT_PROFILE, invalid);
    await h.ui.submitProfile();
    assert.equal(h.ui.state.match, null);
    assert.equal(h.element('form-error').hidden, false);
    assert(h.element('form-error').textContent.length > 0);
  }
  Object.assign(h.input, DEFAULT_PROFILE, {essentialMoney:true});
  await h.ui.submitProfile();
  assert.equal(h.ui.state.match.eligible, false);
  assert.equal(h.ui.state.match.allocations.length, 0);
  assert.equal(h.ui.state.shortPlan.status, 'blocked');
  assert(!h.element('portfolio-content').textContent.includes('Download allocation'));
  h.noFetch();
});

test('portable matching calculates local amounts and a preliminary checklist without AI retries or market claims', async () => {
  const h = harness();
  let prevented = false;
  await h.ui.submitProfile({preventDefault() { prevented = true; }});
  assert(prevented);
  assert.equal(h.ui.state.profile.budget, 10000);
  assert.equal(h.ui.state.match.allocations.reduce((sum, row) => sum + row.amount, 0), 10000);
  assert.equal(h.ui.state.match.allocations.reduce((sum, row) => sum + row.weight, 0), 100);
  assert.equal(h.ui.state.matchController, null);
  assert.equal(h.ui.state.sessionToken, null);
  assert.equal(h.ui.state.explanation.status, 'unavailable');
  assert.equal(h.ui.state.shortPlan.status, 'preliminary');
  assert.equal(h.ui.state.shortPlan.matchId, h.ui.state.match.id);
  assert(h.ui.state.shortPlan.assets.every(asset => asset.market === null));
  assert.equal(h.ui.state.shortPlanLoading, false);
  assert.equal(h.ui.state.shortPlanStatus, null);
  const content = h.element('portfolio-content').textContent;
  assert.match(content, /Rule-based template match/);
  assert.match(content, /Portable demo: the maintained rules calculated this allocation/);
  assert.match(content, /observations pending/);
  assert(!content.includes('Retry explanation'));
  assert(!content.includes('Refresh market observations'));
  await h.ui.refreshShortPlan();
  await h.ui.startResearch();
  assert.equal(h.ui.state.job, null);
  assert.match(h.element('global-message').textContent, /connected app setup/);
  h.noFetch();
});

test('offline research action opens a separately labelled saved report without rewriting current inputs or short-term plan', async () => {
  const h = harness();
  h.input.budget = 15000;
  await h.ui.submitProfile();
  const profile = plain(h.ui.state.profile), match = plain(h.ui.state.match), plan = plain(h.ui.state.shortPlan);
  h.ui.updateResearchAction();
  const action = h.element('research-action').lastChild;
  assert.equal(action.textContent, 'Open saved research');
  assert.equal(action.disabled, false);
  await action.click();
  await Promise.resolve();
  assert.equal(h.ui.state.report.id, 'test-only-portable-report');
  assert.equal(h.ui.state.report.profile.budget, 9000);
  assert.equal(h.ui.state.report.generatedAt, '2026-10-02T18:00:00Z');
  assert.equal(h.ui.state.reportExample, true);
  assert.equal(h.ui.state.activeTab, 'research');
  assert.deepEqual(plain(h.ui.state.profile), profile);
  assert.deepEqual(plain(h.ui.state.match), match);
  assert.deepEqual(plain(h.ui.state.shortPlan), plan);
  assert.equal(h.input.budget, 15000);
  assert.match(h.element('report-content').textContent, /PREVIOUSLY GENERATED REPORT/);
  assert.match(h.element('report-content').textContent, /not for your current questionnaire/);
  assert.match(h.element('report-content').textContent, /No historical fixture is supplied/);
  h.noFetch();
});

test('editing and rematching the offline profile keeps the old report immutable and generates only a new local checklist', async () => {
  const h = harness();
  await h.ui.submitProfile();
  await h.ui.loadExample('test-only-portable-report');
  const originalReport = plain(h.ui.state.report), originalMatch = plain(h.ui.state.match);
  h.input.budget = 12000;
  h.ui.updateInputs();
  assert.equal(h.ui.isStale(), true);
  assert.equal(h.element('stale-notice').hidden, false);
  assert.deepEqual(plain(h.ui.state.match), originalMatch, 'Editing does not silently relabel old amounts');
  await h.ui.submitProfile();
  assert.equal(h.ui.isStale(), false);
  assert.equal(h.ui.state.profile.budget, 12000);
  assert.equal(h.ui.state.match.allocations.reduce((sum, row) => sum + row.amount, 0), 12000);
  assert.equal(h.ui.state.shortPlan.status, 'preliminary');
  assert.deepEqual(plain(h.ui.state.report), originalReport);
  assert.equal(h.ui.state.reportExample, true);
  h.noFetch();
});

test('portable uploaded prose stays inert, unverified and separate from both the saved report and local allocation', async () => {
  const h = harness();
  await h.ui.submitProfile();
  await h.ui.loadExample('test-only-portable-report');
  const report = plain(h.ui.state.report), match = plain(h.ui.state.match), plan = plain(h.ui.state.shortPlan);
  const text = '# Test-only upload\nDate: 2026-10-01\n## 6–12 months\n<script>fetch("https://example.invalid")</script>\n';
  h.ui.state.uploadedDocument = parseUploadedReport({filename:'test-only.md', text, id:'test-only-upload'});
  h.ui.state.selectedResearchType = 'uploaded';
  h.ui.renderUploadedDocument();
  h.ui.renderReport();
  assert.match(h.element('uploaded-report-content').textContent, /Uploaded document — not a fresh analysis/);
  assert.match(h.element('uploaded-report-content').textContent, /Unverified text extraction/);
  assert(h.element('uploaded-report-content').textContent.includes(text));
  assert.equal(h.element('report-content').hidden, true);
  assert.deepEqual(plain(h.ui.state.report), report);
  assert.deepEqual(plain(h.ui.state.match), match);
  assert.deepEqual(plain(h.ui.state.shortPlan), plan);
  assert(!findNode(h.element('uploaded-report-content'), element => element.tagName === 'script'));
  h.noFetch();
});
