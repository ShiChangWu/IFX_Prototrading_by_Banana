"""Synthetic price paths test the math; these fixtures are never report data."""
from datetime import date, timedelta
import unittest
from unittest.mock import patch

from worker.hedging import compare_histories, historical_hedge_assessment


def fixture():
    days = [(date(2024, 1, 1) + timedelta(days=i)).isoformat() for i in range(21)]
    # Deliberately different actual fund paths: multiplying the index's whole
    # period return by a daily target would produce different results.
    return {ticker: dict(zip(days, values)) for ticker, values in {
        "SPY": [100 + i for i in range(21)],
        "SH": [100 - .8 * i for i in range(21)],
        "SDS": [100 - 1.6 * i for i in range(21)],
        "SPXU": [100 - 2.3 * i for i in range(21)],
    }.items()}


class HedgeTests(unittest.TestCase):
    def test_actual_fund_path_not_negative_cumulative_benchmark(self):
        result = compare_histories(fixture())
        self.assertEqual(result["benchmark"]["returnPct"], 20)
        self.assertEqual([p["returnPct"] for p in result["products"]], [-16, -32, -46])
        self.assertEqual(result["sessions"], 20)
        self.assertEqual(result["observations"], 21)
        self.assertFalse(result["allocated"])

    def test_equal_first_day_exposure_scenarios_reconcile(self):
        result = compare_histories(fixture(), cost_bps=0)
        for scenario, multiple in zip(result["scenarios"], (-1, -2, -3)):
            weights = scenario["weightsPct"]
            self.assertAlmostEqual(sum(weights.values()), 100, places=5)
            self.assertAlmostEqual(weights[scenario["ticker"]] * multiple, -5, places=5)
            self.assertEqual(weights["SPY"], 90)
        # 90% SPY gains20%, 5%SH loses16%, 5%cash unchanged =>17.2%.
        self.assertEqual(result["scenarios"][0]["returnPct"], 17.2)

    def test_transaction_costs_reduce_scenario_return(self):
        free = compare_histories(fixture(), cost_bps=0)
        cost = compare_histories(fixture(), cost_bps=10)
        for a, b in zip(free["scenarios"], cost["scenarios"]):
            self.assertLess(b["endingValue"], a["endingValue"])
            self.assertGreater(b["initialTransactionCost"], 0)

    def test_missing_session_is_not_interpolated_or_silently_shortened(self):
        prices = fixture()
        prices["SH"].pop("2024-01-10")
        with self.assertRaises(ValueError):
            compare_histories(prices)

    def test_no_optin_makes_no_network_call(self):
        with patch("builtins.__import__", side_effect=AssertionError("No dependency/network required")):
            result = historical_hedge_assessment("none", 10000)
        self.assertEqual(result["status"], "not_requested")


if __name__ == "__main__":
    unittest.main()
