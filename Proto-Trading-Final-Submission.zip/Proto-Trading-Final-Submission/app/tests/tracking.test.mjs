import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { LocalStore } from '../server/store.mjs';
import { createTrackingService } from '../server/tracking.mjs';
import { createApi } from '../server/api.mjs';
import { configuration } from '../server/config.mjs';
import { DEFAULT_PROFILE } from '../shared/strategy.mjs';

const hash = value => createHash('sha256').update(value).digest('hex');
const OWNER = 'owner-private-session-token';
const OTHER = 'another-private-session-token';
const email = 'member@example.com';
const tokens = text => [...text.matchAll(/#token=([A-Za-z0-9_-]+)/g)].map(match => match[1]);
const config = { mode: 'local', emailDeliveryEnabled:true, intradayProvider:'alpaca', gmailUser: 'demo@gmail.com', gmailAppPassword: 'abcdefghijklmnop', alpacaKey: 'key', alpacaSecret: 'secret', alpacaFeed: 'iex', alertBaseUrl: 'http://127.0.0.1:8787', alertIntervalSeconds: 60 };
const input = changes => ({ tickers: ['NVDA'], schoolId: 'balanced', email, consent: true, enabled: false, conditions: [{ ticker: 'NVDA', buyBelow: 100, sellAbove: 110, sellBelow: 90 }], ...changes });

test('demo email pause blocks confirmation, activation, old outbox delivery and automatic checks',async t=>{
  const f=await fixture(t,{config:{emailDeliveryEnabled:false}});
  await f.save();
  await assert.rejects(()=>f.call('/api/tracking/verify','POST'),/paused for this demo/);
  await assert.rejects(()=>f.save({enabled:true}),/paused for this demo/);
  await f.store.transact(state=>{
    state.tracking[f.key].enabled=true;state.tracking[f.key].verified=true;
    state.mailOutbox.old={id:'old',key:f.key,to:email,subject:'Old pending mail',text:'Private old message',status:'pending',createdAt:new Date(f.now()).toISOString()};
  });
  await f.service.flush();await f.service.tick();
  assert.equal(f.sent.length,0);assert.equal(f.quoteCalls,0);
  await f.service.checkOne(f.key);
  const result=await f.call();assert.equal(result.capabilities.emailDeliveryEnabled,false);
  assert.equal(result.tracking.alerts[0].status,'preview');assert.equal(f.sent.length,0);
});

async function fixture(t, changes = {}) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-tracking-test-'));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const store = new LocalStore(path.join(directory, 'state.json'));
  let clock = Date.parse('2026-10-05T15:05:30Z'), price = 99, quoteAge = 90000, quoteCalls = 0;
  const sent = [], selectedConfig = { ...config, ...changes.config };
  let sendResult = changes.sendResult || 'accepted';
  await store.transact(state => {
    for (const token of [OWNER, OTHER]) state.sessions[hash(token)] = { expiresAt: clock + 7 * 86400000, trackingEligible: true, matching: false, profileHash: 'profile-one', selectedTemplateId: 'balanced' };
  });
  const service = createTrackingService({ config: selectedConfig, store, now: () => clock,
    fetchImpl: async () => { throw new Error('Tests must not call an external provider.'); },
    assetProvider: async ticker => ({ ticker, status: 'complete', assetClass: 'us_equity', tradable: true, exchange: 'NASDAQ', name: ticker + ' company' }),
    searchStocks: async ticker => ({ results: ticker === 'UNKNOWN' ? [] : [{ ticker, name: ticker + ' company' }] }),
    getSnapshot: async () => ({ snapshot: { snapshots: [] } }),
    // Mock only public data and email boundaries; persistence and transitions are real.
    quoteProvider: async tickers => { quoteCalls++; return { status: 'complete', source: 'Alpaca', feed: 'iex', warnings: [], quotes: Object.fromEntries(tickers.map(ticker => [ticker, { ticker, status: 'complete', price, barTime: new Date(clock - quoteAge).toISOString() }])) }; },
    mailer: async message => { sent.push(structuredClone(message)); return { status: sendResult }; },
    ...(changes.service || {}),
  });
  const call = (route = '/api/tracking', method = 'GET', body = {}, session = OWNER) => service.handle(route, method, body, session);
  const save = changes => call('/api/tracking', 'POST', input(changes));
  const confirmEmail = async () => {
    await call('/api/tracking/verify', 'POST');
    const token = tokens(sent.at(-1).text)[0];
    await call('/api/tracking/confirm', 'POST', { token }, undefined);
    return token;
  };
  return { store, service, sent, call, save, confirmEmail, key: hash(OWNER), get quoteCalls() { return quoteCalls; }, now: () => clock,
    advance: milliseconds => { clock += milliseconds; }, setPrice: value => { price = value; }, setQuoteAge: value => { quoteAge = value; }, setSendResult: value => { sendResult = value; } };
}

test('watchlists and fills are private to the owning unexpired session', async t => {
  const f = await fixture(t);
  await f.save();
  assert.equal((await f.call()).tracking.email, email);
  assert.equal((await f.call('/api/tracking', 'GET', {}, OTHER)).tracking, null);
  await assert.rejects(() => f.call('/api/tracking', 'GET', {}, 'unknown-token'), { status: 401 });
  await assert.rejects(() => f.call('/api/tracking/fills', 'POST', {}, OTHER), { status: 409 });
  const publicResult = JSON.stringify(await f.call());
  assert.doesNotMatch(publicResult, /profileHash|revision|trackingLinks|mailOutbox|owner-private-session-token/);
  await f.store.transact(state => { state.sessions[f.key].expiresAt = f.now() - 1; });
  await assert.rejects(() => f.call(), { status: 401 });
});

test('alerts require consent, a confirmed address and both configured providers', async t => {
  const f = await fixture(t);
  await f.save();
  await assert.rejects(() => f.save({ enabled: true }), { status: 409 });
  await f.service.tick();
  assert.equal(f.sent.length, 0);
  assert.equal(f.quoteCalls, 0);
  await f.call('/api/tracking/check', 'POST');
  assert.equal(f.sent.length, 0);
  assert.equal((await f.call()).tracking.alerts[0].status, 'preview');
  await f.save({ consent: false });
  await assert.rejects(() => f.call('/api/tracking/verify', 'POST'), { status: 400 });
  await f.save();
  const confirmation = await f.confirmEmail();
  assert.equal(f.sent.length, 1);
  assert.equal((await f.call('/api/tracking/link', 'POST', { token: confirmation }, undefined)).purpose, 'verify');
  assert.equal((await f.call()).tracking.enabled, false);
  await f.save({ enabled: true });
  assert.equal((await f.call()).tracking.enabled, true);
  const noCredentials = await fixture(t, { config: { gmailAppPassword: '' } });
  await noCredentials.save();
  await assert.rejects(() => noCredentials.call('/api/tracking/verify', 'POST'), { status: 503 });
  assert.equal(noCredentials.sent.length, 0);
});

test('buy alert, private fill, idempotent recording, sell alert and unsubscribe form a working lifecycle', async t => {
  const f = await fixture(t);
  await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
  await f.service.tick();
  assert.equal(f.sent.length, 2);
  assert.match(f.sent[1].subject, /NVDA BUY review/);
  const [fillToken, stopToken] = tokens(f.sent[1].text);
  const link = await f.call('/api/tracking/link', 'POST', { token: fillToken }, undefined);
  assert.equal(link.side, 'buy'); assert.equal(link.ticker, 'NVDA'); assert.deepEqual(link.positions, []);
  const fill = { token: fillToken, ticker: 'NVDA', side: 'buy', quantity: 2, price: 98.5, executedAt: new Date(f.now()).toISOString(), idempotencyKey: 'recorded-trade-0001' };
  await assert.rejects(() => f.call('/api/tracking/confirm', 'POST', { ...fill, ticker: 'AMD' }, undefined), { status: 400 });
  const recorded = await f.call('/api/tracking/confirm', 'POST', fill, undefined);
  assert.equal(recorded.positions[0].quantity, 2);
  assert.equal(recorded.positions[0].averagePrice, 98.5);
  await assert.rejects(() => f.call('/api/tracking/confirm', 'POST', fill, undefined), { status: 409 });
  assert.equal((await f.call('/api/tracking/fills', 'POST', fill)).duplicate, true);
  assert.equal((await f.call()).tracking.fills.length, 1);
  await assert.rejects(() => f.call('/api/tracking/fills', 'POST', { ...fill, quantity: 3 }), { status: 400 });
  await assert.rejects(() => f.call('/api/tracking/fills', 'POST', { ...fill, side: 'sell', quantity: 3, idempotencyKey: 'recorded-trade-0002' }), { status: 400 });
  assert.equal((await f.call()).tracking.positions[0].quantity, 2);
  f.advance(60000); f.setPrice(112);
  await f.service.tick();
  assert.equal(f.sent.length, 3);
  assert.match(f.sent[2].subject, /NVDA SELL review/);
  assert.match(f.sent[2].text, /2 recorded shares/);
  const sellToken = tokens(f.sent[2].text)[0];
  await f.call('/api/tracking/confirm', 'POST', { ...fill, token: sellToken, side: 'sell', quantity: 2, price: 111.5, executedAt: new Date(f.now()).toISOString(), idempotencyKey: 'recorded-trade-0003' }, undefined);
  assert.equal((await f.call()).tracking.positions[0].quantity, 0);
  await f.call('/api/tracking/confirm', 'POST', { token: stopToken }, undefined);
  assert.equal((await f.call()).tracking.enabled, false);
  f.advance(60000); await f.service.tick();
  assert.equal(f.sent.length, 3);
  const state = await f.store.read();
  assert.ok(Object.values(state.mailOutbox).every(row => row.status !== 'accepted' || row.text === undefined));
});

test('minute freshness and holdings gate alerts, and repeated signals are deduplicated', async t => {
  const f = await fixture(t);
  await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
  f.setQuoteAge(10 * 60000); await f.service.tick();
  assert.equal(f.sent.length, 1); assert.equal((await f.call()).tracking.alerts.length, 0);
  f.setQuoteAge(30000); await f.service.tick();
  assert.equal(f.sent.length, 1);
  f.setQuoteAge(90000); f.setPrice(112); await f.service.tick();
  assert.equal(f.sent.length, 1); // No recorded shares: no sell reminder.
  f.setPrice(99); await f.service.tick();
  assert.equal(f.sent.length, 2);
  f.advance(60000); await f.service.tick(); await f.service.tick();
  assert.equal(f.sent.length, 2);
  assert.equal((await f.call()).tracking.alerts.length, 1);
});

test('changed email loses verification and old confirmation links cannot authorize the new address', async t => {
  const f = await fixture(t);
  await f.save(); const old = await f.confirmEmail(); await f.save({ enabled: true });
  await assert.rejects(() => f.save({ email: 'different@example.com', enabled: true }), { status: 409 });
  await f.save({ email: 'different@example.com' });
  assert.equal((await f.call()).tracking.verified, false);
  await assert.rejects(() => f.call('/api/tracking/confirm', 'POST', { token: old }, undefined), { status: 409 });
  f.advance(86400001);
  await assert.rejects(() => f.call('/api/tracking/link', 'POST', { token: old }, undefined), { status: 404 });
});

test('uncertain and failed SMTP outcomes are recorded without automatic resend', async t => {
  for (const status of ['uncertain', 'failed']) {
    const f = await fixture(t);
    await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
    f.setSendResult(status); await f.service.tick();
    assert.equal(f.sent.length, 2);
    assert.equal((await f.call()).tracking.alerts[0].status, status);
    await f.service.flush(); f.advance(60000); await f.service.tick();
    assert.equal(f.sent.length, 2);
  }
});

test('profile matching pauses checks and pending emails must also be cancelled before sending', async t => {
  const f = await fixture(t);
  await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
  const before = f.quoteCalls;
  await f.store.transact(state => {
    state.sessions[f.key].matching = true;
    state.tracking[f.key].alerts.push({ id: 'queued-before-match', status: 'pending' });
    state.mailOutbox['queued-before-match'] = { id: 'queued-before-match', key: f.key, to: email, subject: 'Old rule', text: 'Old profile alert', alertId: 'queued-before-match', status: 'pending', createdAt: new Date(f.now()).toISOString() };
  });
  await f.service.tick();
  assert.equal(f.quoteCalls, before);
  assert.equal(f.sent.length, 1, 'A pending alert must not bypass the paused matching state');
  assert.equal((await f.store.read()).mailOutbox['queued-before-match'].status, 'cancelled');
});

test('interrupted SMTP sending state becomes uncertain and is never retried after restart', async t => {
  const f = await fixture(t);
  await f.save();
  await f.store.transact(state => {
    state.mailOutbox ||= {};
    state.mailOutbox.interrupted = { id: 'interrupted', key: f.key, to: email, subject: 'Prior message', text: 'Private prior body', status: 'sending', createdAt: new Date(f.now()).toISOString() };
  });
  await f.service.flush(); await f.service.flush();
  assert.equal((await f.store.read()).mailOutbox.interrupted.status, 'uncertain');
  assert.equal(f.sent.length, 0);
});

test('unverified instruments cannot enable alerts or produce preview conditions', async t => {
  const f = await fixture(t, { service: { assetProvider: async ticker => ({ ticker, status: 'unavailable' }) } });
  await f.save(); await f.confirmEmail();
  await assert.rejects(() => f.save({ enabled: true }), { status: 409 });
  await f.call('/api/tracking/check', 'POST');
  assert.equal(f.quoteCalls, 0);
  assert.equal((await f.call()).tracking.status, 'asset_verification_unavailable');
  assert.equal((await f.call()).tracking.alerts.length, 0);
  assert.equal(f.sent.length, 1);
});

test('asset verification is bounded by its cache and a later inactive asset stops checks', async t => {
  let calls = 0, active = true;
  const f = await fixture(t, { service: { assetProvider: async ticker => { calls++; return { ticker, status: active ? 'complete' : 'unavailable', assetClass: 'us_equity', tradable: active }; } } });
  await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
  await f.service.tick(); await f.service.tick();
  assert.equal(calls, 1);
  assert.equal(f.sent.length, 2);
  active = false; f.advance(6 * 3600000 + 1);
  const before = f.quoteCalls;
  await f.service.tick();
  assert.equal(calls, 2);
  assert.equal(f.quoteCalls, before);
  assert.equal((await f.call()).tracking.status, 'asset_verification_unavailable');
  assert.equal(f.sent.length, 2);
});

test('stale outbox alerts are cancelled for changed profile, strategy, eligibility or expiry', async t => {
  for (const sessionChange of [{ profileHash: 'different-profile' }, { selectedTemplateId: 'defensive' }, { trackingEligible: false }, { expiresAt: 0 }]) {
    const f = await fixture(t);
    await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
    await f.store.transact(state => {
      Object.assign(state.sessions[f.key], sessionChange);
      state.tracking[f.key].alerts.push({ id: 'old-alert', status: 'pending' });
      state.mailOutbox['old-alert'] = { id: 'old-alert', key: f.key, to: email, subject: 'Old rule', text: 'Old profile alert', alertId: 'old-alert', status: 'pending', createdAt: new Date(f.now()).toISOString() };
    });
    await f.service.flush();
    assert.equal(f.sent.length, 1);
    const state = await f.store.read();
    assert.equal(state.mailOutbox['old-alert'].status, 'cancelled');
    assert.equal(state.tracking[f.key].alerts[0].status, 'cancelled');
  }
});

test('API rematching a changed profile pauses its existing alerts and preserves recorded holdings', async t => {
  const f = await fixture(t);
  const api = createApi({ config: { ...configuration({}), ...config }, store: f.store, now: f.now, trackingService: f.service, fetchImpl: async () => { throw new Error('No live provider calls in tests.'); } });
  const request = body => api(new Request('http://localhost:8787/api/match', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Session-Token': OWNER }, body: JSON.stringify({ profile: body }) }));
  let response = await request(DEFAULT_PROFILE);
  assert.equal(response.status, 200);
  assert.equal((await response.json()).sessionToken, OWNER);
  await f.save(); await f.confirmEmail(); await f.save({ enabled: true });
  await f.call('/api/tracking/fills', 'POST', { ticker: 'NVDA', side: 'buy', quantity: 1, price: 99, executedAt: new Date(f.now()).toISOString(), idempotencyKey: 'trade-before-rematch' });
  response = await request({ ...DEFAULT_PROFILE, budget: 12000 });
  assert.equal(response.status, 200);
  let tracking = (await f.call()).tracking;
  assert.equal(tracking.enabled, false);
  assert.equal(tracking.status, 'profile_changed_review_required');
  assert.equal(tracking.positions[0].quantity, 1);
  response = await request({ ...DEFAULT_PROFILE, essentialMoney: true });
  assert.equal(response.status, 200);
  assert.equal((await response.json()).match.eligible, false);
  await assert.rejects(() => f.save({ enabled: true }), { status: 409 });
  tracking = (await f.call()).tracking;
  assert.equal(tracking.enabled, false);
  assert.equal(tracking.fills.length, 1);
});
