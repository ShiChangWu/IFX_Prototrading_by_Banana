import test from 'node:test';
import assert from 'node:assert/strict';
import { createWatchlist } from '../public/watchlist.js';

class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.attributes = {}; this.style = {}; this.events = {}; this._text = ''; this.value = ''; this.hidden = false; this.checked = false; }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this.children = []; this._text = ''; this.append(...items); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent).join(' '); }
  setAttribute(k, v) { this.attributes[k] = v; }
  addEventListener(k, fn) { this.events[k] = fn; }
  async click() { if (!this.disabled) await this.events.click?.(); }
}
const all = (root, predicate) => [...(predicate(root) ? [root] : []), ...root.children.flatMap(child => all(child, predicate))];
const settle = () => new Promise(resolve => setTimeout(resolve, 0));
const match = { id: 'match-a', template: { id: 'trend', name: 'Patient trend follower', beginnerSummary: 'Follow an established trend.', exampleTickers: ['AMD', 'NVDA'] }, allocations: [{ ticker: 'VTI' }, { ticker: 'SGOV' }, { ticker: 'CASH' }] };
function harness({ portableMode = false, data, handler, pending = false, profile } = {}) {
  let context = { match, sessionToken: 'session-test', pending, profile };
  let response = data || { tracking: null, capabilities: { mailConfigured: false, marketConfigured: false } };
  const calls = [], request = async (path, options = {}) => {
    calls.push({ path, ...options }); if (handler) return handler(path, options, response);
    if (path.startsWith('/api/stocks/search')) return { status: 'available', source: { name: 'AKShare' }, warnings: ['The directory can be delayed.'], results: [{ ticker: 'TSLA', name: 'Tesla Inc', source: 'AKShare' }] };
    if (path === '/api/tracking' && options.method === 'POST') response = { ...response, tracking: { ...response.tracking, ...options.body } };
    if (path === '/api/tracking/stop') response = { ...response, tracking: { ...response.tracking, enabled: false } };
    return response;
  };
  const selections = [];
  const component = createWatchlist({ createElement: tag => new Element(tag) }, { request, getContext: () => context, portableMode, onSelectionChange: snapshot => selections.push(snapshot) });
  const find = predicate => all(component.element, predicate)[0];
  return { component, calls, selections, find, text: () => component.element.textContent, button: caption => find(e => e.tagName === 'button' && e.textContent === caption), input: suffix => find(e => e.id?.endsWith('-' + suffix)), setContext(value) { context = { ...context, ...value }; component.update(); } };
}
test('selected allocation stocks and AKShare directory results save without subscribing to email', async () => {
  const h = harness(); await settle();
  assert.match(h.text(), /Included in your starting allocation/); assert.match(h.text(), /Strategy learning example/);
  assert.equal(all(h.component.element, e => e.type === 'checkbox' && e.checked).length, 2);
  h.input('search').value = 'TSLA'; await h.button('Search stocks').click();
  assert.match(h.text(), /directory can be delayed/); await h.button('Add to selection').click(); await h.button('Save stocks to follow').click();
  const saved = h.calls.find(call => call.path === '/api/tracking' && call.method === 'POST');
  assert.deepEqual(saved.body.tickers, ['VTI', 'SGOV', 'TSLA']); assert.equal(saved.body.enabled, false); assert.equal(saved.body.consent, false); assert.equal(saved.body.schoolId, 'trend');
  assert.deepEqual(saved.body.conditions[2], { ticker: 'TSLA', buyBelow: null, sellAbove: null, sellBelow: null }); assert.equal(saved.headers['X-Session-Token'], 'session-test');
});
test('missing mail setup disables sending and rejects zero thresholds before a request', async () => {
  const h = harness(); await settle(); assert.equal(h.button('Verify my email address').disabled, true); assert.match(h.text(), /no email can be sent/);
  const threshold = h.input('VTI-buyBelow'); threshold.value = '0'; threshold.events.input(); await h.button('Save reminder settings').click();
  assert.match(h.text(), /Enter a positive buy price/); assert.equal(h.calls.filter(call => call.method === 'POST').length, 0);
  threshold.value = '120.50'; threshold.events.input(); await h.button('Save reminder settings').click();
  assert.equal(h.calls.at(-1).body.conditions[0].buyBelow, 120.5); assert.equal(h.calls.at(-1).body.enabled, false);
});
test('turn off uses saved tracking even when the current unsaved selection is empty', async () => {
  const h = harness({ data: { tracking: { tickers: ['VTI'], email: 'investor@gmail.com', consent: true, verified: true, enabled: true, schoolId: 'trend', conditions: [] }, capabilities: { mailConfigured: true, marketConfigured: true } } }); await settle();
  const checked = h.find(e => e.type === 'checkbox' && e.attributes['aria-label'] === 'Follow VTI'); checked.checked = false; checked.events.change();
  await h.button('Turn off email reminders').click(); const saved = h.calls.at(-1);
  assert.equal(saved.path, '/api/tracking/stop'); assert.deepEqual(saved.body, {}); assert.match(h.text(), /turned off/); assert.equal(h.button('Turn off email reminders').disabled, true);
});
test('trade recording blocks an oversell and retries an uncertain purchase with the same key', async () => {
  let fail = true;
  const h = harness({ data: { tracking: { tickers: ['VTI'], positions: [{ ticker: 'VTI', quantity: 1, averagePrice: 100 }] }, capabilities: {} }, handler: async (path, options, response) => {
    if (path === '/api/tracking/fills') { if (fail) { fail = false; throw new Error('Connection interrupted'); } return { ...response, tracking: { ...response.tracking, positions: [{ ticker: 'VTI', quantity: 3, averagePrice: 110 }] } }; }
    return response;
  } }); await settle();
  h.input('fill-side').value = 'sell'; h.input('quantity').value = '2'; h.input('price').value = '115'; await h.button('Record completed trade').click();
  assert.match(h.text(), /recorded holding is 1 shares/); assert.equal(h.calls.filter(call => call.path === '/api/tracking/fills').length, 0);
  h.input('fill-side').value = 'buy'; await h.button('Record completed trade').click(); assert.match(h.text(), /Connection interrupted/); await h.button('Record completed trade').click();
  const fills = h.calls.filter(call => call.path === '/api/tracking/fills'); assert.equal(fills.length, 2); assert.equal(fills[0].body.idempotencyKey, fills[1].body.idempotencyKey); assert.equal(fills[0].body.quantity, 2); assert.equal(fills[0].body.price, 115); assert.match(h.text(), /3 shares/); assert.equal(h.input('quantity').value, '');
});
test('portable mode searches only the included directory and cannot send or save trades', async () => {
  const h = harness({ portableMode: true }); await settle(); h.input('search').value = 'AMD'; await h.button('Search stocks').click();
  assert.match(h.text(), /Included stock list only/); assert.equal(h.calls.length, 0);
  assert.equal(h.button('Verify my email address').disabled, true); assert.equal(h.button('Record completed trade').disabled, true); assert.equal(h.button('Refresh email status').disabled, true);
  await h.button('Keep this selection for this visit').click(); assert.match(h.text(), /Selection kept for this visit/); assert.equal(h.calls.length, 0);
});
test('tracking waits for a pending match and a late load cannot overwrite selection edits', async () => {
  let deliver;
  const h = harness({ pending: true, handler: () => new Promise(resolve => { deliver = resolve; }) }); assert.equal(h.calls.length, 0);
  h.setContext({ pending: false }); assert.equal(h.calls.length, 1);
  const checkbox = h.find(e => e.type === 'checkbox' && e.attributes['aria-label'] === 'Follow VTI'); checkbox.checked = false; checkbox.events.change();
  deliver({ tracking: { tickers: ['VTI', 'SGOV'], email: 'saved@gmail.com' }, capabilities: {} }); await settle();
  assert.match(h.text(), /1 of 8 stocks selected/); assert.equal(h.find(e => e.type === 'checkbox' && e.attributes['aria-label'] === 'Follow VTI').checked, false);
});

test('demo delivery remains paused even with configured credentials and displays dated Yahoo minute bars', async () => {
  const h = harness({ data: { tracking: { tickers: ['NVDA', 'AMD'], positions: [], email: 'investor@gmail.com', verified: true, consent: true, market: { source: 'Yahoo Finance', fetchedAt: '2026-10-02T20:10:00Z', quotes: { NVDA: { status: 'stale', price: 120.5, barTime: '2026-10-02T19:55:00Z' }, AMD: { status: 'unavailable', reason: 'No minute bars returned.' } } } }, capabilities: { emailDeliveryEnabled: false, mailConfigured: true, marketConfigured: true, automatic: false } } });
  await settle(); assert.equal(h.button('Verify my email address').disabled, true); assert.equal(h.button('Refresh email status').disabled, true);
  assert.match(h.text(), /Yahoo Finance intraday/); assert.match(h.text(), /Older quote · not a current signal/); assert.match(h.text(), /\$120.50/); assert.match(h.text(), /No minute bars returned/); assert.match(h.text(), /refresh on request/);
  const yahoo = all(h.component.element, e => e.tagName === 'a' && e.href?.startsWith('https://finance.yahoo.com/quote/')); assert.equal(yahoo.length, 2); assert.equal(yahoo[0].rel, 'noopener noreferrer');
  await h.button('Save stocks to follow').click(); assert.equal(h.calls.at(-1).body.enabled, false); assert.equal(h.calls.some(call => call.path === '/api/tracking/verify'), false);
  await h.button('Refresh prices').click(); assert.equal(h.calls.at(-1).path, '/api/tracking/check');
});

test('selection snapshots update immediately, include searched assets, and honor an empty saved list', async () => {
  const h = harness({ data: { tracking: { tickers: [], positions: [] }, capabilities: {} } }); await settle();
  assert.deepEqual(h.component.getSelection().tickers, []);
  assert.equal(h.component.getSelection().saved, true);
  assert.equal(h.selections.at(-1).reason, 'hydrated');
  h.input('search').value = 'TSLA'; await h.button('Search stocks').click(); await h.button('Add to selection').click();
  assert.deepEqual(h.selections.at(-1).tickers, ['TSLA']); assert.equal(h.selections.at(-1).reason, 'selection');
  assert.equal(h.selections.at(-1).assets[0].name, 'Tesla Inc'); assert.equal(h.selections.at(-1).saved, false);
  await h.button('Save stocks to follow').click(); assert.equal(h.component.getSelection().saved, true);
  const checkbox = h.find(e => e.attributes['aria-label'] === 'Follow TSLA'); checkbox.checked = false; checkbox.events.change();
  assert.deepEqual(h.selections.at(-1).tickers, []); assert.equal(h.selections.at(-1).saved, false);
  await h.button('Save stocks to follow').click(); assert.deepEqual(h.calls.at(-1).body.tickers, []);
  assert.deepEqual(h.component.getSelection().tickers, []); assert.equal(h.component.getSelection().saved, true);
});

test('stock edits survive matching on the same profile, and a new profile clears old quotes and holdings', async () => {
  const profile = { budget: 10000, goal: 'balanced' };
  const h = harness({ pending: true, profile, data: { tracking: { tickers: ['VTI'], positions: [{ ticker: 'VTI', quantity: 1, averagePrice: 100 }] }, capabilities: {} } });
  const box = h.find(e => e.attributes['aria-label'] === 'Follow VTI'); box.checked = false; box.events.change();
  h.setContext({ sessionToken: 'new-session', pending: false, match: { ...match, id: 'match-server' }, profile: { goal: 'balanced', budget: 10000 } }); await settle();
  assert.deepEqual(h.component.getSelection().tickers, ['SGOV']); assert.equal(h.component.getSelection().saved, false);
  h.setContext({ pending: true, profile: { ...profile, budget: 20000 }, match: { ...match, id: 'match-profile-two' } });
  assert.deepEqual(h.component.getSelection().tickers, ['VTI', 'SGOV']);
  assert.deepEqual(h.component.getSelection().positions, []); assert.equal(h.component.getSelection().market, null);
});

test('late saves preserve newer edits and market and fill responses publish independent snapshots', async () => {
  let deliverSave;
  const market = { quotes: { VTI: { price: 125, status: 'stale' } }, source: 'Yahoo Finance' };
  const h = harness({ data: { tracking: { tickers: ['VTI', 'SGOV'], positions: [] }, capabilities: {} }, handler: async (path, options, response) => {
    if (path === '/api/tracking' && options.method === 'POST') return new Promise(resolve => { deliverSave = () => resolve({ ...response, tracking: { ...response.tracking, tickers: options.body.tickers } }); });
    if (path === '/api/tracking/check') return { ...response, tracking: { ...response.tracking, market } };
    if (path === '/api/tracking/fills') return { ...response, tracking: { ...response.tracking, market, positions: [{ ticker: 'VTI', quantity: 2, averagePrice: 120 }] } };
    return response;
  } }); await settle();
  const saving = h.button('Save stocks to follow').click();
  const box = h.find(e => e.attributes['aria-label'] === 'Follow SGOV'); box.checked = false; box.events.change();
  deliverSave(); await saving;
  assert.deepEqual(h.component.getSelection().tickers, ['VTI']); assert.equal(h.component.getSelection().saved, false);
  await h.button('Refresh prices').click(); assert.equal(h.selections.at(-1).reason, 'market'); assert.equal(h.component.getSelection().market.quotes.VTI.price, 125);
  const externalSnapshot = h.component.getSelection(); externalSnapshot.market.quotes.VTI.price = 999;
  assert.equal(h.component.getSelection().market.quotes.VTI.price, 125);
  h.input('quantity').value = '2'; h.input('price').value = '120'; await h.button('Record completed trade').click();
  assert.equal(h.selections.at(-1).reason, 'fill'); assert.equal(h.selections.at(-1).positions[0].quantity, 2);
  assert.deepEqual(h.selections.at(-1).tickers, ['VTI']);
});
