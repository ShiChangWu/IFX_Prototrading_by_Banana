import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { DEFAULT_PROFILE, TEMPLATES, createMatch, validateProfile } from '../shared/strategy.mjs';
import { createShortPlan } from '../shared/short-plan.mjs';

const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
function extract(name) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  assert(start >= 0, name); const body = source.slice(start), end = body.indexOf('\n}\n') + 2;
  assert(end > 1, name); return body.slice(0, end);
}
class Element {
  constructor(tag = 'div', text = '') { this.tagName = tag; this.children = []; this.events = {}; this._text = text; this._value = ''; this.hidden = false; this.checked = false; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = children; this._text = ''; if (this.tagName === 'select') this._value = ''; }
  get firstChild() { return this.children[0]; }
  get options() { return this.children; }
  get textContent() { return this._text + this.children.map(child => child?.textContent || '').join(' '); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get value() { return this._value; }
  set value(value) { const text = String(value); this._value = this.tagName === 'select' && !this.children.some(option => option.value === text) ? '' : text; }
  addEventListener(name, callback) { this.events[name] = callback; }
  scrollIntoView() {}
}
const descendants = (node, predicate) => [...(predicate(node) ? [node] : []), ...node.children.flatMap(child => descendants(child, predicate))];
function harness({ portableMode = false, saved = null } = {}) {
  const nodes = new Map(), fields = new Map(), storage = new Map(); let rendered = 0, fetched = 0, handler;
  for (const [key, value] of Object.entries(DEFAULT_PROFILE)) { const field = new Element('input'); field.value = value; if (typeof value === 'boolean') { field.type = 'checkbox'; field.checked = value; } fields.set(key, field); }
  const template = new Element('select'); fields.set('templateId', template); nodes.set('templateId', template);
  const form = new Element('form'); form.elements = { namedItem: name => fields.get(name) }; nodes.set('profile-form', form);
  const state = { profile: null, match: null, templates: TEMPLATES, explanation: null, sessionToken: null, health: null, matchController: null };
  if (saved) storage.set('proto-strategy-session-v1', JSON.stringify(saved));
  const $ = id => { if (!nodes.has(id)) nodes.set(id, new Element()); return nodes.get(id); };
  const node = (tag, cls, text) => { const e = new Element(tag, text ?? ''); e.className = cls || ''; return e; };
  const context = vm.createContext({
    state, $, portableMode, portableReports: [], TEMPLATES, createMatch, validateProfile, createShortPlan, structuredClone, JSON, Date, Number, String, Object, Array,
    signature: profile => JSON.stringify(Object.keys(profile).sort().map(key => [key, profile[key]])),
    FormData: class { get(key) { return fields.get(key)?.value ?? ''; } has(key) { return fields.get(key)?.checked === true; } },
    sessionStorage: { setItem: (key, value) => storage.set(key, value), getItem: key => storage.get(key) || null, removeItem: key => storage.delete(key) },
    node, append: (parent, ...children) => { parent.append(...children); return parent; },
    button: (label, cls, callback) => { const e = node('button', cls, label); e.events.click = callback; return e; },
    more: (label, key, content) => { const e = node('details', '', label); e.key = key; e.append(content); return e; },
    list: values => { const e = node('ul'); for (const value of values) e.append(node('li', '', value)); return e; },
    date: value => value, renderPortfolio: () => { rendered++; }, setTab: () => {}, refreshHealth: () => {}, submitProfile: () => {},
    AbortController, DOMException, setTimeout, clearTimeout,
    fetch: async (...args) => { fetched++; return handler(...args); },
    usd: { format: value => '$' + value },
  });
  const names = ['savedExplanation', 'rememberStrategy', 'restoreStrategy', 'populateTemplateOptions', 'readProfile', 'renderAIExplanation', 'renderModeBanner', 'request'];
  vm.runInContext(`${names.map(extract).join('\n')}\nglobalThis.ui = {${names.join(',')}};`, context);
  return { state, ui: context.ui, $, fields, storage, setHandler: callback => { handler = callback; }, get rendered() { return rendered; }, get fetched() { return fetched; } };
}
const answer = { status: 'ready', summary: 'Your reserve and diversified core fit a measured start.', why: ['Keeps a reserve.'], risks: ['Stocks can fall.'], nextSteps: ['Read the original inputs.'], model: 'test-model', generatedAt: '2026-10-04T06:00:00Z' };
function savedFor(profile, selectedTemplate = 'balanced', method = 'deepseek') { return { token: 'test-private-session', profile, templateId: selectedTemplate, selection: { method, selectedTemplateId: selectedTemplate }, explanation: answer }; }

test('the AI summary is visible outside disclosure controls and precedes stock selection in the plan', () => {
  const h = harness(); h.state.match = createMatch(DEFAULT_PROFILE); h.state.explanation = answer;
  const card = h.ui.renderAIExplanation();
  assert.equal(card.hidden, false); assert(card.children.some(child => child.tagName === 'p' && child.textContent === answer.summary));
  assert(descendants(card, child => child.tagName === 'details').every(child => !child.textContent.includes(answer.summary)));
  assert.match(card.textContent, /Fresh DeepSeek answer/); assert.match(card.textContent, /Checkbox changes do not update this answer/);
  const portfolio = extract('renderPortfolio'); assert(portfolio.indexOf('area.append(renderAIExplanation())') < portfolio.indexOf('createWatchlist('));
  assert.doesNotMatch(portfolio, /more\([^\n]*renderAIExplanation/);
});
test('remembered AI text is bounded display data without extra response payload fields', () => {
  const h = harness(); h.state.profile = { ...DEFAULT_PROFILE }; h.state.match = createMatch(DEFAULT_PROFILE); h.state.sessionToken = 'test-private-session';
  h.state.explanation = { ...answer, summary: 'x'.repeat(2000), why: ['y'.repeat(800), 7, ...Array(9).fill('reason')], model: 'm'.repeat(150), internalCredential: 'test-only-never-copy' };
  h.ui.rememberStrategy(); const saved = JSON.parse(h.storage.get('proto-strategy-session-v1'));
  assert.equal(saved.explanation.summary.length, 1600); assert.equal(saved.explanation.why.length, 5); assert.equal(saved.explanation.why[0].length, 600); assert.equal(saved.explanation.model.length, 100);
  assert.equal(saved.matchId, h.state.match.id); assert.equal(saved.templateVersion, h.state.match.template.version);
  assert.equal(saved.explanation.internalCredential, undefined); assert.equal(h.ui.savedExplanation({ status: 'loading', summary: 'Wait' }), null);
});
test('manual template selection is populated before restoration and preserves the questionnaire', () => {
  const profile = { ...DEFAULT_PROFILE, templateId: 'defensive' }; const h = harness({ saved: savedFor(profile, 'defensive', 'rules') });
  assert.equal(h.fields.get('templateId').options.length, 0); h.ui.restoreStrategy();
  assert.equal(h.fields.get('templateId').value, 'defensive'); assert.equal(h.ui.readProfile().templateId, 'defensive');
  assert.equal(h.state.profile.templateId, 'defensive'); assert.equal(h.state.match.template.id, 'defensive'); assert.equal(h.state.sessionToken, 'test-private-session'); assert.equal(h.rendered, 1);
  assert.equal(h.state.explanation.summary, answer.summary); assert.equal(h.state.explanation.restored, true); assert.match(h.ui.renderAIExplanation().textContent, /Saved DeepSeek answer/);
});
test('automatic DeepSeek template choice is restored without making it a manual questionnaire request', () => {
  const h = harness({ saved: savedFor({ ...DEFAULT_PROFILE }, 'defensive') }); h.ui.restoreStrategy();
  assert.equal(h.state.match.template.id, 'defensive'); assert.equal(h.state.match.selection.method, 'deepseek'); assert.equal(h.state.match.selection.selectedTemplateId, 'defensive');
  assert.equal(h.fields.get('templateId').value, ''); assert.equal(h.ui.readProfile().templateId, undefined); assert.equal(h.state.profile.templateId, undefined);
  h.ui.rememberStrategy(); const second = harness({ saved: JSON.parse(h.storage.get('proto-strategy-session-v1')) }); second.ui.restoreStrategy();
  assert.equal(second.state.match.selection.method, 'deepseek'); assert.equal(second.state.explanation.summary, answer.summary);
});
test('older saved sessions without AI text restore honestly, without an invented answer', () => {
  const stored = savedFor({ ...DEFAULT_PROFILE }); delete stored.explanation;
  const h = harness({ saved: stored }); h.ui.restoreStrategy(); assert.equal(h.state.explanation.status, 'unavailable'); assert.match(h.state.explanation.summary, /no saved AI explanation/);
  assert.match(h.ui.renderAIExplanation().textContent, /AI answer unavailable/);
});
test('matching plan stamps retain the saved AI answer while changed match or template stamps invalidate it', () => {
  const current = createMatch({ ...DEFAULT_PROFILE, templateId: 'balanced' });
  const saved = { ...savedFor({ ...DEFAULT_PROFILE }), matchId: current.id, templateVersion: current.template.version };
  const same = harness({ saved }); same.ui.restoreStrategy();
  assert.equal(same.state.explanation.status, 'ready'); assert.equal(same.state.explanation.summary, answer.summary);
  for (const change of [{ matchId: 'different-maintained-match' }, { templateVersion: 'older-template-version' }]) {
    const changed = harness({ saved: { ...saved, ...change } }); changed.ui.restoreStrategy();
    assert.equal(changed.state.explanation.status, 'unavailable'); assert.match(changed.state.explanation.summary, /maintained plan changed/);
    assert.equal(changed.state.explanation.restored, true); assert.equal(changed.state.match.id, current.id);
    assert.equal(changed.state.profile.budget, DEFAULT_PROFILE.budget); assert(!changed.ui.renderAIExplanation().textContent.includes(answer.summary));
  }
});
test('legacy sessions without plan stamps retain the existing compatible-cache behavior', () => {
  const saved = savedFor({ ...DEFAULT_PROFILE }); assert.equal(saved.matchId, undefined); assert.equal(saved.templateVersion, undefined);
  const h = harness({ saved }); h.ui.restoreStrategy();
  assert.equal(h.state.explanation.status, 'ready'); assert.equal(h.state.explanation.summary, answer.summary); assert.equal(h.state.explanation.restored, true);
});
test('portable mode labels its limits, never restores live state and cannot issue paid research calls', async () => {
  const h = harness({ portableMode: true, saved: savedFor({ ...DEFAULT_PROFILE }) }); h.ui.restoreStrategy(); assert.equal(h.rendered, 0); assert.equal(h.state.sessionToken, null);
  h.ui.renderModeBanner(); const banner = h.$('mode-banner'); assert.match(banner.textContent, /Offline backup/); assert.match(banner.textContent, /offline selections are not transferred/);
  const links = descendants(banner, child => child.tagName === 'a'); assert.equal(links[0].href, 'http://127.0.0.1:8787/'); assert.equal(links[0].rel, 'noopener noreferrer');
  await assert.rejects(() => h.ui.request('/api/research', { method: 'POST', body: {} }), /portable demo/); assert.equal(h.fetched, 0);
});
test('live mode shows AI/report entry and distinguishes unavailable server state', () => {
  const h = harness(); h.ui.renderModeBanner(); assert.match(h.$('mode-banner').textContent, /connection needs attention/);
  h.state.health = { deepseekConfigured: true }; h.ui.renderModeBanner(); assert.match(h.$('mode-banner').textContent, /Connected app/); assert.match(h.$('mode-banner').textContent, /Open Research for the prepared report/);
  assert.equal(descendants(h.$('mode-banner'), child => child.tagName === 'button')[0].textContent, 'Check connection');
});
test('HTTP JSON error status and retry guidance survive the request wrapper', async () => {
  const h = harness(); h.setHandler(async () => ({ ok: false, status: 404, headers: { get: () => null }, json: async () => ({ error: 'Private report not found' }) }));
  await assert.rejects(() => h.ui.request('/api/research/missing'), error => error.status === 404 && error.message === 'Private report not found');
  h.setHandler(async () => ({ ok: false, status: 429, headers: { get: key => key === 'retry-after' ? '121' : null }, json: async () => ({ error: 'Request limit reached' }) }));
  await assert.rejects(() => h.ui.request('/api/match'), error => error.status === 429 && /3 minute/.test(error.message));
});
test('non-JSON HTTP errors preserve status for missing-report recovery instead of becoming generic retries', async () => {
  const h = harness();
  for (const status of [404, 503]) {
    h.setHandler(async () => ({ ok: false, status, json: async () => { throw new SyntaxError('HTML response instead of JSON'); } }));
    await assert.rejects(() => h.ui.request('/api/research/missing'), error => error.status === status && /unreadable response/.test(error.message));
  }
});
