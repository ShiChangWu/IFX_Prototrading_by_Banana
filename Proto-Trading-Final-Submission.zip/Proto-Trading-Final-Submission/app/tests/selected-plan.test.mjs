import test from 'node:test';
import assert from 'node:assert/strict';
import { selectedPlan } from '../shared/selected-plan.mjs';
const match={profile:{budget:10000},allocations:[{ticker:'VTI',weight:60},{ticker:'SGOV',weight:30},{ticker:'CASH',weight:10}]};
test('checkbox selection preserves only matching targets and returns removed money to cash',()=>{
  const p=selectedPlan(match,{tickers:['SGOV','NVDA'],assets:[]});
  assert.deepEqual(p.allocations.map(a=>[a.ticker,a.amount]),[['SGOV',3000],['NVDA',0],['CASH',7000]]);
  assert.equal(p.allocations.reduce((s,a)=>s+a.amount,0),10000);
  assert.equal(p.stress.assumptions.some(a=>a.ticker==='VTI'),false);
  assert.equal(match.allocations.length,3);
});
test('custom searched symbols can be assigned money with explicit conservative shock assumptions',()=>{
  const p=selectedPlan(match,{tickers:['XYZ'],assets:[{ticker:'XYZ',name:'Example Co'}]},{XYZ:25});
  assert.equal(p.allocations[0].name,'Example Co');assert.equal(p.allocations[0].amount,2500);
  assert.equal(p.stress.lossAmount,1250);assert.equal(p.stress.lossPct,12.5);
  assert.equal(p.stress.assumptions[0].returnPct,-50);
});
test('clearing selection gives all cash, invalid amounts cannot invent an over-budget plan',()=>{
  assert.deepEqual(selectedPlan(match,{tickers:[]}).allocations,[{ticker:'CASH',name:'Unallocated cash',weight:100,amount:10000}]);
  assert.throws(()=>selectedPlan(match,{tickers:['AMD','NVDA']},{AMD:60,NVDA:60}),/100%/);
  assert.throws(()=>selectedPlan(match,{tickers:['AMD']},{AMD:NaN}),/between/);
  assert.throws(()=>selectedPlan(match,{tickers:['AMD']},{AMD:-10}),/between/);
  assert.throws(()=>selectedPlan(match,{tickers:['<script>']}),/valid stocks/);
});
