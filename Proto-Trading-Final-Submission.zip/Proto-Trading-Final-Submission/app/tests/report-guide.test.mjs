import test from 'node:test';
import assert from 'node:assert/strict';
import { returnScenario, guideAllocations } from '../shared/report-guide.mjs';
import { createReportCompanion } from '../public/report-guide.js';

class Element {
  constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.style={};this.events={};this._text='';this.value='';}
  append(...children){this.children.push(...children);}
  set textContent(value){this._text=String(value);this.children=[];}
  get textContent(){return this._text+this.children.map(child=>child.textContent).join(' ');}
  setAttribute(key,value){this.attributes[key]=String(value);}
  addEventListener(name,fn){this.events[name]=fn;}
}
const document={createElement:tag=>new Element(tag),createElementNS:(_ns,tag)=>new Element(tag)};
const all=(root,predicate)=>[...(predicate(root)?[root]:[]),...root.children.flatMap(child=>all(child,predicate))];

test('return scenarios compound the explicit annual assumption across time without calling it a forecast',()=>{
  assert.equal(returnScenario(10000,10,12).endingValue,11000);
  assert.equal(returnScenario(10000,10,24).endingValue,12100);
  assert.equal(returnScenario(10000,-10,12).change,-1000);
  assert.equal(returnScenario(10000,0,1).endingValue,10000);
  assert.equal(returnScenario(10000,21,6).endingValue,11000);
  assert.equal(returnScenario(10000,10,12).forecast,false);
  for(const input of [[0,10,12],[10000,-100,12],[10000,101,12],[10000,NaN,12],[10000,10,5]])assert.throws(()=>returnScenario(...input));
});
test('allocation pictures reject invalid, duplicated and non-totalled holdings',()=>{
  const rows=[{ticker:'NVDA',weight:5},{ticker:'CASH',weight:95}];
  assert.equal(guideAllocations(rows).length,2);
  for(const bad of [[{ticker:'NVDA',weight:120}],[{ticker:'CASH',weight:99}],[{ticker:'NVDA',weight:50},{ticker:'NVDA',weight:50}],[{ticker:'<script>',weight:100}]])assert.deepEqual(guideAllocations(bad),[]);
});
test('pictured report connects amount, editable time assumptions and dated reported company numbers',()=>{
  const options={allocations:[{ticker:'NVDA',weight:5},{ticker:'SPCX',weight:5},{ticker:'CASH',weight:90}],budget:10000};
  const before=structuredClone(options),report=createReportCompanion(document,options);
  assert.equal(all(report,x=>x.tagName==='svg').length,1);
  assert.match(report.textContent,/NVDA · 5.0% · \$500/);
  assert.match(report.textContent,/GAAP loss per share/);assert.match(report.textContent,/-\$0.09/);
  assert.match(report.textContent,/no validated forecast/);
  const input=all(report,x=>x.tagName==='input')[0],select=all(report,x=>x.tagName==='select')[0];
  input.value='10';select.value='24';input.events.input();
  assert.match(report.textContent,/\$12,100/);
  select.value='12';select.events.change();assert.match(report.textContent,/\$11,000/);
  input.value='';input.events.input();assert.match(report.textContent,/Enter an annual assumption/);
  assert.deepEqual(options,before);
  for(const a of all(report,x=>x.tagName==='a')){assert(a.href.startsWith('https:'));assert.equal(a.rel,'noopener noreferrer');}
});
test('old reports cannot show later financial releases or derive EPS from an ETF',()=>{
  const old=createReportCompanion(document,{tickers:['AMD','NVDA','VTI'],factAsOf:'2026-01-01'});
  assert.equal(all(old,x=>x.className==='company-fact-card').length,0);
  assert.match(old.textContent,/No matching company earnings snapshot/);
  const stale=createReportCompanion(document,{tickers:['NVDA'],factAsOf:'2026-10-10'});
  assert.match(stale.textContent,/has not been refreshed after 2026-10-04/);
});
test('uploaded-document guide never infers allocations, returns or company ownership from prose',()=>{
  const report=createReportCompanion(document,{imported:true,tickers:['NVDA']});
  assert.match(report.textContent,/No allocation or return forecast has been inferred/);
  assert.match(report.textContent,/A ticker mention does not confirm a holding/);
  assert.equal(all(report,x=>x.tagName==='input').length,0);
  assert.equal(all(report,x=>x.className==='reading-step').length,3);
});
