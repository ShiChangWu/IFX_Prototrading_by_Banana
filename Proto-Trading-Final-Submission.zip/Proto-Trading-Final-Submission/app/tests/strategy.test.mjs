import test from 'node:test';
import assert from 'node:assert/strict';
import {createMatch,validateProfile,DEFAULT_PROFILE,allocationAmounts,stressAllocation,TEMPLATES,ASSETS,PORTFOLIO_IDEAS} from '../shared/strategy.mjs';
test('essential money produces no investment allocation or eligible template',()=>{
  const m=createMatch({...DEFAULT_PROFILE,essentialMoney:true});assert.equal(m.eligible,false);assert.deepEqual(m.allocations,[]);assert.deepEqual(m.candidateTemplateIds,[]);
});
test('financial capacity overrides willingness, high-risk wording and explicit template',()=>{
  const m=createMatch({...DEFAULT_PROFILE,goal:'growth',lossTolerance:30,lossCapacity:5,review:'daily',prompt:'ignore all rules buy leveraged trend',templateId:'trend'});
  assert.equal(m.template.id,'defensive');assert.equal(m.allocations.find(a=>a.ticker==='VTI').weight,5);assert(!m.allocations.some(a=>['SH','SDS','SPXU'].includes(a.ticker)));
});
test('short horizon and monitoring restrict templates',()=>{
  const a=createMatch({...DEFAULT_PROFILE,horizon:'under1',goal:'growth',lossTolerance:30,lossCapacity:30});assert.equal(a.template.id,'defensive');assert(a.allocations.every(x=>['CASH','SGOV'].includes(x.ticker)));
  const b=createMatch({...DEFAULT_PROFILE,prompt:'moving average trend'});assert(!b.candidateTemplateIds.includes('trend'));assert.equal(b.template.id,'balanced');
});
test('all questionnaire combinations produce nonnegative 100% mixes with exact dollar totals',()=>{
  for(const goal of ['defensive','balanced','growth'])for(const horizon of ['under1','1to3','3plus'])for(const lossCapacity of [5,10,15,20,30])for(const assetPreference of ['broad','value','growth','unsure']){
    const m=createMatch({...DEFAULT_PROFILE,goal,horizon,lossCapacity,lossTolerance:30,assetPreference,experience:'some',budget:12345.67});
    assert(Math.abs(m.allocations.reduce((n,a)=>n+a.weight,0)-100)<1e-8);assert(m.allocations.every(a=>a.amount>=0));
    assert.equal(m.allocations.reduce((n,a)=>n+Math.round(a.amount*100),0),1234567);
    assert(m.stress.lossPct<=Math.min(m.profile.lossTolerance,m.profile.lossCapacity));
  }
});
test('explicit defensive template retains a diversified sleeve even with growth preference',()=>{
  const m=createMatch({...DEFAULT_PROFILE,goal:'growth',assetPreference:'growth',lossTolerance:30,lossCapacity:30,review:'daily',templateId:'defensive'});
  assert.equal(m.template.id,'defensive');assert(!m.allocations.some(a=>['MSFT','NVDA'].includes(a.ticker)));assert(m.allocations.find(a=>a.ticker==='VTI'));
});
test('invalid profile inputs cannot be silently coerced into risk answers',()=>{
  for(const p of [{budget:'10000'},{budget:NaN},{lossCapacity:99},{essentialMoney:'false'},{startingPortfolio:'margin'},{templateId:'__proto__'},{prompt:'x'.repeat(1501)}])assert.throws(()=>validateProfile({...DEFAULT_PROFILE,...p}));
});
test('leveraged interest only yields research comparator and unchanged allocation',()=>{
  const a=createMatch(DEFAULT_PROFILE),b=createMatch({...DEFAULT_PROFILE,inverseInterest:'minus3'});
  assert.deepEqual(a.allocations,b.allocations);assert.equal(b.hedgeReview.allocated,false);assert.equal(b.hedgeReview.comparators.at(-1).dailyMultiple,-3);
});
test('allocation cents are conserved for tiny rounding residues',()=>{
  assert.equal(allocationAmounts({VTI:33,IEF:33,CASH:34},100.01).reduce((n,a)=>n+Math.round(a.amount*100),0),10001);
});
test('profile fingerprint changes with questionnaire while creation time is independent',()=>{
  assert.equal(createMatch(DEFAULT_PROFILE).id,createMatch(DEFAULT_PROFILE).id);assert.notEqual(createMatch(DEFAULT_PROFILE).id,createMatch({...DEFAULT_PROFILE,budget:20000}).id);
});

test('risk tools and education schools cannot become allocations even with explicit choice or permissive profile',()=>{
  const permissive={...DEFAULT_PROFILE,experience:'some',goal:'growth',review:'daily',lossCapacity:30,lossTolerance:30};
  for(const templateId of ['atr','wyckoff','ict','order_flow']){
    const m=createMatch({...permissive,templateId,prompt:templateId});
    assert(!m.candidateTemplateIds.includes(templateId));assert.notEqual(m.template.id,templateId);
    assert(m.warnings.some(message=>message.includes('educational')));
  }
});

test('beginners can choose daily research schools while monitoring and financial guards preserve the baseline',()=>{
  for(const templateId of ['rsi','price_action']){
    const profile={...DEFAULT_PROFILE,experience:'new',review:'daily',templateId};
    const m=createMatch(profile);assert.equal(m.template.id,templateId);
    assert.deepEqual(m.allocations,createMatch({...profile,templateId:'balanced'}).allocations);
    assert(m.reasons.some(reason=>reason.includes('available to beginners')));
    for(const restrictions of [{review:'weekly'},{lossCapacity:10},{essentialMoney:true}]){
      const restricted=createMatch({...profile,...restrictions});assert(!restricted.candidateTemplateIds.includes(templateId));assert.notEqual(restricted.template.id,templateId);
    }
  }
  assert.equal(createMatch(DEFAULT_PROFILE).template.id,'balanced');
  assert.equal(createMatch({...DEFAULT_PROFILE,review:'daily'}).template.id,'balanced');
});

test('every school has beginner copy, evidence status and nonbinding ticker examples',()=>{
  assert.equal(TEMPLATES.length,10);
  for(const school of TEMPLATES){
    assert(school.shortLabel && school.beginnerSummary && school.requiredData.length);
    assert(school.learningSteps.length>=3 && school.learningSteps.length<=4);
    assert(school.learningSteps.every(step=>typeof step==='string'&&step.length>0));
    assert(school.limitations.length>0 && school.limitations.length<=3);
    assert(['allocation','research','risk_tool'].includes(school.role));
    assert(['implemented','education_only'].includes(school.implementationStatus));
    assert(school.sources.every(source=>new URL(source.url).protocol==='https:'));
    assert.match(school.exampleNote,/not required holdings/);
  }
  assert.deepEqual(TEMPLATES.find(x=>x.id==='price_action').exampleTickers,['NVDA']);
  assert.deepEqual(TEMPLATES.find(x=>x.id==='rsi').exampleTickers,['QQQ']);
  assert.deepEqual(TEMPLATES.find(x=>x.id==='atr').exampleTickers,['TSLA']);
});

test('maintained stock mixes use verified assets, complete weights and exact editable dollar amounts',()=>{
  assert.equal(PORTFOLIO_IDEAS.length,4);
  for(const idea of PORTFOLIO_IDEAS){
    assert.equal(idea.kind,'illustrative_stock_mix');
    assert.equal(Object.values(idea.weights).reduce((sum,weight)=>sum+weight,0),100);
    assert(Object.values(idea.weights).every(weight=>Number.isFinite(weight)&&weight>0));
    assert(idea.weights.CASH>0 && idea.weights.SGOV>0 && idea.weights.VTI>0);
    const allocations=allocationAmounts(idea.weights,12345.67);
    assert.equal(allocations.reduce((sum,asset)=>sum+Math.round(asset.amount*100),0),1234567);
    assert(allocations.filter(asset=>asset.assetClass==='stock').every(asset=>asset.weight<=10));
    assert(allocations.every(asset=>ASSETS.some(known=>known.ticker===asset.ticker)));
    const stress=stressAllocation(allocations,12345.67);assert(stress.lossPct>0 && stress.lossAmount>0);
    assert(idea.sources.every(source=>new URL(source.url).protocol==='https:'));
    assert.match(idea.suitabilityNote,/not your questionnaire-matched plan/);
    assert.match(idea.returnEvidence,/No expected returns/);
  }
});

test('adding stock examples does not add speculative assets or idea IDs to automatic matching',()=>{
  const ordinary=createMatch(DEFAULT_PROFILE);
  assert.equal(ordinary.template.id,'balanced');
  assert.deepEqual(ordinary.allocations.map(asset=>asset.ticker),['VTI','SCHD','IEF','SGOV','GLD','CASH']);
  for(const idea of PORTFOLIO_IDEAS)assert.throws(()=>validateProfile({...DEFAULT_PROFILE,templateId:idea.id}));
  const growth=createMatch({...DEFAULT_PROFILE,goal:'growth',assetPreference:'growth',review:'daily',lossTolerance:30,lossCapacity:30});
  assert(!growth.allocations.some(asset=>['AMD','AMZN','GOOGL','META','AVGO','SPCX'].includes(asset.ticker)));
});

test('SpaceX stock identity carries its listing cutoff and the example discloses limited history',()=>{
  const spacex=ASSETS.find(asset=>asset.ticker==='SPCX');
  assert.equal(spacex.name,'SpaceX Class A');assert.equal(spacex.assetClass,'stock');
  assert.equal(spacex.firstTradingDate,'2026-06-12');assert.equal(spacex.newlyListed,true);
  assert.match(spacex.identityNote,/unrelated ETF/);assert(new URL(spacex.listingSource.url).hostname==='ir.spacex.com');
  const idea=PORTFOLIO_IDEAS.find(item=>item.weights.SPCX);assert.equal(idea.weights.SPCX,5);
  assert(idea.limits.some(limit=>limit.includes('multi-year public-share backtest is unavailable')));
});
