"""Synthetic histories below are calculation fixtures, never market reports."""
from datetime import date, datetime, timedelta, timezone
import io
import json
import math
import statistics
import unittest
from unittest.mock import patch

from worker.quick_market import SnapshotError, create_snapshots, main, snapshot_from_history, validate_request


def weekday_history(count=120, end=date(2026, 10, 2)):
    days, cursor = [], end
    while len(days) < count:
        if cursor.weekday() < 5:
            days.append(cursor)
        cursor -= timedelta(days=1)
    days.reverse()
    return list(zip(days, [100.0 + i for i in range(count)]))


class QuickMarketTests(unittest.TestCase):
    def test_rolling_values_and_population_bollinger_are_exact(self):
        history = weekday_history()
        row = snapshot_from_history("VTI", history, date(2026, 10, 2), "2026-10-04T00:00:00+00:00", "USD")
        closes = [p for _, p in history]
        self.assertEqual(row["latestClose"], 219)
        self.assertEqual(row["previousClose"], 218)
        self.assertEqual(row["sma20"], statistics.fmean(closes[-20:]))
        self.assertEqual(row["sma100"], statistics.fmean(closes[-100:]))
        self.assertEqual(row["previousSma20"], statistics.fmean(closes[-21:-1]))
        self.assertEqual(row["previousSma100"], statistics.fmean(closes[-101:-1]))
        self.assertAlmostEqual(row["bollingerUpper"], statistics.fmean(closes[-20:]) + 2 * statistics.pstdev(closes[-20:]), places=7)
        self.assertAlmostEqual(row["bollingerLower"], statistics.fmean(closes[-20:]) - 2 * statistics.pstdev(closes[-20:]), places=7)
        self.assertTrue(row["currencyVerified"])

    def test_uncompleted_and_future_rows_never_change_snapshot(self):
        history = weekday_history()
        reference = snapshot_from_history("VTI", history, "2026-10-02", "time", "USD")
        rows = history + [(date(2026, 10, 5), 999999), (date(2026, 10, 6), math.nan)]
        actual = snapshot_from_history("VTI", rows, "2026-10-02", "time", "USD")
        self.assertEqual(actual, reference)

    def test_cutoff_uses_new_york_time_before_close_not_host_date(self):
        observed = []

        def fetch(ticker, start, end):
            observed.append(end)
            return {"history": weekday_history(), "currency": "USD"}

        # Monday Oct 5 15:00 New York is already Monday night in Hong Kong.
        result = create_snapshots({"tickers": ["VTI"]}, now=datetime(2026, 10, 5, 19, 0, tzinfo=timezone.utc), history_fetcher=fetch)
        self.assertEqual(result["cutoffDate"], "2026-10-02")
        self.assertEqual(observed, [date(2026, 10, 3)])
        self.assertEqual(result["snapshots"][0]["priceDate"], "2026-10-02")

    def test_weekend_and_holiday_gap_remain_explicit(self):
        result = create_snapshots({"tickers": ["VTI"]}, now=datetime(2026, 10, 4, 12, 0, tzinfo=timezone.utc),
            history_fetcher=lambda *_: {"history": weekday_history(end=date(2026, 10, 1)), "currency": "USD"})
        self.assertEqual(result["cutoffDate"], "2026-10-02")
        self.assertEqual(result["snapshots"][0]["priceDate"], "2026-10-01")
        self.assertEqual(result["snapshots"][0]["ageCalendarDays"], 1)

    def test_missing_currency_not_falsely_confirmed_as_usd(self):
        row = snapshot_from_history("VTI", weekday_history(), "2026-10-02", "time")
        self.assertIsNone(row["currency"])
        self.assertFalse(row["currencyVerified"])
        self.assertTrue(row["warnings"])
        with self.assertRaisesRegex(SnapshotError, "USD"):
            snapshot_from_history("VTI", weekday_history(), "2026-10-02", "time", "CAD")

    def test_per_ticker_failure_does_not_discard_other_prices(self):
        def fetch(ticker, *_):
            if ticker == "IEF":
                raise RuntimeError("sensitive_provider_details_not_for_output")
            return {"history": weekday_history(), "currency": "USD"}
        result = create_snapshots({"tickers": ["VTI", "IEF"]}, now=datetime(2026, 10, 4, tzinfo=timezone.utc), history_fetcher=fetch)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["snapshots"][0]["status"], "complete")
        self.assertEqual(result["snapshots"][1]["status"], "error")
        self.assertNotIn("sensitive_provider", json.dumps(result))

    def test_insufficient_and_invalid_rows_are_not_filled(self):
        with self.assertRaises(SnapshotError) as caught:
            snapshot_from_history("VTI", weekday_history(100), "2026-10-02", "time", "USD")
        self.assertEqual(caught.exception.code, "insufficient_history")
        rows = weekday_history()
        rows[-1] = (rows[-1][0], math.nan)
        with self.assertRaises(SnapshotError):
            snapshot_from_history("VTI", rows, "2026-10-02", "time", "USD")

    def test_validation_limits_and_literal_tickers(self):
        self.assertEqual(validate_request({"tickers": ["vti", "VTI", "IEF"]})[0], ["VTI", "IEF"])
        for payload in ({"tickers": []}, {"tickers": ["A"] * 6}, {"tickers": ["../secret"]}, {"tickers": ["CASH"]}, {"tickers": ["VTI"], "analysisDate": "2026-02-31"}):
            with self.assertRaises(SnapshotError):
                validate_request(payload)

    def test_cli_emits_one_strict_json_object_on_invalid_request_without_network(self):
        output = io.StringIO()
        with patch("sys.stdin", io.StringIO('{"tickers":[]}')), patch("sys.stdout", output), patch("worker.quick_market._make_history_fetcher") as fetch:
            self.assertEqual(main(), 0)
        fetch.assert_not_called()
        result = json.loads(output.getvalue())
        self.assertEqual(result["error"]["code"], "invalid_tickers")


if __name__ == "__main__":
    unittest.main()
