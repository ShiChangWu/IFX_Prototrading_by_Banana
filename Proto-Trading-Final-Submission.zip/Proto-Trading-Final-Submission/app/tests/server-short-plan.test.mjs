import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { EventEmitter } from 'node:events';
import { PassThrough, Writable } from 'node:stream';
import { configuration } from '../server/config.mjs';
import { LocalStore } from '../server/store.mjs';
import { createApi } from '../server/api.mjs';
import { DEFAULT_PROFILE } from '../shared/strategy.mjs';
import { createLocalSnapshotProvider, createSnapshotCache, validateSnapshot, stopOwnedMarketProcess } from '../server/market-snapshot.mjs';

const FIXED_NOW = Date.parse('2026-10-04T04:00:00Z');
function fixture(tickers, overrides = {}) {
  return { status: 'complete', cutoffDate: '2026-10-02', fetchedAt: new Date(FIXED_NOW).toISOString(), snapshots: tickers.map(ticker => ({ ticker, status: 'complete', priceDate: '2026-10-02', latestClose: 102, previousClose: 101, sma20: 101, sma100: 100, previousSma20: 99, previousSma100: 100, bollingerUpper: 110, bollingerLower: 90, observations: 200, currency: 'USD', currencyVerified: true, adjusted: true, source: 'TEST MOCK data — never public research', fetchedAt: new Date(FIXED_NOW).toISOString(), ...overrides })), warnings: ['TEST MOCK: no real data call made.'] };
}
async function harness(t, { provider = async ({ tickers }) => fixture(tickers), config: overrides = {} } = {}) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-short-plan-test-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const config = { ...configuration({}), storeFile: path.join(dir, 'state.json'), ...overrides };
  const store = new LocalStore(config.storeFile);
  let clock = FIXED_NOW, paidCalls = 0;
  const api = createApi({ config, store, snapshotProvider: provider, now: () => clock, fetchImpl: async () => { paidCalls++; throw new Error('Short plans must not call an LLM'); } });
  const call = async (route, body, sessionToken) => {
    const response = await api(new Request('http://localhost:8787' + route, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(sessionToken ? { 'X-Session-Token': sessionToken } : {}) }, body: JSON.stringify(body) }), { clientIp: '127.0.0.1' });
    return { status: response.status, data: await response.json() };
  };
  const match = async (profile = DEFAULT_PROFILE, sessionToken) => {
    const result = await call('/api/match', { profile }, sessionToken);
    assert.equal(result.status, 200); return result.data;
  };
  return { config, store, call, match, tick: ms => { clock += ms; }, paidCalls: () => paidCalls };
}

test('short plan requires header authentication and the exact confirmed current profile', async t => {
  let providerCalls = 0;
  const h = await harness(t, { provider: async ({ tickers }) => { providerCalls++; return fixture(tickers); } });
  const matched = await h.match();
  const body = { profile: DEFAULT_PROFILE, matchId: matched.match.id };
  assert.equal((await h.call('/api/short-plan', body)).status, 401);
  assert.equal((await h.call('/api/short-plan', { ...body, sessionToken: matched.sessionToken })).status, 401);
  assert.equal((await h.call('/api/short-plan', { ...body, matchId: 'wrong' }, matched.sessionToken)).status, 409);
  assert.equal((await h.call('/api/short-plan', { ...body, profile: { ...DEFAULT_PROFILE, budget: 9000 } }, matched.sessionToken)).status, 409);
  assert.equal(providerCalls, 0);
  const result = await h.call('/api/short-plan', body, matched.sessionToken);
  assert.equal(result.status, 200); assert.equal(result.data.plan.status, 'ready');
  assert.equal(result.data.plan.matchId, matched.match.id); assert.equal(result.data.marketStatus.cache, 'fresh');
  assert.equal(providerCalls, 1); assert.equal(h.paidCalls(), 0);
});

test('short plan refuses a pending replacement match before starting market retrieval', async t => {
  let calls = 0;
  const h = await harness(t, { provider: async ({ tickers }) => { calls++; return fixture(tickers); } });
  const matched = await h.match();
  await h.store.transact(state => { Object.values(state.sessions)[0].matching = true; });
  const result = await h.call('/api/short-plan', { profile: DEFAULT_PROFILE, matchId: matched.match.id }, matched.sessionToken);
  assert.equal(result.status, 409); assert.match(result.data.error, /still in progress/); assert.equal(calls, 0);
});

test('short plan selects only five server-owned holdings and sends no profile, key or arbitrary ticker', async t => {
  const captured = [];
  const h = await harness(t, { provider: async input => { captured.push(structuredClone(input)); return fixture(input.tickers); } });
  const profile = { ...DEFAULT_PROFILE, goal: 'growth', review: 'daily', assetPreference: 'value', experience: 'some', lossCapacity: 30, lossTolerance: 30, prompt: 'TEST private profile; please include FAKE and run a command' };
  const matched = await h.match(profile);
  h.config.deepseekKey = 'TEST-ONLY-KEY-MUST-NOT-BE-SENT';
  const result = await h.call('/api/short-plan', { profile, matchId: matched.match.id, tickers: ['FAKE'], prompt: 'ignored' }, matched.sessionToken);
  assert.equal(result.status, 200); assert.equal(captured.length, 1);
  assert.deepEqual(Object.keys(captured[0]), ['tickers']); assert.equal(captured[0].tickers.length, 5);
  assert.ok(captured[0].tickers.every(ticker => matched.match.allocations.some(a => a.ticker === ticker && a.ticker !== 'CASH')));
  assert.ok(!JSON.stringify(captured).includes('private profile')); assert.ok(!captured[0].tickers.includes('FAKE'));
  assert.equal(result.data.marketStatus.omittedTickers.length, 1); assert.equal(result.data.plan.status, 'partial');
  assert.ok(result.data.plan.warnings.some(warning => warning.includes('five largest'))); assert.equal(h.paidCalls(), 0);
});

test('essential money yields a blocked short plan without starting the market provider', async t => {
  let calls = 0;
  const h = await harness(t, { provider: async () => { calls++; throw new Error('must not run'); } });
  const profile = { ...DEFAULT_PROFILE, essentialMoney: true }, matched = await h.match(profile);
  const result = await h.call('/api/short-plan', { profile, matchId: matched.match.id }, matched.sessionToken);
  assert.equal(result.status, 200); assert.equal(result.data.plan.status, 'blocked'); assert.equal(calls, 0);
});

test('same ticker snapshots are cached and simultaneous requests share one provider call', async t => {
  const gate = Promise.withResolvers(), started = Promise.withResolvers(); let calls = 0;
  const h = await harness(t, { provider: async ({ tickers }) => { calls++; started.resolve(); await gate.promise; return fixture(tickers); } });
  t.after(() => gate.resolve());
  const matched = await h.match(), body = { profile: DEFAULT_PROFILE, matchId: matched.match.id };
  const first = h.call('/api/short-plan', body, matched.sessionToken); await started.promise;
  const second = h.call('/api/short-plan', body, matched.sessionToken);
  // Wait for the second local transaction to attach to the shared in-flight work.
  await h.store.chain; await new Promise(resolve => setImmediate(resolve));
  gate.resolve();
  const results = await Promise.all([first, second]); assert.ok(results.every(result => result.status === 200)); assert.equal(calls, 1);
  assert.ok(results.some(result => ['shared', 'cached'].includes(result.data.marketStatus.cache)));
  assert.equal((await h.call('/api/short-plan', body, matched.sessionToken)).data.marketStatus.cache, 'cached');
  h.tick(15 * 60000 + 1);
  assert.equal((await h.call('/api/short-plan', body, matched.sessionToken)).data.marketStatus.cache, 'fresh'); assert.equal(calls, 2);
});

test('a changed match during market retrieval rejects its late plan without mutating the new match', async t => {
  const gate = Promise.withResolvers(), started = Promise.withResolvers();
  const h = await harness(t, { provider: async ({ tickers }) => { started.resolve(); await gate.promise; return fixture(tickers); } });
  t.after(() => gate.resolve());
  const matched = await h.match();
  const plan = h.call('/api/short-plan', { profile: DEFAULT_PROFILE, matchId: matched.match.id }, matched.sessionToken); await started.promise;
  const newer = await h.match({ ...DEFAULT_PROFILE, budget: 12000 }, matched.sessionToken);
  gate.resolve();
  assert.equal((await plan).status, 409);
  assert.equal((await h.call('/api/short-plan', { profile: { ...DEFAULT_PROFILE, budget: 12000 }, matchId: newer.match.id }, matched.sessionToken)).status, 200);
});

test('missing provider, unverified currency and cloud mode remain explicit unavailable plans', async t => {
  const broken = await harness(t, { provider: async () => { throw new Error('TEST private diagnostic'); } });
  const a = await broken.match();
  const failed = await broken.call('/api/short-plan', { profile: DEFAULT_PROFILE, matchId: a.match.id }, a.sessionToken);
  assert.equal(failed.status, 200); assert.equal(failed.data.plan.status, 'unavailable'); assert.ok(!JSON.stringify(failed.data).includes('private diagnostic'));
  const currency = await harness(t, { provider: async ({ tickers }) => fixture(tickers, { currencyVerified: false }) });
  const b = await currency.match();
  assert.equal((await currency.call('/api/short-plan', { profile: DEFAULT_PROFILE, matchId: b.match.id }, b.sessionToken)).data.plan.status, 'unavailable');
  let calls = 0;
  const cloud = await harness(t, { config: { mode: 'cloud' }, provider: async () => { calls++; throw new Error('Cloud must never launch local Python'); } });
  const c = await cloud.match();
  const result = await cloud.call('/api/short-plan', { profile: DEFAULT_PROFILE, matchId: c.match.id }, c.sessionToken);
  assert.equal(result.status, 200); assert.equal(result.data.plan.status, 'unavailable'); assert.equal(result.data.marketStatus.cache, 'unavailable'); assert.equal(calls, 0);
  assert.match(result.data.marketStatus.warnings.join(' '), /market data is not connected on this site/);
});

test('short-plan quota is independent from AI matching and enforced before a provider call', async t => {
  let calls = 0;
  const h = await harness(t, { config: { shortPlanRequestsPerHour: 1 }, provider: async ({ tickers }) => { calls++; return fixture(tickers); } });
  const matched = await h.match(), body = { profile: DEFAULT_PROFILE, matchId: matched.match.id };
  assert.equal((await h.call('/api/short-plan', body, matched.sessionToken)).status, 200);
  assert.equal((await h.call('/api/short-plan', body, matched.sessionToken)).status, 429); assert.equal(calls, 1);
});

test('snapshot boundary rejects fabricated future rows and never upgrades unknown currency', () => {
  const unknown = validateSnapshot(fixture(['VTI'], { currencyVerified: undefined }), ['VTI'], FIXED_NOW);
  assert.equal(unknown.snapshots[0].currencyVerified, false);
  const future = validateSnapshot(fixture(['VTI'], { priceDate: '2027-01-01' }), ['VTI'], FIXED_NOW);
  assert.equal(future.status, 'unavailable'); assert.equal(future.snapshots[0].status, 'error');
  const duplicate = fixture(['VTI']); duplicate.snapshots.push(duplicate.snapshots[0]);
  assert.equal(validateSnapshot(duplicate, ['VTI'], FIXED_NOW).status, 'unavailable');
});

function richDailyFixture() {
  return fixture(['NVDA'], { rsi14: 51, previousRsi14: 49, atr14: 2, previousAtr14: 1.9, latestOpen: 101.5, latestHigh: 103, latestLow: 100.5, latestVolume: 1000,
    bars: [{ date: '2026-10-01', open: 100, high: 102, low: 99, close: 101, volume: 900 }, { date: '2026-10-02', open: 101.5, high: 103, low: 100.5, close: 102, volume: 1000 }],
    candle: { body: .5, range: 2.5, upperWick: 1, lowerWick: 1, closePosition: .6 },
    currencySource: 'TEST currency metadata', priceBasis: 'TEST adjusted daily OHLC', adjustmentMethod: 'TEST same-series adjustment', preferredSource: 'EastMoney via AKShare',
    fallbackReason: 'TEST AKShare adjustment unverified; separate verified adjusted series used.',
    providerReference: { status: 'reference_only', source: 'EastMoney via AKShare', providerSymbol: '105.NVDA', latestClose: 102, priceDate: '2026-10-02', adjustmentVerified: false, eligibleForSignals: false } });
}

test('daily evidence retains separate source provenance and validated OHLCV without upgrading AKShare references', () => {
  const input = richDailyFixture();
  input.snapshots[0].providerReference.eligibleForSignals = true; // Untrusted source cannot grant itself permission.
  const validated = validateSnapshot(input, ['NVDA'], FIXED_NOW);
  assert.equal(validated.status, 'complete');
  const row = validated.snapshots[0];
  assert.equal(row.rsi14, 51); assert.equal(row.atr14, 2); assert.equal(row.bars.length, 2);
  assert.equal(row.latestHigh, 103); assert.equal(row.candle.closePosition, .6);
  assert.match(row.priceBasis, /adjusted daily/); assert.match(row.fallbackReason, /AKShare adjustment unverified/);
  assert.equal(row.providerReference.adjustmentVerified, false); assert.equal(row.providerReference.eligibleForSignals, false);
  assert.equal(row.source, 'TEST MOCK data — never public research');
});

test('daily evidence rejects impossible candles, reordered/mismatched series, invalid RSI and unverified adjustment', () => {
  const edits = [row => { row.bars[1].low = 104; }, row => { row.bars.reverse(); }, row => { row.bars[1].close = 102.5; }, row => { row.rsi14 = 101; }, row => { row.atr14 = -1; }, row => { row.bars[1].date = '2026-02-31'; }, row => { row.adjustmentVerified = false; }];
  for (const edit of edits) {
    const input = richDailyFixture(); edit(input.snapshots[0]);
    assert.equal(validateSnapshot(input, ['NVDA'], FIXED_NOW).status, 'unavailable');
  }
});

test('daily evidence never adds OHLCV or ATR when a legacy provider returned only closes', () => {
  const row = validateSnapshot(fixture(['VTI']), ['VTI'], FIXED_NOW).snapshots[0];
  assert.equal(row.atr14, undefined); assert.equal(row.bars, undefined); assert.equal(row.ohlcvAvailable, false);
});

function fakeChild(onInput) {
  const child = new EventEmitter(); child.stdout = new PassThrough(); child.stderr = new PassThrough(); child.killed = false;
  child.kill = () => { child.killed = true; return true; };
  child.stdin = new Writable({ write(chunk, _encoding, callback) { child.input = (child.input || '') + chunk.toString(); callback(); }, final(callback) { queueMicrotask(() => onInput(child)); callback(); } });
  return child;
}

test('Python adapter uses a fixed command with ticker-only stdin and stripped secret environment', async () => {
  let launch;
  const provider = createLocalSnapshotProvider({ appDir: path.resolve('TEST-ONLY-APP'), env: { PATH: 'TEST-PATH', DEEPSEEK_API_KEY: 'TEST-SECRET', WORKER_SECRET: 'TEST-WORKER-SECRET', SUPABASE_SERVICE_ROLE_KEY: 'TEST-DB-SECRET' }, spawnImpl: (command, args, options) => {
    const child = fakeChild(instance => { instance.stdout.write(JSON.stringify(fixture(['VTI']))); instance.emit('close', 0); }); launch = { command, args, options, child }; return child;
  } });
  const result = await provider({ tickers: ['VTI'] });
  assert.equal(result.status, 'complete'); assert.deepEqual(launch.args, ['-m', 'worker.quick_market']);
  assert.equal(launch.options.shell, false); assert.equal(launch.options.windowsHide, true);
  assert.deepEqual(JSON.parse(launch.child.input), { tickers: ['VTI'] });
  assert.equal(launch.options.env.PATH, 'TEST-PATH'); assert.equal(launch.options.env.DEEPSEEK_API_KEY, undefined); assert.equal(launch.options.env.WORKER_SECRET, undefined); assert.equal(launch.options.env.SUPABASE_SERVICE_ROLE_KEY, undefined);
  assert.ok(!JSON.stringify(launch.options).includes('TEST-SECRET'));
});

test('Python adapter bounds output/time and reports missing executable without leaking diagnostics', async () => {
  let timed;
  const timeout = createLocalSnapshotProvider({ timeoutMs: 5, spawnImpl: () => { timed = fakeChild(() => {}); return timed; } });
  assert.equal((await timeout({ tickers: ['VTI'] })).snapshots[0].error.code, 'MARKET_TIMEOUT'); assert.equal(timed.killed, true);
  let excessive;
  const output = createLocalSnapshotProvider({ maxOutputBytes: 10, spawnImpl: () => { excessive = fakeChild(instance => instance.stdout.write('x'.repeat(20))); return excessive; } });
  assert.equal((await output({ tickers: ['VTI'] })).snapshots[0].error.code, 'MARKET_OUTPUT_LIMIT'); assert.equal(excessive.killed, true);
  const missing = createLocalSnapshotProvider({ spawnImpl: () => { const child = fakeChild(() => child.emit('error', Object.assign(new Error('TEST private filesystem detail'), { code: 'ENOENT' }))); return child; } });
  const result = await missing({ tickers: ['VTI'] }); assert.equal(result.snapshots[0].error.code, 'MARKET_ADAPTER_MISSING'); assert.ok(!JSON.stringify(result).includes('filesystem detail'));
});

test('failed snapshot cache retries after its short cooldown', async () => {
  let time = FIXED_NOW, calls = 0;
  const get = createSnapshotCache({ now: () => time, provider: async () => { calls++; throw new Error('TEST data failure'); } });
  assert.equal((await get(['VTI'])).snapshot.status, 'unavailable');
  assert.equal((await get(['VTI'])).cache, 'cached'); assert.equal(calls, 1);
  time += 30001; assert.equal((await get(['VTI'])).cache, 'fresh'); assert.equal(calls, 2);
});

test('in-flight market requests coalesce independently of caller ordering and protect cached objects', async () => {
  const gate = Promise.withResolvers(); let calls = 0;
  const get = createSnapshotCache({ now: () => FIXED_NOW, provider: async () => { calls++; return gate.promise; } });
  const first = get(['VTI', 'IEF']), second = get(['IEF', 'VTI']);
  assert.equal(calls, 1);
  gate.resolve(fixture(['IEF', 'VTI']));
  const [a, b] = await Promise.all([first, second]);
  assert.equal(a.cache, 'fresh'); assert.equal(b.cache, 'shared');
  a.snapshot.snapshots[0].latestClose = 999999;
  assert.equal((await get(['VTI', 'IEF'])).snapshot.snapshots[0].latestClose, 102);
});

test('Windows timeout termination targets only its owned running child tree, without a shell', async () => {
  const owned = fakeChild(() => {}); owned.pid = 12345; owned.exitCode = null; owned.signalCode = null;
  let launch;
  const result = await stopOwnedMarketProcess(owned, { platform: 'win32', env: { SystemRoot: 'C:\\Windows', DEEPSEEK_API_KEY: 'TEST-SECRET' }, spawnImpl: (command, args, options) => {
    launch = { command, args, options }; const helper = new EventEmitter(); helper.kill = () => true; queueMicrotask(() => helper.emit('close', 0)); return helper;
  } });
  assert.equal(result, true); assert.equal(launch.command, 'C:\\Windows\\System32\\taskkill.exe');
  assert.deepEqual(launch.args, ['/PID', '12345', '/T', '/F']); assert.equal(launch.options.shell, false); assert.equal(launch.options.windowsHide, true);
  assert.equal(launch.options.env.DEEPSEEK_API_KEY, undefined); assert.ok(!launch.args.includes('worker.main'));
  owned.exitCode = 0;
  assert.equal(await stopOwnedMarketProcess(owned, { platform: 'win32', spawnImpl: () => assert.fail('An exited PID must never be targeted') }), false);
});
