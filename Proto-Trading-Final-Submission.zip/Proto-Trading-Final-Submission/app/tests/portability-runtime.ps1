$ErrorActionPreference = 'Stop'
$AppRoot = Split-Path -Parent $PSScriptRoot
$PriorNode = $env:PROTO_NODE
$PriorPython = $env:PROTO_PYTHON
try {
  $env:PROTO_NODE = Join-Path $AppRoot 'missing-test-only-node.exe'
  $RejectedNode = $false
  try { . (Join-Path $AppRoot 'scripts/runtime.ps1') } catch { $RejectedNode = $_.Exception.Message -match 'PROTO_NODE.*installed Node' }
  if (-not $RejectedNode) { throw 'Missing explicit Node runtime did not produce an actionable error.' }
  $env:PROTO_NODE = $PriorNode
  . (Join-Path $AppRoot 'scripts/runtime.ps1')
  if (-not $NodeRuntime) { throw 'Installed Node selection failed.' }
  . (Join-Path $AppRoot 'scripts/python-runtime.ps1')
  $env:PROTO_PYTHON = Join-Path $AppRoot 'missing-test-only-python.exe'
  $RejectedPython = $false
  try { Find-ProtoSetupPython | Out-Null } catch { $RejectedPython = $_.Exception.Message -match 'PROTO_PYTHON.*Python 3' }
  if (-not $RejectedPython) { throw 'Missing explicit Python runtime did not produce an actionable error.' }
  $ExistingPython = Join-Path $AppRoot '.venv/Scripts/python.exe'
  if (Test-Path -LiteralPath $ExistingPython) {
    $Version = Get-ProtoPythonVersion $ExistingPython
    if (-not $Version -or $Version.minor -notin @(11,12,13)) { throw 'Read-only Python executable version check failed.' }
  }
  Write-Output 'PASS: runtime selection and actionable missing-runtime errors; no setup or service changes.'
} finally {
  $env:PROTO_NODE = $PriorNode
  $env:PROTO_PYTHON = $PriorPython
}
