import test from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { normalizeStockQuery, validateStockCatalog, createStockSearch, createLocalStockCatalogProvider, parseNasdaqDirectory, createNasdaqStockCatalogProvider } from '../server/stock-search.mjs';

const stamp = '2026-10-04T08:00:00Z';
const now = () => Date.parse(stamp);
const catalog = (extra = {}) => ({ status: 'complete', version: 1, scope: 'all_us', fetchedAt: stamp, rows: [{ ticker: 'TSLA', name: 'Tesla', providerSymbol: '105.TSLA' }, { ticker: 'JPM', name: 'JPMorgan Chase', providerSymbol: '106.JPM' }, { ticker: 'NFLX', name: 'Netflix', providerSymbol: '105.NFLX' }], ...extra });

test('queries are bounded and catalogs reject fabricated identifiers, quotes and reused SPCX', () => {
  assert.equal(normalizeStockQuery('  Tesla  '), 'Tesla');
  for (const q of ['x'.repeat(61), 'A\nB', 'A\u202eB', null]) assert.throws(() => normalizeStockQuery(q));
  assert.deepEqual(validateStockCatalog(catalog(), now()).rows, catalog().rows);
  for (const rows of [[{ ticker: 'TSLA', name: 'Tesla', providerSymbol: '106.FAKE' }], [{ ticker: 'TSLA', name: 'Tesla', providerSymbol: 'FAKE' }], [{ ticker: 'SPCX', name: 'SPAC ETF', providerSymbol: '105.SPCX' }], [catalog().rows[0], catalog().rows[0]]]) assert.throws(() => validateStockCatalog(catalog({ rows }), now()));
  assert.throws(() => validateStockCatalog(catalog({ fetchedAt: '2027-10-04' }), now()));
});

test('search extends beyond starter list, coalesces refreshes, ranks exact symbols and never claims a quote', async () => {
  let calls = 0;
  const search = createStockSearch({ now, cacheFile: null, provider: async () => { calls++; await new Promise(resolve => setTimeout(resolve, 3)); return catalog(); } });
  const [a, b] = await Promise.all([search('TSLA'), search('JPMorgan')]);
  assert.equal(calls, 1);
  assert.equal(a.results[0].ticker, 'TSLA');
  assert.equal(a.results[0].providerSymbol, '105.TSLA');
  assert.equal(a.results[0].currencyVerified, false);
  assert.equal(a.results[0].assetClass, 'unclassified');
  assert.equal(b.results[0].ticker, 'JPM');
  assert.equal((await search('NFLX')).results[0].ticker, 'NFLX');
  assert.equal(calls, 1);
  assert.equal((await search('not-a-listing')).results.length, 0);
  await assert.rejects(() => search('TSLA', { limit: 99 }));
});

test('provider failure returns honest maintained fallback and uses retry cooldown', async () => {
  let clock = now(), calls = 0;
  const search = createStockSearch({ now: () => clock, cacheFile: null, failureTtlMs: 1000, provider: async () => { calls++; throw new Error('private provider detail'); }, fallbackProvider: async () => ({ status: 'unavailable' }) });
  const result = await search('NVDA');
  assert.equal(result.status, 'fallback');
  assert.equal(result.results[0].identityStatus, 'maintained');
  assert.match(result.warnings[0], /unavailable/);
  assert.equal((await search('TSLA')).results.length, 0);
  assert.equal(calls, 1);
  clock += 1001;
  await search('NVDA');
  assert.equal(calls, 2);
  const remote = createStockSearch({ mode: 'netlify', cacheFile: null, provider: () => assert.fail('no local subprocess on hosted API') });
  assert.equal((await remote('NVDA')).status, 'fallback');
});

test('disk cache persists, stale full catalog is retained, and invalid old cache is not trusted', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-stock-search-test-'));
  const cacheFile = path.join(directory, 'catalog.json');
  try {
    const search = createStockSearch({ now, cacheFile, provider: async () => catalog() });
    await search('TSLA');
    const cached = createStockSearch({ now, cacheFile, provider: () => assert.fail('fresh disk cache should be used') });
    assert.equal((await cached('Tesla')).results[0].ticker, 'TSLA');
    const later = () => now() + 2 * 86400000;
    const stale = createStockSearch({ now: later, cacheFile, provider: async () => catalog({ scope: 'well_known_us', fetchedAt: new Date(later()).toISOString() }) });
    assert.equal((await stale('TSLA')).status, 'stale');
    assert.equal((await stale('TSLA')).scope, 'all_us');
    await fs.writeFile(cacheFile, JSON.stringify(catalog({ fetchedAt: '2001-01-01' })));
    const old = createStockSearch({ now, cacheFile, provider: async () => ({ status: 'unavailable' }), fallbackProvider: async () => ({ status: 'unavailable' }) });
    assert.equal((await old('TSLA')).status, 'fallback');
  } finally {
    assert.equal(path.dirname(path.resolve(directory)), path.resolve(os.tmpdir()));
    assert.ok(path.basename(directory).startsWith('proto-stock-search-test-'));
    await fs.rm(directory, { recursive: true, force: true });
  }
});

function fakeChild(response) {
  const child = new EventEmitter();
  child.stdout = new PassThrough(); child.stderr = new PassThrough();
  child.kill = () => { child.signalCode = 'SIGKILL'; return true; };
  queueMicrotask(() => response(child));
  return child;
}

test('catalog subprocess is isolated from secrets, bounded and shell-free', async () => {
  const provider = createLocalStockCatalogProvider({ env: { PATH: 'path', DEEPSEEK_API_KEY: 'TEST-secret', SMTP_PASSWORD: 'TEST-mail' }, spawnImpl: (command, args, options) => {
    assert.deepEqual(args, ['-m', 'worker.stock_search']);
    assert.equal(options.shell, false);
    assert.equal(options.windowsHide, true);
    assert.equal(options.env.DEEPSEEK_API_KEY, undefined);
    assert.equal(options.env.SMTP_PASSWORD, undefined);
    return fakeChild(child => { child.stdout.write(JSON.stringify(catalog())); child.exitCode = 0; child.emit('close', 0); });
  } });
  assert.equal((await provider()).rows[0].ticker, 'TSLA');
  let stalled;
  const timeout = createLocalStockCatalogProvider({ timeoutMs: 3, spawnImpl: () => { stalled = fakeChild(() => {}); return stalled; } });
  assert.equal((await timeout()).status, 'unavailable');
  assert.equal(stalled.signalCode, 'SIGKILL');
  const oversized = createLocalStockCatalogProvider({ maxOutputBytes: 3, spawnImpl: () => fakeChild(child => child.stdout.write('1234')) });
  assert.equal((await oversized()).status, 'unavailable');
});

const directoryHeader = 'Nasdaq Traded|Symbol|Security Name|Listing Exchange|Market Category|ETF|Round Lot Size|Test Issue|Financial Status|CQS Symbol|NASDAQ Symbol|NextShares';
const directoryText = (extra = []) => [directoryHeader,
  'Y|TSLA|Tesla, Inc. - Common Stock|Q|Q|N|100|N|N||TSLA|N',
  'Y|JPM|JP Morgan Chase & Co. Common Stock|N| |N|100|N||JPM|JPM|N',
  'Y|DIA|SPDR Dow Jones Industrial Average ETF Trust|P| |Y|100|N||DIA|DIA|N',
  'Y|SPCX|Space Exploration Technologies Corp. - Class A Common Stock|Q|Q|N|100|N|N||SPCX|N',
  ...extra, 'File Creation Time: 1002202621:33|||||'].join('\n');

test('Nasdaq parser keeps exact active security names and ETF flag, excludes tests/inactive/old issuer', () => {
  const parsed = parseNasdaqDirectory(directoryText([
    'Y|ZZZZ|Test Security|Q|Q|N|100|Y|N||ZZZZ|N',
    'N|DEAD|Inactive Security|Q|Q|N|100|N|N||DEAD|N',
    'Y|STOP|Suspended Security|Q|Q|N|100|N|S||STOP|N',
    'Y|SPCX|The SPAC ETF|Q|Q|Y|100|N|N||SPCX|N',
    'Y|TWO|Company One|Q|Q|N|100|N|N||TWO|N',
    'Y|TWO|Company Two|Q|Q|N|100|N|N||TWO|N',
  ]), now());
  assert.equal(parsed.scope, 'nasdaq_traded_us');
  assert.equal(parsed.directoryDate, '2026-10-02');
  assert.deepEqual(parsed.rows.map(row => row.ticker), ['TSLA', 'JPM', 'DIA', 'SPCX']);
  const dia = parsed.rows.find(row => row.ticker === 'DIA');
  assert.equal(dia.etf, true);
  assert.equal(dia.providerSymbol, 'DIA');
  assert.equal(dia.listingExchange, 'P');
  assert.equal(parsed.rows.find(row => row.ticker === 'SPCX').name, 'Space Exploration Technologies Corp. - Class A Common Stock');
  assert.throws(() => parseNasdaqDirectory(directoryText().replace('1002202621:33', '1002202721:33'), now()));
  assert.throws(() => parseNasdaqDirectory(directoryText().replace(directoryHeader, 'Fake|Format'), now()));
  assert.throws(() => parseNasdaqDirectory(directoryText().replace(/File Creation Time:.*/, ''), now()));
});

test('Nasdaq fallback fetch is bounded, excludes redirects/credentials, and is cached after AKShare failure', async () => {
  let sourceCalls = 0, requests = 0;
  const fetchImpl = async (url, options) => {
    requests++;
    assert.equal(url, 'https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqtraded.txt');
    assert.equal(options.redirect, 'error');
    assert.equal(options.credentials, 'omit');
    assert.deepEqual(options.headers, { Accept: 'text/plain' });
    return new Response(directoryText(), { headers: { 'content-type': 'text/plain' } });
  };
  const search = createStockSearch({ now, cacheFile: null, fetchImpl, provider: async () => { sourceCalls++; return { status: 'unavailable' }; } });
  const result = await search('TSLA');
  assert.equal(result.results[0].name, 'Tesla, Inc. - Common Stock');
  assert.equal(result.source.name, 'Nasdaq Trader directory; AKShare unavailable');
  assert.equal(result.directoryDate, '2026-10-02');
  assert.equal(result.results[0].currencyVerified, false);
  assert.equal((await search('DIA')).results[0].assetClass, 'etf');
  assert.equal(requests, 1);
  assert.equal(sourceCalls, 1);
  const noFallback = createStockSearch({ now, cacheFile: null, provider: async () => catalog(), fetchImpl: () => assert.fail('AKShare remains preferred') });
  assert.match((await noFallback('TSLA')).source.name, /AKShare/);
  const stalled = createNasdaqStockCatalogProvider({ timeoutMs: 3, now, fetchImpl: () => new Promise(() => {}) });
  assert.equal((await stalled()).status, 'unavailable');
  const oversized = createNasdaqStockCatalogProvider({ maxOutputBytes: 5, now, fetchImpl: async () => new Response(directoryText()) });
  assert.equal((await oversized()).status, 'unavailable');
});

test('Nasdaq directory provenance persists across restart without mislabeling as AKShare', async () => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-stock-search-test-'));
  const cacheFile = path.join(directory, 'catalog.json');
  try {
    const search = createStockSearch({ now, cacheFile, provider: async () => ({ status: 'unavailable' }), fetchImpl: async () => new Response(directoryText()) });
    await search('TSLA');
    const cached = createStockSearch({ now, cacheFile, provider: () => assert.fail('fresh persisted directory is used'), fetchImpl: () => assert.fail('no duplicate directory fetch') });
    const result = await cached('JPM');
    assert.equal(result.results[0].ticker, 'JPM');
    assert.equal(result.source.name, 'Nasdaq Trader directory; AKShare unavailable');
    assert.equal(result.scope, 'nasdaq_traded_us');
    assert.equal(result.directoryDate, '2026-10-02');
  } finally {
    assert.equal(path.dirname(path.resolve(directory)), path.resolve(os.tmpdir()));
    assert.ok(path.basename(directory).startsWith('proto-stock-search-test-'));
    await fs.rm(directory, { recursive: true, force: true });
  }
});
