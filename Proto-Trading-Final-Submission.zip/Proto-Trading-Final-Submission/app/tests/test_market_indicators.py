"""Synthetic fixtures prove calculations and provenance; not market performance."""
from datetime import date, timedelta
import json
import math
import unittest

import pandas as pd

from worker.akshare_reference import ReferenceProbe, reference_from_frame
from worker.market_indicators import rsi_pair, wilder
from worker.quick_market import SnapshotError, snapshot_from_history
from tests.test_quick_market import weekday_history


def bars(count=140):
    return [dict(date=day, open=close - .5, high=close + 1, low=close - 1,
                 close=close, volume=1000 + index) for index, (day, close) in enumerate(weekday_history(count))]


class IndicatorTests(unittest.TestCase):
    def test_wilder_initial_average_and_recursive_updates(self):
        self.assertEqual(wilder([1, 2, 3, 6], 3), [2, 10 / 3])
        self.assertEqual(rsi_pair(list(range(1, 121))), (100, 100))
        self.assertEqual(rsi_pair(list(range(120, 0, -1))), (0, 0))
        self.assertEqual(rsi_pair([100] * 120), (50, 50))

    def test_atr_uses_gaps_and_wilder_smoothing(self):
        rows = bars()
        row = snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')
        self.assertEqual(row['atr14'], 2)
        self.assertEqual(row['previousAtr14'], 2)
        # Latest bar gaps upwards: TR=11, not merely the high-low range=2.
        for key in ('open', 'high', 'low', 'close'):
            rows[-1][key] += 9
        actual = snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')
        self.assertAlmostEqual(actual['atr14'], (13 * 2 + 11) / 14, places=7)
        self.assertEqual(actual['previousAtr14'], 2)

    def test_support_excludes_current_and_bars_are_bounded_and_consistent(self):
        rows = bars()
        rows[-1]['low'] = 1
        result = snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')
        self.assertEqual(result['prior20Low'], rows[-21]['low'])
        self.assertEqual(result['previousPrior20High'], rows[-3]['high'])
        self.assertEqual(len(result['bars']), 120)
        self.assertEqual(result['bars'][-1]['date'], result['priceDate'])
        self.assertEqual(result['latestClose'], result['bars'][-1]['close'])
        self.assertTrue(result['ohlcvAvailable'])
        self.assertGreater(result['candle']['lowerWick'], 100)
        encoded = json.dumps({'snapshots': [result] * 5}, allow_nan=False).encode()
        self.assertLess(len(encoded), 131072)

    def test_close_only_never_fabricates_atr_candles_or_volume(self):
        result = snapshot_from_history('QQQ', weekday_history(), '2026-10-02', 'time', 'USD')
        self.assertFalse(result['ohlcvAvailable'])
        self.assertNotIn('atr14', result)
        self.assertNotIn('bars', result)
        self.assertEqual(result['rsi14'], 100)

    def test_missing_nonfinite_or_inconsistent_ohlcv_is_not_filled(self):
        for key, value in [('open', None), ('high', math.inf), ('volume', -1), ('low', 9999), ('close', math.nan)]:
            with self.subTest(key=key):
                rows = bars()
                rows[-1][key] = value
                with self.assertRaises(SnapshotError):
                    snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')
        rows = bars()
        rows[-1] = (rows[-1]['date'], rows[-1]['close'])
        with self.assertRaisesRegex(SnapshotError, 'partial OHLCV'):
            snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')

    def test_future_bad_candle_excluded_before_any_indicator_calculation(self):
        rows = bars()
        reference = snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD')
        rows.append(dict(date=date(2026, 10, 5), close=math.nan))
        self.assertEqual(snapshot_from_history('NVDA', rows, '2026-10-02', 'time', 'USD'), reference)

    def test_akshare_no_fuzzy_symbols_or_guessed_market_codes(self):
        with self.assertRaises(ValueError):
            reference_from_frame('NVDA', '105.NVDA', pd.DataFrame(), date(2026, 10, 2))
        with self.assertRaises(ValueError):
            reference_from_frame('../secret', '../secret', pd.DataFrame(), date(2026, 10, 2))

    def test_akshare_unadjusted_reference_never_upgraded_to_adjusted_or_confirmed_currency(self):
        frame = pd.DataFrame({'date': ['2026-10-02'], 'open': [100.0], 'high': [103.0], 'low': [99.0], 'close': [102.0], 'volume': [1000.0]})
        result = reference_from_frame('NVDA', 'NVDA', frame, date(2026, 10, 2))
        self.assertFalse(result['adjustmentVerified'])
        self.assertFalse(result['eligibleForSignals'])
        self.assertEqual(result['status'], 'reference_only')
        self.assertIsNone(result['currency'])
        self.assertFalse(result['currencyVerified'])
        self.assertIn('no provider series are mixed', result['fallbackReason'])

    def test_akshare_failure_is_bounded_without_exposing_exception_details(self):
        class Broken:
            def stock_us_daily(self, **kwargs):
                raise RuntimeError('private diagnostics')
        results = ReferenceProbe(['NVDA'], date(2025, 9, 1), date(2026, 10, 2), ak_module=Broken()).collect()
        self.assertEqual(results['NVDA']['errorCode'], 'history_unavailable')
        self.assertNotIn('private diagnostics', json.dumps(results))


if __name__ == '__main__':
    unittest.main()
