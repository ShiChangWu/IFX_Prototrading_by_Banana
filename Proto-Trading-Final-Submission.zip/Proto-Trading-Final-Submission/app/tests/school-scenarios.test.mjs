import test from 'node:test';
import assert from 'node:assert/strict';
import { buildSchoolScenario, getSchoolReference } from '../shared/school-scenarios.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { SCHOOL_TESTS, schoolIndicators, schoolEntryCondition } from '../shared/school-backtest.mjs';

const reference=getSchoolReference('NVDA',SCHOOL_PRICES);
const guide=(schoolId,values={},extra={})=>buildSchoolScenario({schoolId,ticker:'NVDA',reference,values,budget:10000,...extra});
const text=result=>result.cards.map(card=>`${card.title} ${card.text}`).join(' ');
test('saved indicator context is verified and calculated only from the selected stock history',()=>{
  assert.equal(reference.ticker,'NVDA');assert.equal(reference.date,'2026-10-02');
  const rows=SCHOOL_PRICES.stocks.NVDA.bars.map(row=>({open:row[1],high:row[2],low:row[3],close:row[4],volume:row[5]}));
  assert.deepEqual(reference.indicator,schoolIndicators(rows).at(-1));
  assert.notEqual(getSchoolReference('AMD',SCHOOL_PRICES).close,reference.close);
  assert.equal(getSchoolReference('UNKNOWN',SCHOOL_PRICES),null);
  for(const invalid of [{currencyVerified:false},{adjusted:false},{currency:'HKD'},{bars:[['2026-13-03',10,11,9,10,100]]},{bars:[['2026-10-03',10,9,11,10,100]]}]){
    assert.equal(getSchoolReference('NVDA',{...SCHOOL_PRICES,stocks:{NVDA:{...SCHOOL_PRICES.stocks.NVDA,...invalid}}}),null);
  }
});
test('all ten approaches have different presentations and never use generic rise/fall triggers',()=>{
  const titles=new Set();
  for(const id of Object.keys(SCHOOL_TESTS)){
    const result=guide(id);titles.add(result.heading);
    assert(!result.fields.some(field=>['fall','rise'].includes(field.key)));
    assert.equal(result.error,'');assert.match(result.position,/nothing to sell now/);
  }
  assert.equal(titles.size,10);
});
test('allocation examples depend on scheduled weight reviews, not stock price movements',()=>{
  assert.match(text(guide('defensive')),/restoring the reserve/);
  assert.match(text(guide('defensive',{targetWeight:'10',assumedWeight:'7'})),/does not automatically justify/);
  assert.match(text(guide('balanced',{targetWeight:'25',assumedWeight:'32'})),/\$700\.00/);
  assert.match(text(guide('balanced',{targetWeight:'25',assumedWeight:'28'})),/no rebalance review is triggered/);
  assert.match(text(guide('balanced',{event:'early'})),/daily rise or fall does not trigger/);
  assert.match(guide('balanced',{targetWeight:'101'}).error,/0% to 100%/);
});
test('moving-average, RSI and bands rules require their own evidence',()=>{
  assert.match(text(guide('trend',{event:'up'})),/was at or below.*now crosses above/);
  assert.match(text(guide('trend',{event:'down'})),/falls to or below/);
  assert.match(text(guide('trend',{event:'none'})),/does not open a new position/);
  assert.match(text(guide('rsi',{priorRsi:'28',nextRsi:'34'})),/crosses back above 30/);
  assert.match(text(guide('rsi',{priorRsi:'28',nextRsi:'29'})),/Wait for a recovery/);
  assert.match(text(guide('rsi',{priorRsi:'50',nextRsi:'72'})),/70 exit threshold/);
  assert.match(guide('rsi',{priorRsi:'',nextRsi:'30'}).error,/Enter RSI/);
  assert.match(text(guide('mean_reversion',{event:'recovery'})),/updated lower band/);
  assert.match(text(guide('mean_reversion',{event:'mean'})),/updated 20-day mean/);
  assert.match(text(guide('mean_reversion',{event:'below'})),/not the recovery/);
});
test('ATR and setup risk arithmetic is explicit, with no automatic trade or invented entry signal',()=>{
  const result=guide('atr',{highestClose:'100',atr:'4',nextClose:'93'});
  assert.match(text(result),/trailing level: \$94\.00/);assert.match(text(result),/review selling held NVDA/);
  assert.match(guide('atr').intro,/no buy signal/);
  assert.match(text(guide('atr',{highestClose:'100',atr:'4',nextClose:'110'})),/trailing level: \$104\.00/);
  assert.match(text(guide('atr',{highestClose:'100',atr:'4',nextClose:'94'})),/not below it/);
  assert.match(guide('atr',{highestClose:'5',atr:'4',nextClose:'1'}).error,/must exceed/);
  for(const id of ['price_action','wyckoff']){
    const setup=guide(id,{entry:'100',atr:'4'});
    assert.match(text(setup),/at \/ below \$94\.00/);assert.match(text(setup),/at \/ above \$112\.00/);
  }
  assert.match(text(guide('price_action',{event:'none'})),/touch of support alone/);
  assert.match(text(guide('wyckoff',{event:'weak'})),/volume above the preceding 20-day median/);
  assert.match(guide('atr',{}, {reference:null}).error,/No indicator is invented/);
});
test('learning-only schools show the missing evidence instead of trade recommendations',()=>{
  const ict=guide('ict'),flow=guide('order_flow');
  assert.match(text(ict),/No verified ICT entry, exit, backtest or return/);
  assert.match(text(flow),/Tick trades and depth-of-book data are unavailable/);
  assert(ict.fields.every(field=>field.type==='select'));assert(flow.fields.every(field=>field.type==='select'));
  assert.notEqual(text(guide('ict',{event:'sweep'})),text(guide('ict',{event:'gap'})));
  assert.notEqual(text(guide('order_flow',{event:'imbalance'})),text(guide('order_flow',{event:'absorption'})));
});

test('RSI examples apply entry while flat and exit while holding, including a recovery above 70',()=>{
  for(const [prior,next] of [[28,34],[30,30],[30,30.01],[28,75],[50,70],[50,69.99]]){
    const flat=guide('rsi',{priorRsi:String(prior),nextRsi:String(next)});
    const held=guide('rsi',{priorRsi:String(prior),nextRsi:String(next)},{heldQuantity:2});
    const engineEntry=schoolEntryCondition('rsi',[{},{}],[{rsi:prior},{rsi:next}],1);
    assert.equal(flat.cards[0].title==='Recovery: consider an entry review',engineEntry,`Flat ${prior} -> ${next} follows the backtest entry condition`);
    assert.equal(held.cards[0].title==='High RSI: review an exit',next>=70,`Held ${prior} -> ${next} uses the exit threshold`);
    assert.doesNotMatch(text(held),/rule reviews buying/);
  }
  assert.match(text(guide('rsi',{priorRsi:'28',nextRsi:'75'})),/checks entry while flat/);
  for(const values of [{priorRsi:'-0.01'},{nextRsi:'100.01'},{nextRsi:'Infinity'},{nextRsi:' '}])assert.match(guide('rsi',values).error,/0 to 100/);
});

test('a new entry setup never recommends adding another position under a single-position rule',()=>{
  for(const id of ['trend','mean_reversion','price_action','wyckoff']){
    const result=guide(id,{}, {heldQuantity:3});
    assert.equal(result.cards[0].title,'Already holding: no additional entry');
    assert.doesNotMatch(text(result),/review (a purchase|buying|an entry) at the next/);
    assert.match(result.position,/Recorded holding: 3 shares/);
  }
  assert.match(text(guide('price_action')),/inputs are assumptions, not recorded fills/);
  assert.match(guide('rsi',{}, {heldQuantity:Infinity}).position,/No holding recorded/);
  assert.match(text(guide('balanced',{targetWeight:'25',assumedWeight:'32'},{budget:NaN})),/\$700\.00/);
});
