import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateTracking,validateTracking} from '../server/tracking-rules.mjs';
const now=Date.parse('2026-10-05T15:05:30Z');
const quotes={source:'Alpaca',feed:'iex',quotes:{NVDA:{status:'complete',price:100,barTime:'2026-10-05T15:04:00Z'}}};
const bars=Array.from({length:25},(_,i)=>({date:new Date(Date.UTC(2026,8,8+i)).toISOString().slice(0,10),open:100,high:102,low:99,close:101,volume:1000}));
const row={ticker:'NVDA',status:'complete',currency:'USD',currencyVerified:true,adjusted:true,priceDate:'2026-10-02',fetchedAt:'2026-10-05T15:00:00Z',rsi14:31,previousRsi14:29,bars};
const follow={tickers:['NVDA'],schoolId:'rsi',positions:[],conditions:[]};
test('daily RSI recovery uses longer-history evidence, with a separate current minute quote',()=>{
  const signal=evaluateTracking(follow,quotes,{snapshots:[row]},now);
  assert.equal(signal.length,1);assert.equal(signal[0].side,'buy');assert.equal(signal[0].price,100);assert.equal(signal[0].evidenceDate,'2026-10-02');
  assert.deepEqual(evaluateTracking(follow,quotes,{snapshots:[{...row,rsi14:29,previousRsi14:28}]},now),[]);
  assert.deepEqual(evaluateTracking(follow,quotes,{snapshots:[{...row,rsi14:null}]},now),[]);
});
test('daily exit requires actual holdings, valid dates and verified currency',()=>{
  const exit={...row,rsi14:75,previousRsi14:72};
  assert.deepEqual(evaluateTracking(follow,quotes,{snapshots:[exit]},now),[]);
  const owned={...follow,positions:[{ticker:'NVDA',quantity:3,averagePrice:80}]};
  assert.equal(evaluateTracking(owned,quotes,{snapshots:[exit]},now)[0].side,'sell');
  for(const bad of [{currencyVerified:false},{priceDate:'2026-09-25'},{priceDate:'2026-10-06'},{fetchedAt:'2026-10-01T15:00:00Z'}])assert.deepEqual(evaluateTracking(owned,quotes,{snapshots:[{...exit,...bad}]},now),[]);
});
test('allocation schools do not invent timing signals; own price lines are separate',()=>{
  const allocation={...follow,schoolId:'balanced'};
  assert.deepEqual(evaluateTracking(allocation,quotes,{snapshots:[row]},now),[]);
  const result=evaluateTracking({...allocation,conditions:[{ticker:'NVDA',buyBelow:101}]},quotes,{snapshots:[]},now);
  assert.equal(result[0].trigger,'price_buy_below');assert.equal(result[0].side,'buy');
});
test('reminder settings reject duplicated tickers, header injection and contradictory exit levels',()=>{
  const input={tickers:['NVDA'],schoolId:'balanced',email:'owner@example.com',consent:true,enabled:false};
  assert.throws(()=>validateTracking({...input,tickers:['NVDA','NVDA']}));
  assert.throws(()=>validateTracking({...input,email:'a@example.com\r\nBcc:b@example.com'}));
  assert.throws(()=>validateTracking({...input,conditions:[{ticker:'NVDA',sellBelow:120,sellAbove:100}]}));
  assert.equal(validateTracking({...input,conditions:[{ticker:'NVDA',buyBelow:null}]}).conditions[0].buyBelow,null);
});
