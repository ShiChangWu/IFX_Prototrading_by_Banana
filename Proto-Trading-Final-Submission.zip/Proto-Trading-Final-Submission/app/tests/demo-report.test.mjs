import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { initDemoReport } from '../public/demo-report.js';

function harness(view, { dialogSupported = true, dialogFailure = false } = {}) {
  const elements = new Map();
  const document = { body: { style: { overflow: 'auto' } }, defaultView: view, activeElement: null, getElementById: id => elements.get(id) };
  for (const id of ['open-demo-report', 'demo-report-dialog', 'close-demo-report', 'demo-report-frame', 'demo-generated-report', 'demo-report-modal-title', 'demo-report-modal-note', 'demo-report-own-page']) {
    const listeners = new Map(), attributes = new Map();
    const element = {
      id, open: false, style: {}, hidden: false, textContent: '', scrollTop: 0,
      addEventListener(type, action) { listeners.set(type, action); },
      dispatch(type, event = {}) { listeners.get(type)?.(event); },
      focus() { document.activeElement = this; },
      getAttribute(name) { return attributes.get(name) || null; },
      setAttribute(name, value) { attributes.set(name, value); },
      removeAttribute(name) { attributes.delete(name); },
      showModal() { if (dialogFailure) throw new Error('Dialog unavailable'); this.open = true; },
      close() { this.open = false; this.dispatch('close'); },
      getBoundingClientRect() { return { left: 20, top: 20, right: 1000, bottom: 800 }; },
    };
    elements.set(id, element);
  }
  elements.get('open-demo-report').setAttribute('href', 'prepared-report.html');
  elements.get('open-demo-report').setAttribute('aria-haspopup', 'dialog');
  elements.get('demo-report-modal-title').textContent = 'Everyday balance · saved research';
  elements.get('demo-report-modal-note').textContent = '4 Oct 2026, 15:27 HKT';
  if (!dialogSupported) delete elements.get('demo-report-dialog').showModal;
  document.activeElement = elements.get('open-demo-report');
  return { document, get: id => elements.get(id), api: initDemoReport(document) };
}

test('prepared research opens a static report immediately without invoking analysis', async () => {
  const h = harness();
  assert.equal(h.get('demo-report-frame').getAttribute('src'), null);
  h.get('open-demo-report').dispatch('click');
  assert.equal(h.get('demo-report-dialog').open, true);
  assert.equal(h.get('demo-report-frame').getAttribute('src'), 'prepared-report.html');
  assert.equal(h.document.body.style.overflow, 'hidden');
  assert.equal(h.document.activeElement, h.get('close-demo-report'));
  const source = await fs.readFile(new URL('../public/demo-report.js', import.meta.url), 'utf8');
  assert.doesNotMatch(source, /\bfetch\s*\(|\/api\/|startResearch|XMLHttpRequest|WebSocket/);
  h.get('close-demo-report').dispatch('click');
  assert.equal(h.get('demo-report-dialog').open, false);
  assert.equal(h.document.body.style.overflow, 'auto');
  assert.equal(h.document.activeElement, h.get('open-demo-report'));
});

test('generated research opens its actual contents and date without loading the prepared example', () => {
  const h = harness(), generated = h.get('demo-generated-report');
  let rendered = 0;
  const trigger = { focused: false, focus() { this.focused = true; }, getBoundingClientRect() { return { top: 360 }; } };
  assert.equal(h.api.openGenerated({ reportTitle: 'My generated NVDA report', reportNote: '4 Oct 2026, 15:57 HKT · NVDA', trigger, render(target) { assert.equal(target, generated); target.textContent = 'Actual NVDA report body'; rendered++; } }), true);
  assert.equal(h.get('demo-report-dialog').open, true);
  assert.equal(h.get('demo-report-frame').hidden, true);
  assert.equal(h.get('demo-report-frame').getAttribute('src'), null, 'A generated report must not load the static prepared artifact');
  assert.equal(generated.hidden, false);
  assert.equal(generated.textContent, 'Actual NVDA report body');
  assert.equal(h.get('demo-report-modal-title').textContent, 'My generated NVDA report');
  assert.match(h.get('demo-report-modal-note').textContent, /15:57/);
  assert.equal(h.get('demo-report-own-page').hidden, true);
  h.get('demo-report-dialog').dispatch('cancel', { preventDefault() {} });
  assert.equal(trigger.focused, true);
  assert.equal(h.document.body.style.overflow, 'auto');
  h.api.openGenerated({ render(target) { target.textContent = 'Actual NVDA report body'; rendered++; }, trigger });
  assert.equal(rendered, 2);
  h.api.close(); h.api.open();
  assert.equal(generated.hidden, true);
  assert.equal(h.get('demo-report-frame').hidden, false);
  assert.equal(h.get('demo-report-modal-title').textContent, 'Everyday balance · saved research');
  assert.match(h.get('demo-report-modal-note').textContent, /15:27/);
  assert.equal(h.get('demo-report-own-page').hidden, false);
});

test('unsupported or failed dialogs leave prepared navigation and generated fallback available', () => {
  const h = harness(undefined, { dialogSupported: false });
  assert.equal(h.api, null);
  assert.equal(h.get('open-demo-report').getAttribute('href'), 'prepared-report.html');
  assert.equal(h.get('open-demo-report').getAttribute('aria-haspopup'), null);
  const failed = harness(undefined, { dialogFailure: true });
  let prevented = false;
  failed.get('open-demo-report').dispatch('click', { preventDefault() { prevented = true; } });
  assert.equal(prevented, false);
  assert.equal(failed.api.openGenerated({ render(target) { target.textContent = 'Generated evidence'; } }), false);
  assert.equal(failed.document.body.style.overflow, 'auto');
  assert.equal(failed.get('demo-report-dialog').open, false);
});

test('Escape, backdrop click and repeated opening restore the calling control', () => {
  const h = harness();
  h.api.open(); h.api.open();
  let prevented = false;
  h.get('demo-report-dialog').dispatch('cancel', { preventDefault() { prevented = true; } });
  assert.equal(prevented, true);
  assert.equal(h.document.body.style.overflow, 'auto');
  assert.equal(h.document.activeElement, h.get('open-demo-report'));
  h.api.open();
  h.get('demo-report-dialog').dispatch('click', { target: h.get('demo-report-dialog'), clientX: 50, clientY: 50 });
  assert.equal(h.get('demo-report-dialog').open, true, 'Clicking inside the dialog must not close the report');
  h.get('demo-report-dialog').dispatch('click', { target: h.get('demo-report-dialog'), clientX: 5, clientY: 5 });
  assert.equal(h.get('demo-report-dialog').open, false);
  assert.equal(h.document.activeElement, h.get('open-demo-report'));
});

test('a tall website iframe positions the report inside the visible outer viewport', () => {
  const parent = { innerHeight: 800, addEventListener() {} };
  const view = { innerHeight: 1600, parent, frameElement: { getBoundingClientRect: () => ({ top: -450 }) }, addEventListener() {} };
  const h = harness(view);
  h.api.open();
  assert.equal(h.get('demo-report-dialog').style.top, '466px');
  assert.equal(h.get('demo-report-dialog').style.height, '768px');
  assert.equal(-450 + parseInt(h.get('demo-report-dialog').style.top), 16);
});

test('the prepared report exactly renders the packaged evidence and retains its partial status and inputs', async t => {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-prepared-report-'));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  const output = path.join(directory, 'prepared-report.html');
  const evidencePath = fileURLToPath(new URL('../examples/prepared-report.json', import.meta.url));
  await promisify(execFile)(process.execPath, [
    fileURLToPath(new URL('../scripts/export-report.mjs', import.meta.url)), evidencePath, output,
  ], { timeout: 10000 });
  const [source, copied, html, evidenceText] = await Promise.all([
    fs.readFile(output),
    fs.readFile(new URL('../public/prepared-report.html', import.meta.url)),
    fs.readFile(new URL('../public/workspace.html', import.meta.url), 'utf8'),
    fs.readFile(evidencePath, 'utf8'),
  ]);
  const evidence = JSON.parse(evidenceText);
  assert.deepEqual(copied, source);
  assert.equal(evidence.status, 'partial');
  assert.deepEqual(evidence.research.map(item => item.ticker), ['VTI', 'IEF', 'SGOV']);
  assert.ok(copied.toString().includes(evidence.generatedAt));
  assert.match(copied.toString(), /Partial report/);
  assert.doesNotMatch(copied.toString(), /<script\b|<iframe\b|onload\s*=/i);
  assert.match(html, /Research: VTI, IEF &amp; SGOV/);
  assert.match(html, /changing your selections does not change this report/);
  assert.match(html, /<details id="research-tools"[^>]*><summary>More options/);
  assert.match(html, /<a\b[^>]*id="open-demo-report"[^>]*href="prepared-report\.html"[^>]*>/);
  assert.match(html, /sandbox="allow-popups allow-popups-to-escape-sandbox"/);
});
