import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createApi } from '../server/api.mjs';
import { configuration } from '../server/config.mjs';
import { LocalStore } from '../server/store.mjs';
import { DEFAULT_PROFILE, ASSETS, createMatch } from '../shared/strategy.mjs';
import { selectedPlan } from '../shared/selected-plan.mjs';
import { createSelectedResearchMatch, validateResearchSelection } from '../server/research-selection.mjs';

const SECRET = 'test-only-research-worker-secret-123456789';
const selection = { tickers: ['AMD', 'NVDA'], weights: { AMD: 20, NVDA: 0 } };
async function harness(t, search) {
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-selection-test-'));
  t.after(() => fs.rm(directory, { recursive: true, force: true }));
  let timestamp = Date.parse('2026-10-04T08:00:00Z'), calls = 0;
  const config = { ...configuration({}), workerSecret: SECRET, storeFile: path.join(directory, 'state.json'), researchRequestsPerHour: 50 };
  const store = new LocalStore(config.storeFile);
  const api = createApi({ config, store, now: () => timestamp, fetchImpl: () => assert.fail('No model or provider request is allowed in this test'), stockSearch: async (...args) => { calls++; return search ? search(...args) : { results: [] }; } });
  const call = async (route, body, headers = {}) => {
    const response = await api(new Request(`http://127.0.0.1:8787${route}`, { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) }), { clientIp: 'test-only' });
    return { status: response.status, data: await response.json() };
  };
  const worker = (route, body = {}) => call('/api/worker/' + route, { workerId: 'test-worker', ...body }, { Authorization: `Bearer ${SECRET}` });
  const match = (profile = DEFAULT_PROFILE, token) => call('/api/match', { profile }, token ? { 'X-Session-Token': token } : {});
  const ready = async (profile = DEFAULT_PROFILE) => { const matched = await match(profile); await worker('heartbeat'); return { profile, sessionToken: matched.data.sessionToken, matchId: matched.data.match.id }; };
  return { call, worker, match, ready, store, config, tick: ms => { timestamp += ms; }, searches: () => calls };
}
function reportFor(job) {
  return { id: job.id, status: 'complete', title: 'TEST FIXTURE ONLY', generatedAt: '2026-10-04T08:01:00Z', analysisDate: '2026-10-02', profile: structuredClone(job.profile), match: structuredClone(job.match), provenance: { engine: 'TauricResearch/TradingAgents', repository: 'test://fixture', dataSources: [], warnings: [] }, research: job.match.researchSelection.tickers.map(ticker => ({ ticker, status: 'complete', sections: [] })), outlook: [], limitations: ['Test fixture only'], backtest: { status: 'unavailable' } };
}

test('selected research freezes only current checked stocks, zero-weight ideas and exact residual cash', async t => {
  const h = await harness(t), ready = await h.ready();
  const response = await h.call('/api/research', { ...ready, researchSelection: selection });
  assert.equal(response.status, 202);
  const snapshot = response.data.job.inputSnapshot;
  assert.equal(snapshot.source, 'user-selected');
  assert.deepEqual(snapshot.researchTickers, ['AMD', 'NVDA']);
  assert.deepEqual(snapshot.allocations.map(row => [row.ticker, row.weight, row.amount]), [['AMD', 20, 2000], ['NVDA', 0, 0], ['CASH', 80, 8000]]);
  assert.deepEqual(snapshot.profile, createMatch(DEFAULT_PROFILE).profile);
  assert.deepEqual(snapshot.template, { id: 'balanced', name: 'Everyday balance' });
  assert(!JSON.stringify(snapshot).includes(ready.sessionToken));
  const job = (await h.worker('claim')).data.job;
  assert.equal(job.match.originalMatchId, ready.matchId);
  assert.notEqual(job.match.id, ready.matchId);
  assert.deepEqual(job.match.researchSelection, { version: 1, tickers: ['AMD', 'NVDA'], source: 'user-selected' });
  assert.deepEqual(job.match.allocations.map(row => ({ ticker: row.ticker, weight: row.weight, amount: row.amount })), selectedPlan(createMatch(DEFAULT_PROFILE), { tickers: selection.tickers }, selection.weights).allocations.map(row => ({ ticker: row.ticker, weight: row.weight, amount: row.amount })));
  assert.deepEqual(job.match.stress.assumptions.map(row => row.ticker), ['AMD', 'NVDA', 'CASH']);
  assert(job.match.warnings.some(text => text.includes('not been approved by AI')));
  assert.equal(h.searches(), 0, 'Maintained instrument identities need no external directory call');
  const loaded = await h.call('/api/research/' + job.id, undefined, { 'X-Report-Token': response.data.accessToken });
  assert.deepEqual(loaded.data.job.inputSnapshot, snapshot);
  assert.equal((await h.call('/api/health')).data.selectedStockResearch, true);
});

test('selection IDs are deterministic, removed template assets do not return, and all watch-only cash is valid', () => {
  const base = createMatch(DEFAULT_PROFILE), stocks = ASSETS.filter(asset => selection.tickers.includes(asset.ticker));
  const first = createSelectedResearchMatch(base, selection, stocks);
  const same = createSelectedResearchMatch({ ...base, createdAt: 'different irrelevant receipt time' }, { tickers: ['AMD', 'NVDA'], weights: { NVDA: 0, AMD: 20 } }, stocks);
  assert.equal(first.id, same.id);
  const removed = createSelectedResearchMatch(base, { tickers: ['NVDA'], weights: { NVDA: 0 } }, stocks);
  assert.notEqual(first.id, removed.id);
  assert.deepEqual(removed.allocations.map(row => [row.ticker, row.weight]), [['NVDA', 0], ['CASH', 100]]);
  assert.equal(removed.stress.lossAmount, 0);
  assert.deepEqual(base.allocations.map(row => row.ticker), ['VTI', 'SCHD', 'IEF', 'SGOV', 'GLD', 'CASH'], 'The confirmed match remains unchanged');
});

test('malformed selections, extra client amounts and invalid weights are rejected before lookup or queue mutation', async t => {
  const h = await harness(t), ready = await h.ready();
  const invalid = [null, [], {}, { tickers: [], weights: {} }, { tickers: ['AMD', 'AMD'], weights: { AMD: 10 } }, { tickers: ['amd'], weights: { amd: 10 } }, { tickers: ['CASH'], weights: { CASH: 100 } }, { tickers: ['^GSPC'], weights: { '^GSPC': 10 } }, { tickers: ['ABCDEFGHIJK'], weights: { ABCDEFGHIJK: 10 } }, { tickers: ['AMD'], weights: {} }, { tickers: ['AMD'], weights: { AMD: '10' } }, { tickers: ['AMD'], weights: { AMD: -1 } }, { tickers: ['AMD'], weights: { AMD: 101 } }, { tickers: ['AMD'], weights: { AMD: 10, NVDA: 20 } }, { tickers: ['AMD', 'NVDA'], weights: { AMD: 60, NVDA: 60 } }, { ...selection, amounts: { AMD: 1 } }, { tickers: ['AMD', 'NVDA', 'AAPL', 'MSFT', 'VTI', 'SPY', 'IEF', 'GLD', 'SGOV'], weights: {} }];
  for (const researchSelection of invalid) assert.equal((await h.call('/api/research', { ...ready, researchSelection })).status, 400, JSON.stringify(researchSelection));
  assert.throws(() => validateResearchSelection({ tickers: ['AMD'], weights: { AMD: NaN } }), /number/);
  assert.throws(() => validateResearchSelection({ tickers: ['AMD'], weights: { AMD: Infinity } }), /number/);
  assert.equal(h.searches(), 0);
  assert.equal(Object.keys((await h.store.read()).jobs).length, 0);
});

test('directory identity is exact and verified before a custom symbol enters research', async t => {
  const h = await harness(t, async ticker => ({ results: [{ ticker: ticker === 'UBER' ? 'UBER' : 'WRONG', name: 'Test directory identity', identityStatus: 'provider_catalog', etf: false }] }));
  const ready = await h.ready();
  const unknown = await h.call('/api/research', { ...ready, researchSelection: { tickers: ['NOPE'], weights: { NOPE: 5 } } });
  assert.equal(unknown.status, 422);
  const valid = await h.call('/api/research', { ...ready, researchSelection: { tickers: ['UBER'], weights: { UBER: 5 } } });
  assert.equal(valid.status, 202);
  assert.equal(valid.data.job.inputSnapshot.allocations[0].assetClass, 'stock');
  assert.equal(valid.data.job.inputSnapshot.allocations[0].amount, 500);
  assert.deepEqual(valid.data.job.inputSnapshot.allocations.map(row => row.ticker), ['UBER', 'CASH']);
});

test('authentication, essential-money and stale-profile guards precede directory lookup', async t => {
  const h = await harness(t), ready = await h.ready();
  const custom = { tickers: ['UBER'], weights: { UBER: 10 } };
  assert.equal((await h.call('/api/research', { profile: DEFAULT_PROFILE, matchId: ready.matchId, researchSelection: custom })).status, 401);
  assert.equal((await h.call('/api/research', { ...ready, matchId: undefined, researchSelection: custom })).status, 400);
  assert.equal((await h.call('/api/research', { ...ready, matchId: 'old-match', researchSelection: custom })).status, 409);
  assert.equal((await h.call('/api/research', { ...ready, profile: { ...DEFAULT_PROFILE, budget: 9000 }, researchSelection: custom })).status, 409);
  const essential = await h.ready({ ...DEFAULT_PROFILE, essentialMoney: true });
  assert.equal((await h.call('/api/research', { ...essential, researchSelection: custom })).status, 422);
  assert.equal(h.searches(), 0);
});

test('a match changed during stock lookup cannot queue a stale selection and lookup never holds the state lock', async t => {
  const started = Promise.withResolvers(), release = Promise.withResolvers();
  t.after(() => release.resolve());
  const h = await harness(t, async () => { started.resolve(); await release.promise; return { results: [{ ticker: 'UBER', name: 'Test-only stock', identityStatus: 'provider_catalog', etf: false }] }; });
  const ready = await h.ready();
  const pending = h.call('/api/research', { ...ready, researchSelection: { tickers: ['UBER'], weights: { UBER: 10 } } });
  await started.promise;
  await h.store.transact(state => { state.testLookupLockReleased = true; });
  assert.equal((await h.match({ ...DEFAULT_PROFILE, budget: 9000 }, ready.sessionToken)).status, 200);
  release.resolve();
  assert.equal((await pending).status, 409);
  assert.equal(Object.keys((await h.store.read()).jobs).length, 0);
});

test('worker completion rejects changed canonical amounts, selection and missing or duplicate watch-only research', async t => {
  const h = await harness(t), ready = await h.ready();
  const queued = await h.call('/api/research', { ...ready, researchSelection: selection });
  const job = (await h.worker('claim')).data.job, identity = { jobId: job.id, leaseToken: job.leaseToken };
  const canonical = reportFor(job);
  const changedAmount = structuredClone(canonical); changedAmount.match.allocations[0].amount = 1;
  const changedWeight = structuredClone(canonical); changedWeight.match.allocations[0].weight = 1;
  const changedSelection = structuredClone(canonical); changedSelection.match.researchSelection.tickers = ['AMD'];
  const changedBase = structuredClone(canonical); changedBase.match.originalMatchId = 'wrong';
  const missing = structuredClone(canonical); missing.research.pop();
  const duplicate = structuredClone(canonical); duplicate.research[1] = structuredClone(duplicate.research[0]);
  for (const report of [changedAmount, changedWeight, changedSelection, changedBase, missing, duplicate]) assert.equal((await h.worker('complete', { ...identity, report })).status, 400);
  assert.equal((await h.worker('complete', { ...identity, report: canonical })).status, 200);
  const loaded = await h.call('/api/research/' + queued.data.job.id, undefined, { 'X-Report-Token': queued.data.accessToken });
  assert.deepEqual(loaded.data.report.match, job.match);
  assert.deepEqual(loaded.data.report.research.map(row => row.ticker), ['AMD', 'NVDA']);
});

test('legacy research without a selection keeps questionnaire allocation and exposes its own input snapshot', async t => {
  const h = await harness(t), ready = await h.ready();
  const queued = await h.call('/api/research', ready);
  assert.equal(queued.status, 202);
  const snapshot = queued.data.job.inputSnapshot;
  assert.equal(snapshot.source, 'questionnaire');
  assert.deepEqual(snapshot.researchTickers, ['VTI', 'IEF', 'SGOV']);
  const job = (await h.worker('claim')).data.job;
  assert.equal(job.match.id, ready.matchId);
  assert.equal(job.match.researchSelection, undefined);
  assert.deepEqual(snapshot.allocations, job.match.allocations);
});
