import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { bundleWorkspace, portableShell } from '../scripts/portable-bundle.mjs';
import { DEFAULT_PROFILE } from '../shared/strategy.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const literal = '</script><script>window.unexpectedExecution = true</script>\u2028\u2029<img src="https://example.invalid/test-pixel">';
const report = {
  id:'test-only-bundled-report', title:'Test-only saved ' + literal, status:'partial',
  generatedAt:'2026-10-02T18:00:00Z', analysisDate:'2026-10-02',
  profile:{...DEFAULT_PROFILE, budget:9000},
  provenance:{engine:'Test-only fixture', dataSources:[], warnings:[]},
  research:[{ticker:'VTI', status:'complete', sections:[{title:'Literal source', text:literal}]}],
  outlook:[], backtest:{status:'unavailable'}, limitations:['Test-only fixture, never a published report.'],
};
const bundled = await bundleWorkspace(root, [report]);

function find(root, predicate) {
  if (predicate(root)) return root;
  for (const child of root.children || []) { const result = find(child, predicate); if (result) return result; }
  return null;
}
class Element {
  constructor(tag) {
    this.tagName = tag; this.children = []; this.attributes = {}; this.events = new Map();
    this.style = {}; this.dataset = {}; this.value = ''; this.hidden = false; this.disabled = false; this.open = false; this._text = '';
  }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this._text = ''; this.children = [...items]; }
  set textContent(text) { this._text = String(text); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent || '').join(''); }
  setAttribute(key, value) { this.attributes[key] = value; }
  getAttribute(key) { return this.attributes[key] ?? null; }
  addEventListener(name, action) { this.events.set(name, action); }
  async dispatch(name) { return this.events.get(name)?.({preventDefault() {}}); }
  get firstChild() { return this.children[0]; }
  get lastChild() { return this.children.at(-1); }
  get options() { return this.children; }
  querySelector(selector) { return find(this, item => item.tagName === selector); }
  scrollIntoView() {}
  focus() {}
  showModal() { this.open = true; }
  close() { this.open = false; this.events.get('close')?.({}); }
  getBoundingClientRect() { return {height:1000}; }
}

async function bootClassicBundle(code) {
  const input = {...DEFAULT_PROFILE}, elements = new Map(), fetches = [], sessions = [];
  const element = id => {
    if (!elements.has(id)) { const item = new Element('div'); item.id = id; elements.set(id, item); }
    return elements.get(id);
  };
  const tabs = ['questionnaire','portfolio','research','community'].map(name => {
    const item = element('tab-' + name); item.dataset.tab = name; return item;
  });
  const panels = tabs.map(tab => { const item = element('panel-' + tab.dataset.tab); item.hidden = tab.dataset.tab !== 'questionnaire'; return item; });
  const document = {
    body:element('body'), getElementById:element, addEventListener() {}, removeEventListener() {},
    createElement:tag => new Element(tag), createElementNS:(_ns,tag) => new Element(tag),
    createTextNode:text => { const item = new Element('#text'); item.textContent = text; return item; },
    querySelector:selector => selector === '.workspace' ? element('workspace') : null,
    querySelectorAll:selector => selector === '[data-tab]' ? tabs : selector === '.tab-panel' ? panels : [],
  };
  class FormDataDouble { get(key) { return input[key] ?? ''; } has(key) { return Boolean(input[key]); } }
  const window = {document, addEventListener() {}, removeEventListener() {}};
  window.parent = window;
  const context = vm.createContext({
    window, document, FormData:FormDataDouble, structuredClone, AbortController, DOMException,
    setTimeout, clearTimeout, URL, TextEncoder, TextDecoder,
    requestAnimationFrame(callback) { callback(); return 1; }, cancelAnimationFrame() {},
    ResizeObserver:class { constructor(callback) { this.callback = callback; } observe() { this.callback(); } },
    fetch(...args) { fetches.push(args); throw new Error('Forbidden fetch while executing portable bundle'); },
    localStorage:{getItem(key) { return key === 'proto-trading-introduction-v1' ? 'done' : null; },setItem() {}},
    sessionStorage:{getItem(...args) { sessions.push(args); throw new Error('Portable bundle must not read live sessions'); }},
    location:{origin:'null'},
  });
  // Execute the actual classic script without stripping imports, initialization
  // or event listeners. No production internals are added to its closed scope.
  new vm.Script(code, {filename:'test-generated-portable-workspace.js'}).runInContext(context);
  await new Promise(resolve => setImmediate(resolve));
  return {context, window, document, input, element, fetches, sessions};
}

test('generated classic HTML safely carries closing-script text and has no server-root module assets', () => {
  const scripts = [...bundled.html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script\s*>/gi)];
  assert.equal(scripts.length, 1, 'A report cannot create another script element');
  assert.equal(scripts[0][1].trim(), bundled.code.trim(), 'The HTML parser must see the entire generated script');
  assert.doesNotThrow(() => new vm.Script(scripts[0][1]));
  assert(!/<\/script/i.test(bundled.code));
  assert(bundled.code.includes('\\u003c/script>'));
  assert(bundled.code.includes('\\u2028'));
  assert(bundled.code.includes('\\u2029'));
  assert(!/\b(?:src|href)=["']\/(?:workspace|shared)/i.test(bundled.html));
  assert(!/<script\b[^>]*(?:type=["']module|src=)/i.test(bundled.html));
  assert(!/<link\b[^>]*rel=["']stylesheet/i.test(bundled.html));
  assert(/<style>/.test(bundled.html));
  assert(!/^\s*(?:import|export)\s/m.test(bundled.code));
});

test('portable shell changes embedded app navigation to local relative paths without corrupting its template', async () => {
  const original = await fs.readFile(path.join(root,'shell','proto-trading.html'),'utf8');
  const tag = /<script type="__bundler\/template">\s*([\s\S]*?)\s*<\/script>/;
  const originalTemplate = JSON.parse(original.match(tag)[1]);
  const appPaths = '<a href="/workspace.html">Open app</a><iframe src="/workspace.html"></iframe><script>literal source</script>';
  // The source shell is pre-build; add the same app root paths the site build
  // inserts, then exercise the real shell conversion on its complete template.
  const builtShell = original.replace(tag, () => '<script type="__bundler/template">\n' + JSON.stringify(originalTemplate + appPaths).replaceAll('</','<\\/') + '\n</script>');
  const portable = portableShell(builtShell), match = portable.match(tag);
  assert(match);
  const decoded = JSON.parse(match[1]);
  assert.equal(decoded, (originalTemplate + appPaths).replaceAll('src="/workspace.html"','src="workspace.html"').replaceAll('href="/workspace.html"','href="workspace.html"'));
  assert(decoded.includes('<iframe src="workspace.html">'));
  assert(decoded.includes('<a href="workspace.html">'));
  assert(!/\b(?:src|href)="\/workspace\.html"/.test(decoded));
  assert(!/<\/script/i.test(match[1]), 'Embedded template strings cannot close the template script');
  assert.throws(() => portableShell('<html>No template</html>'), /Missing website template/);
});

test('actual bundled startup and registered interactions remain offline with saved examples and literal report text', async () => {
  const h = await bootClassicBundle(bundled.code);
  assert.equal(h.window.PROTO_PORTABLE, true);
  assert.equal(h.window.PROTO_DEMO_REPORTS[0].title, report.title, 'Escaping must preserve the original report text');
  assert.equal(h.window.unexpectedExecution, undefined);
  assert.match(h.element('api-status').textContent, /Portable demo.*rules ready/);
  assert(h.element('examples-list').textContent.includes(report.title));
  assert.match(h.element('uploaded-library').textContent, /does not provide local document storage/);
  assert.equal(h.sessions.length, 0);
  assert.equal(h.fetches.length, 0);
  assert(h.element('profile-form').events.has('submit'), 'Full bundle initialization must bind the form');
  h.input.budget = 12000;
  await h.element('profile-form').dispatch('submit');
  assert.match(h.element('portfolio-content').textContent, /Rule-based template match/);
  assert.match(h.element('portfolio-content').textContent, /\$12,000/);
  assert.match(h.element('portfolio-content').textContent, /observations pending/);
  const open = find(h.element('examples-list'), item => item.tagName === 'button' && item.textContent === 'Open saved report');
  assert(open);
  await open.dispatch('click');
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(h.element('panel-research').hidden, false);
  assert.match(h.element('report-content').textContent, /PREVIOUSLY GENERATED REPORT/);
  assert.match(h.element('report-content').textContent, /not for your current questionnaire/);
  assert(h.element('report-content').textContent.includes(literal));
  assert.equal(h.input.budget, 12000);
  assert.equal(h.window.PROTO_DEMO_REPORTS[0].profile.budget, 9000);
  assert.equal(h.window.unexpectedExecution, undefined);
  assert(!find(h.element('report-content'), item => ['script','img','iframe'].includes(item.tagName)));
  assert.equal(h.fetches.length, 0, 'No bundled startup or interaction can request a service');
});

test('an empty generated bundle directs its offline action to visible upload controls without promising saved research', async () => {
  const empty = await bundleWorkspace(root, []);
  const h = await bootClassicBundle(empty.code);
  assert(!h.element('worker-status').textContent.includes('Saved research available'));
  const action = h.element('research-action').lastChild;
  assert.match(action.textContent, /upload/i);
  await action.dispatch('click');
  assert.equal(h.element('panel-research').hidden, false);
  assert.equal(h.fetches.length, 0);
});

test('the real offline bundle opens the prepared document before a questionnaire with no AI or research request', async () => {
  const h = await bootClassicBundle(bundled.code);
  const launch = h.element('open-demo-report'), frame = h.element('demo-report-frame'), dialog = h.element('demo-report-dialog');
  assert(launch.events.has('click'), 'The bundled initializer wires the prepared report action');
  assert.equal(frame.getAttribute('src'), null, 'The saved document is only loaded when requested');
  await launch.dispatch('click');
  assert.equal(dialog.open, true);
  assert.equal(frame.getAttribute('src'), 'prepared-report.html', 'The file-based app uses a sibling document, never a server route');
  assert.equal(h.element('body').style.overflow, 'hidden');
  await h.element('close-demo-report').dispatch('click');
  assert.equal(dialog.open, false);
  await launch.dispatch('click');
  assert.equal(dialog.open, true, 'Reopening a prepared report needs no regeneration');
  assert.equal(h.fetches.length, 0);
  assert.equal(h.sessions.length, 0);
  assert(bundled.code.includes('protoModules["shared/school-scenarios.mjs"]'), 'Strategy conditions are bundled with the same app');
  assert.doesNotMatch(bundled.html, /(?:src|href|data-report-src)=["']\/presentation\//, 'The submission has no personal demo route');
});
