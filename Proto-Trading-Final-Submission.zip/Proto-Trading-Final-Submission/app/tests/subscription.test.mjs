import test from 'node:test';
import assert from 'node:assert/strict';
import { createSubscription } from '../public/subscription.js';

class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.attributes = {}; this.events = {}; this._text = ''; this.value = ''; this.checked = false; }
  append(...children) { this.children.push(...children); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent).join(' '); }
  setAttribute(key, value) { this.attributes[key] = value; }
  addEventListener(name, fn) { this.events[name] = fn; }
}
const all = (root, predicate) => [...(predicate(root) ? [root] : []), ...root.children.flatMap(child => all(child, predicate))];
function harness(storage, portableMode = false) {
  const { element } = createSubscription({ createElement: tag => new Element(tag) }, { storage, portableMode });
  const find = predicate => all(element, predicate)[0];
  return { element, email: find(e => e.type === 'email'), consent: find(e => e.type === 'checkbox'), clear: find(e => e.textContent === 'Clear saved address'), submit: () => find(e => e.tagName === 'form').events.submit({ preventDefault() {} }) };
}
function memory() { const data = new Map(); return { getItem: key => data.get(key) ?? null, setItem: (key, value) => data.set(key, value), removeItem: key => data.delete(key), data }; }

test('demo subscription needs consent, persists only in supplied browser storage and clears completely', () => {
  const storage = memory(), h = harness(storage);
  h.email.value = 'person@gmail.com'; h.submit(); assert.match(h.element.textContent, /Tick the consent/); assert.equal(storage.data.size, 0);
  h.consent.checked = true; h.submit(); assert.match(h.element.textContent, /Saved on this device only. No email was sent/); assert.equal(storage.data.size, 1);
  const next = harness(storage); assert.equal(next.email.value, 'person@gmail.com'); assert.equal(next.consent.checked, true); assert.equal(next.clear.hidden, false);
  next.clear.events.click(); assert.equal(storage.data.size, 0); assert.equal(next.email.value, ''); assert.equal(next.consent.checked, false); assert.match(next.element.textContent, /Saved address cleared/);
});
test('blocked or non-persistent browser storage never claims an address was saved or cleared', () => {
  for (const storage of [null, { getItem: () => null, setItem: () => { throw Error('blocked'); } }, { getItem: () => null, setItem() {} }]) {
    const h = harness(storage); h.email.value = 'person@gmail.com'; h.consent.checked = true; h.submit();
    assert.match(h.element.textContent, /could not be saved/); assert.doesNotMatch(h.element.textContent, /Saved on this device only/);
  }
  const storage = memory(), h = harness(storage); h.email.value = 'person@gmail.com'; h.consent.checked = true; h.submit(); storage.removeItem = () => { throw Error('blocked'); }; h.clear.events.click(); assert.match(h.element.textContent, /could not be cleared/); assert.equal(h.clear.hidden, false);
});
test('invalid addresses cannot persist and portable preview has no fake trade link or live claims', () => {
  const storage = memory(), h = harness(storage, true); h.consent.checked = true;
  for (const value of ['not-an-address', '<img>@gmail.com', 'person@host', 'x\n@y.com']) { h.email.value = value; h.submit(); assert.match(h.element.textContent, /valid email address/); }
  assert.equal(storage.data.size, 0); assert.equal(all(h.element, e => e.tagName === 'a').length, 0);
  assert.match(h.element.textContent, /Demo · emails paused/); assert.match(h.element.textContent, /Trade-record link appears in enabled emails/); assert.match(h.element.textContent, /offline/);
});
