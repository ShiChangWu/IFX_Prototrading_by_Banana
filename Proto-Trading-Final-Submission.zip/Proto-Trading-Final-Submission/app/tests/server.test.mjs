import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import { writeFileSync } from 'node:fs';
import { configuration, loadLocalEnv } from '../server/config.mjs';
import { LocalStore, SupabaseStore, emptyState } from '../server/store.mjs';
import { createApi } from '../server/api.mjs';
import { localServer } from '../server/index.mjs';
import { netlifyRequest } from '../netlify/functions/api.mjs';
import { clearStaleLocalLock } from '../server/lock.mjs';
import { DEFAULT_PROFILE } from '../shared/strategy.mjs';

const SECRET = 'test-worker-secret-with-at-least-32-characters';
async function harness(t, overrides = {}, fetchImpl) {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-server-test-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const config = { ...configuration({}), workerSecret: SECRET, storeFile: path.join(dir, 'state.json'), ...overrides };
  const store = new LocalStore(config.storeFile);
  let time = Date.now();
  const api = createApi({ config, store, fetchImpl, now: () => time });
  const call = async (route, body, headers = {}) => {
    const response = await api(new Request(`http://localhost:8787${route}`, { method: body === undefined ? 'GET' : 'POST', headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...headers }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) }), { clientIp: '127.0.0.1' });
    return { status: response.status, data: await response.json() };
  };
  const worker = (route, body = {}) => call(`/api/worker/${route}`, { workerId: 'test-worker', ...body }, { Authorization: `Bearer ${SECRET}` });
  const match = (profile = DEFAULT_PROFILE) => call('/api/match', { profile });
  return { call, worker, match, store, config, tick: ms => { time += ms; } };
}
function testReport(job) {
  return { id: job.id, title: 'TEST FIXTURE — NEVER PUBLISHED', status: 'complete', generatedAt: new Date().toISOString(), analysisDate: '2026-10-02', profile: job.profile, match: job.match,
    provenance: { engine: 'TauricResearch/TradingAgents', repository: 'test://fixture', commit: 'test-only', model: 'mock-provider-for-tests', templateVersion: job.match.template.version, dataSources: [], warnings: ['Automated test fixture, not investment research.'] },
    research: [{ ticker: job.match.allocations.find(a => a.ticker !== 'CASH').ticker, status: 'complete', decision: 'TEST ONLY', sections: [{ title: 'Test', text: 'Mocked test evidence.' }] }],
    outlook: [], backtest: { status: 'unavailable', warnings: [], error: 'Test fixture has no market data.' }, hedgeReview: job.match.hedgeReview, limitations: ['Automated test only.'] };
}

test('public strategy catalog preserves beginner choices and educational boundaries', async t => {
  const h = await harness(t);
  const result = await h.call('/api/templates');
  assert.equal(result.status, 200); assert.equal(result.data.templates.length, 10);
  assert.equal(result.data.templates.filter(template => template.matchable).length, 6);
  for (const template of result.data.templates) {
    assert(template.beginnerSummary && template.learningSteps.length && template.requiredData.length);
    assert(!Object.hasOwn(template, 'researchPrompt'));
  }
  for (const id of ['atr', 'ict', 'order_flow', 'wyckoff']) assert.equal(result.data.templates.find(template => template.id === id).matchable, false);
});

test('missing DeepSeek returns real rule calculations with explicit unavailable status', async t => {
  const h = await harness(t);
  const result = await h.match();
  assert.equal(result.status, 200); assert.equal(result.data.explanation.status, 'unavailable');
  assert.equal(result.data.match.allocations.reduce((n, a) => n + a.weight, 0), 100);
  assert.equal(result.data.sessionToken.length, 43);
  assert.deepEqual((await h.call('/api/examples')).data, { reports: [] });
  const raw = await fs.readFile(h.config.storeFile, 'utf8');
  assert.ok(!raw.includes(result.data.sessionToken), 'session token must only be stored as a hash');
});

test('queue rejects missing session, offline worker, unsafe inputs and essential-money profile', async t => {
  const h = await harness(t);
  assert.equal((await h.call('/api/research', { profile: DEFAULT_PROFILE })).status, 401);
  const matched = await h.match(); const sessionToken = matched.data.sessionToken;
  assert.equal((await h.call('/api/research', { profile: DEFAULT_PROFILE, sessionToken })).status, 503);
  assert.equal((await h.worker('heartbeat')).status, 200);
  assert.equal((await h.call('/api/research', { profile: { ...DEFAULT_PROFILE, budget: 11000 }, sessionToken })).status, 409);
  assert.equal((await h.match({ ...DEFAULT_PROFILE, prompt: 'x'.repeat(1501) })).status, 400);
  const essential = { ...DEFAULT_PROFILE, essentialMoney: true };
  const unsafe = await h.match(essential);
  assert.equal((await h.call('/api/research', { profile: essential, sessionToken: unsafe.data.sessionToken })).status, 422);
});

test('persistent job lifecycle protects report access and lease ownership; completion is idempotent', async t => {
  const h = await harness(t);
  const matched = await h.match(); await h.worker('heartbeat');
  const queued = await h.call('/api/research', { profile: DEFAULT_PROFILE, sessionToken: matched.data.sessionToken, matchId: matched.data.match.id });
  assert.equal(queued.status, 202); const { id } = queued.data.job;
  assert.equal((await h.call(`/api/research/${id}`)).status, 404);
  assert.equal((await h.call('/api/worker/claim', { workerId: 'test-worker' })).status, 401);
  const claimed = await h.worker('claim'); const job = claimed.data.job;
  assert.equal(job.id, id);
  assert.equal((await h.worker('claim')).data.job, null);
  assert.equal((await h.worker('progress', { jobId: id, leaseToken: 'wrong', stage: 'bad' })).status, 409);
  const ownership = { jobId: id, leaseToken: job.leaseToken };
  assert.equal((await h.worker('progress', { ...ownership, stage: 'Reading market evidence' })).status, 200);
  const report = testReport(job);
  assert.equal((await h.worker('complete', { ...ownership, report: { ...report, profile: { ...report.profile, budget: 9 } } })).status, 400);
  assert.equal((await h.worker('complete', { ...ownership, report })).status, 200);
  assert.equal((await h.worker('complete', { ...ownership, report })).status, 200);
  const result = await h.call(`/api/research/${id}`, undefined, { 'X-Report-Token': queued.data.accessToken });
  assert.equal(result.data.report.title, report.title); assert.equal(result.data.job.status, 'complete');
  const restored = new LocalStore(h.config.storeFile);
  assert.equal((await restored.read()).jobs[id].report.title, report.title);
  const raw = await fs.readFile(h.config.storeFile, 'utf8'); assert.ok(!raw.includes(queued.data.accessToken));
  assert.deepEqual((await h.call('/api/examples')).data.reports, [], 'private reports are never automatically public examples');
});

test('worker failure and expired lease remain honest failures; heartbeat renews live lease', async t => {
  const h = await harness(t);
  const matched = await h.match(); await h.worker('heartbeat');
  const queued = await h.call('/api/research', { profile: DEFAULT_PROFILE, sessionToken: matched.data.sessionToken });
  const job = (await h.worker('claim')).data.job;
  h.tick(60000); await h.worker('heartbeat', { jobId: job.id });
  h.tick(70000);
  assert.equal((await h.worker('progress', { jobId: job.id, leaseToken: job.leaseToken, stage: 'Continuing' })).status, 200);
  h.tick(121000);
  assert.equal((await h.worker('complete', { jobId: job.id, leaseToken: job.leaseToken, report: testReport(job) })).status, 409);
  const result = await h.call(`/api/research/${job.id}`, undefined, { 'X-Report-Token': queued.data.accessToken });
  assert.equal(result.data.job.status, 'failed'); assert.equal(result.data.report, null);
});

test('API enforces rate limits, single active request, origin restrictions and no secrets in health', async t => {
  const h = await harness(t, { matchRequestsPerHour: 2, researchRequestsPerHour: 1 });
  const matched = await h.match(); await h.worker('heartbeat');
  const payload = { profile: DEFAULT_PROFILE, sessionToken: matched.data.sessionToken };
  assert.equal((await h.call('/api/research', payload)).status, 202);
  assert.equal((await h.call('/api/research', payload)).status, 409);
  const job = (await h.worker('claim')).data.job;
  assert.equal((await h.worker('fail', { jobId: job.id, leaseToken: job.leaseToken, error: 'Test fixture failed deliberately.' })).status, 200);
  assert.equal((await h.call('/api/research', payload)).status, 429);
  await h.match(); assert.equal((await h.match()).status, 429);
  assert.equal((await h.call('/api/health', undefined, { Origin: 'https://untrusted.example' })).status, 403);
  assert.ok(!JSON.stringify((await h.call('/api/health')).data).includes(SECRET));
});

test('mocked DeepSeek can select only an allowed template and selection survives job recomputation', async t => {
  const fetchImpl = async (_url, options) => {
    const request = JSON.parse(options.body);
    const supplied = JSON.parse(request.messages[1].content);
    assert.ok(supplied.candidateTemplates.some(c => c.id === 'defensive'));
    return new Response(JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify({ suggestedTemplateId: 'defensive', summary: 'TEST MOCK — cautious research style selected.', why: ['TEST MOCK'], risks: ['Losses remain possible.'], nextSteps: ['Review the complete research.'] }) } }] }));
  };
  const h = await harness(t, { deepseekKey: 'test-provider-key' }, fetchImpl);
  const result = await h.match(); assert.equal(result.data.explanation.status, 'ready');
  assert.equal(result.data.match.template.id, 'defensive'); assert.equal(result.data.match.selection.method, 'deepseek');
  await h.worker('heartbeat');
  assert.equal((await h.call('/api/research', { profile: DEFAULT_PROFILE, matchId: result.data.match.id, sessionToken: result.data.sessionToken })).status, 202);
  const job = (await h.worker('claim')).data.job;
  assert.equal(job.match.template.id, 'defensive');
  assert.deepEqual(job.match.allocations, result.data.match.allocations);
});

test('invalid provider JSON and unknown suggested templates cannot overwrite calculations', async t => {
  let output = 'not json';
  const fetchImpl = async () => new Response(JSON.stringify({ choices: [{ finish_reason: 'stop', message: { content: output } }] }));
  const h = await harness(t, { deepseekKey: 'test-provider-key' }, fetchImpl);
  assert.equal((await h.match()).data.explanation.status, 'error');
  output = JSON.stringify({ suggestedTemplateId: 'all-in-leveraged', summary: 'TEST MOCK', why: [], risks: [], nextSteps: [], allocations: [{ ticker: 'UNKNOWN', weight: 100 }] });
  const result = await h.match(); assert.equal(result.data.match.selection.method, 'rules');
  assert.ok(!result.data.match.allocations.some(a => a.ticker === 'UNKNOWN'));
});

test('local state serializes concurrent mutations and rejects corrupted data without overwriting', async t => {
  const h = await harness(t);
  await Promise.all(Array.from({ length: 20 }, (_, i) => h.store.transact(state => { state.workers[`test-${i}`] = { lastSeen: i }; })));
  assert.equal(Object.keys((await h.store.read()).workers).length, 20);
  await fs.writeFile(h.config.storeFile, '{broken');
  await assert.rejects(h.store.transact(() => true));
  assert.equal(await fs.readFile(h.config.storeFile, 'utf8'), '{broken');
});

test('cloud state uses CAS retries and never falls back when credentials or storage are unavailable', async () => {
  assert.throws(() => new SupabaseStore({ url: '', key: '' }));
  let revision = 0, data = emptyState(), conflict = true;
  const store = new SupabaseStore({ url: 'https://test.example', key: 'test-only-key', fetchImpl: async (url, options) => {
    if (url.endsWith('proto_read_state')) return Response.json({ revision, data });
    const input = JSON.parse(options.body);
    if (conflict) { conflict = false; revision++; return Response.json(false); }
    assert.equal(input.expected_revision, revision); data = input.next_data; revision++; return Response.json(true);
  } });
  await store.transact(state => { state.workers.test = { lastSeen: 5 }; });
  assert.equal(data.workers.test.lastSeen, 5);
  const broken = new SupabaseStore({ url: 'https://test.example', key: 'test-only', fetchImpl: async () => { throw new Error('private-key-must-not-leak'); } });
  await assert.rejects(broken.transact(() => {}), problem => problem.status === 503 && !problem.message.includes('private-key'));
});

test('env file is parsed as literal data and existing environment wins', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-env-test-')); t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const file = path.join(dir, '.env.local');
  await fs.writeFile(file, '# test only\nEXISTING=replace\nLITERAL="$(never-run-this)"\nQUOTED=\'test value\'\n');
  const target = { EXISTING: 'keep' }; loadLocalEnv(file, target);
  assert.equal(target.EXISTING, 'keep'); assert.equal(target.LITERAL, '$(never-run-this)'); assert.equal(target.QUOTED, 'test value');
});

test('HTTP server binds public routes only, blocks hidden files and rebinding hostnames', async t => {
  const h = await harness(t);
  const server = localServer(h.config, { store: h.store });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  h.config.port = server.address().port;
  t.after(() => new Promise(resolve => { server.closeAllConnections(); server.close(resolve); }));
  const origin = `http://127.0.0.1:${h.config.port}`;
  assert.equal((await fetch(origin + '/api/health')).status, 200);
  assert.equal((await fetch(origin + '/shared/strategy.mjs')).status, 200);
  assert.equal((await fetch(origin + '/shared/templates.mjs')).status, 200);
  assert.equal((await fetch(origin + '/.env.local')).status, 404);
  assert.equal((await fetch(origin + '/server/config.mjs')).status, 404);
  assert.equal((await fetch(origin + '/%2e%2e%5c.env.local')).status, 404);
  const hostileHostStatus = await new Promise((resolve, reject) => {
    const req = http.get(origin + '/api/health', { headers: { Host: 'attacker.example' } }, response => { response.resume(); resolve(response.statusCode); });
    req.on('error', reject);
  });
  assert.equal(hostileHostStatus, 403);
});

test('a late older AI result cannot overwrite a newer session match or create stale research', async t => {
  const olderStarted = Promise.withResolvers(), newerStarted = Promise.withResolvers();
  const releaseOlder = Promise.withResolvers(), releaseNewer = Promise.withResolvers();
  t.after(() => { releaseOlder.resolve(); releaseNewer.resolve(); });
  const fetchImpl = async (_url, options) => {
    const { match } = JSON.parse(JSON.parse(options.body).messages[1].content);
    if (match.profile.prompt === 'older request') { olderStarted.resolve(); await releaseOlder.promise; }
    if (match.profile.prompt === 'newer request') { newerStarted.resolve(); await releaseNewer.promise; }
    return Response.json({ choices: [{ finish_reason: 'stop', message: { content: JSON.stringify({ suggestedTemplateId: match.profile.prompt === 'newer request' ? 'defensive' : 'balanced', summary: 'TEST MOCK', why: [], risks: [], nextSteps: [] }) } }] });
  };
  const h = await harness(t, { deepseekKey: 'test-only-provider-key' }, fetchImpl);
  const sessionToken = (await h.match()).data.sessionToken;
  const headers = { 'X-Session-Token': sessionToken };
  const olderProfile = { ...DEFAULT_PROFILE, prompt: 'older request' };
  const newerProfile = { ...DEFAULT_PROFILE, budget: 20000, prompt: 'newer request' };
  const older = h.call('/api/match', { profile: olderProfile }, headers);
  await olderStarted.promise;
  const newer = h.call('/api/match', { profile: newerProfile }, headers);
  await newerStarted.promise;
  const pendingResearch = await h.call('/api/research', { profile: DEFAULT_PROFILE, sessionToken });
  assert.equal(pendingResearch.status, 409); assert.match(pendingResearch.data.error, /still in progress/);
  releaseNewer.resolve();
  const current = await newer;
  assert.equal(current.status, 200); assert.equal(current.data.match.template.id, 'defensive');
  releaseOlder.resolve();
  const stale = await older;
  assert.equal(stale.status, 409); assert.match(stale.data.error, /newer matching request/);
  await h.worker('heartbeat');
  assert.equal((await h.call('/api/research', { profile: olderProfile, sessionToken })).status, 409);
  assert.equal((await h.call('/api/research', { profile: newerProfile, sessionToken, matchId: current.data.match.id })).status, 202);
  const assigned = (await h.worker('claim')).data.job;
  assert.equal(assigned.profile.budget, 20000); assert.equal(assigned.profile.prompt, 'newer request');
  assert.equal(assigned.match.template.id, 'defensive');
});

test('Netlify adapter preserves public origin and normalizes only the exact function prefix', async () => {
  const event = { httpMethod: 'POST', path: '/.netlify/functions/api/match', rawUrl: 'https://demo.example/api/match?demo=1', headers: { Host: 'internal.example', Origin: 'https://demo.example', 'Content-Type': 'application/json', 'X-Nf-Client-Connection-Ip': '192.0.2.4' }, body: Buffer.from('{"profile":"test-only"}').toString('base64'), isBase64Encoded: true };
  const converted = netlifyRequest(event);
  assert.equal(converted.request.url, 'https://demo.example/api/match?demo=1');
  assert.equal(converted.request.headers.get('Origin'), 'https://demo.example');
  assert.equal(converted.clientIp, '192.0.2.4');
  assert.deepEqual(await converted.request.json(), { profile: 'test-only' });
  const direct = netlifyRequest({ httpMethod: 'GET', path: '/api/health', headers: { Host: 'custom.example', Origin: 'https://custom.example' } });
  assert.equal(direct.request.url, 'https://custom.example/api/health');
  const other = netlifyRequest({ ...event, httpMethod: 'GET', path: '/.netlify/functions/apiary/health', body: undefined });
  assert.equal(new URL(other.request.url).pathname, '/.netlify/functions/apiary/health');
  assert.throws(() => netlifyRequest({ ...event, body: 'x'.repeat(40000), isBase64Encoded: false }), problem => problem.status === 413);
  assert.throws(() => netlifyRequest({ httpMethod: 'GET', headers: { Host: 'evil.example/path' }, path: '/api/health' }), problem => problem.status === 400);
});

test('stale local lock cleanup requires a missing PID and preserves live, inaccessible or replaced owners', async t => {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-lock-test-'));
  t.after(() => fs.rm(dir, { recursive: true, force: true }));
  const lock = path.join(dir, 'state.json.lock');
  const missing = () => { throw Object.assign(new Error('Test-only missing PID'), { code: 'ESRCH' }); };
  assert.equal(await clearStaleLocalLock(lock, { probePid: missing }), false);
  await fs.writeFile(lock, '12345');
  assert.equal(await clearStaleLocalLock(lock, { probePid: pid => { assert.equal(pid, 12345); missing(); } }), true);
  await assert.rejects(fs.access(lock), { code: 'ENOENT' });
  await fs.writeFile(lock, '23456');
  await assert.rejects(clearStaleLocalLock(lock, { probePid: () => {} }), /live local website/);
  assert.equal(await fs.readFile(lock, 'utf8'), '23456');
  await assert.rejects(clearStaleLocalLock(lock, { probePid: () => { throw Object.assign(new Error('Test-only permission failure'), { code: 'EPERM' }); } }), /cannot be verified/);
  assert.equal(await fs.readFile(lock, 'utf8'), '23456');
  await assert.rejects(clearStaleLocalLock(lock, { probePid: () => { writeFileSync(lock, '34567'); missing(); } }), /changed during inspection/);
  assert.equal(await fs.readFile(lock, 'utf8'), '34567');
  for (const invalid of ['0', '-1', 'invalid', '', '9007199254740992']) {
    await fs.writeFile(lock, invalid);
    await assert.rejects(clearStaleLocalLock(lock, { probePid: () => assert.fail('Invalid PID must never be probed') }), /lock is invalid/);
    assert.equal(await fs.readFile(lock, 'utf8'), invalid);
  }
});
