import test from 'node:test';
import assert from 'node:assert/strict';
import { COMPANY_FACTS, COMPANY_FACTS_AS_OF, getCompanyFacts } from '../shared/company-facts.mjs';

test('maintained company financials have explicit units, quarterly periods and primary-source provenance', () => {
  const allowedHosts = new Set(['ir.amd.com', 'investor.nvidia.com', 'www.apple.com', 'www.microsoft.com', 'www.sec.gov']);
  assert.equal(COMPANY_FACTS_AS_OF, '2026-10-04');
  assert.deepEqual(Object.keys(COMPANY_FACTS).sort(), ['AAPL', 'AMD', 'MSFT', 'NVDA', 'SPCX']);
  for (const [ticker, facts] of Object.entries(COMPANY_FACTS)) {
    assert.equal(facts.ticker, ticker);
    assert.equal(facts.periodType, 'quarter');
    assert.equal(facts.coverage, 'maintained_snapshot');
    assert.equal(facts.asOfDate, COMPANY_FACTS_AS_OF);
    assert.equal(facts.latestAvailableChecked, true);
    assert.ok(facts.periodEnd < facts.releaseDate && facts.releaseDate <= facts.asOfDate);
    assert.equal(facts.revenue.unit, 'USD');
    assert.equal(facts.dilutedEPS.unit, 'USD/share');
    assert.equal(facts.dilutedEPS.basis, 'GAAP diluted');
    assert.equal(facts.revenue.basis, 'GAAP');
    assert.ok(facts.revenue.value > 1e9 && facts.revenue.value < 1e12, 'Full USD, not millions or annualized values');
    assert.ok(Number.isFinite(facts.dilutedEPS.value));
    assert.ok(facts.revenue.priorYearPeriodEnd < facts.periodEnd);
    const computed = (facts.revenue.value / facts.revenue.priorYearValue - 1) * 100;
    assert.equal(Number(computed.toFixed(facts.revenue.yoyPrecision)), facts.revenue.yoyPct, `${ticker} same-quarter YoY matches stated rounding`);
    for (const metric of [facts.revenue, facts.dilutedEPS, facts.netIncome]) {
      assert.ok(metric.sourceIds.length);
      assert.ok(metric.sourceIds.every(id => facts.sources.some(source => source.id === id)));
    }
    for (const source of facts.sources) {
      const url = new URL(source.url);
      assert.equal(url.protocol, 'https:');
      assert.ok(allowedHosts.has(url.hostname));
      assert.ok(source.publishedAt <= COMPANY_FACTS_AS_OF);
      assert.ok(source.locator.length > 15);
    }
  }
});

test('older reports cannot receive future earnings or infer company results for ETFs', () => {
  assert.equal(getCompanyFacts('NVDA', '2026-08-25'), null);
  assert.equal(getCompanyFacts('NVDA', '2026-08-26').periodLabel, 'Q2 FY2027');
  assert.equal(getCompanyFacts('AMD', '2026-08-03'), null);
  assert.equal(getCompanyFacts('SPCX', '2026-07-01'), null);
  for (const ticker of ['QQQ', 'VTI', 'SCHD', 'IEF', 'SGOV', 'GLD', 'CASH', 'SPCK', 'UNKNOWN', '__proto__', 'toString']) {
    assert.equal(getCompanyFacts(ticker), null);
  }
  assert.equal(getCompanyFacts(null), null);
  assert.equal(getCompanyFacts('AMD', '2026-02-31'), null);
  assert.equal(getCompanyFacts('AMD', ''), null);
});

test('the snapshot does not claim refresh after its checked date and cannot be mutated through a report', () => {
  const future = getCompanyFacts(' amd ', '2026-12-01');
  assert.equal(future.latestAvailableChecked, false);
  assert.equal(future.lastCheckedDate, '2026-10-04');
  assert.equal(future.freshness, 'snapshot_not_refreshed');
  assert.throws(() => { future.revenue.value = 0; }, TypeError);
  assert.equal(getCompanyFacts('AMD').revenue.value, 11536000000);
});

test('financial comparisons preserve GAAP EPS, genuine losses and quarter versus year distinctions', () => {
  assert.equal(COMPANY_FACTS.NVDA.dilutedEPS.value, 2.46); // Not the non-GAAP 2.22.
  assert.equal(COMPANY_FACTS.AMD.dilutedEPS.value, 1.38); // Not non-GAAP 1.66 or continuing-operations 1.39.
  assert.equal(COMPANY_FACTS.MSFT.revenue.value, 90007000000); // Not full-year 331.839 billion.
  assert.equal(COMPANY_FACTS.MSFT.dilutedEPS.value, 4.81); // Not full-year 17.95 or non-GAAP 4.74.
  assert.equal(COMPANY_FACTS.SPCX.dilutedEPS.value, -0.09);
  assert.equal(COMPANY_FACTS.SPCX.netIncome.value, -541000000);
  assert.equal(COMPANY_FACTS.SPCX.identity.listedSince, '2026-06-12');
  assert.match(COMPANY_FACTS.SPCX.identity.priorTickerUse, /SPCK/);
  assert.ok(COMPANY_FACTS.AAPL.caveats.some(value => value.includes('$0.11')));
});
