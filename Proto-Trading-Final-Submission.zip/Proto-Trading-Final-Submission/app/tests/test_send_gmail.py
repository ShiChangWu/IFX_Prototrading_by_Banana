import smtplib
import unittest
from worker.send_gmail import send_email


class FakeSMTP:
    def __init__(self, error_at=None, error=None):
        self.error_at, self.error = error_at, error
        self.calls = []
        self.closed = False

    def login(self, user, password):
        self.calls.append(('login', user, password))
        if self.error_at == 'login':
            raise self.error

    def send_message(self, message, from_addr, to_addrs):
        self.calls.append(('send', message, from_addr, to_addrs))
        if self.error_at == 'send':
            raise self.error
        return {}

    def close(self):
        self.closed = True


class GmailTest(unittest.TestCase):
    def setUp(self):
        self.payload = dict(user='demo@gmail.com', password='abcdefghijklmnop', to='someone@example.com', subject='Rule check', text='Your rule was met.', messageId='<proto.' + 'a' * 64 + '@proto-trading.local>')

    def test_tls_single_recipient_and_acceptance(self):
        smtp = FakeSMTP()
        args = []

        def factory(*a, **kw):
            args.append((a, kw))
            return smtp

        self.assertEqual(send_email(self.payload, factory), {'status': 'accepted', 'code': 'SMTP_ACCEPTED'})
        self.assertEqual(args[0][0], ('smtp.gmail.com', 465))
        self.assertTrue(args[0][1]['context'].check_hostname)
        self.assertEqual(smtp.calls[1][3], ['someone@example.com'])
        self.assertEqual(smtp.calls[1][1]['Message-ID'], self.payload['messageId'])
        self.assertIsNone(smtp.calls[1][1]['Bcc'])
        self.assertTrue(smtp.closed)

    def test_invalid_data_does_not_connect(self):
        def forbidden(*args, **kwargs):
            self.fail('invalid input attempted SMTP')

        for replacement in [dict(to='a@example.com,b@example.com'), dict(subject='Hi\r\nBcc: a@example.com'), dict(text='x' * 48001), dict(messageId='<wrong@id>')]:
            self.assertEqual(send_email({**self.payload, **replacement}, forbidden)['code'], 'INVALID_EMAIL')
        self.assertEqual(send_email({**self.payload, 'password': ''}, forbidden)['status'], 'unavailable')

    def test_definitive_rejection_is_failed(self):
        for stage, error, code in [('login', smtplib.SMTPAuthenticationError(535, b'private provider detail'), 'SMTP_AUTH_FAILED'), ('send', smtplib.SMTPRecipientsRefused({'someone@example.com': (550, b'private')}), 'SMTP_REJECTED'), ('send', smtplib.SMTPDataError(550, b'private message'), 'SMTP_REJECTED')]:
            smtp = FakeSMTP(stage, error)
            result = send_email(self.payload, lambda *a, **kw: smtp)
            self.assertEqual(result, {'status': 'failed', 'code': code})
            self.assertTrue(smtp.closed)

    def test_disconnection_during_send_is_uncertain_and_not_retried(self):
        smtp = FakeSMTP('send', smtplib.SMTPServerDisconnected('sensitive details'))
        self.assertEqual(send_email(self.payload, lambda *a, **kw: smtp), {'status': 'uncertain', 'code': 'SMTP_OUTCOME_UNKNOWN'})
        self.assertEqual(len(smtp.calls), 2)

    def test_failed_connect_and_close_after_acceptance_do_not_confuse_delivery(self):
        def fail_connect(*a, **kw):
            raise TimeoutError('private diagnostic')

        self.assertEqual(send_email(self.payload, fail_connect)['code'], 'SMTP_CONNECT_FAILED')
        smtp = FakeSMTP()
        smtp.close = lambda: (_ for _ in ()).throw(OSError('closing failed'))
        self.assertEqual(send_email(self.payload, lambda *a, **kw: smtp)['status'], 'accepted')


if __name__ == '__main__':
    unittest.main()
