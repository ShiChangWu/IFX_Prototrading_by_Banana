import { selectedPlan } from '../shared/selected-plan.mjs';
import { SCHOOL_BLURBS, scoreSchoolFit } from '../shared/school-fit.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { createWatchlist } from "../public/watchlist.js";
import { createSchoolLab } from '../public/school-lab.js';
import { SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { createReportCompanion } from '../public/report-guide.js';
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createMatch, validateProfile, DEFAULT_PROFILE } from '../shared/strategy.mjs';
import { createShortPlan } from '../shared/short-plan.mjs';
import { MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument } from '../shared/report-import.mjs';

// Exercise the app's real rendering functions without a browser, network or API key.
class Element {
  constructor(tag) {
    this.tagName = tag; this.children = []; this.attributes = {}; this.style = {};
    this.events = new Map(); this.hidden = false; this.disabled = false;
    this.open = false; this.value = ''; this._text = ''; this.parentElement = null;
  }
  append(...items) { for (const item of items) { item.parentElement = this; this.children.push(item); } }
  replaceChildren(...items) { this._text = ''; this.children = []; this.append(...items); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent || '').join(''); }
  get firstChild() { return this.children[0]; }
  get lastChild() { return this.children.at(-1); }
  get options() { return this.children.filter(child => child.tagName === 'option'); }
  setAttribute(key, value) { this.attributes[key] = String(value); }
  addEventListener(name, handler) { const handlers = this.events.get(name) || []; handlers.push(handler); this.events.set(name, handlers); }
  dispatch(name) { for (const handler of this.events.get(name) || []) handler({ target: this }); }
  focus() { this.focused = true; }
  querySelector() { return null; }
}

const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8');
const html = fs.readFileSync(new URL('../public/workspace.html', import.meta.url), 'utf8');
function harness() {
  const elements = new Map();
  const document = {
    createElement: tag => new Element(tag),
    createElementNS: (_namespace, tag) => new Element(tag),
    createTextNode: text => { const node = new Element('#text'); node.textContent = text; return node; },
    getElementById: id => { if (!elements.has(id)) elements.set(id, new Element('div')); return elements.get(id); },
    querySelectorAll: () => [],
  };
  const input = { ...DEFAULT_PROFILE };
  class FormDataDouble { get(key) { return input[key] ?? ''; } has(key) { return Boolean(input[key]); } }
  const context = vm.createContext({
    document, window: { PROTO_PORTABLE: true }, FormData: FormDataDouble,
    setTimeout, clearTimeout, AbortController, DOMException, Intl, Date, URL, JSON,
    Number, String, Math, Object, Array, Set, structuredClone,
    selectedPlan, SCHOOL_BLURBS, scoreSchoolFit, SCHOOL_PRICES, TEMPLATES, ASSETS, PORTFOLIO_IDEAS, createReportCompanion, createSchoolLab, createWatchlist, SCHOOL_TESTS, createMatch, validateProfile, createShortPlan,
    MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument,
  });
  vm.runInContext(source.replace(/^import .*;\r?\n/gm, '').split('let heightFrame;')[0] +
    '\n globalThis.ui = { state, more, node, revealControl, loadTemplates, renderTemplates, renderPortfolio, renderReport, renderUploadedDocument, signature };', context);
  return { ui: context.ui, elements, input, document };
}
function all(root, predicate) { return [...(predicate(root) ? [root] : []), ...root.children.flatMap(child => all(child, predicate))]; }
function find(root, predicate) { return all(root, predicate)[0]; }
function visibleText(root) {
  if (root.hidden) return '';
  if (root.tagName === 'details' && !root.open) return root.children.find(child => child.tagName === 'summary')?.textContent || '';
  return root._text + root.children.map(visibleText).join(' ');
}
function collapsedAncestor(node) {
  for (let parent = node.parentElement; parent; parent = parent.parentElement) if (parent.tagName === 'details' && !parent.open) return parent;
  return null;
}

test('optional questionnaire controls are disclosed while essential-money and loss questions stay visible', () => {
  const begin = html.indexOf('<details id="profile-more"');
  const end = html.indexOf('<div id="form-error"', begin);
  assert(begin > 0 && end > begin);
  const optional = html.slice(begin, end);
  for (const field of ['review', 'experience', 'assetPreference', 'inverseInterest', 'prompt', 'templateId']) assert(optional.includes(`id="${field}"`), field);
  for (const field of ['budget', 'goal', 'horizon', 'lossTolerance', 'lossCapacity', 'essentialMoney']) {
    assert(html.slice(0, begin).includes(`id="${field}"`), `${field} must remain in the main questions`);
    assert(!optional.includes(`id="${field}"`));
  }
  assert(html.includes('<summary>Connection &amp; details</summary>'));
});

test('More details is a native disclosure and remembers the user’s choice across rerenders', () => {
  const { ui } = harness();
  const first = ui.more('More details', 'test-section', ui.node('p', '', 'Extra information'));
  assert.equal(first.tagName, 'details');
  assert.equal(first.firstChild.tagName, 'summary');
  assert.equal(first.open, false);
  assert(!visibleText(first).includes('Extra information'));
  first.open = true; first.dispatch('toggle');
  assert.equal(ui.more('More details', 'test-section').open, true);
  assert.equal(ui.more('More details', 'different-section').open, false);
  first.open = false; first.dispatch('toggle');
  assert.equal(ui.more('More details', 'test-section').open, false);
});

test('focusing an optional input opens every containing disclosure', () => {
  const { ui, document } = harness();
  const outer = new Element('details'), inner = new Element('details');
  const control = document.getElementById('templateId'); outer.append(inner); inner.append(control);
  ui.revealControl('templateId');
  assert.equal(outer.open, true); assert.equal(inner.open, true); assert.equal(control.focused, true);
});

test('the strategy chooser includes only matchable templates, never education or standalone risk tools', async () => {
  const { ui, elements } = harness();
  await ui.loadTemplates();
  const actual = elements.get('templateId').options.map(option => option.value).filter(Boolean);
  assert.deepEqual(actual.sort(), TEMPLATES.filter(template => template.matchable === true).map(template => template.id).sort());
  for (const id of ['atr', 'ict', 'wyckoff', 'order_flow']) assert(!actual.includes(id), `${id} must not become an allocation template`);
  for (const id of ['rsi', 'price_action']) assert(actual.includes(id));
});

test('new schools are visible, but education and ATR cards cannot select or generate a matched allocation', () => {
  const { ui, elements } = harness(); ui.renderTemplates();
  const cards = all(elements.get('template-list'), node => node.tagName === 'article' && String(node.className || '').split(/\s+/).includes('template-card'));
  for (const id of ['rsi', 'price_action', 'atr', 'ict', 'wyckoff', 'order_flow']) {
    const template = TEMPLATES.find(item => item.id === id);
    assert(template, id);
    const card = cards.find(item => all(item, node => /^h[1-6]$/.test(node.tagName)).some(heading => heading.textContent === template.shortLabel || heading.textContent === template.name));
    assert(card, `${id} must be discoverable`);
    assert(find(card, node => node.tagName === 'summary'), `${id} must offer optional detail`);
    if (template.matchable !== true) assert.equal(all(card, node => node.tagName === 'button').length, 0, `${id} must not offer allocation actions`);
  }
  const text = elements.get('template-list').textContent;
  for (const ticker of ['NVDA', 'QQQ', 'TSLA']) assert(text.includes(ticker), `${ticker} learning example is retained`);
});

test('the portfolio keeps its main loss warning visible while source metadata starts collapsed', () => {
  const { ui, elements, input } = harness();
  ui.state.profile = { ...input }; ui.state.signature = ui.signature(input); ui.state.match = createMatch(input);
  ui.renderPortfolio(); const area = elements.get('portfolio-content');
  assert.match(visibleText(area), /losses can exceed|actual loss could be larger/i);
  const sourceDetails = find(area, node => node.tagName === 'details' && node.attributes['data-detail-key'] === 'plan-source');
  assert(sourceDetails); assert.equal(sourceDetails.open, false);
  assert(sourceDetails.textContent.includes(ui.state.match.template.source.title));
});

test('the prepared research page starts simple and empty advanced renderers do not expand it', () => {
  const openingTag = html.match(/<details\b[^>]*id="research-tools"[^>]*>/)?.[0];
  assert(openingTag, 'Advanced research tools must remain a native disclosure');
  assert.doesNotMatch(openingTag, /\sopen(?:\s|=|>)/);
  const { ui, document } = harness();
  const tools = document.getElementById('research-tools');
  ui.renderReport(); ui.renderUploadedDocument();
  assert.equal(tools.open, false);
  assert.equal(document.getElementById('report-content').hidden, true);
  assert.equal(document.getElementById('uploaded-report-content').hidden, true);
  assert(html.indexOf('id="demo-prepared-report"') < html.indexOf('id="research-tools"'), 'Prepared report stays before optional tools');
});

test('research source gaps remain visible while full research and provenance are available on request', () => {
  const { ui, elements, input, document } = harness();
  const tools = document.getElementById('research-tools');
  assert.equal(tools.open, false);
  ui.state.report = {
    id: 'beginner-test', title: 'A saved test report', status: 'partial', profile: input,
    generatedAt: '2026-10-04T00:00:00Z',
    provenance: { engine: 'TradingAgents', repository: 'https://github.com/TauricResearch/TradingAgents', dataSources: [{ title: 'Unique provenance marker', url: 'https://example.com/source' }] },
    research: [{ ticker: 'VTI', status: 'complete', decision: 'Review', dataQuality: { status: 'limited', engineCompleted: true, message: 'Macro source missing: test coverage gap.' }, sections: [{ title: 'Evidence', text: 'Unique full research marker' }] }],
    outlook: [], backtest: { status: 'unavailable' }, limitations: ['Partial source coverage.'],
  };
  ui.renderReport(); const area = elements.get('report-content');
  assert.equal(area.hidden, false);
  assert.equal(tools.open, true, 'Opening saved or generated research reveals its containing tools panel');
  assert(visibleText(area).includes('Macro source missing: test coverage gap.'));
  assert(!visibleText(area).includes('Unique full research marker'));
  const body = find(area, node => node._text === 'Unique full research marker');
  assert(body && collapsedAncestor(body));
  const provenance = find(area, node => node._text === 'Unique provenance marker');
  assert(provenance && collapsedAncestor(provenance));
  tools.open = false; ui.state.selectedResearchType = 'uploaded'; ui.renderReport();
  assert.equal(area.hidden, true);
  assert.equal(tools.open, false, 'An inactive cached report does not expand the tools');
});

for (const withHorizon of [false, true]) test(`uploaded original text stays inert and collapsed (${withHorizon ? 'with' : 'without'} a horizon heading)`, () => {
  const { ui, elements, document } = harness();
  const tools = document.getElementById('research-tools');
  assert.equal(tools.open, false);
  const payload = '<img src=x onerror="alert(1)"><script>alert(2)</script>';
  const uploaded = parseUploadedReport({ filename: 'review.md', text: '# Research\n' + (withHorizon ? '## 6–12 months\n' : '') + payload, id: 'test-inert', importedAt: '2026-10-04T06:00:00Z' });
  ui.state.uploadedDocument = uploaded; ui.state.selectedResearchType = 'uploaded'; ui.renderUploadedDocument();
  const area = elements.get('uploaded-report-content');
  assert.equal(area.hidden, false);
  assert.equal(tools.open, true, 'Opening an uploaded document reveals its containing tools panel');
  assert.equal(all(area, node => ['img', 'script', 'iframe'].includes(node.tagName)).length, 0);
  const source = find(area, node => node.tagName === 'pre' && node._text === uploaded.originalText);
  assert(source, 'Full original is preserved as text');
  const detail = collapsedAncestor(source); assert(detail, 'Original text is optional even if no horizon was extracted');
  detail.open = true;
  assert(visibleText(detail).includes(payload));
  assert.match(visibleText(area), /importing does not|not independently verified|unverified|original.*inputs|does not verify/i);
  tools.open = false; ui.state.selectedResearchType = 'generated'; ui.renderUploadedDocument();
  assert.equal(area.hidden, true);
  assert.equal(tools.open, false, 'An inactive upload does not expand the tools');
});
