import unittest
from collections import UserDict
from datetime import datetime
import pandas as pd
from worker.yahoo_intraday import valid_request, instrument_metadata, latest_completed_bar, fetch_one


class YahooIntradayTests(unittest.TestCase):
    def meta(self, **changes):
        return {"symbol": "NVDA", "currency": "USD", "exchangeName": "NMS", "instrumentType": "EQUITY", "exchangeTimezoneName": "America/New_York", "longName": "NVIDIA Corporation", **changes}

    def frame(self, dates):
        return pd.DataFrame({"Open": [100.0]*len(dates), "High": [102.0]*len(dates), "Low": [99.0]*len(dates), "Close": [101.0]*len(dates), "Volume": [1000]*len(dates)}, index=pd.DatetimeIndex(dates))

    def test_request_is_bounded(self):
        self.assertEqual(valid_request({"tickers": ["NVDA", "BRK.B"]}), ["NVDA", "BRK.B"])
        for value in (["AAPL", "AAPL"], ["../.env"], ["aapl"], "NVDA"):
            with self.assertRaises(ValueError): valid_request({"tickers": value})

    def test_metadata_requires_us_identity(self):
        self.assertTrue(instrument_metadata("NVDA", self.meta())["verified"])
        for update in ({"currency": "HKD"}, {"symbol": "AMD"}, {"exchangeName": "HKG"}, {"instrumentType": "INDEX"}):
            with self.assertRaises(ValueError): instrument_metadata("NVDA", self.meta(**update))
        with self.assertRaises(ValueError): instrument_metadata("SPCX", self.meta(symbol="SPCX", longName="Old SPAC ETF"))

    def test_yfinance_mapping_and_timestamp_metadata(self):
        meta=UserDict(self.meta(currentTradingPeriod={"regular":{"start":pd.Timestamp("2026-10-02T13:30:00Z"),"end":pd.Timestamp("2026-10-02T20:00:00Z")}}))
        result=instrument_metadata("NVDA",meta)
        self.assertEqual(result["session"]["end"]-result["session"]["start"],6.5*3600)

    def test_latest_bar_discards_unfinished_and_old_issuer(self):
        now = datetime.fromisoformat("2026-10-02T15:02:00+00:00").timestamp()
        frame = self.frame(["2026-10-02T15:00:00Z", "2026-10-02T15:02:00Z"])
        self.assertEqual(latest_completed_bar("NVDA", frame, now)["t"], "2026-10-02T15:00:00+00:00")
        with self.assertRaises(ValueError): latest_completed_bar("SPCX", self.frame(["2026-04-02T15:00:00Z"]), now)

    def test_invalid_latest_price_is_not_replaced_by_older_price(self):
        frame = self.frame(["2026-10-02T15:00:00Z", "2026-10-02T15:01:00Z"])
        frame.iloc[-1, frame.columns.get_loc("Close")] = float('nan')
        with self.assertRaises(ValueError): latest_completed_bar("NVDA", frame, datetime.fromisoformat("2026-10-02T15:02:00+00:00").timestamp())

    def test_fetch_uses_raw_regular_session_minutes(self):
        outer = self
        class Security:
            def history(self, **kwargs):
                outer.assertEqual(kwargs["interval"], "1m")
                outer.assertFalse(kwargs["auto_adjust"])
                outer.assertFalse(kwargs["prepost"])
                return outer.frame(["2026-10-02T15:00:00Z"])
            def get_history_metadata(self): return outer.meta()
        row=fetch_one("NVDA",factory=lambda _: Security(),now=datetime.fromisoformat("2026-10-02T15:02:00+00:00").timestamp())
        self.assertEqual(row["status"], "complete")
        self.assertEqual(row["bar"]["c"], 101)


if __name__ == '__main__':
    unittest.main()
