import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../public/workspace.js', import.meta.url), 'utf8').replace(/\r\n/g, '\n');
function functionSource(name) {
  const start = source.search(new RegExp(`^(?:async )?function ${name}\\(`, 'm'));
  assert(start >= 0, `${name} must exist`);
  const remaining = source.slice(start), end = remaining.indexOf('\n}\n') + 2;
  assert(end > 1);
  return remaining.slice(0, end);
}
class Element {
  constructor(tag = 'div', text = '') { this.tagName = tag; this.children = []; this._text = text; this.hidden = false; }
  append(...children) { this.children.push(...children); }
  replaceChildren(...children) { this.children = children; this._text = ''; }
  get textContent() { return this._text + this.children.map(child => child?.textContent || '').join(' '); }
  set textContent(value) { this._text = value; this.children = []; }
  querySelector() { return null; }
  scrollIntoView(options) { this.scrolled = options; }
  setAttribute(name, value) { this[name] = value; }
  focus() { this.focused = true; }
}
const find = (node, label) => node.tagName === 'button' && node.textContent === label ? node : node.children.map(child => find(child, label)).find(Boolean);
function harness({ popup = null } = {}) {
  const nodes = new Map(), stored = new Map(), timers = new Map(), calls = [], announcements = [];
  let timerSequence = 0, renderCount = 0, actionsUpdated = 0, handler;
  const profile = { budget: 10000 };
  const selection = { tickers: ['AMD', 'NVDA'], weights: { AMD: 20, NVDA: 0 }, plan: { allocations: [{ ticker: 'AMD', weight: 20, amount: 2000 }, { ticker: 'NVDA', weight: 0, amount: 0 }, { ticker: 'CASH', weight: 80, amount: 8000 }] } };
  let selectionError;
  const state = { job: { id: 'private-job', status: 'running', createdAt: '2026-10-04T00:00:00Z' }, jobToken: 'private-token', jobProfile: profile, report: null, generatedReport: null, reportExample: false, selectedResearchType: 'generated', pollFailures: 0, pollTimer: null, health: { worker: { online: true }, selectedStockResearch: true }, profile, match: { id: 'match', eligible: true, template: { id: 'balanced', name: 'Balanced' } }, sessionToken: 'confirmed-session', signature: JSON.stringify(profile) };
  const $ = id => { if (!nodes.has(id)) nodes.set(id, new Element()); return nodes.get(id); };
  const context = vm.createContext({
    state, $, portableMode: false, structuredClone, encodeURIComponent, Date, JSON, document: { activeElement: null }, reportPopup: popup,
    node: (tag, _className, text) => new Element(tag, text || ''),
    append: (parent, ...children) => { parent.append(...children); return parent; },
    button: (label, _className, action) => { const result = new Element('button', label); result.click = action; return result; },
    snapshot: () => new Element('p', 'Original job profile'), date: value => value || '', humanize: value => value, stringify: String,
    readResearchSelection: () => { if (selectionError) throw selectionError; return selection; },
    allocationTable: rows => new Element('table', rows.map(row => `${row.ticker}: ${row.weight}% / $${row.amount}`).join(' ')),
    more: (label, _key, ...children) => { const result = new Element('details', label); result.append(...children.filter(Boolean)); return result; },
    pct: value => `${value}%`, usd: { format: value => `$${value}` },
    announce: (...args) => announcements.push(args),
    updateResearchAction: () => { actionsUpdated++; }, renderReport: () => { renderCount++; },
    setTab: () => {}, isStale: () => false, signature: JSON.stringify, readProfile: () => profile, validateProfile: value => value,
    request: async (...args) => { calls.push(args); return handler(...args); },
    setTimeout: (callback, delay) => { const id = ++timerSequence; timers.set(id, { callback, delay }); return id; },
    clearTimeout: id => timers.delete(id),
    sessionStorage: { setItem: (key, value) => stored.set(key, value), getItem: key => stored.get(key), removeItem: key => stored.delete(key) },
  });
  vm.runInContext(`const jobStorageKey = 'private-job-test';\n${['startResearch', 'recordedResearchInputs', 'renderJob', 'openGeneratedReport', 'pollResearch', 'loadExample', 'rememberJob', 'restoreJob'].map(functionSource).join('\n')}\nglobalThis.ui = {startResearch, recordedResearchInputs, renderJob, openGeneratedReport, pollResearch, loadExample, rememberJob, restoreJob};`, context);
  return { state, ui: context.ui, $, stored, timers, calls, announcements, selection, setSelectionError: value => { selectionError = value; }, setHandler: value => { handler = value; }, get renderCount() { return renderCount; }, get actionsUpdated() { return actionsUpdated; } };
}
const report = { id: 'private-job', status: 'partial', title: 'Private generated report' };
const complete = { job: { id: 'private-job', status: 'partial' }, report, worker: { online: true } };

test('completion caches the private report without displacing an example; its open button restores it', async () => {
  const h = harness(), example = { id: 'example', title: 'Public saved example' };
  h.state.report = example; h.state.reportExample = true; h.setHandler(async () => complete);
  await h.ui.pollResearch();
  assert.equal(h.state.report, example); assert.equal(h.state.generatedReport, report); assert.equal(h.renderCount, 0);
  const open = find(h.$('job-status'), 'Open generated report'); assert(open);
  open.click(); assert.equal(h.state.report, report); assert.equal(h.state.reportExample, false); assert.equal(h.renderCount, 1);
  assert.equal(h.$('research-tools').open, true);
  assert.equal(h.$('report-content').focused, true);
  assert.equal(h.$('report-content').scrolled.block, 'start');
  assert.equal(h.calls[0][1].headers['X-Report-Token'], 'private-token');
});
test('completion preserves an uploaded document until the generated report is explicitly opened', async () => {
  const h = harness(); h.state.selectedResearchType = 'uploaded'; h.$('uploaded-report-content').hidden = false; h.setHandler(async () => complete);
  await h.ui.pollResearch();
  assert.equal(h.state.selectedResearchType, 'uploaded'); assert.equal(h.state.report, null); assert.equal(h.$('uploaded-report-content').hidden, false);
  find(h.$('job-status'), 'Open generated report').click();
  assert.equal(h.state.selectedResearchType, 'generated'); assert.equal(h.$('uploaded-report-content').hidden, true); assert.equal(h.state.report, report);
  assert.equal(h.$('research-tools').open, true); assert.equal(h.$('report-content').focused, true);
});

test('the generated button opens the matching private report in the popup, including original inputs', () => {
  const shown = [];
  const h = harness({ popup: { openGenerated(options) { shown.push(options); options.render(new Element()); return true; } } });
  h.state.job.status = 'partial';
  const actual = { ...report, generatedAt: '2026-10-04T07:57:00Z', profile: { budget: 13000 }, research: [{ ticker: 'NVDA' }] };
  h.state.generatedReport = actual; h.state.report = { id: 'prepared-example' }; h.state.reportExample = true;
  h.ui.renderJob(); find(h.$('job-status'), 'Open generated report').click();
  assert.equal(h.state.report, actual); assert.equal(h.state.report.profile.budget, 13000);
  assert.equal(shown.length, 1); assert.match(shown[0].reportNote, /07:57:00Z/); assert.match(shown[0].reportNote, /NVDA/);
  assert.equal(shown[0].reportTitle, 'Private generated report');
  assert.equal(h.$('report-content').focused, undefined, 'A successful popup does not scroll the background document');
  assert.equal(h.renderCount, 2); assert.equal(h.calls.length, 0, 'Opening existing research makes no new request');
  find(h.$('job-status'), 'Open generated report').click();
  assert.equal(shown.length, 2); assert.equal(h.state.report, actual);
});

test('failed popup opens and focuses the report inline; a mismatched cache cannot replace the current view', () => {
  const h = harness({ popup: { openGenerated() { return false; } } });
  h.state.generatedReport = report; h.ui.openGeneratedReport();
  assert.equal(h.$('report-content').focused, true); assert.equal(h.$('research-tools').open, true);
  assert.equal(h.calls.length, 0);
  const shown = h.state.report; h.state.generatedReport = { id: 'other-job' }; h.ui.openGeneratedReport();
  assert.equal(h.state.report, shown); assert.match(h.announcements.at(-1)[0], /no matching generated report/);
});
test('opening a saved example after completion retains access to the private generated result', async () => {
  const h = harness(); h.state.job.status = 'partial'; h.state.report = report; h.state.generatedReport = report;
  const example = { id: 'example' }; h.setHandler(async () => ({ report: example }));
  await h.ui.loadExample('example'); assert.equal(h.state.report, example); assert.equal(h.state.generatedReport, report);
  find(h.$('job-status'), 'Open generated report').click(); assert.equal(h.state.report, report);
});
test('a missing private task stops polling, clears obsolete persistence and releases the in-progress state', async () => {
  const h = harness(), example = { id: 'example' }; h.state.report = example; h.state.reportExample = true;
  h.ui.rememberJob(); assert(h.stored.size > 0);
  h.setHandler(async () => { throw Object.assign(new Error('Report not found'), { status: 404 }); });
  await h.ui.pollResearch();
  assert.equal(h.state.job.status, 'unavailable'); assert.equal(h.state.jobToken, null); assert.equal(h.state.report, example);
  assert.equal(h.stored.size, 0); assert.equal(h.timers.size, 0); assert.equal(h.calls.length, 1); assert(h.actionsUpdated > 0);
  assert.match(h.$('job-status').textContent, /no new request was submitted automatically/);
});
test('temporary network failures retain the job and token for a bounded retry', async () => {
  const h = harness(); h.setHandler(async () => { throw new Error('Temporary connection failure'); });
  await h.ui.pollResearch(); assert.equal(h.state.job.status, 'running'); assert.equal(h.state.jobToken, 'private-token'); assert.equal([...h.timers.values()][0].delay, 7000);
});
test('a mismatched report cannot replace the current document or enter the generated cache', async () => {
  const h = harness(); h.setHandler(async () => ({ ...complete, report: { ...report, id: 'other-job' } }));
  await h.ui.pollResearch(); assert.equal(h.state.generatedReport, null); assert.equal(h.state.report, null); assert.equal(h.state.job.status, 'running'); assert.match(h.$('job-status').textContent, /different task/);
});
test('a new explicit research request resets only the new-job cache and preserves authenticated original inputs', async () => {
  const h = harness(); h.state.job.status = 'partial'; h.state.generatedReport = report;
  h.setHandler(async path => path === '/api/research' ? { job: { id: 'next-job', status: 'queued' }, accessToken: 'next-private-token' } : { job: { id: 'next-job', status: 'queued' } });
  await h.ui.startResearch();
  assert.equal(h.state.generatedReport, null); assert.equal(h.state.job.id, 'next-job'); assert.equal(h.state.jobToken, 'next-private-token');
  assert.equal(h.calls[0][1].body.profile.budget, 10000); assert.equal(h.calls[0][1].body.matchId, 'match'); assert.equal(h.calls[0][1].headers['X-Session-Token'], 'confirmed-session');
  assert.deepEqual(h.calls[0][1].body.researchSelection, { tickers: ['AMD', 'NVDA'], weights: { AMD: 20, NVDA: 0 } });
});

test('invalid current research selections and unsupported servers never submit a new task', async () => {
  for (const message of ['Choose at least one stock.', 'Selected weights exceed 100%.']) {
    const h = harness(); h.state.job = null; h.setSelectionError(new Error(message));
    await h.ui.startResearch();
    assert.equal(h.calls.length, 0); assert(h.announcements.some(item => item[0].includes(message)));
  }
  const oldServer = harness(); oldServer.state.job = null; oldServer.state.health.selectedStockResearch = false;
  await oldServer.ui.startResearch();
  assert.equal(oldServer.calls.length, 0);
});

test('a pending request freezes its selected tickers and weights before later UI edits', async () => {
  const h = harness(); h.state.job = null;
  let accepted;
  const inputSnapshot = { profile: { budget: 10000 }, template: { id: 'balanced', name: 'Balanced' }, allocations: structuredClone(h.selection.plan.allocations), researchTickers: ['AMD', 'NVDA'], source: 'user-selected' };
  h.setHandler((url) => url === '/api/research' ? new Promise(resolve => { accepted = resolve; }) : Promise.resolve({ job: { id: 'next-job', status: 'queued' } }));
  const pending = h.ui.startResearch();
  assert.equal(h.calls.length, 1);
  h.selection.tickers.splice(0, 2, 'TSLA'); h.selection.weights.AMD = 99; h.selection.weights.TSLA = 1;
  accepted({ job: { id: 'next-job', status: 'queued', inputSnapshot }, accessToken: 'next-token' });
  await pending; await Promise.resolve();
  assert.deepEqual(h.calls[0][1].body.researchSelection, { tickers: ['AMD', 'NVDA'], weights: { AMD: 20, NVDA: 0 } });
  assert.deepEqual(h.state.job.inputSnapshot, inputSnapshot);
  assert.match(h.$('job-status').textContent, /AMD/); assert.match(h.$('job-status').textContent, /NVDA/);
  assert.doesNotMatch(h.$('job-status').textContent, /TSLA/);
  const saved = JSON.parse([...h.stored.values()][0]);
  assert.deepEqual(saved.job.inputSnapshot, inputSnapshot);
});

test('stored snapshots survive restoration and same-job poll responses that omit them', async () => {
  const h = harness();
  const inputSnapshot = { profile: { budget: 10000 }, template: { id: 'balanced', name: 'Balanced' }, allocations: structuredClone(h.selection.plan.allocations), researchTickers: ['AMD', 'NVDA'], source: 'user-selected' };
  h.state.job.inputSnapshot = inputSnapshot; h.ui.rememberJob();
  h.state.job = null; h.state.jobProfile = null;
  h.setHandler(async () => ({ job: { id: 'private-job', status: 'running' } }));
  h.ui.restoreJob(); await Promise.resolve(); await Promise.resolve();
  assert.deepEqual(h.state.job.inputSnapshot, inputSnapshot);
  assert.match(h.$('job-status').textContent, /AMD/); assert.match(h.$('job-status').textContent, /NVDA/);
  h.selection.tickers.splice(0, 2, 'TSLA'); h.ui.renderJob();
  assert.match(h.$('job-status').textContent, /AMD/); assert.doesNotMatch(h.$('job-status').textContent, /TSLA/);
});

test('legacy tasks use only their matching report scope and never the current or prepared selection', () => {
  const h = harness();
  h.state.generatedReport = { ...report, id: 'prepared-example', match: { allocations: [{ ticker: 'GLD', weight: 100, amount: 10000 }] }, research: [{ ticker: 'GLD' }] };
  h.ui.renderJob();
  assert.match(h.$('job-status').textContent, /not recorded/);
  assert.doesNotMatch(h.$('job-status').textContent, /AMD|NVDA|GLD/);
  h.state.generatedReport = { ...report, match: { allocations: [{ ticker: 'VTI', weight: 100, amount: 10000 }] }, research: [{ ticker: 'VTI' }] };
  h.ui.renderJob();
  assert.match(h.$('job-status').textContent, /VTI/); assert.doesNotMatch(h.$('job-status').textContent, /AMD|NVDA|GLD/);
});

test('restored custom reports preserve requested watch-only symbols even without a completed asset result', () => {
  const h = harness();
  h.state.generatedReport = { ...report, match: { researchSelection: { tickers: ['AMD', 'NVDA'] }, allocations: structuredClone(h.selection.plan.allocations) }, research: [{ ticker: 'AMD' }] };
  const inputs = h.ui.recordedResearchInputs(h.state.job, h.state.generatedReport);
  assert.deepEqual(Array.from(inputs.researchTickers), ['AMD', 'NVDA']);
  h.ui.renderJob(); assert.match(h.$('job-status').textContent, /Submitted research inputs: AMD, NVDA/);
});

test('malformed persisted task metadata cannot break the research status renderer', () => {
  const h = harness();
  for (const inputSnapshot of [{}, { researchTickers: null, allocations: 'invalid' }, { researchTickers: 'NVDA', allocations: [] }]) {
    h.state.job.inputSnapshot = inputSnapshot;
    assert.doesNotThrow(() => h.ui.renderJob());
    assert.doesNotMatch(h.$('job-status').textContent, /Submitted research inputs: AMD, NVDA/);
  }
});
