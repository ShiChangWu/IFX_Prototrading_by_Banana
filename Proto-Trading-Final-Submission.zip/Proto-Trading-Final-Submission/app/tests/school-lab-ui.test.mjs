import test from 'node:test';
import assert from 'node:assert/strict';
import { createSchoolLab } from '../public/school-lab.js';
import { SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { scoreSchoolFit } from '../shared/school-fit.mjs';
class Element{constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.style={};this.events={};this._text='';this.value='';this.hidden=false;}append(...items){this.children.push(...items);}replaceChildren(...items){this.children=[];this._text='';this.append(...items);}set textContent(value){this._text=String(value);this.children=[];}get textContent(){return this._text+this.children.map(child=>child.textContent).join(' ');}setAttribute(k,v){this.attributes[k]=v;}addEventListener(k,fn){this.events[k]=fn;}click(){if(!this.disabled)this.events.click?.();}}
const all=(root,predicate)=>[...(predicate(root)?[root]:[]),...root.children.flatMap(child=>all(child,predicate))];
function harness(options={}){const charts=[],downloads=[];const document={createElement:tag=>new Element(tag)};const lab=createSchoolLab(document,{chart(series,label){charts.push({series,label});return new Element('svg');},download(...args){downloads.push(args);},...options});const find=fn=>all(lab.element,fn)[0];return{lab,find,charts,downloads};}
test('strategy search, selection, date and fee controls run a real historical calculation and export its exact inputs',()=>{
  const h=harness();const search=h.find(e=>e.type==='search');search.value='RSI';search.events.input();assert.equal(all(h.lab.element,e=>String(e.className).startsWith('school-choice')&&e.tagName==='button').length,1);
  h.find(e=>e.tagName==='button'&&e.textContent.startsWith('RSI recovery')).click();
  const input=suffix=>h.find(e=>e.id?.endsWith('-'+suffix));input('start').value='2026-01-02';input('end').value='2026-10-02';input('fee').value='0.25';
  h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();assert.equal(h.charts.length,1);assert.match(h.lab.element.textContent,/0.25% fee/);
  input('fee').value='0.50';input('fee').events.input();assert.match(h.lab.element.textContent,/Settings changed/);
  h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();assert.equal(h.charts.length,2);
  h.find(e=>e.tagName==='button'&&e.textContent==='Download this test').click();assert.equal(h.downloads[0][0].parameters.feePct,.5);assert.equal(h.downloads[0][0].schoolId,'rsi');assert.equal(h.downloads[0][0].requested.startDate,'2026-01-02');
});
test('unsupported data has an explanation and cannot emit a fake chart; invalid fees clear old results',()=>{
  const h=harness();h.lab.select('order_flow');assert.match(h.lab.element.textContent,/Requires tick trades/);const run=h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test');assert.equal(run.disabled,true);run.click();assert.equal(h.charts.length,0);
  h.lab.select('trend');h.find(e=>e.id?.endsWith('-fee')).value='';h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();assert.match(h.lab.element.textContent,/Enter a fee/);assert.equal(h.charts.length,0);
});
test('only selected stocks are offered and remain selected across strategy switches',()=>{
  const h=harness({selectedTickers:['AMD','NVDA'],initialSchool:'balanced'});
  const tickers=()=>h.find(e=>e.id?.endsWith('-ticker'));
  assert.deepEqual(tickers().children.map(e=>e.value),['AMD','NVDA']);
  tickers().value='NVDA';tickers().events.change();h.lab.select('rsi');assert.equal(tickers().value,'NVDA');
  h.lab.select('balanced');assert.deepEqual(tickers().children.map(e=>e.value),['AMD','NVDA']);
  h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();assert.equal(h.charts.length,1);
  h.lab.setSelection({tickers:['NVDA','UNLISTED'],assets:[{ticker:'UNLISTED',name:'User selected security'}],budget:2500});
  assert.equal(tickers().value,'NVDA');assert.match(tickers().textContent,/User selected security/);assert.equal(h.find(e=>e.id?.endsWith('-budget')).value,'2500');
  tickers().value='UNLISTED';tickers().events.change();assert.match(h.lab.element.textContent,/No verified historical data is packaged for UNLISTED/);
  assert.equal(h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').disabled,true);
  h.lab.setSelection({tickers:[]});assert.match(h.lab.element.textContent,/Choose stocks in Your plan first/);assert.equal(tickers(),undefined);
});
test('each strategy has its own conditions instead of a generic fall/rise percentage form',()=>{
  const h=harness({selectedTickers:['NVDA'],initialSchool:'rsi',market:[{ticker:'NVDA',price:200.123456,currency:'USD',barEnd:'2026-01-02T20:00:00Z'}]});
  const input=suffix=>h.find(e=>e.id?.endsWith('-scenario-'+suffix));
  assert.match(h.lab.element.textContent,/Older observation/);assert.match(h.lab.element.textContent,/\$200\.12/);
  assert.equal(input('fall'),undefined);assert.equal(input('rise'),undefined);assert.equal(input('base'),undefined);
  assert.match(h.lab.element.textContent,/Recovery: consider an entry review/);assert.match(h.lab.element.textContent,/No holding recorded/);
  input('nextRsi').value='75';input('nextRsi').events.input();assert.match(h.lab.element.textContent,/Recovery: consider an entry review/);assert.doesNotMatch(h.lab.element.textContent,/High RSI: review an exit/);
  h.lab.setSelection({holdings:[{ticker:'NVDA',quantity:2.5}]});assert.match(h.lab.element.textContent,/Recorded holding: 2.5 shares/);assert.match(h.lab.element.textContent,/High RSI: review an exit/);assert.equal(input('nextRsi').value,'75');
  h.lab.select('trend');assert.match(h.lab.element.textContent,/No fixed profit target/);assert.equal(input('nextRsi'),undefined);assert(input('event'));
  input('event').value='down';input('event').events.change();assert.match(h.lab.element.textContent,/Review an exit for held shares/);
  const fee=h.find(e=>e.id?.endsWith('-fee'));fee.value='0.75';fee.events.input();
  h.lab.setSelection({market:[{ticker:'NVDA',price:300,currency:'USD',barEnd:'2026-01-03T20:00:00Z'}]});assert.equal(h.find(e=>e.id?.endsWith('-fee')).value,'0.75');assert.equal(input('event').value,'down');
  h.lab.select('rsi');assert.equal(input('nextRsi').value,'75');input('nextRsi').value='101';input('nextRsi').events.input();assert.match(h.lab.element.textContent,/Enter RSI values from 0 to 100/);
});
test('missing indicators never become an invented quote or a learning-only trading signal',()=>{
  const h=harness({selectedTickers:['ZZZZ'],initialSchool:'ict'});
  const input=suffix=>h.find(e=>e.id?.endsWith('-scenario-'+suffix));
  assert.equal(input('base'),undefined);assert.match(h.lab.element.textContent,/No verified saved price is available for ZZZZ/);
  assert.match(h.lab.element.textContent,/Learning only — data not connected/);assert.doesNotMatch(h.lab.element.textContent,/falls 5% to/);
  h.lab.select('atr');assert.equal(input('atr').value,'');assert.match(h.lab.element.textContent,/No indicator is invented/);
  input('highestClose').value='100';input('highestClose').events.input();input('atr').value='4';input('atr').events.input();input('nextClose').value='93';input('nextClose').events.input();
  assert.match(h.lab.element.textContent,/Example trailing level: \$94\.00/);assert.match(h.lab.element.textContent,/review selling held ZZZZ/);
});

test('ten scenario guides are distinct and keep all stock context tied to the selected ticker',()=>{
  const h=harness({selectedTickers:['AMD','NVDA'],initialSchool:'balanced'}),headings=new Set();
  const input=suffix=>h.find(e=>e.id?.endsWith('-'+suffix));
  input('ticker').value='NVDA';input('ticker').events.change();
  for(const id of Object.keys(SCHOOL_TESTS)){
    h.lab.select(id);const scenario=h.find(e=>e.attributes['data-scenario-school']===id);
    const heading=all(scenario,e=>e.tagName==='h4')[0].textContent;headings.add(heading);
    assert(heading.startsWith('NVDA · '));assert.doesNotMatch(scenario.textContent,/If the price falls|If the price rises/);
    assert.match(scenario.textContent,/not forecasts, live alerts or orders/);
  }
  assert.equal(headings.size,10);
  h.lab.select('atr');const atr=input('scenario-atr');assert.match(atr.value,/^\d+(\.\d{1,2})?$/);
  atr.value='10';atr.events.input();input('ticker').value='AMD';input('ticker').events.change();assert.notEqual(input('scenario-atr').value,'10');
  input('ticker').value='NVDA';input('ticker').events.change();assert.equal(input('scenario-atr').value,'10');
});

test('every approach has a concise explanation and a score for the current selection, including expanded guides',()=>{
  const h=harness({selectedTickers:['AMD','NVDA']});
  h.find(e=>e.tagName==='button'&&e.textContent.startsWith('More approaches:')).click();
  for(const id of Object.keys(SCHOOL_TESTS)){
    const card=h.find(e=>e.attributes['data-school']===id);
    const explanation=all(card,e=>e.attributes['data-approach-explanation']===id)[0];
    assert(explanation?.textContent.length>60,'Each approach needs an actual explanation, not just a name');
    assert(card.textContent.includes(`${scoreSchoolFit(id,{tickers:['AMD','NVDA']},SCHOOL_PRICES).score}/100 fit`));
    assert(explanation.textContent.split(/\s+/).length<=32,'Keep the beginner explanation brief');
  }
  const trend=()=>h.find(e=>e.attributes['data-school']==='trend').textContent;
  const initial=trend();h.lab.setSelection({tickers:['SGOV']});assert.notEqual(trend(),initial);
  assert(h.lab.element.textContent.includes('For SGOV.'));
  h.lab.select('trend');assert(h.lab.element.textContent.includes(`SGOV · ${scoreSchoolFit('trend',{tickers:['SGOV']},SCHOOL_PRICES).score}/100`));
  h.lab.setSelection({tickers:[]});assert(trend().includes('Choose stocks'));assert(!trend().includes('/100'));
});

test('every selected strategy explains its mechanics before the stock and scenario controls',()=>{
  const h=harness({selectedTickers:['AMD','NVDA']});
  const mechanisms={defensive:/reserve.*quarter/,balanced:/different assets.*5 percentage points/,trend:/20-day.*100-day.*Crossing above/,mean_reversion:/lower band.*recover inside/,rsi:/0–100.*above 30.*70/,price_action:/previously turned.*daily price pattern confirms/,atr:/daily price swings.*does not tell you when to buy/,wyckoff:/earlier low.*more shares trade.*not the full Wyckoff/,ict:/Learning only.*not connected/,order_flow:/Learning only.*no tick trades or order-book feed/};
  for(const id of Object.keys(SCHOOL_TESTS)){
    h.lab.select(id);const detail=h.find(e=>e.className==='school-lab-detail');
    const explanation=h.find(e=>e.attributes['data-selected-explanation']===id);
    const card=h.find(e=>e.attributes['data-approach-explanation']===id);
    assert.match(explanation.textContent,/^How it works/);assert.match(explanation.textContent,mechanisms[id]);
    assert(explanation.textContent.includes(card.textContent));assert.equal(explanation.hidden,false);
    assert(detail.children.indexOf(explanation)<detail.children.findIndex(e=>e.className==='school-test-fields'));
    assert.deepEqual(h.find(e=>e.id?.endsWith('-ticker')).children.map(e=>e.value),['AMD','NVDA']);
  }
  h.lab.setSelection({tickers:[]});assert(h.find(e=>e.attributes['data-selected-explanation']==='order_flow'),'Explanation remains readable before choosing a stock');
});

test('unchanged selection updates and fresh quotes preserve a completed historical test and edited inputs',()=>{
  const assets=[{ticker:'NVDA',name:'NVIDIA',assetClass:'stock'}];
  const h=harness({selectedTickers:['NVDA'],assets,initialSchool:'rsi',market:{quotes:{NVDA:{price:200,currency:'USD',barEnd:'2026-01-02T20:00:00Z'}}}});
  const input=suffix=>h.find(e=>e.id?.endsWith('-'+suffix));
  const run=()=>h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();
  input('start').value='2026-01-02';input('start').events.input();input('fee').value='0.25';input('fee').events.input();run();
  const output=h.find(e=>e.className==='school-test-output'),previousText=output.textContent,previousChildren=[...output.children],fee=input('fee');
  assert.equal(h.charts.length,1);
  h.lab.setSelection({tickers:['NVDA'],assets:[{name:'NVIDIA',assetClass:'stock',ticker:'NVDA'}],budget:10000,schoolId:'rsi',market:{quotes:{NVDA:{barEnd:'2026-01-02T20:00:00Z',currency:'USD',price:200}}},holdings:[]});
  assert.equal(h.find(e=>e.className==='school-test-output'),output);assert.deepEqual(output.children,previousChildren);assert.equal(input('fee'),fee);
  h.lab.setSelection({market:{quotes:{NVDA:{price:220,currency:'USD',barEnd:'2026-01-03T20:00:00Z'}}},holdings:[{ticker:'NVDA',quantity:3}]});
  assert.equal(output.textContent,previousText);assert.deepEqual(output.children,previousChildren);assert.equal(h.charts.length,1);
  assert.match(h.lab.element.textContent,/Retrieved NVDA price: \$220\.00/);assert.match(h.lab.element.textContent,/Recorded holding: 3 shares/);
  input('fee').value='0.50';input('fee').events.input();assert.match(h.lab.element.textContent,/Settings changed/);
  h.lab.setSelection({market:{quotes:{NVDA:{price:230,currency:'USD',barEnd:'2026-01-04T20:00:00Z'}}}});
  assert.equal(input('fee').value,'0.50');assert.match(h.lab.element.textContent,/Settings changed/);assert.equal(output.textContent,previousText);
  h.find(e=>e.tagName==='button'&&e.textContent==='Download this test').click();
  assert.equal(h.downloads[0][0].parameters.feePct,.25,'The retained result and download keep their original inputs until recalculation');
});

test('a genuinely changed stock selection clears the previous ticker result while retaining valid test settings',()=>{
  const h=harness({selectedTickers:['AMD','NVDA'],initialSchool:'rsi'});
  const input=suffix=>h.find(e=>e.id?.endsWith('-'+suffix));
  input('fee').value='0.75';input('fee').events.input();
  h.find(e=>e.tagName==='button'&&e.textContent==='Run this rule test').click();
  assert.match(h.find(e=>e.className==='school-test-output').textContent,/AMD · RSI recovery/);
  h.lab.setSelection({tickers:['NVDA']});
  assert.equal(input('ticker').value,'NVDA');assert.equal(h.find(e=>e.className==='school-test-output').children.length,0);
  h.lab.setSelection({tickers:['AMD']});assert.equal(input('ticker').value,'AMD');assert.equal(input('fee').value,'0.75');
  assert.equal(h.find(e=>e.className==='school-test-output').children.length,0,'Changing back does not display stale performance without rerunning');
  h.lab.setSelection({tickers:[]});assert.equal(input('ticker'),undefined);assert.equal(h.find(e=>e.className==='school-test-output'),undefined);
  h.lab.setSelection({market:{quotes:{AMD:{price:200}}},holdings:[{ticker:'AMD',quantity:2}]});
  assert.match(h.lab.element.textContent,/Choose stocks in Your plan first/);assert.equal(h.find(e=>e.className==='school-test-output'),undefined);
});
