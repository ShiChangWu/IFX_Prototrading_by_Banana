import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { configureLocal } from '../scripts/configure.mjs';
import { seedBundledExample, validateBundledExample } from '../scripts/seed-example.mjs';
import { createMatch, DEFAULT_PROFILE, validateProfile } from '../shared/strategy.mjs';
import { createApi } from '../server/api.mjs';
import { LocalStore } from '../server/store.mjs';
import { configuration } from '../server/config.mjs';

async function directory(t) {
  const root = await fs.mkdtemp(path.join(os.tmpdir(), 'proto-configure-test-'));
  t.after(async () => {
    const absolute = path.resolve(root);
    assert.equal(path.dirname(absolute), path.resolve(os.tmpdir()));
    assert.ok(path.basename(absolute).startsWith('proto-configure-test-'));
    await fs.rm(absolute, { recursive: true, force: true });
  });
  await fs.writeFile(path.join(root, '.env.example'), 'WORKER_SECRET=\nDEEPSEEK_API_KEY=\n');
  return root;
}

// Synthetic research is restricted to isolated test directories. It is never a
// deliverable report or a claim that TradingAgents ran during these tests.
function fixture() {
  const profile = validateProfile(DEFAULT_PROFILE), match = createMatch(profile);
  return { id: 'test-example-only', title: 'TEST FIXTURE — NOT REAL RESEARCH', status: 'partial',
    generatedAt: '2026-10-04T01:00:00.000Z', analysisDate: '2026-10-02', profile, match,
    provenance: { engine: 'TauricResearch/TradingAgents', repository: 'https://github.com/TauricResearch/TradingAgents', commit: 'a'.repeat(40), model: 'test-only', templateVersion: match.template.version, dataSources: [], warnings: ['Automated test fixture only.'] },
    research: [{ ticker: match.allocations.find(a => a.ticker !== 'CASH').ticker, status: 'complete', sections: [{ title: 'Test', text: 'No live research performed.' }] }],
    outlook: [], backtest: { status: 'unavailable', warnings: ['Test only.'] }, limitations: ['Test fixture.'] };
}
async function example(root, report = fixture()) {
  await fs.mkdir(path.join(root, 'examples'));
  await fs.writeFile(path.join(root, 'examples', 'demo-report.json'), JSON.stringify(report));
  return report;
}

test('first run seeds only the approved report shape into an empty public-example state', async t => {
  const root = await directory(t), report = await example(root);
  const result = await configureLocal(root, { log() {} });
  assert.equal(result.created, true); assert.equal(result.example.status, 'seeded');
  const stateFile = path.join(root, '.local', 'state.json');
  const state = JSON.parse(await fs.readFile(stateFile, 'utf8'));
  assert.equal(state.schema, 1);
  for (const key of ['sessions', 'workers', 'limits']) assert.deepEqual(state[key], {});
  assert.equal(Object.keys(state.jobs).length, 1);
  const job = state.jobs[report.id];
  assert.equal(job.published, true); assert.deepEqual(job.report, report);
  for (const key of ['sessionHash', 'accessHash', 'accessToken', 'workerId', 'leaseToken']) assert.equal(Object.hasOwn(job, key), false);
  const api = createApi({ config: configuration({}), store: new LocalStore(stateFile) });
  const listed = await (await api(new Request('http://localhost:8787/api/examples'))).json();
  assert.deepEqual(listed.reports.map(r => r.id), [report.id]);
  const loaded = await (await api(new Request(`http://localhost:8787/api/examples/${report.id}`))).json();
  assert.deepEqual(loaded.report, report);
});

test('an explicitly unknown saved revision imports without inventing or changing provenance', async t => {
  const root = await directory(t), report = fixture();
  report.provenance.commit = 'unknown';
  await example(root, report);
  assert.equal((await configureLocal(root, { log() {} })).example.status, 'seeded');
  const state = JSON.parse(await fs.readFile(path.join(root, '.local', 'state.json'), 'utf8'));
  assert.deepEqual(state.jobs[report.id].report, report);
  assert.equal(state.jobs[report.id].report.provenance.commit, 'unknown');
});

test('existing recipient configuration and state remain byte-for-byte unchanged', async t => {
  const root = await directory(t);
  await example(root, { invalid: 'ignored because state exists' });
  await fs.mkdir(path.join(root, '.local'));
  const preserved = '{"private":"existing opaque data must not be read or rewritten"}\n';
  await fs.writeFile(path.join(root, '.local', 'state.json'), preserved);
  await fs.writeFile(path.join(root, '.env.local'), 'TEST_ONLY=preserve-me\n');
  assert.deepEqual(await configureLocal(root, { log() {} }), { created: false, example: { status: 'existing' } });
  assert.equal(await fs.readFile(path.join(root, '.local', 'state.json'), 'utf8'), preserved);
  assert.equal(await fs.readFile(path.join(root, '.env.local'), 'utf8'), 'TEST_ONLY=preserve-me\n');
});

test('optional absent bundle creates no persistent research state', async t => {
  const root = await directory(t);
  assert.equal((await configureLocal(root, { log() {} })).example.status, 'absent');
  await assert.rejects(fs.access(path.join(root, '.local', 'state.json')), { code: 'ENOENT' });
});

test('concurrent first runs use exclusive creation without replacing either winner', async t => {
  const root = await directory(t); await example(root);
  const results = await Promise.all(Array.from({ length: 5 }, () => configureLocal(root, { log() {} })));
  assert.equal(results.filter(r => r.created).length, 1);
  assert.equal(results.filter(r => r.example.status === 'seeded').length, 1);
  const configuration = await fs.readFile(path.join(root, '.env.local'), 'utf8');
  assert.match(configuration, /^WORKER_SECRET=[A-Za-z0-9_-]{64}\nDEEPSEEK_API_KEY=\n$/);
  assert.equal(Object.keys(JSON.parse(await fs.readFile(path.join(root, '.local', 'state.json'), 'utf8')).jobs).length, 1);
});

test('invalid report identity, provenance, questionnaire and credentials cannot seed state', async t => {
  for (const mutate of [
    r => { r.id = '../private'; }, r => { r.status = 'running'; },
    r => { r.provenance.repository = 'https://example.com/fake'; },
    r => { r.provenance.commit = 'invented'; }, r => { r.provenance.commit = ''; },
    r => { delete r.provenance.commit; }, r => { r.provenance.commit = ['a'.repeat(40)]; },
    r => { r.profile.budget = -1; },
    r => { r.profile.unexpected = true; }, r => { r.research = []; },
    r => { r.research[0].ticker = 'UNASSIGNED'; }, r => { r.accessToken = 'test-secret'; },
  ]) {
    const report = fixture(); mutate(report);
    assert.throws(() => validateBundledExample(report), /Bundled example was not imported/);
  }
  const root = await directory(t); await example(root, { status: 'running' });
  await assert.rejects(seedBundledExample(root), /Bundled example was not imported/);
  await assert.rejects(fs.access(path.join(root, '.local', 'state.json')), { code: 'ENOENT' });
});
