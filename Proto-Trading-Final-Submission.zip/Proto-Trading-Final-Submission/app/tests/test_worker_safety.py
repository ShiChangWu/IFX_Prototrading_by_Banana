import os
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import patch

from worker.main import API, load_env, repository_commit, research_asset, selected_assets
from worker.outlook import build_outlook, validate_outlook
from worker.quality import review_report_quality
from worker.tls import configure_trusted_ca


class WorkerSafetyTests(unittest.TestCase):
    def test_packaged_revision_is_strict_and_never_discovers_parent_git(self):
        with tempfile.TemporaryDirectory() as directory:
            app = Path(directory)
            (app / ".git").mkdir()  # This is NOT the vendor repository.
            vendor = app / "vendor" / "TradingAgents"
            vendor.mkdir(parents=True)
            metadata = app / "VENDOR-REVISION.txt"
            expected = "1394a3f72aa4393e1a98f51b382434c4b4c2d972"
            with patch("worker.main.APP", app), patch("worker.main.subprocess.run") as git:
                self.assertEqual(repository_commit(), "unknown")
                metadata.write_text(expected.upper() + "\n", encoding="utf-8")
                self.assertEqual(repository_commit(), expected)
                for invalid in ("HEAD", expected[:-1], expected + "garbage", "z" * 40):
                    metadata.write_text(invalid, encoding="utf-8")
                    self.assertEqual(repository_commit(), "unknown")
                git.assert_not_called()

    def test_missing_key_never_starts_research_or_returns_invented_result(self):
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": ""}):
            with patch("worker.main.subprocess.Popen") as process:
                result = research_asset({}, {"ticker": "SPY"}, Path("unused"), "2024-01-01", 20, threading.Event())
        process.assert_not_called()
        self.assertEqual(result["status"], "error")
        self.assertEqual(result["sections"], [])

    def test_no_completed_research_means_no_outlook(self):
        with patch.dict(os.environ, {"DEEPSEEK_API_KEY": "unit-test-only"}):
            result = build_outlook([], {}, request_fn=lambda _: self.fail("API must not be called"))
        self.assertTrue(all(item["status"] == "unavailable" for item in result))

    def test_fabricated_or_wrong_horizon_quote_is_rejected(self):
        text = "Over the next 2 weeks the source expects volatility to remain elevated."
        sources = {"SPY:0": {"ticker": "SPY", "section": "Market", "text": text}}
        wrong = {"outlook": [{"horizon": "6–12 months", "status": "available", "summary": "Unsupported extension", "evidence": [{"sourceId": "SPY:0", "quote": text}]}]}
        self.assertEqual(validate_outlook(wrong, sources)[2]["status"], "unavailable")
        invented = {"outlook": [{"horizon": "1–4 weeks", "status": "available", "summary": "Unsupported", "evidence": [{"sourceId": "SPY:0", "quote": "In the next 2 weeks prices will certainly double."}]}]}
        self.assertEqual(validate_outlook(invented, sources)[0]["status"], "unavailable")

    def test_exact_time_supported_quote_is_accepted(self):
        text = "Over the next 2 weeks the source expects volatility to remain elevated."
        sources = {"SPY:0": {"ticker": "SPY", "section": "Market", "text": text}}
        payload = {"outlook": [{"horizon": "1–4 weeks", "status": "available", "summary": "The research sees elevated near-term volatility.", "evidence": [{"sourceId": "SPY:0", "quote": text}], "conditions": []}]}
        self.assertEqual(validate_outlook(payload, sources)[0]["status"], "available")

    def test_only_top_three_non_cash_holdings_are_researched(self):
        allocations = [{"ticker": t, "weight": w} for t, w in [("CASH", 40), ("A", 10), ("B", 20), ("C", 15), ("D", 15)]]
        with patch.dict(os.environ, {"RESEARCH_MAX_TICKERS": "99"}):
            result = selected_assets({"allocations": allocations})
        self.assertEqual([a["ticker"] for a in result], ["B", "C", "D"])

    def test_public_plain_http_and_embedded_credentials_are_rejected(self):
        for url in ("http://example.com", "https://user:pass@example.com", "https://example.com?key=secret"):
            with self.assertRaises(ValueError):
                API(url, "test-only")
        self.assertIsInstance(API("http://127.0.0.1:8787", "test-only"), API)

    def test_env_is_parsed_without_expansion_and_existing_value_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / "settings"
            file.write_text('TEST_WORKER_VALUE="$(do-not-run)"\nTEST_WORKER_KEEP=new\n', encoding="utf-8")
            with patch.dict(os.environ, {"TEST_WORKER_KEEP": "existing"}):
                os.environ.pop("TEST_WORKER_VALUE", None)
                load_env(file)
                self.assertEqual(os.environ["TEST_WORKER_VALUE"], "$(do-not-run)")
                self.assertEqual(os.environ["TEST_WORKER_KEEP"], "existing")

    def test_engine_finished_with_failed_market_data_is_partial_without_rewriting_history(self):
        original = {"status": "complete", "generatedAt": "2026-10-04T00:00:00Z",
                    "research": [{"ticker": "VTI", "status": "complete", "sections": [
                        {"title": "Market", "text": "All price tools returned DATA_UNAVAILABLE because of SSLError."}]}],
                    "provenance": {"warnings": []}}
        result = review_report_quality(original)
        self.assertEqual(result["status"], "partial")
        self.assertEqual(result["generatedAt"], original["generatedAt"])
        self.assertEqual(original["status"], "complete")
        self.assertEqual(result["research"][0]["dataQuality"]["status"], "limited")

    def test_quality_review_replaces_only_obsolete_generated_warning(self):
        old = "The analysis process finished, but source text reports unavailable or failed market-data retrieval."
        report = {"status": "complete", "research": [{"ticker": "VTI", "status": "complete",
            "sections": [{"title": "News", "text": "FRED macro observations: DATA_UNAVAILABLE. Verified market prices are available separately."}],
            "warnings": [old, "ETF fundamentals were intentionally excluded."]}], "provenance": {"warnings": []}}
        reviewed = review_report_quality(report)
        warnings = reviewed["research"][0]["warnings"]
        self.assertNotIn(old, warnings)
        self.assertIn("ETF fundamentals were intentionally excluded.", warnings)
        self.assertIn("Some research sources were unavailable", reviewed["research"][0]["dataQuality"]["message"])
        self.assertIn(old, report["research"][0]["warnings"])

    def test_missing_configured_ca_is_an_error_not_verification_bypass(self):
        with patch.dict(os.environ, {"SSL_CERT_FILE": "missing-test-ca-does-not-exist.pem"}):
            with self.assertRaises(ValueError):
                configure_trusted_ca()

    def test_explicit_trust_bundle_is_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / "operator-trust.pem"
            file.write_text("test file; no network calls", encoding="ascii")
            with patch.dict(os.environ, {}, clear=True):
                os.environ["CURL_CA_BUNDLE"] = str(file)
                result = configure_trusted_ca()
                self.assertTrue(result["verification"])
                self.assertEqual(os.environ["SSL_CERT_FILE"], str(file))
                self.assertEqual(os.environ["REQUESTS_CA_BUNDLE"], str(file))

    @unittest.skipUnless(os.name == "nt", "Windows libcurl Unicode CAINFO regression")
    def test_windows_unicode_ca_path_is_relocated_without_changing_trust_material(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "\u8bc1\u4e66.pem"
            content = "public certificate fixture; no network"
            source.write_text(content, encoding="ascii")
            destination = Path(directory) / "ascii-ca"
            destination.mkdir()
            with patch.dict(os.environ, {}, clear=True), patch("worker.tls._ascii_cache_directory", return_value=destination):
                os.environ["SSL_CERT_FILE"] = str(source)
                result = configure_trusted_ca()
                self.assertTrue(result["asciiPath"])
                self.assertTrue(result["verification"])
                self.assertEqual(Path(os.environ["SSL_CERT_FILE"]).read_text(), content)
                self.assertNotEqual(os.environ["SSL_CERT_FILE"], str(source))


if __name__ == "__main__":
    unittest.main()
