import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import { initTradePage } from '../public/trade.js';

class Element {
  constructor(tag) { this.tagName = tag; this.children = []; this.attributes = {}; this.events = {}; this._text = ''; this.value = ''; this.checked = false; this.disabled = false; }
  append(...items) { this.children.push(...items); }
  replaceChildren(...items) { this.children = []; this._text = ''; this.append(...items); }
  set textContent(value) { this._text = String(value); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent).join(' '); }
  setAttribute(k, v) { this.attributes[k] = v; }
  addEventListener(k, fn) { this.events[k] = fn; }
  async click() { if (!this.disabled) await this.events.click?.({ currentTarget: this }); }
}
const all = (root, predicate) => [...(predicate(root) ? [root] : []), ...root.children.flatMap(child => all(child, predicate))];
const token = 'A'.repeat(43);
function harness(link, handler, hash = '#token=' + token) {
  const root = new Element('div'), calls = [], replaced = [];
  const result = initTradePage({ document: { getElementById: () => root, createElement: tag => new Element(tag) }, location: { hash, pathname: '/trade.html' }, history: { replaceState: (...args) => replaced.push(args) }, now: () => Date.parse('2026-10-04T10:00:00Z'), crypto: { randomUUID: () => 'a2af1dfc-6a7a-4836-bdca-253060d3b3fe' }, fetchImpl: async (path, options) => {
    const body = JSON.parse(options.body); calls.push({ path, options, body }); if (handler) return handler(path, options, body);
    return { ok: true, json: async () => path === '/api/tracking/link' ? link : { message: 'Saved.' } };
  } });
  const find = predicate => all(root, predicate)[0];
  return { root, calls, replaced, ready: result.ready, find, button: text => find(e => e.tagName === 'button' && e.textContent === text), input: suffix => find(e => e.id === 'trade-' + suffix) };
}
test('a private verification link is removed from the address bar and does not mutate until clicked', async () => {
  const h = harness({ purpose: 'verify', email: 'user@gmail.com', used: false }); await h.ready;
  assert.equal(h.replaced[0][2], '/trade.html'); assert.equal(h.calls.length, 1); assert.equal(h.calls[0].path, '/api/tracking/link'); assert.equal(h.calls[0].options.referrerPolicy, 'no-referrer'); assert.equal(h.calls[0].options.credentials, 'omit'); assert.equal(h.root.textContent.includes(token), false);
  await h.button('Confirm this email address').click(); assert.equal(h.calls.length, 2); assert.deepEqual(h.calls[1].body, { token }); assert.match(h.root.textContent, /Email address confirmed/); assert.equal(h.button('Confirm this email address'), undefined);
});
test('unsubscribe requires an explicit confirmation and an already-used link offers no mutation', async () => {
  const h = harness({ purpose: 'stop', used: false }); await h.ready; assert.equal(h.calls.length, 1); await h.button('Turn off email reminders').click(); assert.equal(h.calls[1].path, '/api/tracking/confirm'); assert.match(h.root.textContent, /Email reminders are off/);
  const used = harness({ purpose: 'fill', ticker: 'AMD', side: 'buy', used: true }); await used.ready; assert.equal(used.calls.length, 1); assert.match(used.root.textContent, /already been used/); assert.equal(used.button('Save my completed trade'), undefined);
});
test('a fill requires actual values and acknowledgment, fixes ticker and side, and retries with a stable key', async () => {
  let attempts = 0;
  const link = { purpose: 'fill', ticker: 'AMD', side: 'buy', used: false, positions: [] };
  const h = harness(link, async (path, options, body) => { if (path === '/api/tracking/confirm' && ++attempts === 1) throw new TypeError('offline'); return { ok: true, json: async () => path === '/api/tracking/link' ? link : { message: 'Recorded.' } }; }); await h.ready;
  assert.equal(h.input('quantity').value, ''); assert.equal(h.input('price').value, ''); assert.equal(h.input('executed').value, '');
  await h.button('Save my completed trade').click(); assert.match(h.root.textContent, /Confirm that you already completed/); assert.equal(h.calls.length, 1);
  h.input('ack').checked = true; h.input('quantity').value = '2.5'; h.input('price').value = '120.75'; h.input('executed').value = '2026-10-02T10:30';
  await h.button('Save my completed trade').click(); assert.match(h.root.textContent, /Cannot reach/); assert.equal(h.input('quantity').disabled, false);
  await h.button('Save my completed trade').click(); const saved = h.calls.filter(c => c.path === '/api/tracking/confirm'); assert.equal(saved.length, 2); assert.equal(saved[0].body.idempotencyKey, saved[1].body.idempotencyKey); assert.equal(saved[1].body.ticker, 'AMD'); assert.equal(saved[1].body.side, 'buy'); assert.equal(saved[1].body.quantity, 2.5); assert.equal(saved[1].body.price, 120.75); assert.equal(saved[1].body.executedAt, new Date('2026-10-02T10:30').toISOString()); assert.match(h.root.textContent, /completed trade is recorded/); assert.equal(h.button('Save my completed trade'), undefined);
});
test('oversells, future trades and missing bearer tokens cannot submit a record', async () => {
  const h = harness({ purpose: 'fill', ticker: 'NVDA', side: 'sell', used: false, positions: [{ ticker: 'NVDA', quantity: 3 }] }); await h.ready;
  h.input('ack').checked = true; h.input('quantity').value = '4'; h.input('price').value = '100'; h.input('executed').value = '2026-10-02T10:30'; await h.button('Save my completed trade').click(); assert.match(h.root.textContent, /holding is 3/);
  h.input('quantity').value = '1'; h.input('executed').value = '2027-10-02T10:30'; await h.button('Save my completed trade').click(); assert.match(h.root.textContent, /not a future time/); assert.equal(h.calls.length, 1);
  const missing = harness(null, null, ''); await missing.ready; assert.equal(missing.calls.length, 0); assert.match(missing.root.textContent, /complete private link/);
});
test('standalone page has no external assets, no workspace boot code and a no-referrer policy', async () => {
  const html = await fs.readFile(new URL('../public/trade.html', import.meta.url), 'utf8');
  assert.match(html, /name="referrer" content="no-referrer"/); assert.match(html, /src="\/trade.js"/); assert.doesNotMatch(html, /src="https?:|workspace.js|onboarding.js|analytics/i);
});
