import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {PassThrough} from 'node:stream';
import {validateYahooQuote,getYahooIntradayQuotes,getYahooAsset,createYahooAdapter} from '../server/yahoo-intraday.mjs';

const now=Date.parse('2026-10-02T15:02:00Z');
function row(ticker='NVDA',time='2026-10-02T15:00:00Z'){
 return {ticker,status:'complete',bar:{t:time,o:100,h:102,l:99,c:101,v:500},instrument:{ticker,symbol:ticker,name:ticker==='SPCX'?'SpaceX Class A':'NVIDIA Corporation',currency:'USD',exchange:'NMS',instrumentType:'EQUITY',timezone:'America/New_York',verified:true,session:{start:Date.parse('2026-10-02T13:30:00Z')/1000,end:Date.parse('2026-10-02T20:00:00Z')/1000}}};
}
test('Yahoo accepts only a completed fresh minute in the verified US session',()=>{
 const quote=validateYahooQuote(row(),'NVDA',now);assert.equal(quote.status,'complete');assert.equal(quote.price,101);assert.equal(quote.eligibleForAlerts,true);assert.equal(quote.source,'Yahoo Finance');
 assert.equal(validateYahooQuote(row('NVDA','2026-10-02T15:02:00Z'),'NVDA',now).code,'YAHOO_INCOMPLETE_BAR');
 const invalid=row();invalid.bar.l=103;assert.equal(validateYahooQuote(invalid,'NVDA',now).status,'unavailable');
});
test('Yahoo retains dated prices on weekends and rejects stale or delayed alerts',()=>{
 const delayed=validateYahooQuote(row('NVDA','2026-10-02T14:50:00Z'),'NVDA',now);assert.equal(delayed.status,'delayed');assert.equal(delayed.eligibleForAlerts,false);assert.equal(delayed.price,101);
 const stale=validateYahooQuote(row('NVDA','2026-10-02T14:00:00Z'),'NVDA',now);assert.equal(stale.status,'stale');assert.equal(stale.eligibleForAlerts,false);
 const weekend=validateYahooQuote(row(),'NVDA',Date.parse('2026-10-04T05:00:00Z'));assert.equal(weekend.status,'market_closed');assert.equal(weekend.price,101);assert.equal(weekend.eligibleForAlerts,false);
});
test('Yahoo verifies exact identity, currency, exchange and issuer boundary',()=>{
 for(const [key,value]of [['symbol','AMD'],['currency','HKD'],['exchange','HKG'],['timezone','Europe/London'],['instrumentType','CRYPTOCURRENCY']]){const data=row();data.instrument[key]=value;assert.equal(validateYahooQuote(data,'NVDA',now).status,'unavailable');}
 const old=row('SPCX','2026-04-01T14:00:00Z');assert.equal(validateYahooQuote(old,'SPCX',now).code,'YAHOO_ISSUER_HISTORY');
 const wrong=row('SPCX');wrong.instrument.name='Old SPC ETF';assert.equal(validateYahooQuote(wrong,'SPCX',now).code,'YAHOO_IDENTITY_UNVERIFIED');
 const noClock=row();delete noClock.instrument.session;assert.equal(validateYahooQuote(noClock,'NVDA',now).eligibleForAlerts,false);
});
test('Yahoo batch ignores duplicates, rejects cloud, and preserves missing rows',async()=>{
 const data=await getYahooIntradayQuotes(['NVDA','AMD'],{mode:'local'},{now:()=>now,provider:async()=>({rows:[row()]})});assert.equal(data.status,'partial');assert.equal(data.quotes.AMD.status,'unavailable');
 const repeated=await getYahooIntradayQuotes(['NVDA'],{}, {now,provider:async()=>({rows:[row(),row()]})});assert.equal(repeated.quotes.NVDA.code,'YAHOO_MISSING_BAR');
 let called=false;const cloud=await getYahooIntradayQuotes(['NVDA'],{mode:'netlify'},{now,provider:async()=>{called=true;}});assert.equal(cloud.code,'YAHOO_LOCAL_ONLY');assert.equal(called,false);
 await assert.rejects(()=>getYahooIntradayQuotes(['AAPL','AAPL']),/unique/);
});
test('Yahoo registry compatibility does not discard a verified weekend listing',async()=>{
 const result=await getYahooAsset('NVDA',{}, {now:Date.parse('2026-10-04T05:00:00Z'),provider:async()=>({rows:[row()]})});assert.equal(result.status,'complete');assert.equal(result.assetClass,'us_equity');assert.equal(result.source,'Yahoo Finance listing metadata');
});
function fakeProcess(){const child=new EventEmitter();child.stdout=new PassThrough();child.stderr=new PassThrough();child.stdin=new PassThrough();return child;}
test('Yahoo process passes only safe environment and bounded request to an owned child',async()=>{
 let options,input='';const child=fakeProcess();child.stdin.on('data',chunk=>input+=chunk);
 const provider=createYahooAdapter({env:{PATH:'safe',DEEPSEEK_API_KEY:'secret',GMAIL_APP_PASSWORD:'hidden'},spawnImpl:(_path,args,opts)=>{options=opts;assert.deepEqual(args,['-m','worker.yahoo_intraday']);queueMicrotask(()=>{child.stdout.write(JSON.stringify({rows:[row()]}));child.emit('close',0);});return child;}});
 const result=await provider(['NVDA']);assert.equal(result.rows[0].ticker,'NVDA');assert.equal(options.env.DEEPSEEK_API_KEY,undefined);assert.equal(options.env.GMAIL_APP_PASSWORD,undefined);assert.equal(options.windowsHide,true);assert.deepEqual(JSON.parse(input),{tickers:['NVDA']});
});
test('Yahoo process timeout and output overflow terminate only the directly owned child',async()=>{
 for(const overflow of [false,true]){const child=fakeProcess();let stopped=null;const provider=createYahooAdapter({timeoutMs:5,maxOutputBytes:20,spawnImpl:()=>{if(overflow)queueMicrotask(()=>child.stdout.write('x'.repeat(21)));return child;},stopChild:async value=>{stopped=value;return true;}});const result=await provider(['NVDA']);assert.equal(result.code,overflow?'YAHOO_RESPONSE_LIMIT':'YAHOO_TIMEOUT');assert.equal(stopped,child);}
});
