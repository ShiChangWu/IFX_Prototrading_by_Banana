import time
import unittest
from types import SimpleNamespace

import pandas as pd

from worker.stock_search import catalog_from_frames, retrieve_catalog


class StockSearchTests(unittest.TestCase):
    def test_exact_provider_codes_names_and_no_quote_or_currency_claim(self):
        frame = pd.DataFrame([{"\u4ee3\u7801": "105.TSLA", "\u540d\u79f0": "Tesla", "\u6700\u65b0\u4ef7": 999},
                              {"\u4ee3\u7801": "106.BRK.B", "\u540d\u79f0": "Berkshire Hathaway"}])
        result = catalog_from_frames([frame], fetched_at="2026-10-04T00:00:00Z")
        self.assertEqual(result["rows"], [
            {"ticker": "BRK.B", "name": "Berkshire Hathaway", "providerSymbol": "106.BRK.B"},
            {"ticker": "TSLA", "name": "Tesla", "providerSymbol": "105.TSLA"}])
        self.assertEqual(result["scope"], "well_known_us")
        self.assertNotIn("currency", result["rows"][0])
        self.assertNotIn("price", result["rows"][0])

    def test_rejects_ambiguous_ticker_malformed_code_and_old_spcx(self):
        frame = pd.DataFrame([
            {"\u4ee3\u7801": "105.ABC", "\u540d\u79f0": "One"}, {"\u4ee3\u7801": "106.ABC", "\u540d\u79f0": "Another"},
            {"\u4ee3\u7801": "105.SPCX", "\u540d\u79f0": "The SPAC and New Issue ETF"},
            {"\u4ee3\u7801": "105.SPEr", "\u540d\u79f0": "Rights"}, {"\u4ee3\u7801": "105.A;bad", "\u540d\u79f0": "Unsafe"},
            {"\u4ee3\u7801": "AAPL", "\u540d\u79f0": "No verified exchange code"},
            {"\u4ee3\u7801": "105.TSLA", "\u540d\u79f0": "Tesla"}])
        result = catalog_from_frames([frame])
        self.assertEqual([row["ticker"] for row in result["rows"]], ["TSLA"])
        self.assertEqual(result["droppedRows"], 5)

    def test_partial_categories_finish_without_waiting_for_stalled_source(self):
        def lookup(symbol):
            if symbol == "\u79d1\u6280\u7c7b":
                return pd.DataFrame([{"\u4ee3\u7801": "105.TSLA", "\u540d\u79f0": "Tesla"}])
            time.sleep(.25)
            raise RuntimeError("test source unavailable")
        started = time.monotonic()
        result = retrieve_catalog(ak=SimpleNamespace(stock_us_famous_spot_em=lookup), timeout=.03)
        self.assertLess(time.monotonic() - started, .2)
        self.assertEqual(result["completedGroups"], 1)
        self.assertEqual(result["requestedGroups"], 6)
        self.assertEqual(result["scope"], "well_known_us")

    def test_full_catalog_and_empty_failures_do_not_turn_into_fake_results(self):
        ak = SimpleNamespace(stock_us_spot_em=lambda: pd.DataFrame([{"\u4ee3\u7801": "105.SPCX", "\u540d\u79f0": "Space Exploration Technologies"}]))
        self.assertEqual(retrieve_catalog(ak=ak, full=True)["scope"], "all_us")
        with self.assertRaises(ValueError):
            catalog_from_frames([])


if __name__ == "__main__":
    unittest.main()
