import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreSchoolFit, SCHOOL_BLURBS, SCHOOL_FIT_RUBRIC } from '../shared/school-fit.mjs';
import { SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';

function fixture(tickers = ['NVDA'], count = 120) {
  const bars = [];
  for (let stamp = Date.parse('2026-01-02T00:00:00Z'); bars.length < count; stamp += 86400000) {
    const d = new Date(stamp); if ([0, 6].includes(d.getUTCDay())) continue;
    bars.push([d.toISOString().slice(0, 10), 100, 102, 99, 101, 1000]);
  }
  return { cutoffDate: bars.at(-1)?.[0] || '2026-01-02', stocks: Object.fromEntries(tickers.map(ticker => [ticker,
    { ticker, currency: 'USD', currencyVerified: true, adjusted: true, bars: structuredClone(bars) }])) };
}

test('all ten schools have a concise English introduction and transparent complete rubric', () => {
  assert.deepEqual(Object.keys(SCHOOL_BLURBS).sort(), Object.keys(SCHOOL_TESTS).sort());
  assert.deepEqual(SCHOOL_FIT_RUBRIC.weights, { assetCompatibility: 45, beginnerEase: 30, historyCoverage: 25 });
  for (const [schoolId, blurb] of Object.entries(SCHOOL_BLURBS)) {
    assert(blurb.split(/\s+/).length <= 15); assert.doesNotMatch(blurb, /[\u4e00-\u9fff]/);
    assert(SCHOOL_FIT_RUBRIC.beginnerEase[schoolId] >= 0 && SCHOOL_FIT_RUBRIC.beginnerEase[schoolId] <= 100);
    assert.equal(SCHOOL_FIT_RUBRIC.assetCompatibility[schoolId].unknown, 0);
    assert(Object.values(SCHOOL_FIT_RUBRIC.assetCompatibility[schoolId]).every(value => value >= 0 && value <= 100));
  }
});

test('score uses the published 45/30/25 formula and equal ticker influence, not money', () => {
  const dataset = fixture(['NVDA', 'VTI']);
  const params = { tickers: ['NVDA', 'VTI'], assets: [{ ticker: 'NVDA', weight: 99 }, { ticker: 'VTI', weight: 1 }] };
  const result = scoreSchoolFit('balanced', params, dataset);
  assert.equal(result.components.assetCompatibility.score, (70 + 90) / 2);
  assert.equal(result.components.beginnerEase.score, 95);
  assert.equal(result.components.historyCoverage.score, 100);
  assert.equal(result.rawScore, 80 * .45 + 95 * .30 + 100 * .25);
  assert.equal(result.score, 90); assert.equal(result.kind, 'educational_fit');
  const switched = scoreSchoolFit('balanced', { ...params, assets: [{ ticker: 'NVDA', weight: 1 }, { ticker: 'VTI', weight: 99 }] }, dataset);
  assert.deepEqual(result, switched);
});

test('selection normalization counts duplicates once, keeps eight maximum and never scores an empty selection', () => {
  const empty = scoreSchoolFit('balanced', { tickers: [] });
  assert.equal(empty.score, null); assert.equal(empty.rawScore, null); assert.equal(empty.components, null); assert.deepEqual(empty.perTicker, []);
  assert.equal(scoreSchoolFit('balanced', { tickers: ['CASH', '<script>', null] }).score, null);
  const result = scoreSchoolFit('balanced', { tickers: [' nvda ', 'NVDA', 'aapl', 'MSFT', 'VTI', 'QQQ', 'AMD', 'SGOV', 'IEF', 'GLD'] });
  assert.deepEqual(result.perTicker.map(row => row.ticker), ['NVDA', 'AAPL', 'MSFT', 'VTI', 'QQQ', 'AMD', 'SGOV', 'IEF']);
  assert(result.limits.some(line => /Repeated/.test(line))); assert(result.limits.some(line => /first eight/.test(line)));
  assert.throws(() => scoreSchoolFit('invented', { tickers: ['NVDA'] }), /maintained strategy/);
  assert.throws(() => scoreSchoolFit('constructor', { tickers: ['NVDA'] }), /maintained strategy/);
});

test('unknown selected assets remain in the average and remote type claims cannot override maintained data', () => {
  const dataset = fixture(['NVDA', 'NEWCO']);
  const result = scoreSchoolFit('balanced', { tickers: ['NVDA', 'NEWCO'], assets: [
    { ticker: 'NVDA', assetClass: 'short_treasury_etf' }, { ticker: 'NEWCO', assetClass: 'stock', etf: false },
  ] }, dataset);
  assert.equal(result.perTicker.length, 2);
  assert.equal(result.perTicker[0].assetClass, 'stock'); assert.equal(result.perTicker[1].assetClass, 'unknown');
  assert.equal(result.components.assetCompatibility.score, 35);
  assert.equal(result.perTicker[1].components.assetCompatibility.score, 0);
  assert(result.limits.some(line => /stay in the average/.test(line)));
});

test('verified history earns coverage only at warm-up plus two valid observations', () => {
  for (const [count, available] of [[101, false], [102, true]]) {
    const result = scoreSchoolFit('trend', { tickers: ['NVDA'] }, fixture(['NVDA'], count));
    assert.equal(result.perTicker[0].history.required, 102);
    assert.equal(result.perTicker[0].history.available, available);
    assert.equal(result.components.historyCoverage.score, available ? 100 : 0);
  }
  const good = fixture(['NVDA']);
  for (const change of [
    data => { data.stocks.NVDA.currency = 'HKD'; },
    data => { data.stocks.NVDA.currencyVerified = false; },
    data => { data.stocks.NVDA.adjusted = false; },
    data => { data.cutoffDate = '2026-02-30'; },
    data => { data.stocks.NVDA.bars[1][0] = data.stocks.NVDA.bars[0][0]; },
    data => { data.stocks.NVDA.bars[2][2] = 1; },
    data => { data.stocks.NVDA.bars[2][4] = NaN; },
    data => { data.stocks.NVDA.bars.at(-1)[0] = '2028-01-02'; },
  ]) {
    const data = structuredClone(good); change(data);
    assert.equal(scoreSchoolFit('trend', { tickers: ['NVDA'] }, data).components.historyCoverage.score, 0);
  }
});

test('SpaceX never earns coverage from the earlier unrelated SPCX security', () => {
  const result = scoreSchoolFit('balanced', { tickers: ['SPCX'] }, fixture(['SPCX']));
  assert.equal(result.components.historyCoverage.score, 0);
  assert.match(result.perTicker[0].history.reason, /security identity/);
  const actual = scoreSchoolFit('rsi', { tickers: ['SPCX'] }, SCHOOL_PRICES);
  assert.equal(actual.components.historyCoverage.score, 100);
  const longWarmup = scoreSchoolFit('trend', { tickers: ['SPCX'] }, SCHOOL_PRICES);
  assert.equal(longWarmup.components.historyCoverage.score, 0);
});

test('returns and prices do not change the score when valid coverage is unchanged', () => {
  const before = fixture(['NVDA']); const after = structuredClone(before);
  after.stocks.NVDA.bars.forEach((bar, index) => { for (const field of [1, 2, 3, 4]) bar[field] *= index + 1; });
  after.returnPct = 999; after.winRate = 100; after.aiRecommendation = 'BUY';
  assert.deepEqual(scoreSchoolFit('trend', { tickers: ['NVDA'] }, before), scoreSchoolFit('trend', { tickers: ['NVDA'] }, after));
});

test('unsupported schools are learning-only and capped while ATR remains a risk tool', () => {
  for (const schoolId of ['ict', 'order_flow']) {
    const result = scoreSchoolFit(schoolId, { tickers: ['NVDA'] }, fixture());
    assert.equal(result.learningOnly, true); assert.equal(result.cap, 20); assert.equal(result.score, 20);
    assert.equal(result.components.historyCoverage.score, 0); assert.equal(result.perTicker[0].score, 20);
    assert(result.limits.some(line => /Learning guide only/.test(line)));
  }
  const atr = scoreSchoolFit('atr', { tickers: ['NVDA'] }, fixture());
  assert.equal(atr.riskToolOnly, true); assert.match(atr.shortReason, /not a stock-entry/);
});

test('each school scores the full real selection with compact reasons without mutating inputs', () => {
  const input = { tickers: ['NVDA', 'VTI', 'SGOV', 'SPCX'], assets: [] };
  const original = structuredClone(input), prices = JSON.stringify(SCHOOL_PRICES);
  for (const schoolId of Object.keys(SCHOOL_TESTS)) {
    const result = scoreSchoolFit(schoolId, input, SCHOOL_PRICES);
    assert(Number.isInteger(result.score) && result.score >= 0 && result.score <= 100);
    assert.equal(result.perTicker.length, 4); assert(result.shortReason.split(/\s+/).length <= 10);
    assert(result.limits.some(line => /not a return forecast/.test(line)));
  }
  assert.deepEqual(input, original); assert.equal(JSON.stringify(SCHOOL_PRICES), prices);
});
