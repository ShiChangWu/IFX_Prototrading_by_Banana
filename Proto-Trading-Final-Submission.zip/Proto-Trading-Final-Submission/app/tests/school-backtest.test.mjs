import test from 'node:test';
import assert from 'node:assert/strict';
import { runSchoolBacktest, schoolIndicators, SCHOOL_TESTS } from '../shared/school-backtest.mjs';
import { SCHOOL_PRICES } from '../shared/school-prices.mjs';
import { ASSETS } from '../shared/strategy.mjs';

function fixture(count=160){const bars=[];for(let value=Date.parse('2025-01-02T00:00:00Z');bars.length<count;value+=86400000){const date=new Date(value);if([0,6].includes(date.getUTCDay()))continue;bars.push([date.toISOString().slice(0,10),99,101,98,100,1000]);}return{version:'TEST ONLY',cutoffDate:bars.at(-1)[0],fetchedAt:'2026-10-04T00:00:00Z',basis:'SYNTHETIC TEST FIXTURE',stocks:Object.fromEntries(['AAPL','NVDA','AMD','SPCX'].map(ticker=>[ticker,{ticker,currency:'USD',currencyVerified:true,adjusted:true,source:'SYNTHETIC TEST FIXTURE',sourceUrl:'https://example.invalid/',bars:structuredClone(bars)}]))};}
const request=(data,overrides={})=>({schoolId:'balanced',ticker:'AAPL',startDate:data.stocks.AAPL.bars[0][0],endDate:data.cutoffDate,feePct:.1,budget:10000,...overrides});
const near=(actual,expected)=>assert(Math.abs(actual-expected)<.000001,`${actual} vs ${expected}`);

test('buy-and-hold uses first open, final close and exact buy/sell costs for both paths',()=>{
  const data=fixture(3);data.stocks.AAPL.bars[0][1]=100;data.stocks.AAPL.bars[2]=[data.cutoffDate,109,111,108,110,1000];
  const result=runSchoolBacktest(request(data,{feePct:1}),data);
  near(result.metrics.endingValue,10000/1.01*1.1*.99);near(result.metrics.endingValue,result.benchmark.endingValue);
  assert.deepEqual(result.orders.map(order=>order.side),['buy','sell']);
  near(result.metrics.transactionCosts,10000/1.01*.01+10000/1.01*1.1*.01);
  near(result.series.at(-1).value,result.metrics.endingValue);
});
test('Wilder RSI and ATR are computed from dated earlier observations',()=>{
  const bars=Array.from({length:30},(_,i)=>({open:100+i,high:102+i,low:99+i,close:101+i}));
  const values=schoolIndicators(bars);assert.equal(values[13].rsi,null);assert.equal(values[14].rsi,100);near(values[13].atr,3);near(values.at(-1).atr,3);near(values[19].sma20,110.5);
  const flat=schoolIndicators(bars.map(bar=>({...bar,open:100,high:101,low:99,close:100})));assert.equal(flat[14].rsi,50);
});
test('Price Action and spring proxy enter only after the observed candle, at the next actual open',()=>{
  const data=fixture(45);for(const ticker of ['NVDA','AMD']){const bars=data.stocks[ticker].bars;bars[30]=[bars[30][0],99,101,95,100,3000];bars[31]=[bars[31][0],105,107,104,106,1000];}
  for(const [schoolId,ticker]of [['price_action','NVDA'],['wyckoff','AMD']]){const bars=data.stocks[ticker].bars;const result=runSchoolBacktest(request(data,{schoolId,ticker,startDate:bars[22][0]}),data);const buy=result.orders.find(order=>order.side==='buy');assert.equal(buy.date,bars[31][0]);assert.equal(buy.signalDate,bars[30][0]);assert.equal(buy.price,105);}
});
test('close-based ATR exits use the next opening gap, never a fabricated stop fill',()=>{
  const data=fixture(30),bars=data.stocks.NVDA.bars;
  bars[21]=[bars[21][0],100,101,89,90,1000];bars[22]=[bars[22][0],80,82,79,81,1000];
  const result=runSchoolBacktest(request(data,{schoolId:'atr',ticker:'NVDA',startDate:bars[20][0]}),data);
  const sale=result.orders.find(order=>order.side==='sell');assert.equal(sale.signalDate,bars[21][0]);assert.equal(sale.date,bars[22][0]);assert.equal(sale.price,80);assert(result.metrics.totalReturnPct<-19);
});
test('future bars cannot alter previous signals, execution or portfolio values',()=>{
  const data=fixture(160),bars=data.stocks.AMD.bars;
  for(let i=0;i<bars.length;i++){const price=100+20*Math.sin(i/7);bars[i]=[bars[i][0],price,price+2,price-2,price,1000];}
  const modified=structuredClone(data);for(let i=100;i<bars.length;i++)for(const field of [1,2,3,4])modified.stocks.AMD.bars[i][field]*=1.5;
  for(const schoolId of ['rsi','mean_reversion','price_action','wyckoff']){const params=request(data,{schoolId,ticker:'AMD',startDate:bars[25][0]});const before=runSchoolBacktest(params,data),after=runSchoolBacktest(params,modified),cutoff=bars[99][0];assert.deepEqual(before.series.filter(row=>row.date<=cutoff),after.series.filter(row=>row.date<=cutoff));assert.deepEqual(before.orders.filter(order=>order.date<=cutoff),after.orders.filter(order=>order.date<=cutoff));}
});
test('no trigger stays in cash; unsupported microstructure schools and invalid input never fabricate a result',()=>{
  const data=fixture();const result=runSchoolBacktest(request(data,{schoolId:'trend',startDate:data.stocks.AAPL.bars[105][0]}),data);assert.equal(result.orders.length,0);assert.equal(result.metrics.totalReturnPct,0);assert.equal(result.metrics.winRatePct,null);
  for(const override of [{schoolId:'order_flow'},{schoolId:'ict'},{feePct:-1},{feePct:NaN},{budget:0},{startDate:'2025-02-30'},{endDate:'2030-01-01'},{schoolId:'trend'}])assert.throws(()=>runSchoolBacktest(request(data,override),data));
  const invalid=structuredClone(data);invalid.stocks.AAPL.bars[2][2]=1;assert.throws(()=>runSchoolBacktest(request(invalid),invalid),/OHLCV/);
});
test('SpaceX cannot inherit the former ETF history or an unavailable warm-up',()=>{
  const data=structuredClone(SCHOOL_PRICES);assert(data.stocks.SPCX.bars.every(row=>row[0]>='2026-06-12'));
  assert.throws(()=>runSchoolBacktest({schoolId:'rsi',ticker:'SPCX',startDate:'2025-01-01',endDate:data.cutoffDate,budget:10000,feePct:.1},data),/different security/);
  assert.throws(()=>runSchoolBacktest({schoolId:'rsi',ticker:'SPCX',startDate:'2026-06-12',endDate:data.cutoffDate,budget:10000,feePct:.1},data),/earlier trading sessions/);
  data.stocks.SPCX.bars.unshift(['2026-06-11',100,101,99,100,1000]);assert.throws(()=>runSchoolBacktest({schoolId:'rsi',ticker:'SPCX',startDate:'2026-08-01',endDate:data.cutoffDate,budget:10000,feePct:.1},data),/security identity/);
});
test('every covered school/candidate runs on the actual saved dataset with exact final trade dates and independent fees',()=>{
  let count=0;
  for(const [schoolId,school]of Object.entries(SCHOOL_TESTS)){if(!school.mode)continue;for(const ticker of school.tickers){const stock=SCHOOL_PRICES.stocks[ticker];const earliest=stock.bars[school.warmup]?.[0];if(!earliest||earliest>=stock.bars.at(-1)[0])continue;const startDate=earliest>'2025-10-01'?earliest:'2025-10-01';const params={schoolId,ticker,startDate,endDate:SCHOOL_PRICES.cutoffDate,feePct:.1,budget:10000};const result=runSchoolBacktest(params,SCHOOL_PRICES),expensive=runSchoolBacktest({...params,feePct:1},SCHOOL_PRICES);assert(Number.isFinite(result.metrics.endingValue));assert(result.metrics.endingValue>=0);assert(result.metrics.maxDrawdownPct<=0);assert(expensive.metrics.endingValue<=result.metrics.endingValue+.000001);assert(result.orders.every(order=>!order.signalDate||order.signalDate<order.date));assert.equal(result.orders.length%2,0);count++;}}
  assert(count>=20);
});

test('an explicitly selected stock can be tested outside the old school candidate list',()=>{
  const data=fixture(3);
  assert(!SCHOOL_TESTS.balanced.tickers.includes('NVDA'));
  const result=runSchoolBacktest(request(data,{ticker:'NVDA',allowedTickers:['NVDA']}),data);
  assert.equal(result.ticker,'NVDA');assert.equal(result.schoolId,'balanced');assert.equal(result.orders.length,2);
  assert.equal(result.orders[0].price,data.stocks.NVDA.bars[0][1]);
  assert.throws(()=>runSchoolBacktest(request(data,{ticker:'NVDA'}),data),/current selection/);
});

test('empty, invalid or oversized selections cannot silently fall back to old school candidates',()=>{
  const data=fixture(3);
  assert.throws(()=>runSchoolBacktest(request(data,{allowedTickers:[]}),data),/current selection/);
  assert.throws(()=>runSchoolBacktest(request(data,{allowedTickers:['NVDA']}),data),/current selection/);
  for(const allowedTickers of [null,'AAPL',['AAPL','AAPL'],['CASH'],['aapl'],['<script>'],['AAPL',null],['AAPL','NVDA','AMD','MSFT','VTI','SGOV','IEF','GLD','QQQ']]){
    assert.throws(()=>runSchoolBacktest(request(data,{allowedTickers}),data),/up to eight valid/);
  }
});

test('a selected ticker without verified saved history reports unavailable instead of creating a result',()=>{
  const data=fixture(3);
  assert.throws(()=>runSchoolBacktest(request(data,{ticker:'UNKNOWN',allowedTickers:['UNKNOWN']}),data),/Verified adjusted USD history is unavailable/);
  data.stocks.NVDA.currencyVerified=false;
  assert.throws(()=>runSchoolBacktest(request(data,{ticker:'NVDA',allowedTickers:['NVDA']}),data),/Verified adjusted USD history is unavailable/);
});

test('every maintained non-cash asset has verified dated history for the selected-stock comparison',()=>{
  for(const {ticker}of ASSETS.filter(asset=>asset.ticker!=='CASH')){
    const stock=SCHOOL_PRICES.stocks[ticker];assert(stock,`${ticker} needs distributable history`);
    const startDate=stock.bars[0][0]>'2025-10-01'?stock.bars[0][0]:'2025-10-01';
    const result=runSchoolBacktest({schoolId:'balanced',ticker,allowedTickers:[ticker],startDate,endDate:SCHOOL_PRICES.cutoffDate,feePct:.1,budget:10000},SCHOOL_PRICES);
    assert.equal(result.ticker,ticker);assert(Number.isFinite(result.metrics.endingValue));assert.equal(result.orders.length,2);
    assert.equal(result.source.name,'Yahoo Finance via yfinance');
  }
});
