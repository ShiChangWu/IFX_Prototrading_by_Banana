$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '../scripts/processes.ps1')

# Synthetic process identities only. This mock prevents access to live CIM and
# the test never invokes Stop-ProtoVerifiedProcess or any process mutation.
$ProjectRoot = [System.IO.Path]::GetFullPath('C:\Proto Launcher Test App')
$NodeRuntime = 'C:\Proto Test Runtime\node.exe'
$PythonRuntime = Join-Path $ProjectRoot '.venv/Scripts/python.exe'
$Utc = [datetime]::ParseExact('2026-10-04T03:45:30.1234560Z', 'o', [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind)
$Canonical = '2026-10-04T03:45:30.1234560Z'
$FixtureProcesses = @{
  41001 = [pscustomobject]@{ ProcessId = 41001; ExecutablePath = $NodeRuntime; CommandLine = '"' + $NodeRuntime + '" "' + (Join-Path $ProjectRoot 'server/index.mjs') + '"'; CreationDate = $Utc.ToLocalTime() }
  41002 = [pscustomobject]@{ ProcessId = 41002; ExecutablePath = $PythonRuntime; CommandLine = '"' + $PythonRuntime + '" -m worker.main'; CreationDate = $Utc }
}
function Get-CimInstance {
  param($ClassName, $Filter, $ErrorAction)
  if ($ClassName -ne 'Win32_Process' -or $Filter -notmatch '^ProcessId = (\d+)$') { throw 'Unexpected mocked process lookup.' }
  return $FixtureProcesses[[int]$Matches[1]]
}
function Assert-Launcher {
  param([bool]$Condition, [string]$Message)
  if (-not $Condition) { throw $Message }
}

$TemporaryRoot = [System.IO.Path]::GetFullPath((Join-Path ([System.IO.Path]::GetTempPath()) ('proto-launcher-record-test-' + [guid]::NewGuid().ToString('N'))))
$RecordFile = Join-Path $TemporaryRoot 'records.json'
New-Item -ItemType Directory -Path $TemporaryRoot | Out-Null
try {
  foreach ($Value in @($Canonical, $Utc, $Utc.ToLocalTime(), [datetimeoffset]::Parse('2026-10-04T11:45:30.1234560+08:00'))) {
    Assert-Launcher ((ConvertTo-ProtoProcessStamp $Value) -eq $Canonical) 'Equivalent creation dates must normalize to the same UTC stamp.'
  }
  Assert-Launcher ($null -eq (ConvertTo-ProtoProcessStamp 'not-a-date')) 'Malformed dates must not pass identity validation.'
  $Server = New-ProtoProcessRecord $FixtureProcesses[41001] 'website'
  $Worker = New-ProtoProcessRecord $FixtureProcesses[41002] 'research'
  Assert-Launcher ($Server.createdAt -eq $Canonical -and $Worker.createdAt -eq $Canonical) 'New records must store canonical UTC strings.'
  Write-ProtoProcessRecords $RecordFile @($Server, $Worker)
  $ParsedRecords = Get-Content -LiteralPath $RecordFile -Raw | ConvertFrom-Json
  $RoundTrip = @($ParsedRecords)
  Assert-Launcher ($RoundTrip.Count -eq 2) 'Two records must survive serialization.'
  foreach ($Entry in $RoundTrip) { Assert-Launcher ((ConvertTo-ProtoProcessStamp $Entry.createdAt) -eq $Canonical) 'JSON-parsed date objects and strings must preserve identity.' }
  $Read = @(Read-ProtoProcessRecords $RecordFile)
  Assert-Launcher ($Read.Count -eq 2) 'Process records must survive JSON read validation.'

  # Explicit DateTime records exercise auto-parsing behavior even on Windows PS5,
  # where ConvertFrom-Json may retain ISO date strings instead of DateTime values.
  $DateObjectRecord = @{ id = 41001; executable = $NodeRuntime; kind = 'website'; createdAt = $Utc }
  Write-ProtoProcessRecords $RecordFile @($Server, $DateObjectRecord, $Worker)
  Assert-Launcher (@(Read-ProtoProcessRecords $RecordFile).Count -eq 2) 'String and DateTime representations of the same process must deduplicate.'
  $Written = Get-Content -LiteralPath $RecordFile -Raw
  Assert-Launcher ($Written.Contains($Canonical)) 'Writing parsed DateTime records must emit canonical UTC strings.'

  # The same PID, command and executable with a different creation instant must
  # still be rejected, rather than accidentally weakening PID-reuse protection.
  $FixtureProcesses[41002].CreationDate = $Utc.AddSeconds(1)
  $Remaining = @(Read-ProtoProcessRecords $RecordFile)
  Assert-Launcher ($Remaining.Count -eq 1 -and $Remaining[0].id -eq 41001) 'A reused PID must not survive creation-time validation.'
  Write-Host ('Launcher record round-trip passed on PowerShell ' + $PSVersionTable.PSVersion.ToString() + '; parsed date type: ' + $RoundTrip[0].createdAt.GetType().Name + '. No live process access or mutation.')
} finally {
  # Only known synthetic files are removed; no recursive cleanup is performed.
  if (Test-Path -LiteralPath $RecordFile) { Remove-Item -LiteralPath $RecordFile -Force }
  if (Test-Path -LiteralPath $TemporaryRoot) { Remove-Item -LiteralPath $TemporaryRoot }
}
