import test from 'node:test';
import assert from 'node:assert/strict';
import {createShortPlan} from '../shared/short-plan.mjs';
const now = new Date('2026-10-04T04:30:00Z');
const match = (type='trend_research') => ({ id:'test',eligible:true,template:{id:'trend',name:'Test',version:'test',rules:{type}},allocations:[{ticker:'VTI',name:'Equity',assetClass:'equity_etf',weight:60,amount:6000},{ticker:'CASH',name:'Cash',assetClass:'cash',weight:40,amount:4000}] });
const row = (overrides={}) => ({ticker:'VTI',status:'complete',priceDate:'2026-10-02',latestClose:102,previousClose:100,sma20:101,sma100:100,previousSma20:99,previousSma100:100,bollingerUpper:110,bollingerLower:90,observations:220,currency:'USD',currencyVerified:true,adjusted:true,source:'synthetic test data',fetchedAt:now.toISOString(),...overrides});
const snapshot = overrides => ({status:'complete',cutoffDate:'2026-10-02',fetchedAt:now.toISOString(),snapshots:[row(overrides)],warnings:[]});
test('preliminary checklist works without a report, model or prices',()=>{const p=createShortPlan(match(),null,{now});assert.equal(p.status,'preliminary');assert.equal(p.assets[0].market,null);assert.equal(p.assets[0].actionCode,'await_data');assert.equal(p.assets[1].actionCode,'retain_reserve');assert(p.steps.length>0);});
test('essential money blocks even a valid market signal',()=>{const m=match();m.eligible=false;const p=createShortPlan(m,snapshot(),{now});assert.equal(p.status,'blocked');assert.equal(p.assets.length,0);});
test('a real crossover differs from merely being above the average',()=>{assert.equal(createShortPlan(match(),snapshot(),{now}).assets[0].actionCode,'trend_entry_watch');assert.equal(createShortPlan(match(),snapshot({previousSma20:102}),{now}).assets[0].actionCode,'trend_watch');assert.equal(createShortPlan(match(),snapshot({sma20:99}),{now}).assets[0].actionCode,'trend_pause');});
test('missing previous indicator cannot become a new crossover',()=>{const p=createShortPlan(match(),snapshot({previousSma20:null}),{now});assert.equal(p.status,'unavailable');assert.equal(p.assets[0].actionCode,'insufficient_history');});
test('stale, future, unverified-currency and invalid-price snapshots never create signals',()=>{for(const bad of [{priceDate:'2026-09-25'},{priceDate:'2026-10-05'},{currencyVerified:false},{currency:'EUR'},{latestClose:NaN},{adjusted:false},{fetchedAt:'2026-10-01T00:00:00Z'}]){const p=createShortPlan(match(),snapshot(bad),{now});assert.equal(p.status,'unavailable');assert.equal(p.assets[0].actionCode,'await_data');}});
test('allocation templates and non-equity sleeves never inherit equity timing signals',()=>{assert.equal(createShortPlan(match('allocation'),snapshot(),{now}).assets[0].actionCode,'review_targets');const m=match();m.allocations[0].assetClass='treasury_etf';assert.equal(createShortPlan(m,snapshot(),{now}).assets[0].actionCode,'review_targets');});
test('band observations produce review conditions, including no holdings to sell',()=>{const m=match('mean_reversion_research');assert.equal(createShortPlan(m,snapshot({latestClose:85}),{now}).assets[0].actionCode,'pullback_watch');const upper=createShortPlan(m,snapshot({latestClose:115}),{now}).assets[0];assert.equal(upper.actionCode,'upper_band_review');assert.match(upper.explanation,/no position to sell/);assert.equal(createShortPlan(m,snapshot(),{now}).assets[0].actionCode,'inside_bands');});
test('partial coverage preserves target amounts and identifies missing assets',()=>{const m=match();m.allocations.push({ticker:'IEF',name:'Treasury',assetClass:'treasury_etf',weight:0,amount:0});const before=structuredClone(m);const p=createShortPlan(m,snapshot(),{now});assert.equal(p.status,'partial');assert.deepEqual(p.coverage.missing,['IEF']);assert.equal(p.assets[0].targetAmount,6000);assert.deepEqual(m,before);});

test('source identity and the non-signal AKShare reference survive checklist creation',()=>{
  const overrides={source:{name:'Adjusted history provider',url:'https://example.com/history'},priceBasis:'Adjusted daily OHLCV',fallbackReason:'AKShare is reference-only.',providerReference:{status:'reference_only',source:'Sina Finance via AKShare',priceDate:'2026-10-02',latestClose:104,adjustmentMethod:'Unadjusted',currencyVerified:false,eligibleForSignals:false}};
  const item=createShortPlan(match(),snapshot(overrides),{now}).assets[0];
  assert.deepEqual(item.market.source,overrides.source);assert.equal(item.market.priceBasis,overrides.priceBasis);
  assert.equal(item.market.providerReference.latestClose,104);assert.equal(item.market.providerReference.eligibleForSignals,false);
  assert.equal(item.market.close,102);assert.equal(item.actionCode,'trend_entry_watch');
});

test('RSI requires a recovery crossing and does not turn extremes into orders',()=>{
  const action=overrides=>createShortPlan(match('rsi_research'),snapshot(overrides),{now}).assets[0];
  assert.equal(action({rsi14:35,previousRsi14:29}).actionCode,'rsi_recovery_watch');
  assert.equal(action({rsi14:25,previousRsi14:27}).actionCode,'rsi_weakness_watch');
  assert.equal(action({rsi14:35,previousRsi14:34}).actionCode,'rsi_no_recovery');
  assert.equal(action({rsi14:30,previousRsi14:29}).actionCode,'rsi_no_recovery');
  const high=action({rsi14:75,previousRsi14:74});assert.equal(high.actionCode,'rsi_high_review');assert.match(high.explanation,/no position to sell/);
  for(const missing of [{rsi14:null,previousRsi14:29},{rsi14:35,previousRsi14:null},{rsi14:101,previousRsi14:29},{rsi14:35,previousRsi14:29,observations:15}])assert.equal(action(missing).actionCode,'insufficient_history');
});

function candles(overrides={}){
  const dates=[];for(let time=Date.parse('2026-10-02T00:00:00Z');dates.length<22;time-=86400000){const date=new Date(time);if(![0,6].includes(date.getUTCDay()))dates.unshift(date.toISOString().slice(0,10));}
  const bars=dates.map(date=>({date,open:99,high:101,low:98,close:100,volume:1000}));
  for(const [index,value] of Object.entries(overrides))Object.assign(bars.at(Number(index)),value);
  return bars;
}
const candleSnapshot=bars=>snapshot({bars,latestClose:bars.at(-1).close,latestOpen:bars.at(-1).open,latestHigh:bars.at(-1).high,latestLow:bars.at(-1).low});

test('Price Action checks fixed prior support and team pin-bar ratios with valid daily bars',()=>{
  const m=match('price_action_research');
  const bars=candles({'-1':{open:99,high:101,low:95,close:100}});
  const hit=createShortPlan(m,candleSnapshot(bars),{now}).assets[0];
  assert.equal(hit.actionCode,'price_pinbar_watch');assert.equal(hit.priceAction.support,98);assert.equal(hit.priceAction.observationDate,'2026-10-02');
  const noTouch=candles({'-1':{open:103,high:105,low:99,close:104}});
  assert.equal(createShortPlan(m,candleSnapshot(noTouch),{now}).assets[0].actionCode,'price_no_setup');
  const doji=candles({'-1':{open:100,high:101,low:95,close:100}});
  assert.equal(createShortPlan(m,candleSnapshot(doji),{now}).assets[0].actionCode,'price_no_setup');
});

test('Price Action retest uses the pre-breakout level rather than a rolling level including the breakout',()=>{
  const bars=candles({'-2':{open:100,high:105,low:99,close:104},'-1':{open:103,high:104,low:100.5,close:102}});
  const p=createShortPlan(match('price_action_research'),candleSnapshot(bars),{now});
  assert.equal(p.assets[0].actionCode,'price_retest_watch');assert.equal(p.assets[0].priceAction.breakoutLevel,101);
  bars.at(-1).close=100.8;bars.at(-1).low=100;
  assert.equal(createShortPlan(match('price_action_research'),candleSnapshot(bars),{now}).assets[0].actionCode,'price_no_setup');
});

test('invalid, unsorted or incomplete OHLC never becomes a Price Action setup',()=>{
  const valid=candles({'-1':{open:99,high:101,low:95,close:100}});
  const corruptions=[valid.slice(1),valid.map((x,i)=>({...x,...(i===3?{high:50}:{})})),valid.map((x,i)=>({...x,...(i===3?{date:valid[4].date}:{})}))];
  for(const bars of corruptions)assert.equal(createShortPlan(match('price_action_research'),candleSnapshot(bars),{now}).assets[0].actionCode,'insufficient_history');
  assert.equal(createShortPlan(match('price_action_research'),snapshot(),{now}).assets[0].actionCode,'insufficient_history');
});

test('ATR is optional risk context and never changes direction, allocation or sets a stop price',()=>{
  const m=match('allocation'),prices=snapshot({atr14:4,latestOpen:101,latestHigh:104,latestLow:99});
  const item=createShortPlan(m,prices,{now}).assets[0];
  assert.equal(item.actionCode,'review_targets');assert.equal(item.targetAmount,6000);
  assert.equal(item.volatility.atr14,4);assert.equal(item.volatility.illustrativeDistance,6);
  assert.equal(item.volatility.percentOfClose,4/102*100);assert(!Object.hasOwn(item.volatility,'stopPrice'));
  assert.match(item.volatility.explanation,/not a recommended stop/);
  assert.equal(createShortPlan(m,snapshot({atr14:4}),{now}).assets[0].volatility,null);
  assert.equal(createShortPlan(m,snapshot({atr14:4,latestOpen:101,latestHigh:104,latestLow:99,priceDate:'2026-09-01'}),{now}).assets[0].volatility,null);
});
