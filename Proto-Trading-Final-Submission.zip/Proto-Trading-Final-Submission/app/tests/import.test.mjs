import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync, existsSync} from 'node:fs';
import {MAX_UPLOAD_BYTES, UPLOADED_SOURCE_LABEL, validateUploadFile, parseUploadedReport, validateStoredDocument, extractHorizonExcerpts} from '../shared/report-import.mjs';

const input = {filename:'test-only.md', id:'test-only-id', importedAt:'2026-10-04T06:00:00Z'};
test('validates local text format, byte limit, encoding characters and dates', () => {
  assert.equal(validateUploadFile({name:'report.MD',size:20}), 'md');
  assert.throws(() => validateUploadFile({name:'report.html',size:20}), /Markdown/);
  assert.throws(() => validateUploadFile({name:'report.md',size:MAX_UPLOAD_BYTES+1}), /2 MiB/);
  assert.throws(() => parseUploadedReport({...input,text:'\u0000binary'}), /binary/);
  assert.throws(() => parseUploadedReport({...input,text:'\u4e2d\u6587'.repeat(400000)}), /2 MiB/);
  assert.throws(() => parseUploadedReport({...input,text:'# Report',reportDate:'2026-02-30'}), /valid report date/);
  assert.throws(() => parseUploadedReport({...input,filename:'report.json',text:'invalid JSON'}), /not valid JSON/);
});
test('preserves the entire source and marks detected dates and horizons as unverified excerpts', () => {
  const text = '\ufeff# My report\r\nAnalysis date: 2026-10-02\r\n\r\n## 1–3 months\r\nInsufficient evidence.\r\n## 6–12 months\r\nConditional view, not a promise.\r\n## Risks\r\nTail risk remains.\r\n';
  const document = parseUploadedReport({...input,text,title:'Chosen local title'});
  assert.equal(document.originalText,text);
  assert.equal(document.sourceLabel,UPLOADED_SOURCE_LABEL);
  assert.equal(document.title,'Chosen local title');
  assert.equal(document.detectedReportDate.value,'2026-10-02');
  assert.equal(document.detectedReportDate.verified,false);
  assert.equal(document.horizonExcerpts.length,2);
  assert(document.horizonExcerpts[0].text.includes('Insufficient evidence.'));
  assert(!document.horizonExcerpts[1].text.includes('Tail risk remains'));
  assert.equal(document.profile,undefined);
  assert.equal(document.allocations,undefined);
  assert.equal(document.provenance,undefined);
  assert.deepEqual(validateStoredDocument(document),document);
});
test('supports explicit standalone bold headings and table first cells without reading maturity prose or code as outlook', () => {
  const text = '**1–3 months — insufficient evidence for a directional call.**\nKeep this uncertainty.\n\n**6–12 months — insufficient evidence.**\nNo driver data.\n\n## Summary\n| **6–12 months** | Conditional, no promise. |\n| Duration | 6–12 months of bond maturity |\n\n```md\n## 6–12 months\nIgnore this code example.\n```\n\nBond maturity is 6–12 months.\nLong-term returns may vary\n## 6–12 months maturity\nThis describes duration.\n';
  const excerpts = extractHorizonExcerpts(text);
  assert.equal(excerpts.length,3);
  assert.equal(excerpts[0].detection,'Standalone bold horizon heading');
  assert(excerpts[0].text.includes('Keep this uncertainty.'));
  assert.equal(excerpts[2].detection,'Explicit horizon table row');
  assert.equal(excerpts[2].text,'| **6–12 months** | Conditional, no promise. |');
  assert(!excerpts.some(excerpt => excerpt.text.includes('Ignore this code example')));
});
test('uploaded HTML-like text and JSON remain inert original documents, never trusted reports', () => {
  const text = '<script>fetch("https://example.com")</script>\n<img src="https://example.com/pixel">';
  const doc = parseUploadedReport({...input,text});
  assert.equal(doc.originalText,text);
  assert.equal(doc.horizonExcerpts.length,0);
  const json = JSON.stringify({status:'complete',provenance:{engine:'Untrusted claim'},allocations:[{ticker:'XYZ',weight:100}],outlook:[{horizon:'6–12 months',summary:'Untrusted claim'}]});
  const uploaded = parseUploadedReport({...input,filename:'untrusted.json',text:json});
  assert.equal(uploaded.kind,'uploaded-document');
  assert.equal(uploaded.provenance,undefined);
  assert.equal(uploaded.horizonExcerpts.length,0);
  assert.equal(uploaded.originalText,json);
});
for (const ticker of ['VTI','IEF']) {
  const file = new URL(`../data/worker/0050c3dd-3e9f-454c-b438-1581f1b91d18/${ticker}/reports/complete_report.md`,import.meta.url);
  test(`real saved ${ticker} Markdown remains intact with explicit horizon excerpts`, {skip:!existsSync(file)}, () => {
    const text = readFileSync(file,'utf8');
    const doc = parseUploadedReport({...input,filename:`${ticker}-report.md`,text});
    assert.equal(doc.originalText,text);
    assert.equal(doc.detectedReportDate?.value,'2026-10-04');
    assert(doc.horizonExcerpts.some(item => item.horizon === '1–3 months'));
    assert(doc.horizonExcerpts.some(item => item.horizon === '6–12 months'));
    if (ticker === 'IEF') assert(doc.horizonExcerpts.some(item => item.detection === 'Standalone bold horizon heading' && item.text.includes('insufficient evidence')));
  });
}
