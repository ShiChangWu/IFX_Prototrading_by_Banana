"""Current-selection research contracts; all provider results are test fixtures."""
import copy
from datetime import datetime, timezone
import os
from pathlib import Path
import sys
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import pandas as pd

from worker.backtest import historical_backtest
from worker.main import compute_report, selected_assets
from worker.ta_runner import run as run_isolated_research


def selected_match(tickers=None, weights=None):
    tickers = tickers or ["AMD", "NVDA", "AAPL", "MSFT", "QQQ", "VTI", "SPCX", "SGOV"]
    weights = weights if weights is not None else [10, 20] + [0] * (len(tickers) - 2)
    rows = [{"ticker": ticker, "weight": weight, "amount": weight * 100,
             "name": ticker, "assetClass": "stock"} for ticker, weight in zip(tickers, weights)]
    cash = 100 - sum(weights)
    rows.append({"ticker": "CASH", "weight": cash, "amount": cash * 100, "assetClass": "cash"})
    return {"id": "selected-test", "originalMatchId": "confirmed-test", "eligible": True,
            "profile": {"budget": 10000, "startingPortfolio": "cash", "inverseInterest": "none"},
            "template": {"id": "balanced", "name": "Balanced test", "version": "test-only"},
            "allocations": rows,
            "researchSelection": {"version": 1, "source": "user-selected", "tickers": tickers}}


class SelectedResearchTests(unittest.TestCase):
    def test_explicit_selection_researches_all_eight_in_order_including_watch_only(self):
        match = selected_match()
        original = copy.deepcopy(match)
        with patch.dict(os.environ, {"RESEARCH_MAX_TICKERS": "1"}):
            result = selected_assets(match)
        self.assertEqual([row["ticker"] for row in result], match["researchSelection"]["tickers"])
        self.assertEqual(len(result), 8)
        self.assertEqual(result[2]["weight"], 0)
        self.assertEqual(match, original)

    def test_malformed_selection_cannot_reach_a_history_or_ai_provider(self):
        mutations = [
            lambda m: m.update(researchSelection=None),
            lambda m: m["researchSelection"].update(version=True),
            lambda m: m["researchSelection"].update(version=2),
            lambda m: m["researchSelection"].update(source="injected"),
            lambda m: m["researchSelection"].update(tickers=[]),
            lambda m: m["researchSelection"].update(tickers=["AMD", "AMD"]),
            lambda m: m["researchSelection"].update(tickers=["CASH"]),
            lambda m: m["researchSelection"].update(tickers=["AMD"] * 9),
            lambda m: m["researchSelection"].update(tickers=["../../private"]),
            lambda m: m["researchSelection"].update(tickers=["ABCDEFGHIJK"]),
            lambda m: m["researchSelection"].update(extra="unexpected"),
            lambda m: m["allocations"].reverse(),
            lambda m: m["allocations"].pop(0),
            lambda m: m["allocations"][0].update(weight=-1),
            lambda m: m["allocations"][0].update(weight=float("nan")),
            lambda m: m["allocations"][0].update(amount=-1),
            lambda m: m["allocations"][0].update(amount=100000),
            lambda m: m.update(originalMatchId=""),
        ]
        heartbeat = SimpleNamespace(update=lambda _: None, lost_lease=threading.Event())
        with tempfile.TemporaryDirectory() as directory:
            for mutate in mutations:
                with self.subTest(mutate=mutate):
                    match = selected_match()
                    mutate(match)
                    with patch("worker.main.historical_backtest") as history, patch("worker.main.research_asset") as research:
                        with self.assertRaises(ValueError):
                            compute_report({"id": "invalid-test", "match": match, "profile": match["profile"]}, heartbeat, directory)
                    history.assert_not_called()
                    research.assert_not_called()

    def report(self, match, fail=None):
        stages, requested = [], []
        heartbeat = SimpleNamespace(update=stages.append, lost_lease=threading.Event())
        original = copy.deepcopy(match)

        def research(job, asset, *_):
            self.assertEqual(job["match"], original)
            requested.append(asset["ticker"])
            return {"ticker": asset["ticker"], "status": "error" if asset["ticker"] == fail else "complete",
                    "decision": None, "sections": [], "warnings": []}

        with tempfile.TemporaryDirectory() as directory, patch("worker.main.repository_commit", return_value="unknown"), \
                patch("worker.main.historical_backtest", return_value={"status": "complete", "dataSources": []}) as history, \
                patch("worker.main.research_asset", side_effect=research), patch("worker.main.build_outlook", return_value=[]):
            result = compute_report({"id": "selected-test", "match": match, "profile": match["profile"]}, heartbeat, directory)
            self.assertTrue((Path(directory) / "selected-test" / "report.json").is_file())
        self.assertEqual(history.call_args.args[0], original)
        self.assertEqual(result["match"], original)
        self.assertEqual(match, original)
        return result, requested, stages

    def test_report_preserves_submitted_allocation_and_explicit_watch_only_coverage(self):
        match = selected_match()
        report, requested, stages = self.report(match)
        self.assertEqual(requested, match["researchSelection"]["tickers"])
        self.assertIn("TradingAgents researching SGOV (8/8)", stages)
        self.assertEqual(report["status"], "complete")
        coverage = report["provenance"]["researchCoverage"]
        self.assertEqual(coverage["requested"], requested)
        self.assertEqual(coverage["omitted"], [])
        self.assertEqual(coverage["watchOnly"], requested[2:])
        self.assertEqual(coverage["targetWeightPct"], 30)
        self.assertEqual(coverage["allocationBasis"], "user-simulated")
        self.assertIn("not a new AI-approved allocation", " ".join(report["limitations"]))

    def test_all_watch_only_rows_are_still_researched_and_failed_rows_are_not_omissions(self):
        match = selected_match(["AMD", "NVDA"], [0, 0])
        report, requested, _ = self.report(match, fail="AMD")
        self.assertEqual(requested, ["AMD", "NVDA"])
        self.assertEqual(report["status"], "partial")
        coverage = report["provenance"]["researchCoverage"]
        self.assertEqual(coverage["watchOnly"], requested)
        self.assertEqual(coverage["failed"], ["AMD"])
        self.assertEqual(coverage["omitted"], [])
        self.assertEqual(coverage["targetWeightPct"], 0)

    def test_legacy_jobs_keep_weight_sorted_top_three_and_report_actual_omissions(self):
        match = selected_match(["A", "B", "C", "D"], [10, 20, 15, 15])
        del match["researchSelection"]
        del match["originalMatchId"]
        with patch.dict(os.environ, {"RESEARCH_MAX_TICKERS": "3"}):
            report, requested, _ = self.report(match)
        self.assertEqual(requested, ["B", "C", "D"])
        self.assertEqual(report["provenance"]["researchCoverage"]["omitted"], ["A"])
        self.assertEqual(report["provenance"]["researchCoverage"]["allocationBasis"], "rule-matched")


class SelectedHistoryTests(unittest.TestCase):
    def history(self, match):
        requests = []
        frame = pd.DataFrame({"Close": [100.0] * 40}, index=pd.bdate_range("2026-08-03", periods=40))

        def ticker(symbol):
            requests.append(symbol)
            return SimpleNamespace(history=lambda **_: frame)

        fake = SimpleNamespace(Ticker=ticker, set_tz_cache_location=lambda _: None)
        with tempfile.TemporaryDirectory() as directory, patch.dict("sys.modules", {"yfinance": fake}), \
                patch("worker.tls.configure_trusted_ca"):
            result = historical_backtest(match, cache_dir=directory, now=datetime(2026, 10, 4, 12, tzinfo=timezone.utc))
        return result, requests

    def test_zero_weight_watch_rows_never_require_or_fetch_their_history(self):
        result, requests = self.history(selected_match(["AAPL", "SPCX"], [20, 0]))
        self.assertEqual(result["status"], "complete")
        self.assertEqual(requests, ["AAPL", "SPY"])
        self.assertEqual(result["assumptions"]["weights"]["SPCX"], 0)

    def test_all_cash_comparison_uses_only_the_separate_spy_benchmark(self):
        result, requests = self.history(selected_match(["AMD", "SPCX"], [0, 0]))
        self.assertEqual(result["status"], "complete")
        self.assertEqual(requests, ["SPY"])
        self.assertEqual(result["metrics"]["endingValue"], 10000)
        self.assertEqual(result["metrics"]["trades"], 0)
        self.assertEqual(result["metrics"]["totalReturnPct"], 0)
        self.assertIn("entirely cash", " ".join(result["warnings"]))

    def test_malformed_weights_and_amount_budget_do_not_start_history_fetch(self):
        for invalid in (-1, float("nan"), float("inf"), True, "20"):
            match = selected_match(["AMD", "NVDA"], [20, 0])
            match["allocations"][0]["weight"] = invalid
            with patch("worker.tls.configure_trusted_ca") as tls:
                result = historical_backtest(match)
            tls.assert_not_called()
            self.assertEqual(result["status"], "unavailable")
            self.assertNotIn("metrics", result)


class ResearchClassificationTests(unittest.TestCase):
    def test_selected_simulations_and_unknown_instrument_types_are_not_misrepresented(self):
        for asset_class, expected_analysts in (("stock", ["market", "news", "fundamentals"]),
                                                ("etf", ["market", "news"]),
                                                ("unclassified", ["market", "news"])):
            with self.subTest(asset_class=asset_class), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                (root / "tradingagents").mkdir()
                captured = {}

                class FakeGraph:
                    def __init__(self, selected_analysts, **_):
                        captured["analysts"] = selected_analysts
                        self.quick_thinking_llm = SimpleNamespace(extra_body={})
                        self.deep_thinking_llm = SimpleNamespace(extra_body={})

                    def resolve_instrument_context(self, *_, **__):
                        return "Test-only base context."

                    def propagate(self, ticker, analysis_date, **_):
                        captured["context"] = self.resolve_instrument_context(ticker, trade_date=analysis_date)
                        return {"market_report": "Test-only source, not real research."}, "TEST ONLY"

                    def save_reports(self, *_, **__):
                        pass

                modules = {"yfinance": SimpleNamespace(set_tz_cache_location=lambda _: None),
                           "tradingagents.default_config": SimpleNamespace(DEFAULT_CONFIG={"data_vendors": {}}),
                           "tradingagents.graph.trading_graph": SimpleNamespace(TradingAgentsGraph=FakeGraph),
                           "tradingagents.portfolio": SimpleNamespace(PortfolioContext=lambda **kwargs: kwargs)}
                match = selected_match(["AMD"], [0])
                asset = {**match["allocations"][0], "assetClass": asset_class}
                request = {"match": match, "profile": match["profile"], "asset": asset,
                           "analysisDate": "2026-10-04", "workDir": str(root / "work")}
                with patch.dict(os.environ, {"DEEPSEEK_API_KEY": "test-only"}, clear=True), \
                        patch.dict(sys.modules, modules), patch.object(sys, "path", list(sys.path)), \
                        patch("worker.ta_runner.VENDOR", root), patch("worker.tls.configure_trusted_ca"):
                    result = run_isolated_research(request)
                self.assertEqual(captured["analysts"], expected_analysts)
                self.assertIn("user supplied the simulated allocation", captured["context"])
                self.assertIn("0% watch-only", captured["context"])
                self.assertIn("not a new AI-approved allocation", captured["context"])
                if asset_class == "unclassified":
                    self.assertIn("instrument type is unverified", captured["context"])
                    self.assertNotIn("This instrument is an ETF", captured["context"])
                    self.assertIn("classification is unverified", " ".join(result["warnings"]))
                elif asset_class == "etf":
                    self.assertIn("This instrument is an ETF", captured["context"])
                else:
                    self.assertEqual(result["warnings"], [])


if __name__ == "__main__":
    unittest.main()
