-- Prototype persistence for a single research worker. Run once in a NEW Supabase
-- project using SQL Editor. This table and its RPC functions are service-only.
-- No browser anon key ever receives access to private profiles or reports.
begin;
create table if not exists public.proto_private_state (
  id integer primary key check (id = 1),
  revision bigint not null default 0,
  data jsonb not null,
  updated_at timestamptz not null default now(),
  constraint proto_state_schema check (data->>'schema' = '1')
);
insert into public.proto_private_state(id, data)
values (1, '{"schema":1,"sessions":{},"jobs":{},"workers":{},"limits":{}}'::jsonb)
on conflict (id) do nothing;

alter table public.proto_private_state enable row level security;
revoke all on public.proto_private_state from public, anon, authenticated;
grant select, update on public.proto_private_state to service_role;

create or replace function public.proto_read_state()
returns jsonb language sql security invoker set search_path = '' as $$
  select jsonb_build_object('revision', revision, 'data', data)
  from public.proto_private_state where id = 1;
$$;

create or replace function public.proto_compare_exchange(expected_revision bigint, next_data jsonb)
returns boolean language plpgsql security invoker set search_path = '' as $$
declare touched integer;
begin
  if next_data->>'schema' is distinct from '1'
     or jsonb_typeof(next_data->'sessions') is distinct from 'object'
     or jsonb_typeof(next_data->'jobs') is distinct from 'object'
     or jsonb_typeof(next_data->'workers') is distinct from 'object'
     or jsonb_typeof(next_data->'limits') is distinct from 'object'
     or octet_length(next_data::text) > 33554432 then
    raise exception 'Invalid prototype state';
  end if;
  update public.proto_private_state
  set data = next_data, revision = revision + 1, updated_at = now()
  where id = 1 and revision = expected_revision;
  get diagnostics touched = row_count;
  return touched = 1;
end;
$$;

revoke all on function public.proto_read_state() from public, anon, authenticated;
revoke all on function public.proto_compare_exchange(bigint, jsonb) from public, anon, authenticated;
grant execute on function public.proto_read_state() to service_role;
grant execute on function public.proto_compare_exchange(bigint, jsonb) to service_role;
commit;
