. (Join-Path $PSScriptRoot 'scripts/runtime.ps1')
Set-Location -LiteralPath $ProjectRoot
& $NodeRuntime scripts/configure.mjs
if ($LASTEXITCODE -ne 0) { throw 'Local configuration failed. No service was started.' }
& $NodeRuntime scripts/build.mjs
if ($LASTEXITCODE -ne 0) { throw 'The website build failed.' }
Write-Host 'Open http://127.0.0.1:8787 in your browser. Keep this terminal open. Press Ctrl+C to stop.'
& $NodeRuntime server/index.mjs
