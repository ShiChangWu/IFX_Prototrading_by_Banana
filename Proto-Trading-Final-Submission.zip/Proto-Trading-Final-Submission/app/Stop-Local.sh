#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' 'The macOS/Linux launchers run in foreground terminals.' 'Press Ctrl+C in the Start-Local.sh terminal to stop the website.' 'Press Ctrl+C in the Start-Research.sh terminal to stop research.' 'This helper does not kill processes or claim that they have stopped.'
