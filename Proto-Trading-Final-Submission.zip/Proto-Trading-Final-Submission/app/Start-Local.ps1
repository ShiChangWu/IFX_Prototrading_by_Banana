. (Join-Path $PSScriptRoot 'scripts/runtime.ps1')
$LauncherMutex = Enter-ProtoLauncherLock
try {
Set-Location -LiteralPath $ProjectRoot
& $NodeRuntime scripts/configure.mjs
if ($LASTEXITCODE -ne 0) { throw 'Local configuration failed. No service was started.' }
& $NodeRuntime scripts/build.mjs
if ($LASTEXITCODE -ne 0) { throw 'Build failed. No service was started.' }
$RunDirectory = Join-Path $ProjectRoot '.local'
New-Item -ItemType Directory -Path $RunDirectory -Force | Out-Null
$RecordFile = Join-Path $RunDirectory 'launcher-processes.json'
$Processes = @(Read-ProtoProcessRecords $RecordFile)
$Health = $null
try { $Health = Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/health' -TimeoutSec 3 } catch { }
if (-not $Health.ok) {
  $ServerFile = Join-Path $ProjectRoot 'server/index.mjs'
  $ServerProcess = Start-Process -FilePath $NodeRuntime -ArgumentList ('"' + $ServerFile + '"') -WorkingDirectory $ProjectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $RunDirectory 'website.log') -RedirectStandardError (Join-Path $RunDirectory 'website-error.log')
  $ServerInfo = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $ServerProcess.Id) -ErrorAction SilentlyContinue
  $ServerRecord = New-ProtoProcessRecord $ServerInfo 'website'
  if ($ServerRecord) { $Processes += $ServerRecord; Write-ProtoProcessRecords $RecordFile $Processes }
  for ($Attempt = 0; $Attempt -lt 20; $Attempt++) {
    Start-Sleep -Milliseconds 300
    try { $Health = Invoke-RestMethod -Uri 'http://127.0.0.1:8787/api/health' -TimeoutSec 2; if ($Health.ok) { break } } catch { }
  }
}
if (-not $Health.ok) { throw 'The local website did not start. Check .local/website-error.log.' }
# A cached heartbeat can outlive a stopped worker for 90 seconds. Only an actual
# process with this project's venv executable and module prevents a new launch.
$WorkerSnapshot = @(Get-CimInstance Win32_Process -Filter "Name = 'python.exe' OR Name = 'pythonw.exe'" -ErrorAction Stop)
$ExistingWorkers = @($WorkerSnapshot | Where-Object { Test-ProtoService $_ 'research' })
if ($ExistingWorkers.Count -eq 0 -and @($Processes | Where-Object { $_.kind -eq 'research-runner' }).Count -gt 0) { throw 'A previously tracked research subprocess is still running. Use Stop-Local.ps1 again before starting another research worker.' }
if ($ExistingWorkers.Count -eq 0 -and (Test-Path -LiteralPath $PythonRuntime)) {
  $WorkerProcess = Start-Process -FilePath $PythonRuntime -ArgumentList '-m','worker.main' -WorkingDirectory $ProjectRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $RunDirectory 'research.log') -RedirectStandardError (Join-Path $RunDirectory 'research-error.log')
  $WorkerInfo = Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $WorkerProcess.Id) -ErrorAction SilentlyContinue
  $WorkerRecord = New-ProtoProcessRecord $WorkerInfo 'research'
  if ($WorkerRecord) { $Processes += $WorkerRecord }
} elseif ($ExistingWorkers.Count -gt 0) {
  Write-Host 'A matching local research process is already running; no duplicate was started.'
} else {
  Write-Host 'Research environment not installed. Run Setup-Research.ps1 before starting research.'
}
Write-ProtoProcessRecords $RecordFile $Processes
Write-Host 'Website ready: http://127.0.0.1:8787'
Write-Host 'Direct app: http://127.0.0.1:8787/workspace.html'
Write-Host 'The website and research worker run in the background. Keep the computer awake.'
Write-Host 'Use Stop-Local.ps1 to stop services started by this launcher.'
} finally { $LauncherMutex.ReleaseMutex(); $LauncherMutex.Dispose() }
