"""Run: python -m worker.main [--check|--once] from app/.

The worker makes outbound authenticated requests. It never exposes a local port.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timedelta, timezone
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .backtest import allocation_weights, historical_backtest
from .hedging import historical_hedge_assessment
from .outlook import build_outlook, outlook_method_metadata
from .quality import review_report_quality

APP = Path(__file__).resolve().parents[1]
REPOSITORY = "https://github.com/TauricResearch/TradingAgents"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def load_env(path=None):
    """Tiny dotenv reader: no evaluation, expansion or secret printing."""
    path = Path(path or APP / ".env.local")
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key, value = key.strip(), value.strip()
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", key):
            continue
        if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
            value = value[1:-1]
        os.environ.setdefault(key, value)


class WorkerHTTPError(RuntimeError):
    def __init__(self, status):
        self.status = status
        super().__init__(f"Worker endpoint returned HTTP {status}.")


class API:
    def __init__(self, base_url, secret):
        parsed = urllib.parse.urlparse(base_url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("APP_BASE_URL must not contain credentials, query or fragment.")
        if parsed.scheme != "https" and not (parsed.scheme == "http" and parsed.hostname in ("127.0.0.1", "localhost", "::1")):
            raise ValueError("Public worker endpoints require HTTPS; HTTP is allowed only on loopback.")
        if not secret:
            raise ValueError("WORKER_SECRET is missing.")
        self.base_url, self.secret = base_url.rstrip("/"), secret

    def post(self, route, payload):
        request = urllib.request.Request(self.base_url + "/api/worker/" + route,
            data=json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + self.secret}, method="POST")
        # Redirects are disallowed so the bearer secret cannot cross origins.
        class NoRedirect(urllib.request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        try:
            with urllib.request.build_opener(NoRedirect).open(request, timeout=20) as response:
                return json.loads(response.read(8_000_000))
        except urllib.error.HTTPError as exc:
            raise WorkerHTTPError(exc.code) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            raise RuntimeError("Worker endpoint is unreachable; no credentials were logged.") from None


class Heartbeat:
    def __init__(self, api, worker_id):
        self.api, self.worker_id = api, worker_id
        self.stop_event, self.lost_lease = threading.Event(), threading.Event()
        self.lock = threading.Lock()
        self.job, self.stage = None, "Idle"
        self.thread = threading.Thread(target=self.loop, name="worker-heartbeat", daemon=True)

    def start(self):
        self.thread.start()

    def set_job(self, job):
        with self.lock:
            self.job, self.stage = job, "Preparing research"
            self.lost_lease.clear()

    def update(self, stage):
        with self.lock:
            self.stage = stage
        self.send()

    def send(self):
        with self.lock:
            job, stage = self.job, self.stage
        heartbeat = {"workerId": self.worker_id}
        if job:
            heartbeat["jobId"] = job["id"]
        self.api.post("heartbeat", heartbeat)
        if job:
            self.api.post("progress", {"workerId": self.worker_id, "jobId": job["id"],
                                      "leaseToken": job["leaseToken"], "stage": stage})

    def loop(self):
        last_success = time.monotonic()
        while not self.stop_event.is_set():
            try:
                self.send()
                last_success = time.monotonic()
            except WorkerHTTPError as exc:
                if exc.status in (401, 403, 409):
                    self.lost_lease.set()
            except Exception:
                if time.monotonic() - last_success > 85:
                    self.lost_lease.set()
            self.stop_event.wait(15)

    def stop(self):
        self.stop_event.set()
        self.thread.join(timeout=2)


def repository_commit():
    vendor = (APP / "vendor" / "TradingAgents").resolve()
    # A source-only delivery has no nested Git repository. Never let Git walk
    # upward and misattribute the surrounding application's commit to TA.
    if not (vendor / ".git").exists():
        try:
            commit = (APP / "VENDOR-REVISION.txt").read_text(encoding="utf-8-sig").strip()
            return commit.lower() if re.fullmatch(r"[0-9a-fA-F]{40}", commit) else "unknown"
        except (OSError, UnicodeError):
            return "unknown"
    try:
        result = subprocess.run(["git", "-C", str(vendor), "rev-parse", "--show-toplevel", "HEAD"],
                                capture_output=True, text=True, timeout=10, check=True)
        lines = result.stdout.strip().splitlines()
        if len(lines) != 2 or Path(lines[0]).resolve() != vendor:
            return "unknown"
        commit = lines[1]
        return commit.lower() if re.fullmatch(r"[0-9a-fA-F]{40}", commit) else "unknown"
    except Exception:
        return "unknown"


def selected_assets(match):
    weights = allocation_weights(match)
    if "researchSelection" in match:
        selection = match["researchSelection"]
        if (not isinstance(selection, dict) or set(selection) != {"version", "source", "tickers"}
                or type(selection.get("version")) is not int or selection["version"] != 1
                or selection.get("source") != "user-selected"):
            raise ValueError("Unsupported selected-stock research metadata.")
        tickers = selection.get("tickers")
        if (not isinstance(tickers, list) or not 1 <= len(tickers) <= 8
                or any(not isinstance(ticker, str) or ticker == "CASH"
                       or not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,9}", ticker) for ticker in tickers)
                or len(set(tickers)) != len(tickers)):
            raise ValueError("Select one to eight unique stock or ETF tickers.")
        if list(weights) != tickers + ["CASH"]:
            raise ValueError("Research tickers and allocation rows must match in the submitted order.")
        original = match.get("originalMatchId")
        if not isinstance(original, str) or not 1 <= len(original) <= 100:
            raise ValueError("The selected allocation needs its original confirmed match reference.")
        budget = match.get("profile", {}).get("budget")
        if isinstance(budget, bool) or not isinstance(budget, (int, float)) or not math.isfinite(budget) or not 100 <= budget <= 1000000:
            raise ValueError("Invalid selected-allocation budget.")
        total_amount = 0
        for asset in match["allocations"]:
            amount = asset.get("amount")
            if (isinstance(amount, bool) or not isinstance(amount, (int, float)) or not math.isfinite(amount)
                    or amount < 0 or abs(amount - weights[asset["ticker"]] * budget) > 0.010001):
                raise ValueError("Selected amounts must reconcile with the submitted weights.")
            total_amount += amount
        if abs(total_amount - budget) > 0.010001:
            raise ValueError("Selected amounts must reconcile with the submitted budget.")
        # Explicit selections include watch-only rows and never inherit the
        # legacy top-three cap or target-weight ordering.
        return match["allocations"][:-1]
    limit = min(3, max(1, int(os.getenv("RESEARCH_MAX_TICKERS", "3"))))
    assets = [a for a in match.get("allocations", [])
              if a.get("ticker") != "CASH" and float(a.get("weight", 0)) > 0]
    # Largest weights first gives transparent, deterministic research coverage.
    return sorted(assets, key=lambda x: (-float(x["weight"]), x["ticker"]))[:limit]


def research_asset(job, asset, directory, analysis_date, timeout_seconds, lost_lease):
    ticker = asset["ticker"]
    base_error = {"ticker": ticker, "status": "error", "decision": None, "sections": []}
    if not os.getenv("DEEPSEEK_API_KEY", "").strip():
        return {**base_error, "error": "DEEPSEEK_API_KEY is not configured; no TradingAgents research was generated."}
    if not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,9}", ticker):
        return {**base_error, "error": "Ticker validation failed."}
    ticker_dir = directory / ticker
    ticker_dir.mkdir(parents=True, exist_ok=True)
    request_path, result_path = ticker_dir / "request.json", ticker_dir / "research.json"
    request_path.write_text(json.dumps({"asset": asset, "profile": job["profile"], "match": job["match"],
        "analysisDate": analysis_date, "workDir": str(ticker_dir)}, ensure_ascii=False), encoding="utf-8")
    command = [sys.executable, "-m", "worker.ta_runner", str(request_path), str(result_path)]
    options = {"cwd": str(APP), "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL,
               "env": {**os.environ, "PYTHONUTF8": "1", "PYTHONUNBUFFERED": "1"}}
    if os.name == "nt":
        options["creationflags"] = subprocess.CREATE_NO_WINDOW
    process = subprocess.Popen(command, **options)
    deadline = time.monotonic() + timeout_seconds
    try:
        while process.poll() is None:
            if lost_lease.is_set():
                raise RuntimeError("Research stopped because the worker no longer owns this job.")
            if time.monotonic() >= deadline:
                process.kill()
                process.wait(timeout=10)
                return {**base_error, "error": "TradingAgents reached the configured time limit; no incomplete result was published."}
            time.sleep(0.5)
        if process.returncode != 0 or not result_path.is_file():
            return {**base_error, "error": "The isolated TradingAgents process did not produce a completed result."}
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if result.get("ticker") != ticker or result.get("status") not in ("complete", "error"):
            raise ValueError("Invalid isolated research output.")
        return result
    finally:
        if process.poll() is None:
            process.kill()
            process.wait(timeout=10)


def compute_report(job, heartbeat, output_dir=None):
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}", str(job.get("id", ""))):
        raise ValueError("Invalid job identifier.")
    match, profile = job["match"], job["profile"]
    if not match.get("eligible"):
        raise ValueError("This profile is not eligible for a generated investment allocation.")
    if profile.get("startingPortfolio") != "cash":
        raise ValueError("Only an initially empty portfolio is supported in version 1.")
    directory = Path(output_dir or APP / "data" / "worker") / job["id"]
    directory.mkdir(parents=True, exist_ok=True)
    # Current Hong Kong calendar date for research; price history uses last completed US close.
    analysis_date = datetime.now(timezone(timedelta(hours=8))).date().isoformat()
    assets = selected_assets(match)
    heartbeat.update("Calculating fixed-allocation historical comparison")
    backtest = historical_backtest(match, cost_bps=10, cache_dir=directory / "historical-cache")
    hedge_comparison = None
    if profile.get("inverseInterest", "none") != "none":
        heartbeat.update("Comparing actual inverse ETF histories (research only)")
        hedge_comparison = historical_hedge_assessment(profile["inverseInterest"], profile["budget"],
                                                     cache_dir=directory / "hedge-cache")
    if heartbeat.lost_lease.is_set():
        raise RuntimeError("Worker lease was lost.")
    research, max_seconds = [], max(60, min(7200, int(os.getenv("RESEARCH_TIMEOUT_SECONDS", "1800"))))
    per_asset = max(60, max_seconds // max(1, len(assets)))
    for index, asset in enumerate(assets, 1):
        heartbeat.update(f"TradingAgents researching {asset['ticker']} ({index}/{len(assets)})")
        research.append(research_asset(job, asset, directory, analysis_date, per_asset, heartbeat.lost_lease))
    heartbeat.update("Checking evidence for separate outlook horizons")
    outlook = build_outlook(research, match["template"])
    is_selection = "researchSelection" in match
    noncash = [a for a in match.get("allocations", []) if a["ticker"] != "CASH" and (is_selection or a["weight"] > 0)]
    researched_weight = sum(float(a["weight"]) for a in assets)
    requested = [asset["ticker"] for asset in assets]
    omitted = [asset["ticker"] for asset in noncash if asset["ticker"] not in requested]
    watch_only = [asset["ticker"] for asset in assets if asset["weight"] == 0]
    coverage_note = (f"Research covers all {len(assets)} user-selected instruments in the submitted order, including "
                     f"{len(watch_only)} watch-only instruments with 0% allocation. Cash has no company research."
                     if is_selection else
                     f"Research is limited to {len(assets)} of {len(noncash)} non-cash holdings, selected by target weight ({researched_weight:g}% of the full portfolio). Cash has no company research.")
    limitations = [
        "No orders are placed and no brokerage account is connected.",
        coverage_note,
        ("The allocation is the user's simulated selection, not a new AI-approved allocation or recorded purchases. Zero-weight rows are researched for observation and remain uninvested."
         if is_selection else "The allocation is the original rule-matched questionnaire plan."),
        "TradingAgents may suggest a different action or size; it is independent research and never silently overrides the submitted allocation.",
        "Historical results describe the stated fixed allocation with monthly rebalancing, not the performance of TradingAgents or the full strategy template.",
        "Horizon summaries extract the completed research. Missing evidence is shown as unavailable; quoted research itself can be wrong.",
        "The team's maintained template is a research lens. User-specific final doctrine prompts remain subject to later template maintenance.",
        "Company fundamentals are excluded for ETFs; ETF holdings, fund expenses and tracking differences are not fully modelled.",
    ]
    hedge_review = {**match.get("hedgeReview", {}), "allocated": False,
        "status": "research_only", "assessment": "No inverse ETF has been allocated automatically. "
        "Most inverse and leveraged inverse funds target daily returns and reset daily; multi-day results depend on the return path. "
        "A -2x/-3x interest is a request for evaluation, not a suitability result. Any historical exposure comparisons are educational scenarios, not recommended sizing.",
        "source": "https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-alerts/sec"}
    if hedge_comparison is not None:
        hedge_review["historicalComparison"] = hedge_comparison
    completed = len([r for r in research if r["status"] == "complete"])
    status = "complete" if (completed > 0 and completed == len(assets) and backtest["status"] == "complete"
                              and (hedge_comparison is None or hedge_comparison["status"] == "complete")) else "partial"
    commit = repository_commit()
    commit_source = "unavailable" if commit == "unknown" else (
        "vendor Git HEAD" if (APP / "vendor" / "TradingAgents" / ".git").exists()
        else "pinned bundled source revision (VENDOR-REVISION.txt)")
    report = {"id": job["id"], "title": match["template"]["name"] + " — research report",
              "status": status, "generatedAt": utc_now(), "analysisDate": analysis_date,
              "profile": profile, "match": match,
              "provenance": {"engine": "TauricResearch/TradingAgents", "repository": REPOSITORY,
                "commit": commit, "commitSource": commit_source,
                "model": os.getenv("TRADINGAGENTS_MODEL") or os.getenv("DEEPSEEK_MODEL", "deepseek-flash"),
                "templateVersion": match["template"].get("version"),
                "dataSources": backtest.get("dataSources", []),
                "warnings": ["Market/news research sources appear in the corresponding agent text; source completeness is not guaranteed.",
                             "AI output is research material, not verified fact or a guaranteed loss limit."],
                "researchCoverage": {"requested": requested, "omitted": omitted, "completed": completed,
                                     "failed": [row["ticker"] for row in research if row["status"] != "complete"],
                                     "watchOnly": watch_only, "targetWeightPct": researched_weight,
                                     "source": "user-selected" if is_selection else "largest-target-weights",
                                     "allocationBasis": "user-simulated" if is_selection else "rule-matched"}},
              "research": research, "outlook": outlook, "outlookMethod": outlook_method_metadata(outlook), "backtest": backtest,
              "hedgeReview": hedge_review, "limitations": limitations}
    report = review_report_quality(report)
    (directory / "report.json").write_text(json.dumps(report, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    return report


def readiness():
    return {"deepseekConfigured": bool(os.getenv("DEEPSEEK_API_KEY", "").strip()),
            "workerSecretConfigured": bool(os.getenv("WORKER_SECRET", "").strip()),
            "tradingAgentsRepositoryPresent": (APP / "vendor" / "TradingAgents" / "tradingagents").is_dir(),
            "yfinanceInstalled": importlib.util.find_spec("yfinance") is not None,
            "langgraphInstalled": importlib.util.find_spec("langgraph") is not None,
            "appBaseUrl": os.getenv("APP_BASE_URL", "http://127.0.0.1:8787")}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Check configuration without paid API calls")
    parser.add_argument("--once", action="store_true", help="Claim at most one queued job and exit")
    args = parser.parse_args(argv)
    load_env()
    if args.check:
        state = readiness()
        # Avoid accidentally printing credentials if URL was misconfigured.
        state.pop("appBaseUrl", None)
        print(json.dumps(state))
        return 0 if all(state.values()) else 2
    state = readiness()
    if not all(state[k] for k in ("deepseekConfigured", "workerSecretConfigured", "tradingAgentsRepositoryPresent", "yfinanceInstalled", "langgraphInstalled")):
        print("Worker unavailable: configure DeepSeek/worker secrets and install the documented dependencies. Run --check for nonsecret status.")
        return 2
    try:
        api = API(state["appBaseUrl"], os.getenv("WORKER_SECRET", ""))
    except ValueError:
        print("Worker configuration is invalid. APP_BASE_URL must use HTTPS or loopback HTTP and WORKER_SECRET must be present.")
        return 2
    worker_id = "local-" + uuid.uuid4().hex[:12]
    heartbeat = Heartbeat(api, worker_id)
    heartbeat.start()
    print("Research worker is ready. Waiting for queued research jobs.", flush=True)
    try:
        while True:
            try:
                payload = api.post("claim", {"workerId": worker_id})
                job = payload.get("job")
                if job:
                    heartbeat.set_job(job)
                    try:
                        report = compute_report(job, heartbeat)
                        if heartbeat.lost_lease.is_set():
                            raise RuntimeError("Worker lease was lost.")
                        completion = {"workerId": worker_id, "jobId": job["id"],
                                      "leaseToken": job["leaseToken"], "report": report}
                        # Completion is idempotent; retry one transient delivery failure.
                        try:
                            api.post("complete", completion)
                        except RuntimeError:
                            api.post("complete", completion)
                        print("Research job finished: " + report["status"], flush=True)
                    except Exception as exc:
                        try:
                            api.post("fail", {"workerId": worker_id, "jobId": job["id"],
                                "leaseToken": job["leaseToken"],
                                "error": "Research job could not complete (" + type(exc).__name__ + "). Please retry after checking worker status."})
                        except Exception:
                            pass
                        print("Research job failed; no fabricated report was submitted.", flush=True)
                    finally:
                        heartbeat.set_job(None)
                if args.once:
                    return 0
            except (RuntimeError, ValueError):
                print("Site connection unavailable; will reconnect without exposing credentials.", flush=True)
                if args.once:
                    return 2
            time.sleep(5)
    except KeyboardInterrupt:
        print("Research worker stopped.", flush=True)
        return 0
    finally:
        heartbeat.stop()


if __name__ == "__main__":
    raise SystemExit(main())
