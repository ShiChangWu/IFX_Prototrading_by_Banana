"""Public US security-name catalog through AKShare; no prices or signals.

The quick endpoint gathers AKShare's six well-known US categories. The full
EastMoney catalog paginates thousands of instruments and belongs in a separate
local refresh: ``python -m worker.stock_search --refresh-full``. Both preserve
the provider's exact symbol and name; instrument type and currency are not
inferred from a US-market endpoint.
"""
from contextlib import redirect_stdout, redirect_stderr
from datetime import datetime, timezone
import io
import json
from pathlib import Path
import queue
import re
import sys
import threading
import time

DOCUMENTATION = "https://akshare.akfamily.xyz/data/stock/stock.html"
SOURCE = "EastMoney security catalog via AKShare"
CATEGORIES = ("\u79d1\u6280\u7c7b", "\u91d1\u878d\u7c7b", "\u533b\u836f\u98df\u54c1\u7c7b", "\u5a92\u4f53\u7c7b", "\u6c7d\u8f66\u80fd\u6e90\u7c7b", "\u5236\u9020\u96f6\u552e\u7c7b")
MAX_ROWS = 30000
CODE = re.compile(r"(105|106|107)\.([A-Z][A-Za-z0-9.\-]{0,11})")


def catalog_from_frames(frames, *, scope="well_known_us", fetched_at=None):
    """Drop malformed rows and ambiguous ticker identities, never guess codes."""
    rows, ambiguous, dropped = {}, set(), 0
    for frame in frames:
        if "\u4ee3\u7801" not in frame or "\u540d\u79f0" not in frame:
            raise ValueError("AKShare catalog columns are unavailable")
        for record in frame.to_dict("records"):
            code, name = record["\u4ee3\u7801"], record["\u540d\u79f0"]
            match = CODE.fullmatch(code) if isinstance(code, str) else None
            if (not match or not isinstance(name, str) or not name.strip()
                    or len(name) > 240 or any(ord(ch) < 32 for ch in name)):
                dropped += 1
                continue
            ticker = match.group(2)
            # Do not uppercase provider suffixes: e.g. r can mean rights.
            # Restrict discovery to the ticker grammar supported by the app.
            if ticker != ticker.upper():
                dropped += 1
                continue
            # SPCX changed issuer in 2026; old ETF records cannot identify SpaceX.
            if ticker == "SPCX" and not re.search(r"space\s*(?:x|exploration)", name, re.I):
                dropped += 1
                continue
            row = {"ticker": ticker, "name": name.strip(), "providerSymbol": code}
            if ticker in rows and rows[ticker] != row:
                ambiguous.add(ticker)
            rows[ticker] = row
            if len(rows) > MAX_ROWS:
                raise ValueError("AKShare catalog exceeds its size limit")
    for ticker in ambiguous:
        rows.pop(ticker, None)
    if not rows:
        raise ValueError("No unambiguous US security names were returned")
    return {"version": 1, "status": "complete", "scope": scope,
            "source": {"name": SOURCE, "url": DOCUMENTATION},
            "fetchedAt": fetched_at or datetime.now(timezone.utc).isoformat(),
            "rows": sorted(rows.values(), key=lambda row: row["ticker"]),
            "droppedRows": dropped + len(ambiguous)}


def retrieve_catalog(*, full=False, timeout=15, ak=None):
    """Deadline bounds AKShare APIs that have no timeout argument.

    Threads are daemon-only, do not write files, and are contained in the
    short-lived process owned by the Node adapter. Partial category coverage is
    explicit and has no implication that a missing ticker is not listed.
    """
    if ak is None:
        import akshare as ak
    results = queue.Queue()
    calls = [lambda: ak.stock_us_spot_em()] if full else [
        lambda category=category: ak.stock_us_famous_spot_em(symbol=category)
        for category in CATEGORIES]

    def run(call):
        try:
            results.put((True, call()))
        except Exception:
            results.put((False, None))

    for call in calls:
        threading.Thread(target=run, args=(call,), daemon=True).start()
    deadline, frames, completed = time.monotonic() + timeout, [], 0
    while completed < len(calls):
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            success, frame = results.get(timeout=remaining)
        except queue.Empty:
            break
        completed += 1
        if success:
            frames.append(frame)
    catalog = catalog_from_frames(frames, scope="all_us" if full else "well_known_us")
    catalog["completedGroups"] = len(frames)
    catalog["requestedGroups"] = len(calls)
    return catalog


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv not in ([], ["--refresh-full"]):
        return 2
    full = bool(argv)
    try:
        # AKShare progress messages are not part of this public JSON boundary.
        with redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO()):
            catalog = retrieve_catalog(full=full, timeout=300 if full else 15)
        if full:
            destination = Path(__file__).resolve().parents[1] / ".local" / "us-stock-catalog.json"
            destination.parent.mkdir(parents=True, exist_ok=True)
            temporary = destination.with_suffix(".tmp")
            temporary.write_text(json.dumps(catalog, ensure_ascii=False), encoding="utf-8")
            temporary.replace(destination)
            print(json.dumps({"status": "complete", "scope": catalog["scope"],
                              "count": len(catalog["rows"]), "fetchedAt": catalog["fetchedAt"]}))
        else:
            print(json.dumps(catalog, ensure_ascii=False))
        return 0
    except Exception:
        print(json.dumps({"status": "unavailable", "errorCode": "AKSHARE_CATALOG_UNAVAILABLE"}))
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
