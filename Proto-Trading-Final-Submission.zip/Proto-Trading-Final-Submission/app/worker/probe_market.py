"""No AI calls: verify the exact vendor data methods used by TradingAgents."""
from __future__ import annotations

from datetime import datetime, timedelta
import json
from pathlib import Path
import sys

from .tls import configure_trusted_ca


def main():
    app = Path(__file__).resolve().parents[1]
    work = app / "data" / "worker" / "market-probe"
    work.mkdir(parents=True, exist_ok=True)
    trust = configure_trusted_ca(work / "tls")
    import yfinance as yf
    yf.set_tz_cache_location(str(work / "yfinance"))
    sys.path.insert(0, str(app / "vendor" / "TradingAgents"))
    from tradingagents.default_config import DEFAULT_CONFIG
    from tradingagents.dataflows.config import set_config
    from tradingagents.dataflows.vendors.yahoo.market import get_YFin_data_online
    from tradingagents.dataflows.vendors.yahoo.snapshot import build_verified_market_snapshot
    from tradingagents.dataflows.vendors.yahoo.news import get_news_yfinance
    config = {**DEFAULT_CONFIG, "data_cache_dir": str(work / "cache"), "results_dir": str(work / "results")}
    set_config(config)
    today = datetime.now().date()
    checks = [
        ("get_stock_data", lambda: get_YFin_data_online("VTI", (today - timedelta(days=30)).isoformat(), today.isoformat())),
        ("get_verified_market_snapshot", lambda: build_verified_market_snapshot("VTI", today.isoformat())),
        ("get_news", lambda: get_news_yfinance("VTI", (today - timedelta(days=7)).isoformat(), today.isoformat())),
    ]
    results = []
    for name, run in checks:
        try:
            text = run()
            (work / (name + ".txt")).write_text(str(text), encoding="utf-8")
            results.append({"tool": name, "status": "complete", "characters": len(str(text)), "preview": str(text)[:500]})
        except Exception as exc:
            cause = exc.__cause__
            results.append({"tool": name, "status": "error", "type": type(exc).__name__,
                            "causeType": type(cause).__name__ if cause else None,
                            "curlCode": getattr(cause, "code", None)})
    output = {"tls": trust, "paidAICalls": 0, "checks": results}
    (work / "probe.json").write_text(json.dumps(output, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(output, ensure_ascii=True))
    return 0 if all(row["status"] == "complete" for row in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
