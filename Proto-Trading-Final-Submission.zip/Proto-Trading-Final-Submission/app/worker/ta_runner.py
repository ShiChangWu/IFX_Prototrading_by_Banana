"""One isolated TradingAgents invocation. Called only by worker.main subprocess."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import sys
import traceback

APP = Path(__file__).resolve().parents[1]
VENDOR = APP / "vendor" / "TradingAgents"
SECTIONS = (
    ("market_report", "Market and technical research"),
    ("news_report", "News research"),
    ("fundamentals_report", "Company fundamentals"),
    ("investment_plan", "Research discussion conclusion"),
    ("trader_investment_plan", "TradingAgents proposal (not an order)"),
    ("final_trade_decision", "TradingAgents portfolio review"),
)


def configure_environment(work_dir):
    # Vendor modules may read these during import, before config is passed.
    mapping = {"TRADINGAGENTS_RESULTS_DIR": "results", "TRADINGAGENTS_CACHE_DIR": "cache",
               "TRADINGAGENTS_MEMORY_LOG_PATH": "memory/trading_memory.md"}
    for key, relative in mapping.items():
        os.environ[key] = str(work_dir / relative)
    os.environ["TRADINGAGENTS_CHECKPOINT_ENABLED"] = "false"


def run(request):
    if not os.getenv("DEEPSEEK_API_KEY", "").strip():
        raise RuntimeError("DEEPSEEK_API_KEY is not configured; research unavailable.")
    ticker = request["asset"]["ticker"]
    if not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,9}", ticker):
        raise ValueError("Invalid approved ticker.")
    work_dir = Path(request["workDir"]).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    configure_environment(work_dir)
    from .tls import configure_trusted_ca
    configure_trusted_ca(work_dir / "tls")
    if not (VENDOR / "tradingagents").is_dir():
        raise RuntimeError("TradingAgents repository is not installed.")
    sys.path.insert(0, str(VENDOR))
    import yfinance as yf
    (work_dir / "yfinance-cache").mkdir(parents=True, exist_ok=True)
    yf.set_tz_cache_location(str(work_dir / "yfinance-cache"))
    from tradingagents.default_config import DEFAULT_CONFIG
    from tradingagents.graph.trading_graph import TradingAgentsGraph
    from tradingagents.portfolio import PortfolioContext

    template = request["match"]["template"]
    research_prompt = str(template.get("researchPrompt", ""))[:8000]
    profile = request["profile"]
    constraints = {
        key: profile.get(key) for key in
        ("budget", "goal", "horizon", "review", "lossTolerance", "lossCapacity", "experience")
    }
    asset_class = str(request["asset"].get("assetClass", "")).lower()
    is_stock = asset_class in ("stock", "equity_stock")
    is_etf = asset_class == "etf" or asset_class.endswith("_etf")
    user_selected = request["match"].get("researchSelection", {}).get("source") == "user-selected"

    class MaintainedTemplateGraph(TradingAgentsGraph):
        def resolve_instrument_context(self, symbol, asset_type="stock", trade_date=None):
            context = super().resolve_instrument_context(symbol, asset_type, trade_date)
            context += "\nApplication research context: educational research for a beginner with USD cash and no positions. "
            context += "Do not place orders, promise a maximum loss, or interpret risk tolerance as a guarantee. "
            context += ("The user supplied the simulated allocation and selected research tickers, including possible 0% watch-only rows. "
                        "It is not a new AI-approved allocation or actual holdings. Your proposed sizing is research, not a modification to that allocation. "
                        if user_selected else
                        "The application sets allocation independently; your proposed sizing is research, not a modification to that allocation. ")
            context += "Consider evidence for 1–4 weeks, 1–3 months and 6–12 months separately; mark horizons without support as insufficient evidence.\n"
            context += "User constraints: " + json.dumps(constraints, ensure_ascii=False) + "\n"
            if is_etf:
                context += "This instrument is an ETF, not an operating company. Do not invent company earnings or treat its holdings as its own operating fundamentals.\n"
            elif not is_stock:
                context += "The instrument type is unverified. Do not call it an ETF or an operating company without source evidence; company fundamentals analysis is excluded until classification is verified.\n"
            if research_prompt:
                context += "Team-maintained strategy research lens (not a claim this rule has been backtested):\n" + research_prompt
            return context

    config = copy.deepcopy(DEFAULT_CONFIG)
    model = os.getenv("TRADINGAGENTS_MODEL") or os.getenv("DEEPSEEK_MODEL", "deepseek-flash")
    config.update({
        "llm_provider": "deepseek", "quick_think_provider": "deepseek", "deep_think_provider": "deepseek",
        "quick_think_llm": model, "deep_think_llm": model,
        "backend_url": os.getenv("DEEPSEEK_BASE_URL", "https://api.deepseek.com"),
        "quick_think_backend_url": None, "deep_think_backend_url": None,
        "results_dir": str(work_dir / "results"), "data_cache_dir": str(work_dir / "cache"),
        "memory_log_path": str(work_dir / "memory" / "trading_memory.md"),
        "checkpoint_enabled": False, "output_language": "English",
        "max_debate_rounds": min(2, max(1, int(os.getenv("TRADINGAGENTS_MAX_DEBATE_ROUNDS", "1")))),
        "max_risk_discuss_rounds": min(2, max(1, int(os.getenv("TRADINGAGENTS_MAX_RISK_ROUNDS", "1")))),
        "max_tool_rounds": 5, "max_recur_limit": 120, "llm_max_retries": 1, "max_tokens": 6000,
        "news_article_limit": 10, "global_news_article_limit": 5,
    })
    # Explicitly selected vendor chain, no implicit paid market-data API.
    config["data_vendors"].update({"core_stock_apis": "yfinance", "technical_indicators": "yfinance",
                                   "news_data": "yfinance", "fundamental_data": "sec_edgar,yfinance"})
    analysts = ["market", "news"] + (["fundamentals"] if is_stock else [])
    graph = MaintainedTemplateGraph(selected_analysts=analysts, debug=False, config=config)
    # Set the documented provider body on the actual LangChain clients. The graph
    # closures/bindings share these clients; no vendor monkey-patching is needed.
    for llm in (graph.quick_thinking_llm, graph.deep_thinking_llm):
        llm.extra_body = {**(llm.extra_body or {}), "thinking": {"type": "disabled"}}
    book = PortfolioContext(cash=float(profile["budget"]), currency="USD", positions=[])
    state, decision = graph.propagate(ticker, request["analysisDate"], asset_type="stock", portfolio=book)
    sections = [{"title": title, "text": str(state[key])[:50000]}
                for key, title in SECTIONS if state.get(key)]
    if not sections:
        raise RuntimeError("TradingAgents returned no research content.")
    # The pinned vendor supports this API. Raw reports stay in the private job directory.
    graph.save_reports(state, ticker, save_path=work_dir / "reports", html=True)
    from .quality import annotate_research_quality
    return annotate_research_quality({"ticker": ticker, "status": "complete", "decision": str(decision), "sections": sections,
            "analysts": analysts, "generatedAt": datetime.now(timezone.utc).isoformat(),
            "analysisDate": request["analysisDate"], "templateApplied": bool(research_prompt),
            "warnings": [] if is_stock else ["ETF research uses market and news analysts; operating-company fundamentals are intentionally excluded."
                                              if is_etf else "Instrument classification is unverified. Research uses market and news analysts; company fundamentals are excluded until the instrument type is verified."]})


def main():
    request_path, output_path = map(Path, sys.argv[1:3])
    request = json.loads(request_path.read_text(encoding="utf-8-sig"))
    try:
        result = run(request)
    except Exception as exc:
        # Do not serialize provider exceptions: they may contain request headers or keys.
        result = {"ticker": request.get("asset", {}).get("ticker", ""), "status": "error",
                  "decision": None, "sections": [],
                  "error": "TradingAgents research did not complete (" + type(exc).__name__ + "). No result was fabricated."}
        # Private diagnostics contain call sites only, never exception messages,
        # source lines, locals, request bodies, headers or provider responses.
        diagnostic = {"type": type(exc).__name__, "frames": [
            {"file": Path(frame.filename).name, "function": frame.name, "line": frame.lineno}
            for frame in traceback.extract_tb(exc.__traceback__)]}
        output_path.with_name("diagnostic.json").write_text(json.dumps(diagnostic), encoding="utf-8")
    output_path.write_text(json.dumps(result, ensure_ascii=False, allow_nan=False), encoding="utf-8")


if __name__ == "__main__":
    main()
