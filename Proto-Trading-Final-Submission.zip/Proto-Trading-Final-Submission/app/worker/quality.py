"""Keep engine completion separate from research evidence quality."""
from __future__ import annotations

import copy
from datetime import datetime, timezone
import re

FAILURE_MARKERS = re.compile(r"DATA_UNAVAILABLE|SSLError|vendor\s+(?:SSL|error)|no\s+verified\s+(?:price|OHLCV)|every\s+.*?tool\s+.*?failed", re.I)


def annotate_research_quality(research):
    result = copy.deepcopy(research)
    failures = []
    for section in research.get("sections", []):
        if FAILURE_MARKERS.search(str(section.get("text", ""))):
            failures.append(section.get("title", "Research"))
    quality = {"status": "limited" if failures else "not_independently_verified",
               "engineCompleted": research.get("status") == "complete",
               "affectedSections": failures,
               "message": "Some research sources were unavailable; see the affected sections for which inputs were missing."
               if failures else "The engine completed; source statements still require verification."}
    result["dataQuality"] = quality
    # Replace only our earlier generic classification text, never agent text or
    # an actual provider warning. This permits reviewing an existing report copy.
    obsolete = "The analysis process finished, but source text reports unavailable or failed market-data retrieval."
    warnings = [warning for warning in result.get("warnings", []) if warning != obsolete]
    if failures and quality["message"] not in warnings:
        warnings.append(quality["message"])
    result["warnings"] = warnings
    return result


def review_report_quality(report):
    result = copy.deepcopy(report)
    result["research"] = [annotate_research_quality(r) for r in report.get("research", [])]
    limited = [r["ticker"] for r in result["research"] if r["dataQuality"]["status"] == "limited"]
    result["qualityReviewedAt"] = datetime.now(timezone.utc).isoformat()
    if limited:
        result["status"] = "partial"
        warning = "Some research inputs were unavailable for: " + ", ".join(limited) + ". See affected sections for the exact sources; engine completion is not complete data coverage."
        warnings = result.setdefault("provenance", {}).setdefault("warnings", [])
        old_prefix = "Critical source retrieval was limited for: "
        warnings[:] = [item for item in warnings if not str(item).startswith(old_prefix)]
        if warning not in warnings:
            warnings.append(warning)
    return result
