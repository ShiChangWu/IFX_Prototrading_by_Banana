"""Read-only Yahoo minute bars for a local educational demonstration.

yfinance is independent of Yahoo. Public deployment requires appropriate
market-data rights; this adapter does not promise real-time execution prices.
https://help.yahoo.com/kb/account/SLN2310.html
https://ranaroussi.github.io/yfinance/reference/api/yfinance.Ticker.history.html
"""
import json
import math
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from collections.abc import Mapping
from contextlib import redirect_stdout
from datetime import datetime, timezone

from .security_identity import first_trading_date

SYMBOL = re.compile(r"^[A-Z][A-Z0-9.-]{0,9}$")
EXCHANGES = {"NMS", "NGM", "NCM", "NYQ", "PCX", "ASE", "BTS", "NASDAQ", "NYSE", "NYSEARCA", "NYSEAMERICAN", "BATS"}


def valid_request(payload):
    tickers = payload.get("tickers") if isinstance(payload, dict) else None
    if not isinstance(tickers, list) or len(tickers) > 50 or any(not isinstance(t, str) or not SYMBOL.fullmatch(t) for t in tickers) or len(set(tickers)) != len(tickers):
        raise ValueError("Provide up to 50 unique US ticker symbols.")
    return tickers


def _finite(value):
    return not isinstance(value, bool) and isinstance(value, (int, float)) and math.isfinite(value)


def instrument_metadata(ticker, meta):
    provider_symbol = ticker.replace(".", "-")
    if not isinstance(meta, Mapping) or meta.get("symbol") != provider_symbol or meta.get("currency") != "USD" or meta.get("exchangeName") not in EXCHANGES or meta.get("instrumentType") not in {"EQUITY", "ETF"} or meta.get("exchangeTimezoneName") != "America/New_York":
        raise ValueError("US-listed USD security identity could not be verified.")
    name = meta.get("longName") or meta.get("shortName") or ticker
    if not isinstance(name, str) or not name.strip() or len(name) > 300 or any(ord(c) < 32 or ord(c) == 127 for c in name):
        raise ValueError("Invalid security name.")
    if ticker == "SPCX" and not ("spacex" in name.lower().replace(" ", "") or "space exploration" in name.lower()):
        raise ValueError("SPCX must identify SpaceX, not an earlier ticker user.")
    period = meta.get("currentTradingPeriod", {}).get("regular", {})
    session = {key: period.get(key) for key in ("start", "end")}
    # New yfinance versions expose a Mapping and timezone-aware pandas
    # Timestamps here; older versions return epoch seconds.
    session = {key: value.timestamp() if isinstance(value, datetime) and value.tzinfo is not None else value for key, value in session.items()}
    if not all(_finite(value) and value > 0 for value in session.values()) or session["end"] <= session["start"]:
        session = None
    return {"ticker": ticker, "symbol": provider_symbol, "name": name.strip(), "currency": "USD", "exchange": meta["exchangeName"], "instrumentType": meta["instrumentType"], "timezone": "America/New_York", "verified": True, "session": session}


def latest_completed_bar(ticker, frame, now):
    first = first_trading_date(ticker)
    for timestamp, row in frame.sort_index(ascending=False).iterrows():
        if timestamp.tzinfo is None:
            raise ValueError("Minute bar timezone missing.")
        time = timestamp.to_pydatetime().astimezone(timezone.utc)
        if time.timestamp() + 60 > now:
            continue
        if first and time.date() < first:
            continue
        values = {key: float(row[column]) for key, column in (("o", "Open"), ("h", "High"), ("l", "Low"), ("c", "Close"), ("v", "Volume"))}
        if any(not math.isfinite(v) for v in values.values()) or any(values[key] <= 0 for key in ("o", "h", "l", "c")) or values["v"] <= 0 or values["l"] > min(values["o"], values["c"]) or values["h"] < max(values["o"], values["c"]):
            raise ValueError("The latest completed bar is invalid; no earlier price was substituted.")
        return {"t": time.isoformat(), **values}
    raise ValueError("No completed minute bar for this issuer.")


def fetch_one(ticker, *, factory=None, now=None):
    if factory is None:
        import yfinance as yf
        factory = yf.Ticker
    now = datetime.now(timezone.utc).timestamp() if now is None else now
    try:
        security = factory(ticker.replace(".", "-"))
        # Raw prices, regular-session only. Never join adjusted daily prices to
        # this minute stream or fill missing rows.
        frame = security.history(period="5d", interval="1m", prepost=False, auto_adjust=False, back_adjust=False, repair=False, actions=False, timeout=8)
        meta = security.get_history_metadata()
        instrument = instrument_metadata(ticker, meta)
        bar = latest_completed_bar(ticker, frame, now)
        return {"ticker": ticker, "status": "complete", "instrument": instrument, "bar": bar}
    except Exception as exc:
        # Provider exception details may contain request material. Never echo.
        return {"ticker": ticker, "status": "unavailable", "code": "YAHOO_DATA_UNAVAILABLE", "errorType": type(exc).__name__}


def main():
    try:
        raw = sys.stdin.buffer.read(65537)
        if len(raw) > 65536:
            raise ValueError("Request too large.")
        tickers = valid_request(json.loads(raw.decode("utf-8-sig")))
        with redirect_stdout(sys.stderr):
            if tickers:
                # Match the working daily adapter: libcurl on Windows needs
                # a readable CA path. Keep verification and OS trust intact.
                from .tls import configure_trusted_ca
                configure_trusted_ca()
                with ThreadPoolExecutor(max_workers=min(4, len(tickers))) as executor:
                    rows = list(executor.map(fetch_one, tickers))
            else:
                rows = []
        result = {"source": "Yahoo Finance", "fetchedAt": datetime.now(timezone.utc).isoformat(), "rows": rows}
    except Exception:
        result = {"source": "Yahoo Finance", "rows": [], "code": "YAHOO_INVALID_REQUEST"}
    print(json.dumps(result, ensure_ascii=True, allow_nan=False, separators=(",", ":")))


if __name__ == "__main__":
    main()
