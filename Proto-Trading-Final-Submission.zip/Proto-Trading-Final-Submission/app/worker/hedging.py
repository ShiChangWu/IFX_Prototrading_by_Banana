"""Opt-in historical inverse ETF comparison; never changes an allocation."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import math
from pathlib import Path

from .backtest import last_completed_us_date, rebalance

PRODUCTS = (
    {"ticker": "SH", "name": "ProShares Short S&P500", "dailyTargetMultiple": -1,
     "source": "https://www.proshares.com/our-etfs/leveraged-and-inverse/sh"},
    {"ticker": "SDS", "name": "ProShares UltraShort S&P500", "dailyTargetMultiple": -2,
     "source": "https://www.proshares.com/our-etfs/leveraged-and-inverse/sds"},
    {"ticker": "SPXU", "name": "ProShares UltraPro Short S&P500", "dailyTargetMultiple": -3,
     "source": "https://www.proshares.com/our-etfs/leveraged-and-inverse/spxu"},
)


def interval_metrics(values, baseline):
    peak, drawdown = baseline, 0.0
    for value in values:
        peak = max(peak, value)
        drawdown = min(drawdown, value / peak - 1)
    return {"returnPct": round((values[-1] / baseline - 1) * 100, 4),
            "maxDrawdownPct": round(drawdown * 100, 4)}


def buy_and_hold_scenario(prices, dates, weights, budget, cost_bps):
    instruments = {ticker: 0.0 for ticker in weights if ticker != "CASH"}
    targets, cash, fees = rebalance(instruments, budget, weights, cost_bps / 10000)
    units = {ticker: value / prices[ticker][dates[0]] for ticker, value in targets.items()}
    values = [cash + sum(units[t] * prices[t][day] for t in units) for day in dates]
    return {"weightsPct": {t: round(w * 100, 6) for t, w in weights.items()},
            "startingValue": budget, "endingValue": round(values[-1], 2),
            "initialTransactionCost": round(fees, 4), **interval_metrics(values, budget),
            "series": [{"date": day, "value": round(value, 4)} for day, value in zip(dates, values)]}


def compare_histories(prices, sessions=20, budget=10000.0, cost_bps=10.0):
    """Use actual fund paths, never multiply a cumulative benchmark return.

    Requires all 21 most recent valid SPY closes for every fund, preventing an
    apparently 20-session comparison from silently skipping missing sessions.
    """
    if not isinstance(sessions, int) or sessions < 2:
        raise ValueError("At least two completed return sessions are required.")
    if not math.isfinite(budget) or budget <= 0 or not 0 <= cost_bps <= 100:
        raise ValueError("Invalid scenario budget or trading cost.")
    for ticker in ("SPY", "SH", "SDS", "SPXU"):
        if ticker not in prices:
            raise ValueError("Required inverse ETF price history is missing.")
    dates = sorted(day for day, value in prices["SPY"].items()
                   if isinstance(value, (int, float)) and math.isfinite(value) and value > 0)[-(sessions + 1):]
    if len(dates) != sessions + 1:
        raise ValueError("Insufficient completed sessions.")
    for ticker in ("SPY", "SH", "SDS", "SPXU"):
        if any(day not in prices[ticker] or not math.isfinite(prices[ticker][day])
               or prices[ticker][day] <= 0 for day in dates):
            raise ValueError("Incomplete aligned history; missing sessions are not interpolated.")
    benchmark_values = [prices["SPY"][day] for day in dates]
    benchmark = {"ticker": "SPY", **interval_metrics(benchmark_values, benchmark_values[0])}
    products, scenarios = [], []
    for product in PRODUCTS:
        ticker = product["ticker"]
        values = [prices[ticker][day] for day in dates]
        products.append({**product, **interval_metrics(values, values[0])})
        inverse_weight = .05 / abs(product["dailyTargetMultiple"])
        weights = {"SPY": .9, ticker: inverse_weight, "CASH": .1 - inverse_weight}
        scenarios.append({"ticker": ticker,
            "label": f"Illustration only: 90% SPY + {100*inverse_weight:.4g}% {ticker} + cash",
            "approximateInitialInverseExposurePct": -5,
            "approximateInitialNetIndexExposurePct": 85,
            **buy_and_hold_scenario(prices, dates, weights, budget, cost_bps)})
    baseline = {"label": "100% SPY illustrative baseline",
                **buy_and_hold_scenario(prices, dates, {"SPY": 1.0}, budget, cost_bps)}
    cash_comparator = {"label": "90% SPY + 10% cash illustrative comparator",
                **buy_and_hold_scenario(prices, dates, {"SPY": .9, "CASH": .1}, budget, cost_bps)}
    return {"status": "complete", "allocated": False, "start": dates[0], "end": dates[-1],
            "sessions": sessions, "observations": len(dates), "benchmark": benchmark,
            "products": products, "scenarios": scenarios, "baseline": baseline, "cashComparator": cash_comparator,
            "methodology": f"Actual adjusted daily closing-price paths for SH, SDS and SPXU over the same {sessions} completed SPY return sessions. "
            f"Product return/drawdown excludes brokerage costs. Educational portfolio scenarios include {cost_bps:g} bps initial transaction cost on traded notional, "
            "zero cash interest, fractional units, no subsequent rebalancing and no final liquidation. "
            "All three scenarios use a 90% SPY core and approximately -5% initial index exposure from an inverse sleeve; their cash weights differ. "
            "These are hypothetical historical comparisons, not suggested allocations or suitability decisions.",
            "assumptions": {"costBps": cost_bps, "rebalance": "none", "cashInterestPct": 0,
                            "firstDayInverseExposurePct": -5, "coreSPYWeightPct": 90},
            "warnings": [
                "SH, SDS and SPXU target -1x, -2x and -3x DAILY S&P 500 performance before fund fees/expenses, respectively; targets are not guaranteed.",
                "SPY is an investable S&P 500 proxy, not the exact price index used in fund objectives. Distribution timing and tracking differences matter.",
                "Daily reset and compounding make multi-day results path-dependent. These calculations use each actual fund path, not the negative of SPY's cumulative return.",
                "Approximate exposure equivalence applies only at the initial weights; prices, daily resets, cash and no rebalancing cause exposure to drift.",
                "The 20-session holding period is for evaluating historical behavior, not a recommended holding period. It does not establish suitability for a beginner.",
                "The comparison concerns S&P 500 exposure only and does not establish a hedge for technology, small-cap, bond, gold or the user's full portfolio.",
                "Historical performance and drawdown do not predict future losses; no inverse product is added to the matched allocation.",
            ]}


def historical_hedge_assessment(interest, budget, cache_dir=None, now=None):
    if interest in (None, "none", ""):
        return {"status": "not_requested", "allocated": False, "products": [], "scenarios": [],
                "warnings": [], "message": "Inverse ETF research was not requested."}
    try:
        from .tls import configure_trusted_ca
        configure_trusted_ca()
        import yfinance as yf
        cache = Path(cache_dir or Path(__file__).resolve().parents[1] / "data" / "worker" / "hedge-cache")
        cache.mkdir(parents=True, exist_ok=True)
        yf.set_tz_cache_location(str(cache))
        cutoff = last_completed_us_date(now)
        fetched = datetime.now(timezone.utc).isoformat()
        histories, sources = {}, []
        for ticker in ("SPY", "SH", "SDS", "SPXU"):
            frame = yf.Ticker(ticker).history(start=(cutoff - timedelta(days=90)).isoformat(),
                end=(cutoff + timedelta(days=1)).isoformat(), auto_adjust=True,
                actions=False, raise_errors=True, timeout=25)
            if frame.empty or "Close" not in frame:
                raise ValueError("Adjusted history unavailable.")
            histories[ticker] = {idx.date().isoformat(): float(value) for idx, value in frame["Close"].items()
                                 if idx.date() <= cutoff and math.isfinite(float(value)) and value > 0}
            sources.append({"ticker": ticker, "source": "Yahoo Finance via yfinance",
                            "field": "auto_adjust=True Close", "fetchedAt": fetched})
        result = compare_histories(histories, sessions=20, budget=float(budget))
        result.update({"requestedInterest": interest, "fetchedAt": fetched,
                       "dataSources": sources,
                       "productSources": [{"ticker": p["ticker"], "url": p["source"]} for p in PRODUCTS]})
        return result
    except Exception as exc:
        return {"status": "unavailable", "allocated": False, "products": [], "scenarios": [],
                "warnings": [], "requestedInterest": interest,
                "error": "Actual inverse ETF comparison is unavailable (" + type(exc).__name__ + "). No fund histories or scenario returns were fabricated."}
