# Research worker

From the `app` directory, after the project environment and vendored TradingAgents dependencies have been installed:

```powershell
.\.venv\Scripts\python.exe -m worker.main --check
.\.venv\Scripts\python.exe -m worker.main
```

`--check` verifies nonsecret configuration without making paid calls. `--once` claims at most one waiting job and exits. `.env.local` supplies `APP_BASE_URL`, `WORKER_SECRET`, `DEEPSEEK_API_KEY`, `DEEPSEEK_MODEL` and optionally `TRADINGAGENTS_MODEL`. Do not put secrets in the frontend. Public URLs must use HTTPS; local development uses `http://127.0.0.1:8787`.

The worker sends heartbeat and job progress every 15 seconds. All communication is outbound. Only one job runs at a time. Each job and ticker has separate report, cache and memory directories under private `app/data/worker/`. The research subprocess has a time limit and stops if its lease is lost. No visitor reports are published automatically. The saved `report.json` is an actual result suitable for the application's explicit publication/export step.

TLS verification stays enabled. Before importing market-data libraries the worker combines certifi with the host's installed trusted CA roots in a private PEM, or respects an existing operator-configured CA bundle. `python -m worker.probe_market` checks the exact TradingAgents stock-data, verified-snapshot and news vendor paths with zero AI calls. A completed agent graph whose source text reports failed critical market retrieval is marked as a partial report through separate data-quality fields; engine completion is never treated as proof of data coverage.

TradingAgents is used through `TradingAgentsGraph.propagate`, an empty `PortfolioContext` with the user's USD budget, and `save_reports`. A small subclass adds the team-maintained template research lens to instrument context; the vendor repository is unchanged. At most three holdings are researched, largest target weights first. ETFs receive market/news analysis without operating-company fundamentals. The application allocation stays separate from agents' proposals.

Historical comparison uses actual Yahoo Finance adjusted daily closes obtained with yfinance. It rebalances the fixed target allocation monthly, charging 10 bps on initial and rebalance traded notional. Prices through the last completed US session are used. Cash earns zero, fractional units are assumed, the benchmark is buy-and-hold SPY over identical valid dates, and no final liquidation is assumed. This is not TradingAgents performance, nor a backtest of a trend or mean-reversion template. Missing history yields unavailable status; no synthetic fallback is used.

Outlooks contain only extraction from completed agent research. Each supported horizon requires an exact source excerpt that mentions a corresponding time period. Missing or unverifiable evidence stays unavailable. Inverse-product opt-in adds actual SH/SDS/SPXU adjusted-price comparisons over the latest 20 completed SPY return sessions. Educational scenarios use the same 90% SPY core with different inverse-fund and cash weights targeting approximately -5% initial inverse exposure; they do not rebalance afterward. These scenarios never alter the matched allocation or establish suitability. No inverse-data requests occur without opt-in.

Run isolated numerical and failure-mode checks without keys or external network calls:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -p "test_worker*.py" -v
```

The contract is portable to an AWS worker: preserve endpoints, authentication and report schema, replace the process host and private job storage.
