"""AKShare Sina US reference quotes, separate from adjusted indicator history.

Sina's direct-symbol daily endpoint avoids EastMoney's whole-market identity
lookup. It is deliberately requested unadjusted. Original prices are useful
reference evidence, but never silently reused as adjusted strategy inputs.
"""
from datetime import date
import math
import re
import threading
import time

SOURCE = 'Sina Finance via AKShare'
DOCUMENTATION = 'https://akshare.akfamily.xyz/data/stock/stock.html'
ADJUSTMENT_NOTE = ('AKShare supplied unadjusted reference prices. '
                   'Rules use a separate Yahoo Finance adjusted series; no provider series are mixed.')


def reference_from_frame(ticker, symbol, frame, cutoff):
    if not re.fullmatch(r'[A-Z][A-Z0-9.\-]{0,11}', ticker) or symbol != ticker:
        raise ValueError('AKShare reference requires the exact approved US ticker')
    required = ('date', 'open', 'high', 'low', 'close', 'volume')
    if not all(key in frame for key in required):
        raise ValueError('AKShare OHLCV columns missing')
    seen, rows = set(), []
    for record in frame.to_dict('records'):
        day = date.fromisoformat(str(record['date'])[:10])
        if day > cutoff:
            continue
        if day.weekday() > 4 or day in seen:
            raise ValueError('Ambiguous AKShare trading session')
        seen.add(day)
        values = [float(record[key]) for key in required[1:]]
        if any(not math.isfinite(value) for value in values) or min(values[:4]) <= 0 or values[4] < 0:
            raise ValueError('Invalid AKShare OHLCV')
        opening, high, low, closing, volume = values
        if low > min(opening, closing) or high < max(opening, closing) or high < low:
            raise ValueError('Inconsistent AKShare candle')
        rows.append((day, closing))
    if not rows:
        raise ValueError('AKShare returned no completed sessions')
    day, closing = max(rows)
    return {'ticker': ticker, 'status': 'reference_only', 'source': SOURCE,
            'providerSymbol': symbol, 'priceDate': day.isoformat(), 'latestClose': closing,
            'observations': len(rows), 'currency': None, 'currencyVerified': False,
            'currencySource': 'US-market endpoint; no per-instrument currency metadata returned',
            'identitySource': 'Exact approved ticker requested through AKShare stock_us_daily US-market endpoint',
            'adjustmentMethod': 'Unadjusted (adjust="")', 'adjustmentVerified': False,
            'eligibleForSignals': False, 'fallbackReason': ADJUSTMENT_NOTE,
            'sourceUrl': DOCUMENTATION}


class ReferenceProbe:
    """Bounded waiting; slow optional requests never delay the main process exit.

    Daemon threads do no file writes, and do not
    execute commands or call models. The owning Node process still applies its
    25-second hard process deadline. Only public ticker/date requests go out.
    """
    def __init__(self, tickers, start, cutoff, budget_seconds=6, ak_module=None):
        self.tickers, self.start, self.cutoff = list(tickers), start, cutoff
        self.deadline = time.monotonic() + budget_seconds
        self.module = ak_module
        self.rows, self.lock, self.event = {}, threading.Lock(), threading.Event()
        threading.Thread(target=self._run, daemon=True).start()

    def _record(self, ticker, row):
        with self.lock:
            self.rows[ticker] = row
            if len(self.rows) == len(self.tickers):
                self.event.set()

    def _failure(self, ticker, code):
        return {'ticker': ticker, 'status': 'unavailable', 'source': SOURCE,
                'adjustmentVerified': False, 'eligibleForSignals': False, 'errorCode': code,
                'fallbackReason': f'AKShare reference data unavailable ({code}); using Yahoo Finance adjusted history when available.'}

    def _run(self):
        try:
            if self.module is None:
                import akshare
                self.module = akshare
        except ModuleNotFoundError:
            for ticker in self.tickers:
                self._record(ticker, self._failure(ticker, 'not_installed'))
            return
        except Exception:
            for ticker in self.tickers:
                self._record(ticker, self._failure(ticker, 'provider_initialization_failed'))
            return
        for ticker in self.tickers:
            threading.Thread(target=self._one, args=(ticker, ticker), daemon=True).start()

    def _one(self, ticker, symbol):
        try:
            frame = self.module.stock_us_daily(symbol=symbol, adjust='')
            if 'date' in frame:
                frame = frame.loc[frame['date'].astype(str).str.slice(0, 10) >= self.start.isoformat()]
            row = reference_from_frame(ticker, symbol, frame, self.cutoff)
        except Exception:
            row = self._failure(ticker, 'history_unavailable')
        self._record(ticker, row)

    def collect(self):
        self.event.wait(max(0, self.deadline - time.monotonic()))
        with self.lock:
            return {ticker: dict(self.rows.get(ticker) or self._failure(ticker, 'request_deadline'))
                    for ticker in self.tickers}
