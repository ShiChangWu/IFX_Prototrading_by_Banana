"""Lightweight market snapshots, with no LLM or TradingAgents calls.

Run from app/: python -m worker.quick_market
Input on stdin: {"tickers":["VTI","IEF"],"analysisDate":"YYYY-MM-DD"}
One JSON object is written to stdout. The caller enforces its ticker allowlist
and process deadline. This module validates syntax and never executes input.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from contextlib import redirect_stdout
from datetime import date, datetime, timedelta, timezone
import json
import math
from pathlib import Path
import re
import statistics
import sys

from .backtest import last_completed_us_date
from .market_indicators import daily_indicators, rsi_pair
from .security_identity import first_trading_date

MAX_TICKERS = 5
SOURCE = "Yahoo Finance via yfinance"


class SnapshotError(ValueError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def iso_date(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if not isinstance(value, str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        raise SnapshotError("invalid_date", "Dates must use YYYY-MM-DD.")
    try:
        return date.fromisoformat(value)
    except ValueError:
        raise SnapshotError("invalid_date", "A supplied calendar date is invalid.") from None


def validate_request(payload):
    if not isinstance(payload, dict):
        raise SnapshotError("invalid_request", "Expected a JSON object.")
    values = payload.get("tickers")
    if not isinstance(values, list) or not 1 <= len(values) <= MAX_TICKERS:
        raise SnapshotError("invalid_tickers", "Provide one to five approved stock or ETF tickers.")
    tickers = []
    for value in values:
        if not isinstance(value, str):
            raise SnapshotError("invalid_ticker", "Ticker must be a string.")
        ticker = value.strip().upper()
        if not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,11}", ticker) or ticker == "CASH":
            raise SnapshotError("invalid_ticker", "Ticker syntax is invalid or is not a priced security.")
        if ticker not in tickers:
            tickers.append(ticker)
    requested = payload.get("analysisDate")
    if requested is not None:
        requested = iso_date(requested)
    return tickers, requested


def snapshot_from_history(ticker, history, cutoff, fetched_at, currency=None, *,
                          source=SOURCE, currency_source=None, fallback_reason=None,
                          preferred_source=None):
    """Calculate exact rolling measures on completed, non-filled daily closes.

    history is an iterable of (session_date, adjusted_close). There must be at
    least 101 observations to calculate both current and prior 100-day SMA.
    Future/uncompleted rows are excluded BEFORE inspecting their prices.
    """
    cutoff = iso_date(cutoff)
    issuer_start = first_trading_date(ticker)
    if issuer_start and cutoff < issuer_start:
        raise SnapshotError('issuer_not_yet_listed',
            f'{ticker} means SpaceX Class A here. Its public trading starts on {issuer_start.isoformat()}, after this snapshot cutoff.')
    dated = {}
    bars_by_date = {}
    for item in history:
        if isinstance(item, dict):
            day, raw = item.get('date'), item.get('close')
        else:
            day, raw = item
        session = iso_date(day)
        if session > cutoff:
            continue
        if issuer_start and session < issuer_start:
            # A provider can return an earlier security that used the same
            # symbol. Discard those rows before price validation or indicators.
            continue
        if session.weekday() > 4:
            raise SnapshotError("invalid_history", "A daily price was labelled with a non-trading weekend date.")
        if session in dated:
            raise SnapshotError("duplicate_session", "Duplicate daily price rows make the history ambiguous.")
        try:
            price = float(raw)
        except (TypeError, ValueError):
            raise SnapshotError("invalid_history", "An adjusted daily close is missing or invalid.") from None
        if isinstance(raw, bool) or not math.isfinite(price) or price <= 0:
            raise SnapshotError("invalid_history", "An adjusted daily close is missing or invalid.")
        dated[session] = price
        if isinstance(item, dict):
            bar = {'date': session.isoformat(), 'close': price}
            for key in ('open', 'high', 'low', 'volume'):
                value = item.get(key)
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0 or (key != 'volume' and value == 0):
                    raise SnapshotError('invalid_ohlcv', 'Daily open, high, low and volume must be present and valid; missing values are not filled.')
                bar[key] = float(value)
            if bar['low'] > min(bar['open'], bar['close']) or bar['high'] < max(bar['open'], bar['close']) or bar['low'] > bar['high']:
                raise SnapshotError('invalid_ohlcv', 'Daily candle prices are inconsistent.')
            bars_by_date[session] = bar
    days = sorted(dated)
    if len(days) < 101:
        if issuer_start:
            raise SnapshotError('insufficient_history',
                f'Only {len(days)} completed daily closes belong to {ticker} SpaceX since {issuer_start.isoformat()}. '
                'This snapshot needs at least 101 for current and prior SMA100. Earlier prices from an unrelated ticker user were excluded; no indicators were calculated.')
        raise SnapshotError("insufficient_history", "At least 101 completed daily closes are required for current and prior SMA100.")
    closes = [dated[day] for day in days]
    currency = currency.strip().upper() if isinstance(currency, str) and currency.strip() else None
    if currency and currency != "USD":
        raise SnapshotError("currency_mismatch", "The provider did not identify this security's prices as USD.")
    sma20 = statistics.fmean(closes[-20:])
    deviation = statistics.pstdev(closes[-20:])
    warnings = []
    if currency is None:
        warnings.append("Provider currency metadata was unavailable; USD currency is not independently confirmed by this snapshot.")
    if bars_by_date and len(bars_by_date) != len(dated):
        raise SnapshotError('incomplete_ohlcv', 'A partial OHLCV history cannot be combined with close-only rows.')
    if fallback_reason:
        warnings.append(fallback_reason)
    rsi, previous_rsi = rsi_pair(closes)
    extra = daily_indicators([bars_by_date[day] for day in days]) if bars_by_date else {}
    result = {
        "ticker": ticker, "status": "complete", "priceDate": days[-1].isoformat(),
        "previousPriceDate": days[-2].isoformat(), "cutoffDate": cutoff.isoformat(),
        "latestClose": round(closes[-1], 8), "previousClose": round(closes[-2], 8),
        "sma20": round(sma20, 8), "sma100": round(statistics.fmean(closes[-100:]), 8),
        "previousSma20": round(statistics.fmean(closes[-21:-1]), 8),
        "previousSma100": round(statistics.fmean(closes[-101:-1]), 8),
        "bollingerUpper": round(sma20 + 2 * deviation, 8),
        "bollingerLower": round(sma20 - 2 * deviation, 8),
        "observations": len(closes), "currency": currency, "currencyVerified": currency == "USD",
        "currencySource": (currency_source or "Yahoo Finance chart metadata") if currency else None,
        "adjusted": True, "priceBasis": "Completed daily adjusted close, not an executable live quote",
        "adjustmentMethod": "Yahoo Finance auto_adjust OHLC (split/dividend-adjusted)",
        "timestampPrecision": "session_date", "priceTimestamp": None,
        "ageCalendarDays": (cutoff - days[-1]).days, "source": source,
        "fetchedAt": fetched_at, "warnings": warnings,
        "rsi14": rsi, "previousRsi14": previous_rsi,
        "ohlcvAvailable": bool(bars_by_date), **extra,
    }
    if fallback_reason:
        result['fallbackReason'] = fallback_reason
    if preferred_source:
        result['preferredSource'] = preferred_source
    if issuer_start:
        result['firstTradingDate'] = issuer_start.isoformat()
        result['historyIdentityNote'] = 'Only SpaceX-era prices on or after its first public trading date are used.'
    return result


def _make_history_fetcher():
    # Establish readable trusted CA paths before importing curl/yfinance.
    from .tls import configure_trusted_ca
    configure_trusted_ca()
    import yfinance as yf
    cache = Path(__file__).resolve().parents[1] / "data" / "quick-market-cache"
    cache.mkdir(parents=True, exist_ok=True)
    yf.set_tz_cache_location(str(cache))

    def fetch(ticker, start, end_exclusive):
        instrument = yf.Ticker(ticker)
        frame = instrument.history(start=start.isoformat(), end=end_exclusive.isoformat(),
                                   interval="1d", auto_adjust=True, actions=False,
                                   raise_errors=True, timeout=10)
        if frame.empty or "Close" not in frame:
            raise SnapshotError("data_unavailable", "The provider returned no usable adjusted daily history.")
        # history_metadata normally reads the same cached chart response. Do
        # not query quote/info endpoints or infer USD from a symbol's spelling.
        try:
            metadata = instrument.history_metadata or {}
            currency = metadata.get("currency")
        except Exception:
            currency = None
        required = ('Open', 'High', 'Low', 'Close', 'Volume')
        if not all(column in frame for column in required):
            raise SnapshotError('missing_ohlcv', 'The provider did not return complete daily OHLCV fields.')
        rows = [dict(date=index.date(), **{column.lower(): float(row[column]) for column in required})
                for index, row in frame.iterrows()]
        return {"history": rows, "currency": currency}

    return fetch


def _error_snapshot(ticker, code, message):
    return {"ticker": ticker, "status": "error", "error": {"code": code, "message": message},
            "source": SOURCE, "fetchedAt": datetime.now(timezone.utc).isoformat()}


def create_snapshots(payload, now=None, history_fetcher=None):
    tickers, requested = validate_request(payload)
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise SnapshotError("invalid_time", "The current time must include a timezone.")
    completed_cutoff = last_completed_us_date(now)
    cutoff = min(requested, completed_cutoff) if requested else completed_cutoff
    # A historical weekend request also uses the last preceding weekday;
    # actual holiday gaps are reflected in priceDate and ageCalendarDays.
    while cutoff.weekday() > 4:
        cutoff -= timedelta(days=1)
    warnings = []
    if requested and requested > completed_cutoff:
        warnings.append("Requested date is later than the completed-session cutoff; only completed US sessions were used.")
    result = {
        "status": "unavailable", "mode": "market_snapshot",
        "requestedAnalysisDate": requested.isoformat() if requested else None,
        "cutoffDate": cutoff.isoformat(), "fetchedAt": now.isoformat(), "snapshots": [], "warnings": warnings,
        "indicatorParameters": {"smaWindows": [20, 100], "bollingerWindow": 20,
                                "bollingerStdDev": 2, "standardDeviation": "population",
                                "basis": "single-provider adjusted daily OHLC; reported volume", "calendarLookbackDays": 400,
                                "rsiWindow": 14, "atrWindow": 14, "smoothing": "Wilder", "supportResistanceWindow": 20,
                                "supportResistanceExcludesCurrent": True, "maxReturnedBars": 120},
    }
    reference_probe = None
    if history_fetcher is None:
        try:
            history_fetcher = _make_history_fetcher()
            from .akshare_reference import ReferenceProbe
            reference_probe = ReferenceProbe(tickers, cutoff - timedelta(days=400), cutoff)
        except Exception as exc:
            result["snapshots"] = [_error_snapshot(t, "provider_initialization_failed",
                "Market-data provider could not be initialized (" + type(exc).__name__ + ").") for t in tickers]
            return result

    def one(ticker):
        try:
            issuer_start = first_trading_date(ticker)
            if issuer_start and cutoff < issuer_start:
                raise SnapshotError('issuer_not_yet_listed',
                    f'{ticker} means SpaceX Class A here. Its public trading starts on {issuer_start.isoformat()}, after this snapshot cutoff.')
            start = max(cutoff - timedelta(days=400), issuer_start) if issuer_start else cutoff - timedelta(days=400)
            response = history_fetcher(ticker, start, cutoff + timedelta(days=1))
            fetched = datetime.now(timezone.utc).isoformat()
            return snapshot_from_history(ticker, response["history"], cutoff, fetched, response.get("currency"),
                source=response.get('source', SOURCE), currency_source=response.get('currencySource'),
                fallback_reason=response.get('fallbackReason'), preferred_source=response.get('preferredSource'))
        except SnapshotError as exc:
            return _error_snapshot(ticker, exc.code, str(exc))
        except Exception as exc:
            # Provider exception text may contain request details. Only its
            # class is surfaced; never print headers, environment or secrets.
            return _error_snapshot(ticker, "data_unavailable",
                                   "Adjusted market history is unavailable (" + type(exc).__name__ + ").")

    # Three parallel requests keep the five-ticker path within a small caller
    # deadline when the provider is responsive. The backend also kills the
    # entire process after 25 seconds, bounding slow provider behavior.
    with ThreadPoolExecutor(max_workers=min(3, len(tickers))) as executor:
        result["snapshots"] = list(executor.map(one, tickers))
    if reference_probe is not None:
        references = reference_probe.collect()
        result['dataSources'] = {'reference': 'Sina Finance via AKShare', 'indicators': SOURCE,
            'policy': 'AKShare unadjusted reference history is kept separate; unverified adjustment never drives indicators.'}
        for row in result['snapshots']:
            reference = references[row['ticker']]
            row['preferredSource'] = 'Sina Finance via AKShare'
            row['providerReference'] = reference
            row['fallbackReason'] = reference['fallbackReason']
            row.setdefault('warnings', []).append(reference['fallbackReason'])
    completed = sum(row["status"] == "complete" for row in result["snapshots"])
    result["status"] = "complete" if completed == len(tickers) else "partial" if completed else "unavailable"
    result["fetchedAt"] = datetime.now(timezone.utc).isoformat()
    return result


def main():
    try:
        stream = getattr(sys.stdin, "buffer", sys.stdin)
        raw = stream.read(65537)
        if len(raw) > 65536:
            raise SnapshotError("request_too_large", "Market snapshot request exceeds its size limit.")
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8-sig")
        payload = json.loads(raw)
        # Keep provider/library diagnostic prints off the JSON output channel.
        with redirect_stdout(sys.stderr):
            result = create_snapshots(payload)
    except (json.JSONDecodeError, UnicodeError):
        result = {"status": "unavailable", "mode": "market_snapshot", "snapshots": [],
                  "error": {"code": "invalid_json", "message": "Input must be UTF-8 JSON."}, "warnings": []}
    except SnapshotError as exc:
        result = {"status": "unavailable", "mode": "market_snapshot", "snapshots": [],
                  "error": {"code": exc.code, "message": str(exc)}, "warnings": []}
    except Exception as exc:
        result = {"status": "unavailable", "mode": "market_snapshot", "snapshots": [],
                  "error": {"code": "snapshot_failed", "message": "Snapshot process could not complete (" + type(exc).__name__ + ")."}, "warnings": []}
    print(json.dumps(result, ensure_ascii=True, allow_nan=False, separators=(',', ':')))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
