"""Single-recipient Gmail SMTP adapter; credentials arrive on stdin only.

No mailbox read access, no attachments, no debug logs. SMTP acceptance does not
prove inbox delivery. A lost acknowledgement is explicitly uncertain.
https://support.google.com/accounts/answer/185833
"""
import json
import re
import smtplib
import ssl
import sys
from email.message import EmailMessage
from email.utils import formatdate


def valid_address(value):
    if not isinstance(value, str) or len(value) > 254:
        return False
    pattern = r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+"
    if not re.fullmatch(pattern, value):
        return False
    local = value.split('@')[0]
    return len(local) <= 64 and not local.startswith('.') and not local.endswith('.') and '..' not in local


def send_email(payload, smtp_factory=smtplib.SMTP_SSL):
    if not isinstance(payload, dict):
        return {"status": "failed", "code": "INVALID_EMAIL"}
    user, password = payload.get('user'), payload.get('password')
    if not valid_address(user) or not isinstance(password, str) or not re.fullmatch(r'[A-Za-z0-9]{16}', password):
        return {"status": "unavailable", "code": "GMAIL_NOT_CONFIGURED"}
    recipient, subject, text, message_id = (payload.get(key) for key in ('to', 'subject', 'text', 'messageId'))
    if (not valid_address(recipient) or not isinstance(subject, str) or not subject.strip()
            or len(subject) > 180 or re.search(r'[\x00-\x1f\x7f]', subject)
            or not isinstance(text, str) or not text.strip() or '\x00' in text or len(text.encode('utf-8')) > 48000
            or not isinstance(message_id, str) or not re.fullmatch(r'<proto\.[0-9a-f]{64}@proto-trading\.local>', message_id)):
        return {"status": "failed", "code": "INVALID_EMAIL"}
    message = EmailMessage()
    message['From'] = user
    message['To'] = recipient
    message['Subject'] = subject
    message['Message-ID'] = message_id
    message['Date'] = formatdate(localtime=False, usegmt=True)
    message.set_content(text)
    client, attempted = None, False
    try:
        client = smtp_factory('smtp.gmail.com', 465, timeout=12, context=ssl.create_default_context())
        client.login(user, password)
        attempted = True
        refused = client.send_message(message, from_addr=user, to_addrs=[recipient])
        if refused:
            return {"status": "failed", "code": "SMTP_REJECTED"}
        return {"status": "accepted", "code": "SMTP_ACCEPTED"}
    except smtplib.SMTPAuthenticationError:
        return {"status": "failed", "code": "SMTP_AUTH_FAILED"}
    except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused, smtplib.SMTPDataError):
        return {"status": "failed", "code": "SMTP_REJECTED"}
    except Exception:
        # Never serialize exception strings: providers can include addresses,
        # credentials or content. Do not retry a potentially accepted message.
        return {"status": "uncertain", "code": "SMTP_OUTCOME_UNKNOWN"} if attempted else {"status": "failed", "code": "SMTP_CONNECT_FAILED"}
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass


def main():
    try:
        raw = sys.stdin.buffer.read(65537)
        result = send_email(json.loads(raw.decode('utf-8'))) if len(raw) <= 65536 else {"status": "failed", "code": "INVALID_EMAIL"}
    except Exception:
        result = {"status": "failed", "code": "INVALID_EMAIL"}
    sys.stdout.write(json.dumps(result))


if __name__ == '__main__':
    main()
