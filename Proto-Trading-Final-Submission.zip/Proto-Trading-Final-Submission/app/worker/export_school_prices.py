"""Maintain the shareable dated school-test dataset; public tickers only, no models."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime, timedelta, timezone
import json
from pathlib import Path
from .quick_market import _make_history_fetcher
from .backtest import last_completed_us_date
from .security_identity import first_trading_date


def main():
    fetch = _make_history_fetcher()
    cutoff = last_completed_us_date()
    # Public maintained assets in shared/strategy.mjs, plus the existing SPY example.
    # Keep this explicit: private user watchlists must never enter the distributable data.
    tickers = ['VTI', 'SCHD', 'QQQ', 'SGOV', 'IEF', 'GLD', 'MSFT', 'AAPL',
               'NVDA', 'AMD', 'AMZN', 'GOOGL', 'META', 'AVGO', 'SPCX', 'SPY']
    start = date(2023, 5, 1)
    def one(ticker):
        first = first_trading_date(ticker)
        requested_start = max(start, first) if first else start
        response = fetch(ticker, requested_start, cutoff + timedelta(days=1))
        if response.get('currency') != 'USD':
            raise ValueError('Currency not independently confirmed for '+ticker)
        rows=[]
        for bar in response['history']:
            day=str(bar['date'])[:10]
            if requested_start.isoformat() <= day <= cutoff.isoformat():
                rows.append([day]+[round(float(bar[key]),8) for key in ['open','high','low','close','volume']])
        if len(rows)<20: raise ValueError('Insufficient history for '+ticker)
        return ticker, {'ticker':ticker,'currency':'USD','currencyVerified':True,'adjusted':True,'source':'Yahoo Finance via yfinance','sourceUrl':'https://finance.yahoo.com/quote/'+ticker+'/history/','firstTradingDate':first.isoformat() if first else None,'columns':['date','open','high','low','close','volume'],'bars':rows}
    with ThreadPoolExecutor(max_workers=3) as executor:
        stocks=dict(executor.map(one,tickers))
    dataset={'version':'2026-10-04.2','fetchedAt':datetime.now(timezone.utc).isoformat(),'cutoffDate':cutoff.isoformat(),'basis':'Dated saved history; split/dividend-adjusted daily OHLC and reported volume. Not a live feed.','stocks':stocks}
    target=Path(__file__).resolve().parents[1]/'shared'/'school-prices.mjs'
    target.write_text('// Actual dated price observations. Refresh with python -m worker.export_school_prices.\nexport const SCHOOL_PRICES = '+json.dumps(dataset,separators=(',',':'),allow_nan=False)+';\n',encoding='utf-8')
    print(json.dumps({'cutoffDate':dataset['cutoffDate'],'rows':{ticker:len(data['bars']) for ticker,data in stocks.items()},'bytes':target.stat().st_size}))

if __name__=='__main__':
    main()
