"""Auditable, fixed-allocation historical comparison; this is NOT TA performance."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
import math
from pathlib import Path
import re
import statistics
from .security_identity import IssuerHistoryError, require_issuer_window, require_issuer_price_dates

CASH = "CASH"


def allocation_weights(match):
    """Validate the submitted allocation before any history provider is called."""
    allocations = match.get("allocations")
    if not isinstance(allocations, list) or not 1 <= len(allocations) <= 9:
        raise ValueError("An allocation must contain at most eight instruments plus cash.")
    weights = {}
    for asset in allocations:
        if not isinstance(asset, dict):
            raise ValueError("Invalid allocation row.")
        ticker, weight = asset.get("ticker"), asset.get("weight")
        if not isinstance(ticker, str) or not re.fullmatch(r"[A-Z][A-Z0-9.\-]{0,9}", ticker) or ticker in weights:
            raise ValueError("Allocation tickers must be valid and unique.")
        if isinstance(weight, bool) or not isinstance(weight, (int, float)) or not math.isfinite(weight) or not 0 <= weight <= 100:
            raise ValueError("Allocation weights must be finite numbers from zero to 100.")
        weights[ticker] = weight / 100
    if abs(sum(weights.values()) - 1) > 1e-6:
        raise ValueError("Allocation weights must sum to 100 percent.")
    return weights


def rebalance(values, cash, weights, cost_rate):
    """Solve after-cost NAV so purchases, sales and cash reconcile exactly."""
    before = sum(values.values()) + cash
    low, high = 0.0, before
    for _ in range(70):
        after = (low + high) / 2
        turnover = sum(abs(after * weights.get(ticker, 0) - value)
                       for ticker, value in values.items())
        if after + cost_rate * turnover > before:
            high = after
        else:
            low = after
    after = (low + high) / 2
    targets = {ticker: after * weights.get(ticker, 0) for ticker in values}
    fees = cost_rate * sum(abs(targets[t] - values[t]) for t in values)
    remaining_cash = before - sum(targets.values()) - fees
    return targets, remaining_cash, fees


def calculate_metrics(values, budget, dates):
    peak, worst = budget, 0.0
    returns, previous = [], budget
    for value in values:
        peak = max(peak, value)
        worst = min(worst, value / peak - 1)
        returns.append(value / previous - 1)
        previous = value
    years = (date.fromisoformat(dates[-1]) - date.fromisoformat(dates[0])).days / 365.25
    annual = (values[-1] / budget) ** (1 / years) - 1 if years > 0 else None
    return {
        "startingValue": round(budget, 2), "endingValue": round(values[-1], 2),
        "totalReturnPct": round((values[-1] / budget - 1) * 100, 4),
        "cagrPct": round(annual * 100, 4) if annual is not None else None,
        "annualizedVolatilityPct": round(statistics.stdev(returns) * math.sqrt(252) * 100, 4)
        if len(returns) > 1 else 0.0,
        "maxDrawdownPct": round(worst * 100, 4),
        "observations": len(values),
    }


def simulate_fixed_allocation(prices, weights, budget=10000.0, cost_bps=10.0):
    """prices: {ticker: {ISO-date: adjusted-close}}; requires SPY benchmark.

    Initial purchase and monthly rebalance occur at the first available closing
    price of the month. The schedule and weights are fixed in advance. Price
    movement is applied to OLD holdings before a rebalance, preventing a day's
    return from being earned with newly selected holdings. No indicators or AI
    forecasts are used to pick a historical entry.
    """
    if not 0 <= cost_bps <= 100:
        raise ValueError("Trading cost must be between zero and 100 basis points.")
    if not math.isfinite(budget) or budget <= 0:
        raise ValueError("Budget must be positive.")
    weights = {t: float(w) for t, w in weights.items()}
    if not weights or any(not math.isfinite(w) or w < 0 for w in weights.values()):
        raise ValueError("Weights must be finite and nonnegative.")
    if abs(sum(weights.values()) - 1) > 1e-6:
        raise ValueError("Weights must sum to one.")
    tickers = [t for t, w in weights.items() if t != CASH and w > 0]
    required = set(tickers) | {"SPY"}
    if any(t not in prices or not prices[t] for t in required):
        raise ValueError("A required adjusted-price history is missing.")
    for ticker in required:
        require_issuer_price_dates(ticker, prices[ticker])
    valid_dates = None
    for ticker in required:
        valid = {d for d, p in prices[ticker].items()
                 if isinstance(p, (int, float)) and math.isfinite(p) and p > 0}
        valid_dates = valid if valid_dates is None else valid_dates & valid
    dates = sorted(valid_dates or [])
    if len(dates) < 2:
        raise ValueError("At least two common adjusted-price observations are required.")
    rate = cost_bps / 10000
    values, cash = {t: 0.0 for t in tickers}, float(budget)
    equity, series, fees_total, trades, previous_date = [], [], 0.0, 0, None
    spy_units = budget / (1 + rate) / prices["SPY"][dates[0]]
    spy_values = []
    for day in dates:
        if previous_date:
            values = {t: v * prices[t][day] / prices[t][previous_date] for t, v in values.items()}
        if previous_date is None or day[:7] != previous_date[:7]:
            old_values = values.copy()
            values, cash, fees = rebalance(values, cash, weights, rate)
            fees_total += fees
            trades += sum(abs(values[t] - old_values[t]) > 1e-8 for t in values)
        nav = sum(values.values()) + cash
        benchmark = spy_units * prices["SPY"][day]
        equity.append(nav)
        spy_values.append(benchmark)
        series.append({"date": day, "value": round(nav, 4), "benchmark": round(benchmark, 4)})
        previous_date = day
    metrics = calculate_metrics(equity, budget, dates)
    metrics.update({"transactionCosts": round(fees_total, 4), "trades": trades})
    return {
        "status": "complete", "start": dates[0], "end": dates[-1],
        "methodology": "Fixed target allocations; monthly rebalancing at the first common trading close. "
        "Initial purchase and each purchase/sale charge the stated cost on traded notional. "
        "Uses adjusted closing prices, fractional shares and zero cash interest. "
        "Current TradingAgents opinions are never used in historical decisions. "
        "This is a fixed-allocation historical comparison, not a backtest of AI predictions or an unimplemented trend rule.",
        "metrics": metrics, "series": series,
        "benchmark": {"ticker": "SPY", "methodology": "Buy and hold SPY over the identical common dates; initial purchase cost included; no final liquidation.",
                      "metrics": calculate_metrics(spy_values, budget, dates)},
        "assumptions": {"costBpsPerTradedNotional": cost_bps, "cashInterestPct": 0,
                        "fractionalShares": True, "rebalance": "monthly", "weights": weights},
        "warnings": [
            "Historical performance does not predict future results or bound maximum loss.",
            "Today's selected instruments and fixed weights create selection/survivorship bias; this is not a point-in-time strategy-selection study.",
            "Adjusted prices approximate distributions and corporate actions. Taxes, bid/ask changes, liquidity limits and tracking error are not individually modelled.",
            "Only dates with valid prices for every holding and SPY are used; missing dates are not forward-filled.",
        ] + (["The selected allocation is entirely cash. Its line keeps principal unchanged with zero interest and no trades; SPY is a separate historical benchmark."] if not tickers else []),
    }


def last_completed_us_date(now=None):
    now = now or datetime.now(timezone.utc)
    try:
        from zoneinfo import ZoneInfo
        local = now.astimezone(ZoneInfo("America/New_York"))
        cutoff = local.date() if (local.hour, local.minute) >= (16, 15) else local.date() - timedelta(days=1)
    except Exception:
        cutoff = now.date() - timedelta(days=1)  # conservative when timezone DB is absent
    while cutoff.weekday() > 4:
        cutoff -= timedelta(days=1)
    return cutoff


def historical_backtest(match, years=3, cost_bps=10, now=None, cache_dir=None):
    """Fetch actual histories lazily; no synthetic fallback or silent substitutions."""
    try:
        cutoff = last_completed_us_date(now)
        start = cutoff - timedelta(days=round(365.25 * years))
        weights = allocation_weights(match)
        budget = match["profile"]["budget"]
        if isinstance(budget, bool) or not isinstance(budget, (int, float)) or not math.isfinite(budget) or budget <= 0:
            raise ValueError("Budget must be a positive finite number.")
        if not isinstance(cost_bps, (int, float)) or not math.isfinite(cost_bps) or not 0 <= cost_bps <= 100:
            raise ValueError("Trading cost must be between zero and 100 basis points.")
        tickers = sorted({t for t, w in weights.items() if t != CASH and w > 0} | {"SPY"})
        # Reject unavailable issuer history before fetching any data. A newer
        # IPO must not inherit the prior security's history or shorten the test.
        require_issuer_window(tickers, start)
        from .tls import configure_trusted_ca
        configure_trusted_ca()
        import yfinance as yf
        cache_dir = Path(cache_dir or Path(__file__).resolve().parents[1] / "data" / "worker" / "market-cache")
        cache_dir.mkdir(parents=True, exist_ok=True)
        yf.set_tz_cache_location(str(cache_dir))
        prices, source = {}, []
        fetched = datetime.now(timezone.utc).isoformat()
        for ticker in tickers:
            history = yf.Ticker(ticker).history(start=start.isoformat(),
                end=(cutoff + timedelta(days=1)).isoformat(), auto_adjust=True,
                actions=False, raise_errors=True, timeout=25)
            if history.empty or "Close" not in history:
                raise ValueError("Missing adjusted historical prices.")
            require_issuer_price_dates(ticker, (idx.date() for idx in history.index))
            daily = {idx.date().isoformat(): float(value) for idx, value in history["Close"].items()
                     if start <= idx.date() <= cutoff and math.isfinite(float(value)) and float(value) > 0}
            if len(daily) < 30:
                raise ValueError("Insufficient adjusted historical prices.")
            prices[ticker] = daily
            source.append({"ticker": ticker, "source": "Yahoo Finance via yfinance",
                           "field": "auto_adjust=True Close", "start": min(daily),
                           "end": max(daily), "fetchedAt": fetched})
        result = simulate_fixed_allocation(prices, weights, float(budget), cost_bps)
        result["dataSources"] = source
        result["fetchedAt"] = fetched
        return result
    except IssuerHistoryError as exc:
        return {"status": "unavailable", "errorCode": "issuer_history_unavailable",
                "warnings": ["No ticker history was substituted and the requested window was not silently shortened."],
                "error": str(exc)}
    except Exception as exc:
        return {"status": "unavailable", "warnings": [],
                "error": "Historical data calculation is unavailable (" + type(exc).__name__ + "). No prices or performance were invented."}
