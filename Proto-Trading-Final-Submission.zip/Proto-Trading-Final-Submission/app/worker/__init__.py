"""Outbound research worker. Financial calculations never depend on LLM output."""
