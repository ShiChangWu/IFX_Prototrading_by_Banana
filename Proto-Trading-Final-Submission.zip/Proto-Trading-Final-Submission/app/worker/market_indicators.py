"""Deterministic daily indicators; no prices, signals or missing bars are invented."""
import statistics


def compact(value):
    if isinstance(value, float):
        return round(value, 8)
    if isinstance(value, dict):
        return {key: compact(item) for key, item in value.items()}
    if isinstance(value, list):
        return [compact(item) for item in value]
    return value


def wilder(values, period=14):
    if len(values) < period:
        return []
    current = statistics.fmean(values[:period])
    result = [current]
    for value in values[period:]:
        current = (current * (period - 1) + value) / period
        result.append(current)
    return result


def rsi_pair(closes):
    changes = [current - previous for previous, current in zip(closes, closes[1:])]
    gains = wilder([max(value, 0) for value in changes])
    losses = wilder([max(-value, 0) for value in changes])
    values = [50.0 if gain == loss == 0 else 100.0 if loss == 0 else
              100 - 100 / (1 + gain / loss) for gain, loss in zip(gains, losses)]
    return (values[-1], values[-2]) if len(values) > 1 else (None, None)


def daily_indicators(bars):
    """All bars are already validated, ascending, complete and on one price basis."""
    latest = bars[-1]
    true_ranges = [max(current['high'] - current['low'],
                       abs(current['high'] - previous['close']),
                       abs(current['low'] - previous['close']))
                   for previous, current in zip(bars, bars[1:])]
    atr = wilder(true_ranges)
    candle_range = latest['high'] - latest['low']
    return compact({
        'atr14': atr[-1], 'previousAtr14': atr[-2],
        'latestOpen': latest['open'], 'latestHigh': latest['high'],
        'latestLow': latest['low'], 'latestVolume': latest['volume'],
        'prior20High': max(row['high'] for row in bars[-21:-1]),
        'prior20Low': min(row['low'] for row in bars[-21:-1]),
        'previousPrior20High': max(row['high'] for row in bars[-22:-2]),
        'previousPrior20Low': min(row['low'] for row in bars[-22:-2]),
        'prior20VolumeMedian': statistics.median(row['volume'] for row in bars[-21:-1]),
        'candle': {
            'body': abs(latest['close'] - latest['open']), 'range': candle_range,
            'upperWick': latest['high'] - max(latest['open'], latest['close']),
            'lowerWick': min(latest['open'], latest['close']) - latest['low'],
            'closePosition': (latest['close'] - latest['low']) / candle_range if candle_range else None,
        },
        'bars': bars[-120:],
    })
