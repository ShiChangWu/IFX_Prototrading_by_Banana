"""Issuer boundaries for reused tickers; never infer identity from a symbol alone.

SPCX is SpaceX Class A in this application, with first public trading on
2026-06-12. Earlier SPCX prices belong to an unrelated security and must not
enter SpaceX indicators or performance. Keep this boundary aligned with the
public ASSETS registry in shared/strategy.mjs.
Source: SpaceX investor relations IPO closing announcement, 2026-06-15.
"""
from datetime import date, datetime


ISSUER_START_DATES = {"SPCX": date(2026, 6, 12)}
ISSUER_NAMES = {"SPCX": "SpaceX Class A"}


class IssuerHistoryError(ValueError):
    """The requested period includes dates before this issuer used the ticker."""


def first_trading_date(ticker):
    return ISSUER_START_DATES.get(str(ticker).upper())


def as_date(value):
    if isinstance(value, datetime):
        return value.date()
    return value if isinstance(value, date) else date.fromisoformat(value)


def require_issuer_window(tickers, start):
    start = as_date(start)
    for ticker in tickers:
        first = first_trading_date(ticker)
        if first and start < first:
            name = ISSUER_NAMES[str(ticker).upper()]
            raise IssuerHistoryError(
                f"{ticker} means {name} here and began public trading on {first.isoformat()}. "
                f"The requested window starts on {start.isoformat()}, before that listing. "
                "Earlier prices for the reused ticker are not this issuer's history; "
                "the requested backtest is unavailable and its window was not shortened."
            )


def require_issuer_price_dates(ticker, dates):
    first = first_trading_date(ticker)
    if first:
        for value in dates:
            if as_date(value) < first:
                raise IssuerHistoryError(
                    f"{ticker} price history contains a date before {first.isoformat()}, "
                    "the first public trading date of SpaceX Class A. "
                    "Prices from the unrelated earlier ticker user cannot be backtested as SpaceX."
                )
