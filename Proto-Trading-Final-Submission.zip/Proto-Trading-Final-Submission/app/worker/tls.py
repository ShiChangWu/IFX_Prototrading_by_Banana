"""Use installed OS trust roots with certifi; never disable TLS verification."""
from __future__ import annotations

import os
import hashlib
from pathlib import Path
import ssl
import tempfile
import uuid


def _ascii_cache_directory():
    project = str(Path(__file__).resolve().parents[1])
    suffix = hashlib.sha256(project.encode("utf-8")).hexdigest()[:12]
    target = Path(tempfile.gettempdir()) / ("proto-trading-ca-" + suffix)
    target.mkdir(parents=True, exist_ok=True)
    if os.name == "nt" and not str(target).isascii():
        # Some Windows libcurl builds cannot open Unicode CAINFO paths. A
        # short path is acceptable only when it actually resolves to ASCII.
        import ctypes
        buffer = ctypes.create_unicode_buffer(32768)
        length = ctypes.windll.kernel32.GetShortPathNameW(str(target), buffer, len(buffer))
        if not length or not buffer.value.isascii():
            raise RuntimeError("Windows TLS needs a readable ASCII temporary CA directory.")
        target = Path(buffer.value)
    return target


def _write_bundle(content):
    target = _ascii_cache_directory()
    bundle = target / "trusted-ca.pem"
    temporary = target / ("trusted-ca-" + uuid.uuid4().hex + ".tmp")
    temporary.write_text(content, encoding="ascii")
    os.replace(temporary, bundle)
    return bundle


def configure_trusted_ca(directory=None):
    # Honour explicit deployment/operator trust configuration unchanged.
    keys = ("SSL_CERT_FILE", "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE")
    existing = next((os.environ[k] for k in keys if os.getenv(k)), None)
    if existing:
        if not Path(existing).is_file():
            raise ValueError("Configured CA bundle does not exist.")
        original = existing
        if os.name == "nt" and not str(existing).isascii():
            # Copy exactly the operator's trust material; only its filesystem
            # location changes, never which certificates are trusted.
            existing = str(_write_bundle(Path(existing).read_text(encoding="ascii")))
        for key in keys:
            if key not in os.environ or os.environ[key] == original:
                os.environ[key] = existing
        return {"source": "operator-configured", "verification": True, "asciiPath": str(existing).isascii()}
    certificates = []
    try:
        import certifi
        certificates.append(Path(certifi.where()).read_text(encoding="ascii"))
    except ImportError:
        pass
    # create_default_context loads the host's trusted roots, including Windows
    # trust stores; only public certificates are exported, never private keys.
    context = ssl.create_default_context()
    certificates.extend(ssl.DER_cert_to_PEM_cert(certificate)
                        for certificate in context.get_ca_certs(binary_form=True))
    if not certificates:
        raise RuntimeError("No trusted CA roots are available.")
    # ``directory`` remains accepted for callers; CA files intentionally use
    # the ASCII system temp directory rather than a Unicode project path.
    bundle = _write_bundle("\n".join(certificates))
    for key in keys:
        os.environ[key] = str(bundle)
    return {"source": "certifi-and-os-trusted-roots", "verification": True, "asciiPath": str(bundle).isascii()}
