$ErrorActionPreference = 'Stop'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'MANIFEST.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach ($entry in $manifest.files) {
  $file = Join-Path $PSScriptRoot $entry.path
  if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw ('Missing: ' + $entry.path) }
  if ((Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) { throw ('Changed: ' + $entry.path) }
}
Write-Host ('Verified ' + $manifest.files.Count + ' packaged files.')
